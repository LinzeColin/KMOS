#!/usr/bin/env python3
"""Generate and self-validate the rotary-kiln general-arrangement DXF.

The DXF uses millimetres in modelspace and an A1 landscape paperspace viewport
at 1:100.  Run from any directory:

    python gen_dxf.py
    python gen_dxf.py --output kiln_GA.dxf --preview preview.png
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from typing import Iterable, Sequence

import ezdxf
from ezdxf import units
from ezdxf.addons.drawing.matplotlib import qsave
from ezdxf.enums import TextEntityAlignment


# =============================================================================
# AUTHORITATIVE TECHNICAL SPECIFICATION (all linear values are millimetres)
# =============================================================================

KILN_INNER_DIAMETER = 4000.0
KILN_LENGTH = 60000.0
KILN_SLOPE = 0.035
SHELL_WALL = 25.0
SHELL_WALL_AT_TYRE = 40.0

TYRE_POSITIONS = (12000.0, 33000.0, 51000.0)
TYRE_OUTER_DIAMETER = 4900.0
TYRE_WIDTH = 1000.0
TYRE_TOTAL_RADIAL = 450.0

GEAR_POSITION = 22000.0
GEAR_OUTER_DIAMETER = 4600.0
GEAR_WIDTH = 700.0
GEAR_TEETH_APPROX = 200

ROLLERS_PER_STATION = 2
ROLLER_CENTER_DISTANCE = 3200.0
ROLLER_DIAMETER = 1400.0
ROLLER_LENGTH = 1000.0

# Approved mapping: height x axial length x transverse width.
FOUNDATION_HEIGHT = 3000.0
FOUNDATION_AXIAL = 5000.0
FOUNDATION_TRANSVERSE = 6000.0

HEAD_HOOD_AXIAL = 6000.0
HEAD_HOOD_WIDTH = 7500.0
HEAD_HOOD_HEIGHT = 7500.0

BURNER_LENGTH = 10000.0
BURNER_DIAMETER = 900.0
BURNER_INSERTION = 8000.0

TAIL_CHAMBER_AXIAL = 7000.0
TAIL_CHAMBER_WIDTH = 7000.0
TAIL_CHAMBER_HEIGHT = 8000.0

CAPACITY_T_PER_DAY = 3000.0
PEAK_BURNING_TEMPERATURE_C = 1450.0


# =============================================================================
# EXPLICIT ASSUMPTIONS / DRAWING PRESENTATION CONSTANTS
# =============================================================================

# The specification gives no enclosure fabrication or absolute elevation.
HEAD_HOOD_MIN_X = -2000.0
HEAD_HOOD_MAX_X = HEAD_HOOD_MIN_X + HEAD_HOOD_AXIAL
TAIL_CHAMBER_MIN_X = KILN_LENGTH
TAIL_CHAMBER_MAX_X = TAIL_CHAMBER_MIN_X + TAIL_CHAMBER_AXIAL

# Refractory thickness is not specified.  Section A-A marks the inner-surface
# material interface but does not invent a lining thickness.
REFRACTORY_GEOMETRY_THICKNESS = 0.0

DRAWING_NUMBER = "KILN-GA-001"
DRAWING_DATE = "2026-07-14"
DRAWING_SCALE = "1:100"
PAPER_WIDTH = 841.0
PAPER_HEIGHT = 594.0
MODEL_VIEW_SCALE = 100.0

SLOPE_ANGLE = math.atan(KILN_SLOPE)
COS_SLOPE = math.cos(SLOPE_ANGLE)
SIN_SLOPE = math.sin(SLOPE_ANGLE)
AXIS_BASE_Y = 20000.0
TYRE_RADIUS = TYRE_OUTER_DIAMETER / 2.0
ROLLER_RADIUS = ROLLER_DIAMETER / 2.0
ROLLER_HALF_SPACING = ROLLER_CENTER_DISTANCE / 2.0
ROLLER_VERTICAL_OFFSET = math.sqrt(
    (TYRE_RADIUS + ROLLER_RADIUS) ** 2 - ROLLER_HALF_SPACING**2
)
FOUNDATION_CENTER_RADIAL = -(
    ROLLER_VERTICAL_OFFSET + ROLLER_RADIUS + FOUNDATION_HEIGHT / 2.0
)
SECTION_CENTER = (73500.0, 20500.0)


# Layers requested by the drawing specification.
LAYER_OUTLINE = "GA_OUTLINE"
LAYER_CENTER = "GA_CENTER"
LAYER_DIM = "GA_DIMENSIONS"
LAYER_TEXT = "GA_TEXT"
LAYER_HATCH = "GA_HATCH"
LAYER_BORDER = "GA_BORDER_TITLE"
LAYER_VIEWPORT = "GA_VIEWPORT"
REQUIRED_LAYERS = (
    LAYER_OUTLINE,
    LAYER_CENTER,
    LAYER_DIM,
    LAYER_TEXT,
    LAYER_HATCH,
    LAYER_BORDER,
    LAYER_VIEWPORT,
)
DIMSTYLE_NAME = "KILN_DIM_100"
TEXT_STYLE_NAME = "KILN_TEXT"
SPEC_APPID = "KILN_SPEC"


def parse_args() -> argparse.Namespace:
    """Resolve outputs beside this script unless explicit paths are supplied."""

    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=script_dir / "kiln_GA.dxf")
    parser.add_argument("--preview", type=Path, default=script_dir / "preview.png")
    return parser.parse_args()


def local_point(axial: float, radial: float = 0.0) -> tuple[float, float]:
    """Transform sloped kiln-local elevation coordinates to modelspace."""

    return (
        axial * COS_SLOPE - radial * SIN_SLOPE,
        AXIS_BASE_Y + axial * SIN_SLOPE + radial * COS_SLOPE,
    )


def circle_points(
    center: tuple[float, float], radius: float, count: int = 128
) -> list[tuple[float, float]]:
    """Return deterministic polygon points for hatch boundaries."""

    cx, cy = center
    return [
        (cx + radius * math.cos(2.0 * math.pi * index / count),
         cy + radius * math.sin(2.0 * math.pi * index / count))
        for index in range(count)
    ]


def add_layers_and_styles(doc: ezdxf.document.Drawing) -> None:
    """Create color-, linetype-, and lineweight-controlled CAD layers."""

    if "CENTER2" not in doc.linetypes:
        doc.linetypes.new(
            "CENTER2",
            dxfattribs={
                "description": "Center ____ _ ____ _ ____",
                "pattern": [1.25, 0.75, -0.125, 0.125, -0.125],
            },
        )

    layer_specs = {
        LAYER_OUTLINE: {"color": 7, "linetype": "CONTINUOUS", "lineweight": 50},
        LAYER_CENTER: {"color": 3, "linetype": "CENTER2", "lineweight": 25},
        LAYER_DIM: {"color": 2, "linetype": "CONTINUOUS", "lineweight": 25},
        LAYER_TEXT: {"color": 4, "linetype": "CONTINUOUS", "lineweight": 25},
        LAYER_HATCH: {"color": 8, "linetype": "CONTINUOUS", "lineweight": 18},
        LAYER_BORDER: {"color": 1, "linetype": "CONTINUOUS", "lineweight": 50},
        LAYER_VIEWPORT: {"color": 9, "linetype": "CONTINUOUS", "lineweight": 18},
    }
    for name, attributes in layer_specs.items():
        if name in doc.layers:
            layer = doc.layers.get(name)
            layer.update_dxf_attribs(attributes)
        else:
            layer = doc.layers.new(name, dxfattribs=attributes)
        if name == LAYER_VIEWPORT:
            layer.dxf.plot = 0

    if TEXT_STYLE_NAME not in doc.styles:
        doc.styles.new(TEXT_STYLE_NAME, dxfattribs={"font": "Arial.ttf"})

    if DIMSTYLE_NAME not in doc.dimstyles:
        doc.dimstyles.new(
            DIMSTYLE_NAME,
            dxfattribs={
                "dimtxt": 250.0,
                "dimasz": 250.0,
                "dimexo": 100.0,
                "dimexe": 150.0,
                "dimgap": 100.0,
                "dimdec": 0,
                "dimtad": 1,
                "dimclrd": 2,
                "dimclre": 2,
                "dimclrt": 2,
                "dimtxsty": TEXT_STYLE_NAME,
                "dimscale": 1.0,
            },
        )
    if SPEC_APPID not in doc.appids:
        doc.appids.new(SPEC_APPID)


def add_model_text(
    msp: ezdxf.layouts.Modelspace,
    text: str,
    insert: tuple[float, float],
    *,
    height: float = 300.0,
    rotation: float = 0.0,
    align: TextEntityAlignment = TextEntityAlignment.LEFT,
) -> None:
    """Add modelspace text with the controlled text style and layer."""

    entity = msp.add_text(
        text,
        height=height,
        dxfattribs={
            "layer": LAYER_TEXT,
            "style": TEXT_STYLE_NAME,
            "rotation": rotation,
        },
    )
    entity.set_placement(insert, align=align)


def draw_local_rectangle(
    msp: ezdxf.layouts.Modelspace,
    x_min: float,
    x_max: float,
    radial_min: float,
    radial_max: float,
    *,
    layer: str = LAYER_OUTLINE,
) -> None:
    """Draw a closed rectangle aligned to the sloped kiln coordinate system."""

    points = [
        local_point(x_min, radial_min),
        local_point(x_max, radial_min),
        local_point(x_max, radial_max),
        local_point(x_min, radial_max),
    ]
    msp.add_lwpolyline(points, close=True, dxfattribs={"layer": layer})


def tag_dimension(entity, label: str, expected: float) -> None:
    """Attach traceable expected values to real DIMENSION entities."""

    entity.set_xdata(SPEC_APPID, [(1000, label), (1040, float(expected))])


def add_aligned_spec_dimension(
    msp: ezdxf.layouts.Modelspace,
    label: str,
    p1: tuple[float, float],
    p2: tuple[float, float],
    distance: float,
    expected: float,
    *,
    text: str = "<>",
) -> None:
    """Add, render, and tag an aligned specification dimension."""

    override = msp.add_aligned_dim(
        p1=p1,
        p2=p2,
        distance=distance,
        text=text,
        dimstyle=DIMSTYLE_NAME,
        dxfattribs={"layer": LAYER_DIM},
    )
    tag_dimension(override.dimension, label, expected)
    override.render()


def add_linear_spec_dimension(
    msp: ezdxf.layouts.Modelspace,
    label: str,
    p1: tuple[float, float],
    p2: tuple[float, float],
    base: tuple[float, float],
    expected: float,
    *,
    angle: float = 0.0,
    text: str = "<>",
) -> None:
    """Add, render, and tag a linear specification dimension."""

    override = msp.add_linear_dim(
        base=base,
        p1=p1,
        p2=p2,
        text=text,
        angle=angle,
        dimstyle=DIMSTYLE_NAME,
        dxfattribs={"layer": LAYER_DIM},
    )
    tag_dimension(override.dimension, label, expected)
    override.render()


def add_diameter_spec_dimension(
    msp: ezdxf.layouts.Modelspace,
    label: str,
    p1: tuple[float, float],
    p2: tuple[float, float],
    expected: float,
    *,
    text: str,
) -> None:
    """Add, render, and tag a true diameter DIMENSION entity."""

    override = msp.add_diameter_dim_2p(
        p1=p1,
        p2=p2,
        text=text,
        dimstyle=DIMSTYLE_NAME,
        dxfattribs={"layer": LAYER_DIM},
    )
    tag_dimension(override.dimension, label, expected)
    override.render()


def draw_longitudinal_elevation(msp: ezdxf.layouts.Modelspace) -> None:
    """Draw the sloped 60 m elevation and all specified principal equipment."""

    shell_outer = KILN_INNER_DIAMETER / 2.0 + SHELL_WALL
    msp.add_line(
        local_point(HEAD_HOOD_MIN_X - 1500.0),
        local_point(TAIL_CHAMBER_MAX_X + 1200.0),
        dxfattribs={"layer": LAYER_CENTER},
    )
    msp.add_line(
        local_point(0.0, shell_outer),
        local_point(KILN_LENGTH, shell_outer),
        dxfattribs={"layer": LAYER_OUTLINE},
    )
    msp.add_line(
        local_point(0.0, -shell_outer),
        local_point(KILN_LENGTH, -shell_outer),
        dxfattribs={"layer": LAYER_OUTLINE},
    )
    msp.add_line(local_point(0.0, -shell_outer), local_point(0.0, shell_outer), dxfattribs={"layer": LAYER_OUTLINE})
    msp.add_line(local_point(KILN_LENGTH, -shell_outer), local_point(KILN_LENGTH, shell_outer), dxfattribs={"layer": LAYER_OUTLINE})

    # Exact tyre-zone shell thickening is largely hidden by the tyre. Short
    # shoulder marks preserve it in the GA without adding overlapping solids.
    thick_outer = KILN_INNER_DIAMETER / 2.0 + SHELL_WALL_AT_TYRE
    for position in TYRE_POSITIONS:
        draw_local_rectangle(
            msp,
            position - TYRE_WIDTH / 2.0,
            position + TYRE_WIDTH / 2.0,
            -TYRE_RADIUS,
            TYRE_RADIUS,
        )
        for edge in (position - TYRE_WIDTH / 2.0, position + TYRE_WIDTH / 2.0):
            msp.add_line(local_point(edge, shell_outer), local_point(edge, thick_outer), dxfattribs={"layer": LAYER_OUTLINE})
            msp.add_line(local_point(edge, -shell_outer), local_point(edge, -thick_outer), dxfattribs={"layer": LAYER_OUTLINE})

    draw_local_rectangle(
        msp,
        GEAR_POSITION - GEAR_WIDTH / 2.0,
        GEAR_POSITION + GEAR_WIDTH / 2.0,
        -GEAR_OUTER_DIAMETER / 2.0,
        GEAR_OUTER_DIAMETER / 2.0,
    )

    # Two rollers per station coincide in longitudinal projection; each station
    # is therefore drawn once and explicitly labelled "2X". Section A-A shows
    # the actual transverse pair and 3200 mm centre distance.
    for position in TYRE_POSITIONS:
        draw_local_rectangle(
            msp,
            position - ROLLER_LENGTH / 2.0,
            position + ROLLER_LENGTH / 2.0,
            -ROLLER_VERTICAL_OFFSET - ROLLER_RADIUS,
            -ROLLER_VERTICAL_OFFSET + ROLLER_RADIUS,
        )
        draw_local_rectangle(
            msp,
            position - FOUNDATION_AXIAL / 2.0,
            position + FOUNDATION_AXIAL / 2.0,
            FOUNDATION_CENTER_RADIAL - FOUNDATION_HEIGHT / 2.0,
            FOUNDATION_CENTER_RADIAL + FOUNDATION_HEIGHT / 2.0,
        )

    draw_local_rectangle(
        msp,
        HEAD_HOOD_MIN_X,
        HEAD_HOOD_MAX_X,
        -HEAD_HOOD_HEIGHT / 2.0,
        HEAD_HOOD_HEIGHT / 2.0,
    )
    draw_local_rectangle(
        msp,
        TAIL_CHAMBER_MIN_X,
        TAIL_CHAMBER_MAX_X,
        -TAIL_CHAMBER_HEIGHT / 2.0,
        TAIL_CHAMBER_HEIGHT / 2.0,
    )

    burner_external = BURNER_LENGTH - BURNER_INSERTION
    burner_start = -burner_external
    burner_end = BURNER_INSERTION
    draw_local_rectangle(
        msp,
        burner_start,
        burner_end,
        -BURNER_DIAMETER / 2.0,
        BURNER_DIAMETER / 2.0,
    )

    # Section cut indication at tyre station 1.
    section_x = TYRE_POSITIONS[0]
    msp.add_line(
        local_point(section_x, -3600.0),
        local_point(section_x, 3600.0),
        dxfattribs={"layer": LAYER_CENTER},
    )
    add_model_text(msp, "A", local_point(section_x, 4000.0), align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "A", local_point(section_x, -4000.0), align=TextEntityAlignment.MIDDLE_CENTER)

    # Labels use only specification values or explicit approximation notation.
    add_model_text(msp, "KILN HEAD / LOW END", local_point(500.0, 4800.0), align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "HEAD HOOD 6000 x 7500 x 7500", local_point(1000.0, 4250.0), height=240.0, align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "BURNER DIA 900 / L=10000 / INSERTION APPROX. 8000", local_point(4600.0, -900.0), height=230.0, align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "TYRE DIA 4900 / W=1000", local_point(33000.0, 3300.0), height=260.0, align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "GIRTH GEAR DIA 4600 / W=700 / TEETH APPROX. 200", local_point(GEAR_POSITION, 3200.0), height=240.0, align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "2X ROLLER EACH STATION: DIA 1400 x 1000 / C-C 3200", local_point(33500.0, -3700.0), height=230.0, align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "FOUNDATION EACH: H3000 x A5000 x W6000", local_point(33500.0, -6600.0), height=230.0, align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "TAIL SMOKE CHAMBER 7000 x 7000 x 8000", local_point(63500.0, 4700.0), height=240.0, align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "KILN TAIL / HIGH END", local_point(61000.0, 5400.0), align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(
        msp,
        "SLOPE 3.5%  HEAD LOW -> TAIL HIGH",
        local_point(43000.0, 2850.0),
        height=300.0,
        rotation=math.degrees(SLOPE_ANGLE),
        align=TextEntityAlignment.MIDDLE_CENTER,
    )

    # True DIMENSION entities: overall, chain positions, gear and burner.
    add_aligned_spec_dimension(
        msp,
        "kiln_total_length",
        local_point(0.0),
        local_point(KILN_LENGTH),
        6100.0,
        KILN_LENGTH,
        text="<> TOTAL",
    )
    chain_points = (0.0, *TYRE_POSITIONS, KILN_LENGTH)
    chain_labels = (
        "head_to_tyre_1",
        "tyre_1_to_tyre_2",
        "tyre_2_to_tyre_3",
        "tyre_3_to_tail",
    )
    for label, start, end in zip(chain_labels, chain_points, chain_points[1:]):
        add_aligned_spec_dimension(
            msp,
            label,
            local_point(start),
            local_point(end),
            -7300.0,
            end - start,
        )
    add_aligned_spec_dimension(
        msp,
        "head_to_girth_gear",
        local_point(0.0),
        local_point(GEAR_POSITION),
        -8800.0,
        GEAR_POSITION,
        text="<> TO GEAR C/L",
    )
    add_aligned_spec_dimension(
        msp,
        "burner_total_length",
        local_point(burner_start),
        local_point(burner_end),
        -10400.0,
        BURNER_LENGTH,
        text="<> BURNER",
    )


def add_annulus_hatch(
    msp: ezdxf.layouts.Modelspace,
    center: tuple[float, float],
    outer_radius: float,
    inner_radius: float,
    *,
    scale: float,
) -> None:
    """Add an ANSI31 hatch between deterministic polygonal circles."""

    hatch = msp.add_hatch(
        color=8,
        dxfattribs={"layer": LAYER_HATCH},
    )
    hatch.set_pattern_fill("ANSI31", scale=scale, angle=45.0)
    hatch.paths.add_polyline_path(circle_points(center, outer_radius), is_closed=True)
    hatch.paths.add_polyline_path(list(reversed(circle_points(center, inner_radius))), is_closed=True)


def draw_section_a_a(msp: ezdxf.layouts.Modelspace) -> None:
    """Draw a tyre-station section with shell, lining interface, and roller pair."""

    cx, cy = SECTION_CENTER
    tyre_inner_radius = KILN_INNER_DIAMETER / 2.0 + SHELL_WALL_AT_TYRE
    shell_inner_radius = KILN_INNER_DIAMETER / 2.0
    roller_y = cy - ROLLER_VERTICAL_OFFSET
    foundation_center_y = cy + FOUNDATION_CENTER_RADIAL

    add_model_text(msp, "SECTION A-A @ TYRE 1", (cx, cy + 4300.0), height=360.0, align=TextEntityAlignment.MIDDLE_CENTER)
    msp.add_line((cx - 3900.0, cy), (cx + 3900.0, cy), dxfattribs={"layer": LAYER_CENTER})
    msp.add_line((cx, cy - 7200.0), (cx, cy + 3500.0), dxfattribs={"layer": LAYER_CENTER})

    msp.add_circle((cx, cy), TYRE_RADIUS, dxfattribs={"layer": LAYER_OUTLINE})
    msp.add_circle((cx, cy), tyre_inner_radius, dxfattribs={"layer": LAYER_OUTLINE})
    msp.add_circle((cx, cy), shell_inner_radius, dxfattribs={"layer": LAYER_OUTLINE})
    add_annulus_hatch(msp, (cx, cy), TYRE_RADIUS, tyre_inner_radius, scale=220.0)
    add_annulus_hatch(msp, (cx, cy), tyre_inner_radius, shell_inner_radius, scale=90.0)

    for transverse in (-ROLLER_HALF_SPACING, ROLLER_HALF_SPACING):
        msp.add_circle((cx + transverse, roller_y), ROLLER_RADIUS, dxfattribs={"layer": LAYER_OUTLINE})
        msp.add_line(
            (cx + transverse - 900.0, roller_y),
            (cx + transverse + 900.0, roller_y),
            dxfattribs={"layer": LAYER_CENTER},
        )
        msp.add_line(
            (cx + transverse, roller_y - 900.0),
            (cx + transverse, roller_y + 900.0),
            dxfattribs={"layer": LAYER_CENTER},
        )

    foundation_points = [
        (cx - FOUNDATION_TRANSVERSE / 2.0, foundation_center_y - FOUNDATION_HEIGHT / 2.0),
        (cx + FOUNDATION_TRANSVERSE / 2.0, foundation_center_y - FOUNDATION_HEIGHT / 2.0),
        (cx + FOUNDATION_TRANSVERSE / 2.0, foundation_center_y + FOUNDATION_HEIGHT / 2.0),
        (cx - FOUNDATION_TRANSVERSE / 2.0, foundation_center_y + FOUNDATION_HEIGHT / 2.0),
    ]
    msp.add_lwpolyline(foundation_points, close=True, dxfattribs={"layer": LAYER_OUTLINE})

    add_diameter_spec_dimension(
        msp,
        "kiln_inner_diameter",
        (cx - shell_inner_radius, cy),
        (cx + shell_inner_radius, cy),
        KILN_INNER_DIAMETER,
        text="DIA <>",
    )
    add_diameter_spec_dimension(
        msp,
        "tyre_outer_diameter",
        (cx, cy - TYRE_RADIUS),
        (cx, cy + TYRE_RADIUS),
        TYRE_OUTER_DIAMETER,
        text="TYRE DIA <>",
    )
    add_linear_spec_dimension(
        msp,
        "roller_center_distance",
        (cx - ROLLER_HALF_SPACING, roller_y),
        (cx + ROLLER_HALF_SPACING, roller_y),
        (cx, roller_y - 1300.0),
        ROLLER_CENTER_DISTANCE,
    )

    add_model_text(msp, "TYRE SECTION", (cx + 2900.0, cy + 1700.0), height=220.0)
    add_model_text(msp, "SHELL t=40 AT TYRE", (cx + 2900.0, cy + 1200.0), height=220.0)
    add_model_text(msp, "[ASSUMPTION] REFRACTORY MATERIAL INTERFACE ONLY", (cx - 3600.0, cy - 100.0), height=205.0)
    add_model_text(msp, "LINING THICKNESS NOT SPECIFIED; NO GEOMETRY ADDED", (cx - 3600.0, cy - 500.0), height=205.0)
    add_model_text(msp, "2X ROLLER DIA 1400", (cx, roller_y - 2300.0), height=220.0, align=TextEntityAlignment.MIDDLE_CENTER)
    add_model_text(msp, "FOUNDATION W6000 x H3000", (cx, foundation_center_y - 1900.0), height=220.0, align=TextEntityAlignment.MIDDLE_CENTER)


def add_paper_text(
    layout: ezdxf.layouts.Paperspace,
    text: str,
    insert: tuple[float, float],
    *,
    height: float = 3.0,
    align: TextEntityAlignment = TextEntityAlignment.LEFT,
) -> None:
    """Add title-block text in paper millimetres."""

    entity = layout.add_text(
        text,
        height=height,
        dxfattribs={"layer": LAYER_BORDER, "style": TEXT_STYLE_NAME},
    )
    entity.set_placement(insert, align=align)


def draw_border_and_title(layout: ezdxf.layouts.Paperspace) -> None:
    """Create a deterministic A1 landscape frame and review-status title block."""

    layout.page_setup(
        size=(PAPER_WIDTH, PAPER_HEIGHT),
        margins=(0, 0, 0, 0),
        units="mm",
        rotation=0,
        scale=1,
        name="ISO A1 LANDSCAPE",
    )
    layout.add_lwpolyline(
        [(10, 10), (831, 10), (831, 584), (10, 584)],
        close=True,
        dxfattribs={"layer": LAYER_BORDER},
    )
    layout.add_lwpolyline(
        [(20, 20), (821, 20), (821, 574), (20, 574)],
        close=True,
        dxfattribs={"layer": LAYER_BORDER},
    )

    x0, x1 = 641.0, 821.0
    y0, y1 = 20.0, 70.0
    layout.add_lwpolyline(
        [(x0, y0), (x1, y0), (x1, y1), (x0, y1)],
        close=True,
        dxfattribs={"layer": LAYER_BORDER},
    )
    for y in (34.0, 46.0, 58.0):
        layout.add_line((x0, y), (x1, y), dxfattribs={"layer": LAYER_BORDER})
    for x in (686.0, 731.0, 776.0):
        layout.add_line((x, y0), (x, 46.0), dxfattribs={"layer": LAYER_BORDER})

    add_paper_text(layout, "ROTARY KILN GENERAL ARRANGEMENT", (646.0, 63.0), height=4.4)
    add_paper_text(layout, f"DRAWING NO.  {DRAWING_NUMBER}", (646.0, 51.0), height=3.1)
    add_paper_text(layout, f"SCALE  {DRAWING_SCALE}", (646.0, 39.0), height=2.8)
    add_paper_text(layout, "UNIT  mm", (691.0, 39.0), height=2.8)
    add_paper_text(layout, f"DATE  {DRAWING_DATE}", (736.0, 39.0), height=2.8)
    add_paper_text(layout, "STATUS  FOR REVIEW", (781.0, 39.0), height=2.5)
    add_paper_text(layout, "DESIGN", (646.0, 28.0), height=2.5)
    add_paper_text(layout, "GENERATED", (691.0, 28.0), height=2.5)
    add_paper_text(layout, "CHECK", (736.0, 28.0), height=2.5)
    add_paper_text(layout, "PENDING", (781.0, 28.0), height=2.5)

    add_paper_text(
        layout,
        "NOTES: ALL MODEL DIMENSIONS IN mm. VIEW SCALE 1:100. [ASSUMPTION] NO ABSOLUTE ELEVATION OR LINING THICKNESS PROVIDED.",
        (24.0, 27.0),
        height=2.5,
    )

    viewport_width = 801.0
    viewport_height = 500.0
    viewport = layout.add_viewport(
        center=(420.5, 322.0),
        size=(viewport_width, viewport_height),
        view_center_point=(38000.0, 13000.0),
        view_height=viewport_height * MODEL_VIEW_SCALE,
        status=2,
        dxfattribs={"layer": LAYER_VIEWPORT},
    )
    # A 500 mm paperspace height viewing 50,000 mm modelspace establishes the
    # exact 1:100 scale without relying on CAD-vendor-specific viewport fields.
    viewport.dxf.status = 2


def build_document() -> ezdxf.document.Drawing:
    """Build all DXF entities from a fresh deterministic document."""

    doc = ezdxf.new("R2018", setup=False)
    doc.units = units.MM
    doc.header["$INSUNITS"] = units.MM
    doc.header["$MEASUREMENT"] = 1
    add_layers_and_styles(doc)
    msp = doc.modelspace()
    draw_longitudinal_elevation(msp)
    draw_section_a_a(msp)

    layout = doc.layouts.new("GA_A1")
    draw_border_and_title(layout)
    return doc


def xdata_spec(entity) -> tuple[str, float] | None:
    """Read the dimension label and expected value from KILN_SPEC XDATA."""

    if not entity.has_xdata(SPEC_APPID):
        return None
    tags = entity.get_xdata(SPEC_APPID)
    label = next(str(tag.value) for tag in tags if tag.code == 1000)
    expected = next(float(tag.value) for tag in tags if tag.code == 1040)
    return label, expected


def validate_saved_dxf(path: Path) -> dict[str, object]:
    """Reopen the output, audit it, count layers, and cross-check dimensions."""

    loaded = ezdxf.readfile(path)
    auditor = loaded.audit()
    if auditor.has_errors:
        raise RuntimeError(f"DXF audit errors: {len(auditor.errors)}")
    if loaded.units != units.MM:
        raise RuntimeError(f"DXF units are not millimetres: {loaded.units}")

    missing_layers = [name for name in REQUIRED_LAYERS if name not in loaded.layers]
    if missing_layers:
        raise RuntimeError(f"Missing layers: {missing_layers}")

    model_counts = Counter(entity.dxf.layer for entity in loaded.modelspace())
    paper_counts: Counter[str] = Counter()
    for layout in loaded.layouts:
        if layout.name != "Model":
            paper_counts.update(entity.dxf.layer for entity in layout)

    dimension_checks: dict[str, dict[str, float]] = {}
    for dimension in loaded.modelspace().query("DIMENSION"):
        spec_data = xdata_spec(dimension)
        if spec_data is None:
            continue
        label, expected = spec_data
        measured = float(dimension.get_measurement())
        if not math.isclose(measured, expected, rel_tol=0.0, abs_tol=1e-5):
            raise RuntimeError(
                f"Dimension {label}: expected {expected}, measured {measured}"
            )
        dimension_checks[label] = {"expected_mm": expected, "measured_mm": measured}

    expected_dimension_labels = {
        "kiln_total_length",
        "head_to_tyre_1",
        "tyre_1_to_tyre_2",
        "tyre_2_to_tyre_3",
        "tyre_3_to_tail",
        "head_to_girth_gear",
        "burner_total_length",
        "kiln_inner_diameter",
        "tyre_outer_diameter",
        "roller_center_distance",
    }
    missing_dimensions = sorted(expected_dimension_labels - dimension_checks.keys())
    if missing_dimensions:
        raise RuntimeError(f"Missing tagged DIMENSION entities: {missing_dimensions}")

    signature_payload = {
        "units": int(loaded.units),
        "model_counts": dict(sorted(model_counts.items())),
        "paper_counts": dict(sorted(paper_counts.items())),
        "dimensions": dimension_checks,
        "scale": DRAWING_SCALE,
        "paper": [PAPER_WIDTH, PAPER_HEIGHT],
    }
    canonical_signature = hashlib.sha256(
        json.dumps(signature_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return {
        "audit_error_count": len(auditor.errors),
        "model_layer_entity_counts": dict(sorted(model_counts.items())),
        "paper_layer_entity_counts": dict(sorted(paper_counts.items())),
        "dimension_checks": dimension_checks,
        "canonical_content_signature": canonical_signature,
    }


def generate_preview(doc: ezdxf.document.Drawing, path: Path) -> None:
    """Render the reopened A1 paperspace through ezdxf's Matplotlib backend."""

    path.parent.mkdir(parents=True, exist_ok=True)
    qsave(
        doc.layouts.get("GA_A1"),
        path,
        bg="#f5f3ed",
        fg="#171914",
        dpi=180,
        size_inches=(16.54, 11.69),
    )


def main() -> None:
    args = parse_args()
    output = args.output.expanduser().resolve()
    preview = args.preview.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    preview.parent.mkdir(parents=True, exist_ok=True)

    doc = build_document()
    doc.saveas(output)
    validation = validate_saved_dxf(output)
    reopened = ezdxf.readfile(output)
    generate_preview(reopened, preview)

    print("PHASE3_DXF_OK")
    print(f"OUTPUT dxf={output}")
    print(f"OUTPUT preview={preview}")
    print(f"CHECK units=mm")
    print(f"CHECK paper=A1_landscape_{PAPER_WIDTH:.0f}x{PAPER_HEIGHT:.0f}_mm")
    print(f"CHECK scale={DRAWING_SCALE}")
    print(f"CHECK audit_error_count={validation['audit_error_count']}")
    for layer, count in validation["model_layer_entity_counts"].items():
        print(f"LAYER_MODEL {layer}={count}")
    for layer, count in validation["paper_layer_entity_counts"].items():
        print(f"LAYER_PAPER {layer}={count}")
    for label, values in sorted(validation["dimension_checks"].items()):
        print(
            f"DIM_CHECK {label}: measured={values['measured_mm']:.6f} "
            f"expected={values['expected_mm']:.6f} mm"
        )
    print(f"CHECK canonical_content_signature={validation['canonical_content_signature']}")


if __name__ == "__main__":
    main()
