# DXF 图层清单

`kiln_GA.dxf` 使用毫米模型空间、A1 横式图纸空间和 1:100 viewport。颜色为 ACI，线宽单位为 1/100 mm。

| 图层 | ACI | 线型 | 线宽 | 用途 | 实体数（最终自检） |
|---|---:|---|---:|---|---:|
| `GA_OUTLINE` | 7 | CONTINUOUS | 50 | 设备、基础和断面轮廓 | 35（模型空间） |
| `GA_CENTER` | 3 | CENTER2 | 25 | 窑轴、断面中心线、托轮中心线 | 8（模型空间） |
| `GA_DIMENSIONS` | 2 | CONTINUOUS | 25 | ezdxf DIMENSION 实体 | 10（模型空间） |
| `GA_TEXT` | 4 | CONTINUOUS | 25 | 设备标注、斜度和假设说明 | 19（模型空间） |
| `GA_HATCH` | 8 | CONTINUOUS | 18 | A-A 轮带与筒体剖面 | 2（模型空间） |
| `GA_BORDER_TITLE` | 1 | CONTINUOUS | 50 | A1 图框、标题栏、图签文字 | 20（图纸空间） |
| `GA_VIEWPORT` | 9 | CONTINUOUS | 18 | 1:100 视口边界；设为不打印 | 1（图纸空间） |

图纸空间另有 ezdxf 自动创建的系统层 `VIEWPORTS`，其中 1 个实体为 AutoCAD 必需的默认图纸空间 viewport，不属于业务图层。

重新生成及统计：

```bash
python drawing/gen_dxf.py
```

脚本保存后会重新打开 DXF，执行 audit、逐层计数，并读取每个带 `KILN_SPEC` XDATA 的 DIMENSION 实体进行实测值/规格值交叉验证；任何差异会以非零退出码停止。
