# Φ4.0 × 60 m 回转窑数字交付包

本项目把同一份《技术规格》交付为四个可独立验收的成果：参数化 Blender 模型、离线 Three.js 动态样机、AutoCAD DXF 总装图和完整文档验收包。所有未给定内容均以 `[假设]` 或 `[演示假设]` 明示。

## 目录

```text
.
├── model/
│   ├── build_kiln.py       # Blender bpy 参数化建模脚本
│   ├── kiln.blend          # 可编辑 Blender 场景
│   ├── kiln.glb            # 通用 3D 交付格式
│   └── render.png          # 1920×1080 渲染图
├── web/
│   └── index.html          # Three.js r185 单文件离线动态样机
├── drawing/
│   ├── gen_dxf.py          # ezdxf 总装图生成器与自检
│   ├── kiln_GA.dxf         # R2018 / mm / A1 / 1:100
│   ├── preview.png         # A1 图纸空间预览
│   └── LAYER_LIST.md       # 图层、颜色、线型、线宽与数量
├── docs/
│   ├── CHECKSUMS.sha256
│   ├── MODEL_PARAMETERS.md
│   ├── FEATURE_MATRIX.md
│   ├── DEVLOG.md
│   ├── PHASE1_REPORT.md
│   ├── PHASE2_REPORT.md
│   ├── PHASE2_DEMO_30S.md
│   ├── PHASE3_REPORT.md
│   ├── ACCEPTANCE_CHECKLIST.md
│   ├── DEMO_SCRIPT_3MIN.md
│   ├── PRODUCT.md
│   └── DESIGN.md
├── requirements.txt
├── CHANGELOG.md
└── README.md
```

## 已验证环境

- macOS / Apple M2 Max
- Blender 5.1.2；脚本使用 Blender 内置 Python 与 `bpy`
- Python 3.12
- ezdxf 1.4.4
- Matplotlib 3.11.0
- Three.js r185 已完全内联，无需安装 Node.js 或访问 CDN
- Chromium / ANGLE Metal；Web 样机需要 WebGL2

## Python 环境

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## 一键重建 Blender 模型

macOS 默认 Blender 路径：

```bash
/Applications/Blender.app/Contents/MacOS/Blender \
  --background \
  --python model/build_kiln.py \
  -- \
  --export model/kiln.glb \
  --blend model/kiln.blend \
  --render model/render.png
```

若 `blender` 已加入 PATH：

```bash
blender --background --python model/build_kiln.py -- --export model/kiln.glb
```

脚本会先清空场景，重建并自检，再保存 BLEND、导出 GLB 和渲染 PNG；尺寸、命名、数量或 Collection 结构漂移时会失败退出。

## 打开 Web 动态样机

```bash
open web/index.html
```

不需要本地服务器。左键旋转、滚轮缩放、右键平移；底部可控制转速、剖切、火焰和复位。30 秒演示流程见 `docs/PHASE2_DEMO_30S.md`。

## 一键重建 DXF 与预览

```bash
source .venv/bin/activate
python drawing/gen_dxf.py
```

脚本会生成 `drawing/kiln_GA.dxf` 和 `drawing/preview.png`，随后重新打开 DXF，执行 audit、图层计数和 10 项 DIMENSION 实测交叉验证。任何关键尺寸差异都会以非零退出码停止。

## 关键规格

| 对象 | 规格 |
|---|---|
| 窑体 | 内径 Φ4.0 m；长 60 m；斜度 3.5%；壁厚 25–40 mm |
| 轮带 | 3 个；距窑头 12 / 33 / 51 m；外径 Φ4.9 m；宽 1.0 m |
| 齿圈 | 距窑头 22 m；外径 Φ4.6 m；宽 0.7 m；约 200 齿 |
| 托轮 | 每档 2 个；中心距 3.2 m；Φ1.4 × 1.0 m |
| 基础 | 每档 1 座；高 3.0 × 轴向 5.0 × 横向 6.0 m |
| 窑头罩 | 6.0 × 7.5 × 7.5 m |
| 燃烧器 | 长 10 m；Φ0.9 m；伸入约 8 m |
| 窑尾烟室 | 7.0 × 7.0 × 8.0 m |
| 工艺 | 约 3000 t/d；烧成峰值 1450 ℃ |

全部参数、解释和假设见 `docs/MODEL_PARAMETERS.md`。完整结果见 `docs/ACCEPTANCE_CHECKLIST.md`。

核心成品完整性可从项目根目录验证：

```bash
LC_ALL=C shasum -a 256 -c docs/CHECKSUMS.sha256
```

## 交付边界

- 这是规格驱动的展示模型和总装表达，不是土建、制造、耐火材料、传动选型或结构计算施工图。
- 未给出耐火内衬厚度，所以三维模型只赋内表面材质，DXF 只标材料界面，不生成虚构厚度。
- GLB 格式不支持 Blender Area Light；三点布光完整保存在 `kiln.blend` 并用于 `render.png`，GLB 保留模型、材质和相机。
- 标题栏审核状态为 `PENDING`；需要项目责任人完成正式设计/审核签字。
