# CHANGELOG

## 1.0.0 — 2026-07-14

### PHASE 4 — 最终交付

- 整理为 `/model /web /drawing /docs` 四类目录。
- 新增 README、完整验收自检表、版本记录和 3 分钟演示脚本。
- 完成跨产物规格一致性、文件可打开性和再生成回归。

### PHASE 3 — AutoCAD DXF

- 新增 ezdxf 1.4.4 参数化总装图生成器。
- 新增 A1 横式、1:100、mm 的纵向立面与 A-A 断面。
- 新增 7 个业务图层、10 个真实 DIMENSION 实体、标题栏和预览。
- 新增 DXF reopen audit、图层计数、XDATA 规格追踪和尺寸交叉验证。

### PHASE 2 — Web 3D

- 新增 Three.js r185 + OrbitControls 单文件离线样机。
- 新增旋转、0.4–4.0 r/min、剖切、四段温度带、火焰和视角复位。
- 新增响应式控制界面、键盘焦点、reduced-motion 和 WebGL 错误显示。
- 新增 Metal/软件渲染器自适应质量路径和 Playwright 双打开方式测试。

### PHASE 1 — Blender

- 新增 bpy 参数化模型、GLB、BLEND 和 1920 × 1080 渲染图。
- 新增 8 个分类 Collection、规范对象命名、PBR 材质、相机与三点光。
- 根据反馈将均匀高光材料升级为程序化粗糙度、微表面凹凸和工业哑光配色，降低塑料感。
- 新增实际 Mesh 尺寸、数量、结构、重开和确定性验证。

## 0.1.0 — 2026-07-14

- 建立规格参数表、功能清单、开发记录和阶段化验收基线。
