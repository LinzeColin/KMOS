#!/usr/bin/env python3
"""Deterministically build the Phase 1 rotary-kiln Blender scene.

Run with Blender (not the system Python):

    blender --background --python build_kiln.py -- --export kiln.glb

The script clears the scene, rebuilds every object from the specification,
saves ``kiln.blend``, exports ``kiln.glb``, and renders ``render.png`` in the
same output directory as the requested GLB.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Iterable, Sequence

import bpy
from mathutils import Matrix, Vector


# =============================================================================
# AUTHORITATIVE TECHNICAL SPECIFICATION (all linear values are metres)
# =============================================================================

KILN_INNER_DIAMETER_M = 4.0
KILN_LENGTH_M = 60.0
KILN_SLOPE = 0.035  # 3.5%; kiln head low, kiln tail high.
SHELL_WALL_THICKNESS_M = 0.025
SHELL_WALL_THICKNESS_AT_TYRE_M = 0.040

TYRE_POSITIONS_M = (12.0, 33.0, 51.0)
TYRE_OUTER_DIAMETER_M = 4.9
TYRE_WIDTH_M = 1.0
TYRE_SPEC_TOTAL_RADIAL_M = 0.45

GEAR_POSITION_M = 22.0
GEAR_OUTER_DIAMETER_M = 4.6
GEAR_WIDTH_M = 0.7
GEAR_TOOTH_COUNT = 200

ROLLERS_PER_STATION = 2
ROLLER_CENTER_DISTANCE_M = 3.2
ROLLER_DIAMETER_M = 1.4
ROLLER_LENGTH_M = 1.0

# Approved mapping for 3.0 x 5.0 x 6.0 m: height x axial length x width.
FOUNDATION_HEIGHT_M = 3.0
FOUNDATION_AXIAL_LENGTH_M = 5.0
FOUNDATION_TRANSVERSE_WIDTH_M = 6.0

HEAD_HOOD_AXIAL_LENGTH_M = 6.0
HEAD_HOOD_WIDTH_M = 7.5
HEAD_HOOD_HEIGHT_M = 7.5

BURNER_LENGTH_M = 10.0
BURNER_DIAMETER_M = 0.9
BURNER_INSERTION_M = 8.0

TAIL_CHAMBER_AXIAL_LENGTH_M = 7.0
TAIL_CHAMBER_WIDTH_M = 7.0
TAIL_CHAMBER_HEIGHT_M = 8.0

CAPACITY_T_PER_DAY = 3000.0
PEAK_BURNING_TEMPERATURE_C = 1450.0
TEMPERATURE_ZONES = ("preheat", "calcination", "burning", "cooling")


# =============================================================================
# EXPLICIT APPROVED / VISUAL ASSUMPTIONS (not engineering specification)
# =============================================================================

# Approved option A: the specified 0.45 m is measured from the kiln inner
# radius to the tyre outer radius.  The standalone tyre starts at the 4.08 m
# shell OD and is therefore 0.41 m thick, avoiding intersecting geometry.
TYRE_INNER_DIAMETER_M = (
    KILN_INNER_DIAMETER_M + 2.0 * SHELL_WALL_THICKNESS_AT_TYRE_M
)
TYRE_ACTUAL_RADIAL_THICKNESS_M = (
    TYRE_OUTER_DIAMETER_M - TYRE_INNER_DIAMETER_M
) / 2.0

# Refractory thickness was not specified.  The inner shell faces receive a
# refractory PBR material without changing the specified 4.0 m clear diameter.
REFRACTORY_GEOMETRY_THICKNESS_M = 0.0

# Enclosure wall thickness and detailed fabrication were not specified.
ENCLOSURE_WALL_THICKNESS_M = 0.15
HEAD_HOOD_X_MIN_M = -2.0
HEAD_HOOD_X_MAX_M = HEAD_HOOD_X_MIN_M + HEAD_HOOD_AXIAL_LENGTH_M
TAIL_CHAMBER_X_MIN_M = KILN_LENGTH_M
TAIL_CHAMBER_X_MAX_M = TAIL_CHAMBER_X_MIN_M + TAIL_CHAMBER_AXIAL_LENGTH_M

# Gear root/hub geometry is visual-only; specified OD, width, position, and
# tooth count remain exact.
GEAR_OUTER_RADIUS_M = GEAR_OUTER_DIAMETER_M / 2.0
GEAR_TOOTH_HEIGHT_M = 0.12
GEAR_ROOT_RADIUS_M = GEAR_OUTER_RADIUS_M - GEAR_TOOTH_HEIGHT_M
GEAR_INNER_RADIUS_M = (
    KILN_INNER_DIAMETER_M / 2.0 + SHELL_WALL_THICKNESS_M + 0.03
)

MESH_RADIAL_SEGMENTS = 128
ENCLOSURE_OPENING_HALF_SIZE_M = 0.65
RENDER_RESOLUTION_X = 1920
RENDER_RESOLUTION_Y = 1080


# =============================================================================
# DERIVED GEOMETRY
# =============================================================================

SLOPE_ANGLE_RAD = math.atan(KILN_SLOPE)
LOCAL_TO_WORLD_ROTATION = Matrix.Rotation(-SLOPE_ANGLE_RAD, 4, "Y")
AXIS_DIRECTION = Vector((math.cos(SLOPE_ANGLE_RAD), 0.0, math.sin(SLOPE_ANGLE_RAD)))
TYRE_RADIUS_M = TYRE_OUTER_DIAMETER_M / 2.0
ROLLER_RADIUS_M = ROLLER_DIAMETER_M / 2.0
ROLLER_HALF_SPACING_M = ROLLER_CENTER_DISTANCE_M / 2.0
ROLLER_VERTICAL_OFFSET_M = math.sqrt(
    (TYRE_RADIUS_M + ROLLER_RADIUS_M) ** 2 - ROLLER_HALF_SPACING_M**2
)

# There is no survey elevation in the specification.  Set the head-axis height
# so the first notional foundation datum starts near z=0; all relative geometry
# and the 3.5% slope remain exact.
AXIS_HEAD_Z_M = (
    ROLLER_VERTICAL_OFFSET_M + ROLLER_RADIUS_M + FOUNDATION_HEIGHT_M
) * math.cos(SLOPE_ANGLE_RAD)


def local_to_world(point: Sequence[float]) -> Vector:
    """Transform kiln-local (axial, transverse, radial) coordinates to world."""

    transformed = LOCAL_TO_WORLD_ROTATION @ Vector(point)
    transformed.z += AXIS_HEAD_Z_M
    return transformed


def axis_point(axial_position_m: float) -> Vector:
    """Return the world-space point on the kiln axis at an axial position."""

    return local_to_world((axial_position_m, 0.0, 0.0))


def parse_args() -> argparse.Namespace:
    """Parse only arguments following Blender's ``--`` separator."""

    user_args = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--export", default="kiln.glb", help="GLB output path")
    parser.add_argument("--blend", default=None, help="optional BLEND output path")
    parser.add_argument("--render", default=None, help="optional PNG output path")
    return parser.parse_args(user_args)


def resolve_outputs(args: argparse.Namespace) -> tuple[Path, Path, Path]:
    """Resolve output paths without depending on Blender's launch directory."""

    export_path = Path(args.export).expanduser()
    if not export_path.is_absolute():
        export_path = Path.cwd() / export_path
    export_path = export_path.resolve()
    blend_path = Path(args.blend).expanduser() if args.blend else export_path.with_name("kiln.blend")
    render_path = Path(args.render).expanduser() if args.render else export_path.with_name("render.png")
    if not blend_path.is_absolute():
        blend_path = (Path.cwd() / blend_path).resolve()
    if not render_path.is_absolute():
        render_path = (Path.cwd() / render_path).resolve()
    export_path.parent.mkdir(parents=True, exist_ok=True)
    blend_path.parent.mkdir(parents=True, exist_ok=True)
    render_path.parent.mkdir(parents=True, exist_ok=True)
    return export_path, blend_path, render_path


def clear_scene() -> None:
    """Remove prior objects and generated data so repeated runs start identically."""

    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)

    for collection in list(bpy.data.collections):
        bpy.data.collections.remove(collection)
    for data_group in (
        bpy.data.meshes,
        bpy.data.curves,
        bpy.data.materials,
        bpy.data.cameras,
        bpy.data.lights,
    ):
        for datablock in list(data_group):
            data_group.remove(datablock)


def create_collections() -> dict[str, bpy.types.Collection]:
    """Create the deterministic collection hierarchy required for inspection."""

    root = bpy.data.collections.new("KILN_MODEL")
    bpy.context.scene.collection.children.link(root)
    collections: dict[str, bpy.types.Collection] = {"root": root}
    for key, name in (
        ("body", "01_KILN_BODY"),
        ("tyres", "02_TYRES"),
        ("gear", "03_GIRTH_GEAR"),
        ("supports", "04_SUPPORT_ROLLERS"),
        ("foundations", "05_FOUNDATIONS"),
        ("head", "06_HEAD_ASSEMBLY"),
        ("tail", "07_TAIL_ASSEMBLY"),
        ("lighting", "08_CAMERA_LIGHTING"),
    ):
        collection = bpy.data.collections.new(name)
        root.children.link(collection)
        collections[key] = collection
    return collections


def make_pbr_material(
    name: str,
    base_color: tuple[float, float, float, float],
    metallic: float,
    roughness: float,
    texture_scale: float,
    roughness_variation: float,
    bump_strength: float,
    bump_distance: float,
) -> bpy.types.Material:
    """Create a deterministic, micro-textured industrial PBR material.

    Procedural variation changes only the surface response and never the
    dimensional geometry. This removes the uniform injection-moulded gloss of
    the first review render while preserving exact specification geometry.
    """

    material = bpy.data.materials.new(name=name)
    material.use_nodes = True
    material.diffuse_color = base_color
    node = material.node_tree.nodes.get("Principled BSDF")
    if node is None:
        raise RuntimeError(f"Principled BSDF node missing for {name}")
    node.inputs["Base Color"].default_value = base_color
    node.inputs["Metallic"].default_value = metallic
    node.inputs["Roughness"].default_value = roughness

    nodes = material.node_tree.nodes
    links = material.node_tree.links
    coordinates = nodes.new("ShaderNodeTexCoord")
    coordinates.name = "SurfaceCoordinates"
    coordinates.location = (-720.0, 20.0)

    noise = nodes.new("ShaderNodeTexNoise")
    noise.name = "IndustrialMicroVariation"
    noise.location = (-520.0, 20.0)
    noise.noise_dimensions = "3D"
    noise.inputs["Scale"].default_value = texture_scale
    noise.inputs["Detail"].default_value = 5.0
    noise.inputs["Roughness"].default_value = 0.68
    noise.inputs["Distortion"].default_value = 0.08
    links.new(coordinates.outputs["Object"], noise.inputs["Vector"])

    color_variation = nodes.new("ShaderNodeValToRGB")
    color_variation.name = "SubtleColorVariation"
    color_variation.location = (-300.0, 120.0)
    color_variation.color_ramp.elements[0].position = 0.25
    color_variation.color_ramp.elements[0].color = (
        base_color[0] * 0.72,
        base_color[1] * 0.72,
        base_color[2] * 0.72,
        1.0,
    )
    color_variation.color_ramp.elements[1].position = 0.78
    color_variation.color_ramp.elements[1].color = (
        min(1.0, base_color[0] * 1.10),
        min(1.0, base_color[1] * 1.10),
        min(1.0, base_color[2] * 1.10),
        1.0,
    )
    links.new(noise.outputs["Fac"], color_variation.inputs["Fac"])
    links.new(color_variation.outputs["Color"], node.inputs["Base Color"])

    roughness_node = nodes.new("ShaderNodeValToRGB")
    roughness_node.name = "RoughnessVariation"
    roughness_node.location = (-300.0, -80.0)
    roughness_low = max(0.0, roughness - roughness_variation)
    roughness_high = min(1.0, roughness + roughness_variation)
    roughness_node.color_ramp.elements[0].color = (roughness_low,) * 3 + (1.0,)
    roughness_node.color_ramp.elements[1].color = (roughness_high,) * 3 + (1.0,)
    links.new(noise.outputs["Fac"], roughness_node.inputs["Fac"])
    links.new(roughness_node.outputs["Color"], node.inputs["Roughness"])

    bump = nodes.new("ShaderNodeBump")
    bump.name = "SurfaceMicroBump"
    bump.location = (-80.0, -180.0)
    bump.inputs["Strength"].default_value = bump_strength
    bump.inputs["Distance"].default_value = bump_distance
    links.new(noise.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], node.inputs["Normal"])

    material["surface_profile"] = "deterministic_industrial_microtexture"
    material["texture_scale"] = texture_scale
    material["roughness_range"] = (roughness_low, roughness_high)
    return material


def create_materials() -> dict[str, bpy.types.Material]:
    """Create the required steel, gear, refractory, and concrete PBR set."""

    return {
        "shell": make_pbr_material(
            "MAT_SteelShell", (0.18, 0.20, 0.21, 1.0), 0.72, 0.58, 1.8, 0.10, 0.16, 0.018
        ),
        "tyre": make_pbr_material(
            "MAT_TyreSteel", (0.075, 0.082, 0.086, 1.0), 0.82, 0.50, 4.5, 0.10, 0.18, 0.012
        ),
        "gear": make_pbr_material(
            "MAT_GearSteel", (0.24, 0.105, 0.035, 1.0), 0.74, 0.48, 6.0, 0.12, 0.20, 0.010
        ),
        "refractory": make_pbr_material(
            "MAT_Refractory", (0.34, 0.125, 0.035, 1.0), 0.0, 0.90, 3.0, 0.06, 0.22, 0.025
        ),
        "concrete": make_pbr_material(
            "MAT_Concrete", (0.29, 0.30, 0.29, 1.0), 0.0, 0.91, 1.4, 0.06, 0.36, 0.050
        ),
        "hood": make_pbr_material(
            "MAT_HoodSteel", (0.095, 0.125, 0.135, 1.0), 0.58, 0.63, 2.1, 0.10, 0.18, 0.020
        ),
        "burner": make_pbr_material(
            "MAT_BurnerSteel", (0.13, 0.135, 0.135, 1.0), 0.76, 0.52, 5.0, 0.10, 0.16, 0.010
        ),
    }


def create_mesh_object(
    name: str,
    vertices: Iterable[Sequence[float]],
    faces: Iterable[Sequence[int]],
    collection: bpy.types.Collection,
    materials: Sequence[bpy.types.Material],
    material_indices: Sequence[int] | None = None,
    smooth_face_count: int = 0,
) -> bpy.types.Object:
    """Create, link, and materialize a mesh object without operator context."""

    mesh = bpy.data.meshes.new(f"{name}_mesh")
    mesh.from_pydata(list(vertices), [], list(faces))
    mesh.update(calc_edges=True)
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    for material in materials:
        mesh.materials.append(material)
    if material_indices is not None:
        if len(material_indices) != len(mesh.polygons):
            raise ValueError(f"Material-index count mismatch for {name}")
        for polygon, index in zip(mesh.polygons, material_indices):
            polygon.material_index = index
    for polygon in mesh.polygons[:smooth_face_count]:
        polygon.use_smooth = True
    return obj


def add_bevel(obj: bpy.types.Object, width: float, segments: int = 2) -> None:
    """Add restrained edge softening for render readability."""

    modifier = obj.modifiers.new(name="EdgeSoftening", type="BEVEL")
    modifier.width = width
    modifier.segments = segments
    modifier.limit_method = "ANGLE"


def ring_mesh_data(
    axial_center_m: float,
    axial_width_m: float,
    outer_radius_m: float,
    inner_radius_m: float,
    segments: int,
) -> tuple[list[Vector], list[tuple[int, ...]], int]:
    """Return a sloped annular-cylinder mesh aligned with the kiln axis."""

    x_left = axial_center_m - axial_width_m / 2.0
    x_right = axial_center_m + axial_width_m / 2.0
    vertices: list[Vector] = []
    for x_value, radius in (
        (x_left, outer_radius_m),
        (x_right, outer_radius_m),
        (x_left, inner_radius_m),
        (x_right, inner_radius_m),
    ):
        for index in range(segments):
            theta = 2.0 * math.pi * index / segments
            vertices.append(local_to_world((x_value, radius * math.cos(theta), radius * math.sin(theta))))

    outer_left = 0
    outer_right = segments
    inner_left = 2 * segments
    inner_right = 3 * segments
    faces: list[tuple[int, ...]] = []
    for index in range(segments):
        nxt = (index + 1) % segments
        faces.append((outer_left + index, outer_left + nxt, outer_right + nxt, outer_right + index))
        faces.append((inner_left + index, inner_right + index, inner_right + nxt, inner_left + nxt))
    smooth_face_count = len(faces)
    for index in range(segments):
        nxt = (index + 1) % segments
        faces.append((outer_left + index, inner_left + index, inner_left + nxt, outer_left + nxt))
        faces.append((outer_right + index, outer_right + nxt, inner_right + nxt, inner_right + index))
    return vertices, faces, smooth_face_count


def build_shell(
    collection: bpy.types.Collection,
    materials: dict[str, bpy.types.Material],
) -> bpy.types.Object:
    """Build the hollow 60 m kiln shell with exact tyre-zone thickening."""

    base_outer_radius = KILN_INNER_DIAMETER_M / 2.0 + SHELL_WALL_THICKNESS_M
    tyre_outer_radius = KILN_INNER_DIAMETER_M / 2.0 + SHELL_WALL_THICKNESS_AT_TYRE_M
    profile: list[tuple[float, float]] = [(0.0, base_outer_radius)]
    for position in TYRE_POSITIONS_M:
        start = position - TYRE_WIDTH_M / 2.0
        end = position + TYRE_WIDTH_M / 2.0
        profile.extend(
            [
                (start, base_outer_radius),
                (start, tyre_outer_radius),
                (end, tyre_outer_radius),
                (end, base_outer_radius),
            ]
        )
    profile.append((KILN_LENGTH_M, base_outer_radius))

    vertices: list[Vector] = []
    for x_value, radius in profile:
        for index in range(MESH_RADIAL_SEGMENTS):
            theta = 2.0 * math.pi * index / MESH_RADIAL_SEGMENTS
            vertices.append(local_to_world((x_value, radius * math.cos(theta), radius * math.sin(theta))))

    outer_ring_count = len(profile)
    faces: list[tuple[int, ...]] = []
    material_indices: list[int] = []
    for ring_index in range(outer_ring_count - 1):
        first = ring_index * MESH_RADIAL_SEGMENTS
        second = (ring_index + 1) * MESH_RADIAL_SEGMENTS
        for index in range(MESH_RADIAL_SEGMENTS):
            nxt = (index + 1) % MESH_RADIAL_SEGMENTS
            faces.append((first + index, first + nxt, second + nxt, second + index))
            material_indices.append(0)
    outer_face_count = len(faces)

    inner_start = len(vertices)
    inner_radius = KILN_INNER_DIAMETER_M / 2.0
    for x_value in (0.0, KILN_LENGTH_M):
        for index in range(MESH_RADIAL_SEGMENTS):
            theta = 2.0 * math.pi * index / MESH_RADIAL_SEGMENTS
            vertices.append(local_to_world((x_value, inner_radius * math.cos(theta), inner_radius * math.sin(theta))))
    for index in range(MESH_RADIAL_SEGMENTS):
        nxt = (index + 1) % MESH_RADIAL_SEGMENTS
        faces.append(
            (
                inner_start + index,
                inner_start + MESH_RADIAL_SEGMENTS + index,
                inner_start + MESH_RADIAL_SEGMENTS + nxt,
                inner_start + nxt,
            )
        )
        material_indices.append(1)
    inner_face_count = MESH_RADIAL_SEGMENTS

    outer_end_start = (outer_ring_count - 1) * MESH_RADIAL_SEGMENTS
    for index in range(MESH_RADIAL_SEGMENTS):
        nxt = (index + 1) % MESH_RADIAL_SEGMENTS
        faces.append((index, inner_start + index, inner_start + nxt, nxt))
        material_indices.append(0)
        faces.append(
            (
                outer_end_start + index,
                outer_end_start + nxt,
                inner_start + MESH_RADIAL_SEGMENTS + nxt,
                inner_start + MESH_RADIAL_SEGMENTS + index,
            )
        )
        material_indices.append(0)

    obj = create_mesh_object(
        "kiln_shell",
        vertices,
        faces,
        collection,
        (materials["shell"], materials["refractory"]),
        material_indices,
        smooth_face_count=outer_face_count + inner_face_count,
    )
    obj["spec_inner_diameter_m"] = KILN_INNER_DIAMETER_M
    obj["spec_length_m"] = KILN_LENGTH_M
    obj["spec_slope_percent"] = KILN_SLOPE * 100.0
    obj["spec_wall_thickness_m"] = SHELL_WALL_THICKNESS_M
    obj["spec_wall_thickness_at_tyre_m"] = SHELL_WALL_THICKNESS_AT_TYRE_M
    obj["assumption_refractory_geometry_thickness_m"] = REFRACTORY_GEOMETRY_THICKNESS_M
    return obj


def build_tyres(
    collection: bpy.types.Collection,
    materials: dict[str, bpy.types.Material],
) -> list[bpy.types.Object]:
    """Build three exact-OD tyre rings at their specified axial positions."""

    objects: list[bpy.types.Object] = []
    for station, position in enumerate(TYRE_POSITIONS_M, start=1):
        vertices, faces, smooth_count = ring_mesh_data(
            position,
            TYRE_WIDTH_M,
            TYRE_OUTER_DIAMETER_M / 2.0,
            TYRE_INNER_DIAMETER_M / 2.0,
            MESH_RADIAL_SEGMENTS,
        )
        obj = create_mesh_object(
            f"tyre_{station}", vertices, faces, collection, (materials["tyre"],), smooth_face_count=smooth_count
        )
        add_bevel(obj, 0.018, 2)
        obj["spec_axial_position_m"] = position
        obj["spec_outer_diameter_m"] = TYRE_OUTER_DIAMETER_M
        obj["spec_width_m"] = TYRE_WIDTH_M
        obj["spec_total_radial_from_kiln_id_m"] = TYRE_SPEC_TOTAL_RADIAL_M
        obj["derived_actual_radial_thickness_m"] = TYRE_ACTUAL_RADIAL_THICKNESS_M
        objects.append(obj)
    return objects


def build_girth_gear(
    collection: bpy.types.Collection,
    materials: dict[str, bpy.types.Material],
) -> bpy.types.Object:
    """Build one joined gear mesh with 200 deterministic visual teeth."""

    vertices, faces, smooth_count = ring_mesh_data(
        GEAR_POSITION_M,
        GEAR_WIDTH_M,
        GEAR_ROOT_RADIUS_M,
        GEAR_INNER_RADIUS_M,
        MESH_RADIAL_SEGMENTS,
    )
    pitch_angle = 2.0 * math.pi / GEAR_TOOTH_COUNT
    tooth_half_angle = pitch_angle * 0.28
    x_left = GEAR_POSITION_M - GEAR_WIDTH_M / 2.0
    x_right = GEAR_POSITION_M + GEAR_WIDTH_M / 2.0

    for tooth_index in range(GEAR_TOOTH_COUNT):
        center_angle = tooth_index * pitch_angle
        theta0 = center_angle - tooth_half_angle
        theta1 = center_angle + tooth_half_angle
        base = len(vertices)
        local_vertices = []
        for x_value in (x_left, x_right):
            for radius, theta in (
                (GEAR_ROOT_RADIUS_M, theta0),
                (GEAR_OUTER_RADIUS_M, theta0),
                (GEAR_OUTER_RADIUS_M, theta1),
                (GEAR_ROOT_RADIUS_M, theta1),
            ):
                local_vertices.append(
                    local_to_world((x_value, radius * math.cos(theta), radius * math.sin(theta)))
                )
        vertices.extend(local_vertices)
        faces.extend(
            [
                (base + 0, base + 3, base + 2, base + 1),
                (base + 4, base + 5, base + 6, base + 7),
                (base + 0, base + 1, base + 5, base + 4),
                (base + 1, base + 2, base + 6, base + 5),
                (base + 2, base + 3, base + 7, base + 6),
                (base + 3, base + 0, base + 4, base + 7),
            ]
        )

    obj = create_mesh_object(
        "girth_gear", vertices, faces, collection, (materials["gear"],), smooth_face_count=smooth_count
    )
    add_bevel(obj, 0.006, 1)
    obj["spec_axial_position_m"] = GEAR_POSITION_M
    obj["spec_outer_diameter_m"] = GEAR_OUTER_DIAMETER_M
    obj["spec_width_m"] = GEAR_WIDTH_M
    obj["spec_tooth_count_approx"] = GEAR_TOOTH_COUNT
    obj["assumption_root_radius_m"] = GEAR_ROOT_RADIUS_M
    obj["assumption_inner_radius_m"] = GEAR_INNER_RADIUS_M
    return obj


def create_axis_cylinder(
    name: str,
    axial_center_m: float,
    transverse_m: float,
    radial_m: float,
    radius_m: float,
    length_m: float,
    collection: bpy.types.Collection,
    material: bpy.types.Material,
    vertices: int = 64,
) -> bpy.types.Object:
    """Create a cylinder whose local Z axis is aligned to the kiln axis."""

    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius_m, depth=length_m, end_fill_type="NGON")
    obj = bpy.context.object
    obj.name = name
    obj.data.name = f"{name}_mesh"
    for owner in list(obj.users_collection):
        owner.objects.unlink(obj)
    collection.objects.link(obj)
    obj.location = local_to_world((axial_center_m, transverse_m, radial_m))
    obj.rotation_mode = "QUATERNION"
    obj.rotation_quaternion = Vector((0.0, 0.0, 1.0)).rotation_difference(AXIS_DIRECTION)
    obj.data.materials.append(material)
    for polygon in obj.data.polygons:
        polygon.use_smooth = len(polygon.vertices) == 4
    add_bevel(obj, min(0.015, radius_m * 0.03), 2)
    return obj


def build_support_rollers(
    collection: bpy.types.Collection,
    materials: dict[str, bpy.types.Material],
) -> list[bpy.types.Object]:
    """Build two tangent rollers at each of the three tyre stations."""

    objects: list[bpy.types.Object] = []
    for station, position in enumerate(TYRE_POSITIONS_M, start=1):
        for side_index, transverse in enumerate((-ROLLER_HALF_SPACING_M, ROLLER_HALF_SPACING_M), start=1):
            obj = create_axis_cylinder(
                f"support_roller_{station}_{side_index}",
                position,
                transverse,
                -ROLLER_VERTICAL_OFFSET_M,
                ROLLER_RADIUS_M,
                ROLLER_LENGTH_M,
                collection,
                materials["tyre"],
            )
            obj["spec_station"] = station
            obj["spec_axial_position_m"] = position
            obj["spec_diameter_m"] = ROLLER_DIAMETER_M
            obj["spec_length_m"] = ROLLER_LENGTH_M
            obj["spec_pair_center_distance_m"] = ROLLER_CENTER_DISTANCE_M
            objects.append(obj)
    return objects


def box_mesh_data(
    boxes: Sequence[tuple[tuple[float, float, float], tuple[float, float, float]]]
) -> tuple[list[Vector], list[tuple[int, ...]]]:
    """Combine non-overlapping local-axis boxes into one mesh object."""

    vertices: list[Vector] = []
    faces: list[tuple[int, ...]] = []
    for center, dimensions in boxes:
        cx, cy, cz = center
        dx, dy, dz = (value / 2.0 for value in dimensions)
        base = len(vertices)
        local_vertices = [
            (cx - dx, cy - dy, cz - dz),
            (cx + dx, cy - dy, cz - dz),
            (cx + dx, cy + dy, cz - dz),
            (cx - dx, cy + dy, cz - dz),
            (cx - dx, cy - dy, cz + dz),
            (cx + dx, cy - dy, cz + dz),
            (cx + dx, cy + dy, cz + dz),
            (cx - dx, cy + dy, cz + dz),
        ]
        vertices.extend(local_to_world(vertex) for vertex in local_vertices)
        faces.extend(
            [
                (base + 0, base + 3, base + 2, base + 1),
                (base + 4, base + 5, base + 6, base + 7),
                (base + 0, base + 1, base + 5, base + 4),
                (base + 1, base + 2, base + 6, base + 5),
                (base + 2, base + 3, base + 7, base + 6),
                (base + 3, base + 0, base + 4, base + 7),
            ]
        )
    return vertices, faces


def build_foundations(
    collection: bpy.types.Collection,
    materials: dict[str, bpy.types.Material],
) -> list[bpy.types.Object]:
    """Build one approved 3 x 5 x 6 m concrete base per tyre station."""

    objects: list[bpy.types.Object] = []
    foundation_center_radial = -(
        ROLLER_VERTICAL_OFFSET_M + ROLLER_RADIUS_M + FOUNDATION_HEIGHT_M / 2.0
    )
    for station, position in enumerate(TYRE_POSITIONS_M, start=1):
        vertices, faces = box_mesh_data(
            [
                (
                    (position, 0.0, foundation_center_radial),
                    (
                        FOUNDATION_AXIAL_LENGTH_M,
                        FOUNDATION_TRANSVERSE_WIDTH_M,
                        FOUNDATION_HEIGHT_M,
                    ),
                )
            ]
        )
        obj = create_mesh_object(
            f"foundation_{station}", vertices, faces, collection, (materials["concrete"],)
        )
        add_bevel(obj, 0.06, 2)
        obj["spec_axial_position_m"] = position
        obj["spec_height_m"] = FOUNDATION_HEIGHT_M
        obj["spec_axial_length_m"] = FOUNDATION_AXIAL_LENGTH_M
        obj["spec_transverse_width_m"] = FOUNDATION_TRANSVERSE_WIDTH_M
        objects.append(obj)
    return objects


def build_head_hood(
    collection: bpy.types.Collection,
    materials: dict[str, bpy.types.Material],
) -> bpy.types.Object:
    """Build the approved simplified head hood with an explicit burner opening."""

    length = HEAD_HOOD_AXIAL_LENGTH_M
    width = HEAD_HOOD_WIDTH_M
    height = HEAD_HOOD_HEIGHT_M
    wall = ENCLOSURE_WALL_THICKNESS_M
    x_center = (HEAD_HOOD_X_MIN_M + HEAD_HOOD_X_MAX_M) / 2.0
    front_x = HEAD_HOOD_X_MIN_M + wall / 2.0
    opening = ENCLOSURE_OPENING_HALF_SIZE_M
    side_strip_width = (width - 2.0 * wall - 2.0 * opening) / 2.0
    cap_strip_height = (height - 2.0 * wall - 2.0 * opening) / 2.0
    boxes = [
        ((x_center, -(width - wall) / 2.0, 0.0), (length, wall, height)),
        ((x_center, +(width - wall) / 2.0, 0.0), (length, wall, height)),
        ((x_center, 0.0, +(height - wall) / 2.0), (length, width - 2.0 * wall, wall)),
        ((x_center, 0.0, -(height - wall) / 2.0), (length, width - 2.0 * wall, wall)),
        ((front_x, -(opening + side_strip_width / 2.0), 0.0), (wall, side_strip_width, height - 2.0 * wall)),
        ((front_x, +(opening + side_strip_width / 2.0), 0.0), (wall, side_strip_width, height - 2.0 * wall)),
        ((front_x, 0.0, +(opening + cap_strip_height / 2.0)), (wall, 2.0 * opening, cap_strip_height)),
        ((front_x, 0.0, -(opening + cap_strip_height / 2.0)), (wall, 2.0 * opening, cap_strip_height)),
    ]
    vertices, faces = box_mesh_data(boxes)
    obj = create_mesh_object("kiln_head_hood", vertices, faces, collection, (materials["hood"],))
    add_bevel(obj, 0.035, 2)
    obj["spec_axial_length_m"] = length
    obj["spec_width_m"] = width
    obj["spec_height_m"] = height
    obj["assumption_wall_thickness_m"] = wall
    obj["assumption_x_range_m"] = [HEAD_HOOD_X_MIN_M, HEAD_HOOD_X_MAX_M]
    return obj


def build_burner(
    collection: bpy.types.Collection,
    materials: dict[str, bpy.types.Material],
) -> bpy.types.Object:
    """Build the 10 m burner with exactly 8 m inserted into the kiln."""

    external_length = BURNER_LENGTH_M - BURNER_INSERTION_M
    x_start = -external_length
    x_end = BURNER_INSERTION_M
    obj = create_axis_cylinder(
        "burner",
        (x_start + x_end) / 2.0,
        0.0,
        0.0,
        BURNER_DIAMETER_M / 2.0,
        BURNER_LENGTH_M,
        collection,
        materials["burner"],
        vertices=96,
    )
    obj["spec_length_m"] = BURNER_LENGTH_M
    obj["spec_diameter_m"] = BURNER_DIAMETER_M
    obj["spec_insertion_m"] = BURNER_INSERTION_M
    obj["derived_external_length_m"] = external_length
    return obj


def build_tail_chamber(
    collection: bpy.types.Collection,
    materials: dict[str, bpy.types.Material],
) -> bpy.types.Object:
    """Build the simplified tail smoke chamber with an open kiln-facing side."""

    length = TAIL_CHAMBER_AXIAL_LENGTH_M
    width = TAIL_CHAMBER_WIDTH_M
    height = TAIL_CHAMBER_HEIGHT_M
    wall = ENCLOSURE_WALL_THICKNESS_M
    x_center = (TAIL_CHAMBER_X_MIN_M + TAIL_CHAMBER_X_MAX_M) / 2.0
    far_x = TAIL_CHAMBER_X_MAX_M - wall / 2.0
    boxes = [
        ((x_center, -(width - wall) / 2.0, 0.0), (length, wall, height)),
        ((x_center, +(width - wall) / 2.0, 0.0), (length, wall, height)),
        ((x_center, 0.0, +(height - wall) / 2.0), (length, width - 2.0 * wall, wall)),
        ((x_center, 0.0, -(height - wall) / 2.0), (length, width - 2.0 * wall, wall)),
        ((far_x, 0.0, 0.0), (wall, width - 2.0 * wall, height - 2.0 * wall)),
    ]
    vertices, faces = box_mesh_data(boxes)
    obj = create_mesh_object(
        "kiln_tail_smoke_chamber", vertices, faces, collection, (materials["hood"],)
    )
    add_bevel(obj, 0.035, 2)
    obj["spec_axial_length_m"] = length
    obj["spec_width_m"] = width
    obj["spec_height_m"] = height
    obj["assumption_wall_thickness_m"] = wall
    obj["assumption_x_range_m"] = [TAIL_CHAMBER_X_MIN_M, TAIL_CHAMBER_X_MAX_M]
    return obj


def aim_object(obj: bpy.types.Object, target: Vector) -> None:
    """Aim a camera or spotlight along local -Z with local Y as up."""

    direction = target - obj.location
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


def build_camera_and_lighting(collection: bpy.types.Collection) -> bpy.types.Camera:
    """Create one camera and a deterministic three-point area-light rig."""

    scene = bpy.context.scene
    target = axis_point(KILN_LENGTH_M * 0.52)
    target.z += 0.3

    camera_data = bpy.data.cameras.new("kiln_camera_data")
    camera = bpy.data.objects.new("kiln_camera", camera_data)
    collection.objects.link(camera)
    camera.location = Vector((37.0, -98.0, 36.0))
    camera_data.lens = 53.0
    camera_data.clip_start = 0.1
    camera_data.clip_end = 500.0
    aim_object(camera, target)
    scene.camera = camera

    light_specs = (
        ("key_light", (11.0, -28.0, 45.0), 11800.0, 24.0, (1.0, 0.92, 0.82)),
        ("fill_light", (35.0, 24.0, 29.0), 7200.0, 26.0, (0.76, 0.84, 1.0)),
        ("rim_light", (65.0, -4.0, 39.0), 8200.0, 20.0, (1.0, 0.70, 0.48)),
    )
    for name, location, energy, size, color in light_specs:
        light_data = bpy.data.lights.new(f"{name}_data", type="AREA")
        light_data.energy = energy
        light_data.shape = "DISK"
        light_data.size = size
        light_data.color = color
        light = bpy.data.objects.new(name, light_data)
        collection.objects.link(light)
        light.location = Vector(location)
        aim_object(light, target)
    return camera_data


def configure_scene(render_path: Path) -> None:
    """Set metric units, render engine, image settings, and color management."""

    scene = bpy.context.scene
    # Keep the requested output directory clean during deterministic rebuilds;
    # the script itself is the reproducible source, so .blend1 backups add no
    # recovery value to this headless generation step.
    bpy.context.preferences.filepaths.save_version = 0
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.length_unit = "METERS"
    scene.unit_settings.scale_length = 1.0
    # Blender 5.1 exposes the Eevee engine identifier as BLENDER_EEVEE.
    scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = RENDER_RESOLUTION_X
    scene.render.resolution_y = RENDER_RESOLUTION_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.film_transparent = False
    scene.render.filepath = str(render_path)
    scene.render.use_file_extension = True
    scene.render.image_settings.compression = 25
    scene.render.fps = 30

    if scene.world is None:
        scene.world = bpy.data.worlds.new("KilnWorld")
    scene.world.use_nodes = True
    background = scene.world.node_tree.nodes.get("Background")
    if background is not None:
        background.inputs["Color"].default_value = (0.024, 0.027, 0.026, 1.0)
        background.inputs["Strength"].default_value = 0.46
    try:
        scene.view_settings.look = "AgX - Medium High Contrast"
        scene.view_settings.exposure = 0.65
    except TypeError:
        pass


def object_vertices_in_kiln_local(obj: bpy.types.Object) -> list[Vector]:
    """Return evaluated object vertices transformed back into kiln-local space."""

    inverse_rotation = LOCAL_TO_WORLD_ROTATION.inverted()
    local_vertices: list[Vector] = []
    for vertex in obj.data.vertices:
        world = obj.matrix_world @ vertex.co
        world.z -= AXIS_HEAD_Z_M
        local_vertices.append(inverse_rotation @ world)
    return local_vertices


def local_bounds(obj: bpy.types.Object) -> tuple[Vector, Vector]:
    """Return minimum and maximum kiln-local coordinates for a mesh object."""

    vertices = object_vertices_in_kiln_local(obj)
    minimum = Vector((min(v.x for v in vertices), min(v.y for v in vertices), min(v.z for v in vertices)))
    maximum = Vector((max(v.x for v in vertices), max(v.y for v in vertices), max(v.z for v in vertices)))
    return minimum, maximum


def radial_range(obj: bpy.types.Object) -> tuple[float, float]:
    """Return minimum and maximum distance from the kiln axis for a mesh."""

    radii = [math.hypot(v.y, v.z) for v in object_vertices_in_kiln_local(obj)]
    return min(radii), max(radii)


def assert_close(label: str, actual: float, expected: float, tolerance: float = 1e-5) -> None:
    """Raise a dimension-specific error rather than silently accepting drift."""

    if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=tolerance):
        raise RuntimeError(f"{label}: expected {expected}, got {actual}")


def validate_scene(collections: dict[str, bpy.types.Collection]) -> dict[str, object]:
    """Fail closed when required structure, names, counts, or dimensions drift."""

    required_objects = {
        "kiln_shell",
        "tyre_1",
        "tyre_2",
        "tyre_3",
        "girth_gear",
        "support_roller_1_1",
        "support_roller_1_2",
        "support_roller_2_1",
        "support_roller_2_2",
        "support_roller_3_1",
        "support_roller_3_2",
        "foundation_1",
        "foundation_2",
        "foundation_3",
        "kiln_head_hood",
        "burner",
        "kiln_tail_smoke_chamber",
        "kiln_camera",
        "key_light",
        "fill_light",
        "rim_light",
    }
    actual_objects = {obj.name for obj in bpy.data.objects}
    missing = sorted(required_objects - actual_objects)
    if missing:
        raise RuntimeError(f"Missing required objects: {missing}")

    if len([name for name in actual_objects if name.startswith("tyre_")]) != 3:
        raise RuntimeError("Tyre object count is not 3")
    if len([name for name in actual_objects if name.startswith("support_roller_")]) != 6:
        raise RuntimeError("Support-roller object count is not 6")
    if len([name for name in actual_objects if name.startswith("foundation_")]) != 3:
        raise RuntimeError("Foundation object count is not 3")

    expected_collection_counts = {
        "body": 1,
        "tyres": 3,
        "gear": 1,
        "supports": 6,
        "foundations": 3,
        "head": 2,
        "tail": 1,
        "lighting": 4,
    }
    for key, expected in expected_collection_counts.items():
        actual = len(collections[key].objects)
        if actual != expected:
            raise RuntimeError(f"Collection {collections[key].name}: expected {expected}, got {actual}")

    shell = bpy.data.objects["kiln_shell"]
    exact_checks = {
        "shell_inner_diameter_m": (float(shell["spec_inner_diameter_m"]), KILN_INNER_DIAMETER_M),
        "shell_length_m": (float(shell["spec_length_m"]), KILN_LENGTH_M),
        "shell_slope_percent": (float(shell["spec_slope_percent"]), KILN_SLOPE * 100.0),
        "gear_outer_diameter_m": (
            float(bpy.data.objects["girth_gear"]["spec_outer_diameter_m"]),
            GEAR_OUTER_DIAMETER_M,
        ),
        "burner_insertion_m": (
            float(bpy.data.objects["burner"]["spec_insertion_m"]),
            BURNER_INSERTION_M,
        ),
    }
    for label, (actual, expected) in exact_checks.items():
        assert_close(label, actual, expected, tolerance=1e-9)

    # Verify real mesh vertices, not only metadata/custom properties.
    shell_min, shell_max = local_bounds(shell)
    shell_min_radius, shell_max_radius = radial_range(shell)
    assert_close("mesh.shell.length_m", shell_max.x - shell_min.x, KILN_LENGTH_M)
    assert_close("mesh.shell.inner_radius_m", shell_min_radius, KILN_INNER_DIAMETER_M / 2.0)
    assert_close(
        "mesh.shell.max_outer_radius_m",
        shell_max_radius,
        KILN_INNER_DIAMETER_M / 2.0 + SHELL_WALL_THICKNESS_AT_TYRE_M,
    )
    shell_radii = {
        round(math.hypot(vertex.y, vertex.z), 6)
        for vertex in object_vertices_in_kiln_local(shell)
    }
    for expected_radius in (
        KILN_INNER_DIAMETER_M / 2.0,
        KILN_INNER_DIAMETER_M / 2.0 + SHELL_WALL_THICKNESS_M,
        KILN_INNER_DIAMETER_M / 2.0 + SHELL_WALL_THICKNESS_AT_TYRE_M,
    ):
        if round(expected_radius, 6) not in shell_radii:
            raise RuntimeError(f"mesh.shell missing radius {expected_radius}")

    for station, position in enumerate(TYRE_POSITIONS_M, start=1):
        tyre = bpy.data.objects[f"tyre_{station}"]
        tyre_min, tyre_max = local_bounds(tyre)
        tyre_inner, tyre_outer = radial_range(tyre)
        assert_close(f"mesh.tyre_{station}.center_m", (tyre_min.x + tyre_max.x) / 2.0, position)
        assert_close(f"mesh.tyre_{station}.width_m", tyre_max.x - tyre_min.x, TYRE_WIDTH_M)
        assert_close(f"mesh.tyre_{station}.inner_radius_m", tyre_inner, TYRE_INNER_DIAMETER_M / 2.0)
        assert_close(f"mesh.tyre_{station}.outer_radius_m", tyre_outer, TYRE_OUTER_DIAMETER_M / 2.0)

    gear = bpy.data.objects["girth_gear"]
    gear_min, gear_max = local_bounds(gear)
    _, gear_outer = radial_range(gear)
    assert_close("mesh.gear.center_m", (gear_min.x + gear_max.x) / 2.0, GEAR_POSITION_M)
    assert_close("mesh.gear.width_m", gear_max.x - gear_min.x, GEAR_WIDTH_M)
    assert_close("mesh.gear.outer_radius_m", gear_outer, GEAR_OUTER_RADIUS_M)

    for station in range(1, 4):
        left = bpy.data.objects[f"support_roller_{station}_1"]
        right = bpy.data.objects[f"support_roller_{station}_2"]
        assert_close(
            f"mesh.roller_station_{station}.center_distance_m",
            abs(right.location.y - left.location.y),
            ROLLER_CENTER_DISTANCE_M,
        )
        for roller in (left, right):
            roller_min, roller_max = local_bounds(roller)
            assert_close(f"mesh.{roller.name}.length_m", roller_max.x - roller_min.x, ROLLER_LENGTH_M)
            assert_close(f"mesh.{roller.name}.diameter_m", roller_max.y - roller_min.y, ROLLER_DIAMETER_M)

        foundation = bpy.data.objects[f"foundation_{station}"]
        foundation_min, foundation_max = local_bounds(foundation)
        assert_close(
            f"mesh.foundation_{station}.axial_length_m",
            foundation_max.x - foundation_min.x,
            FOUNDATION_AXIAL_LENGTH_M,
        )
        assert_close(
            f"mesh.foundation_{station}.width_m",
            foundation_max.y - foundation_min.y,
            FOUNDATION_TRANSVERSE_WIDTH_M,
        )
        assert_close(
            f"mesh.foundation_{station}.height_m",
            foundation_max.z - foundation_min.z,
            FOUNDATION_HEIGHT_M,
        )

    for object_name, expected_dimensions in (
        (
            "kiln_head_hood",
            (HEAD_HOOD_AXIAL_LENGTH_M, HEAD_HOOD_WIDTH_M, HEAD_HOOD_HEIGHT_M),
        ),
        (
            "kiln_tail_smoke_chamber",
            (TAIL_CHAMBER_AXIAL_LENGTH_M, TAIL_CHAMBER_WIDTH_M, TAIL_CHAMBER_HEIGHT_M),
        ),
    ):
        bound_min, bound_max = local_bounds(bpy.data.objects[object_name])
        actual_dimensions = (
            bound_max.x - bound_min.x,
            bound_max.y - bound_min.y,
            bound_max.z - bound_min.z,
        )
        for axis, actual, expected in zip("XYZ", actual_dimensions, expected_dimensions):
            assert_close(f"mesh.{object_name}.{axis}_m", actual, expected)

    burner_min, burner_max = local_bounds(bpy.data.objects["burner"])
    assert_close("mesh.burner.length_m", burner_max.x - burner_min.x, BURNER_LENGTH_M)
    assert_close("mesh.burner.diameter_y_m", burner_max.y - burner_min.y, BURNER_DIAMETER_M)
    assert_close("mesh.burner.insertion_end_m", burner_max.x, BURNER_INSERTION_M)

    for mesh_object in (obj for obj in bpy.data.objects if obj.type == "MESH"):
        if not mesh_object.data.vertices or not mesh_object.data.polygons:
            raise RuntimeError(f"Redundant/empty mesh object: {mesh_object.name}")

    required_materials = {
        "MAT_SteelShell",
        "MAT_TyreSteel",
        "MAT_GearSteel",
        "MAT_Refractory",
        "MAT_Concrete",
    }
    if not required_materials.issubset(set(bpy.data.materials.keys())):
        raise RuntimeError("Required PBR material set is incomplete")
    if bpy.context.scene.unit_settings.system != "METRIC":
        raise RuntimeError("Scene unit system is not METRIC")

    return {
        "object_count": len(bpy.data.objects),
        "mesh_object_count": len([obj for obj in bpy.data.objects if obj.type == "MESH"]),
        "tyre_count": 3,
        "support_roller_count": 6,
        "foundation_count": 3,
        "collection_count": len(collections) - 1,
        "material_count": len(bpy.data.materials),
        "unit_system": bpy.context.scene.unit_settings.system,
        "shell_inner_diameter_m": KILN_INNER_DIAMETER_M,
        "shell_length_m": KILN_LENGTH_M,
        "slope_percent": KILN_SLOPE * 100.0,
        "mesh_verified_shell_length_m": round(shell_max.x - shell_min.x, 6),
        "mesh_verified_shell_inner_diameter_m": round(shell_min_radius * 2.0, 6),
        "mesh_verified_shell_max_outer_diameter_m": round(shell_max_radius * 2.0, 6),
        "tyre_actual_radial_thickness_m": TYRE_ACTUAL_RADIAL_THICKNESS_M,
    }


def canonical_scene_signature() -> str:
    """Hash deterministic scene content while excluding BLEND session metadata."""

    def rounded(values: Iterable[float]) -> list[float]:
        return [round(float(value), 8) for value in values]

    def normalize_property(value: object) -> object:
        if isinstance(value, (str, bool, int, float)):
            return value
        try:
            return [normalize_property(item) for item in value]  # type: ignore[arg-type]
        except TypeError:
            return str(value)

    records: list[dict[str, object]] = []
    for obj in sorted(bpy.data.objects, key=lambda item: item.name):
        record: dict[str, object] = {
            "name": obj.name,
            "type": obj.type,
            "matrix_world": rounded(value for row in obj.matrix_world for value in row),
            "collections": sorted(collection.name for collection in obj.users_collection),
            "properties": {
                key: normalize_property(obj[key])
                for key in sorted(obj.keys())
                if not key.startswith("_")
            },
        }
        if obj.type == "MESH":
            record["vertices"] = [rounded(vertex.co) for vertex in obj.data.vertices]
            record["faces"] = [list(polygon.vertices) for polygon in obj.data.polygons]
            record["face_materials"] = [polygon.material_index for polygon in obj.data.polygons]
            record["materials"] = [
                slot.material.name if slot.material else None for slot in obj.material_slots
            ]
            record["modifiers"] = [
                {
                    "name": modifier.name,
                    "type": modifier.type,
                    "width": round(float(getattr(modifier, "width", 0.0)), 8),
                    "segments": int(getattr(modifier, "segments", 0)),
                }
                for modifier in obj.modifiers
            ]
        elif obj.type == "CAMERA":
            record["camera"] = {
                "lens": round(float(obj.data.lens), 8),
                "clip_start": round(float(obj.data.clip_start), 8),
                "clip_end": round(float(obj.data.clip_end), 8),
            }
        elif obj.type == "LIGHT":
            record["light"] = {
                "light_type": obj.data.type,
                "energy": round(float(obj.data.energy), 8),
                "color": rounded(obj.data.color),
                "size": round(float(getattr(obj.data, "size", 0.0)), 8),
            }

        records.append(record)

    material_records = []
    for material in sorted(bpy.data.materials, key=lambda item: item.name):
        principled = material.node_tree.nodes.get("Principled BSDF") if material.node_tree else None
        material_records.append(
            {
                "name": material.name,
                "base_color": rounded(principled.inputs["Base Color"].default_value) if principled else [],
                "metallic": round(float(principled.inputs["Metallic"].default_value), 8) if principled else None,
                "roughness": round(float(principled.inputs["Roughness"].default_value), 8) if principled else None,
            }
        )

    payload = {
        "unit_system": bpy.context.scene.unit_settings.system,
        "scale_length": bpy.context.scene.unit_settings.scale_length,
        "objects": records,
        "materials": material_records,
    }
    serialized = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def build_scene(render_path: Path) -> dict[str, object]:
    """Build the entire Phase 1 scene and return validation evidence."""

    clear_scene()
    collections = create_collections()
    materials = create_materials()
    configure_scene(render_path)

    build_shell(collections["body"], materials)
    build_tyres(collections["tyres"], materials)
    build_girth_gear(collections["gear"], materials)
    build_support_rollers(collections["supports"], materials)
    build_foundations(collections["foundations"], materials)
    build_head_hood(collections["head"], materials)
    build_burner(collections["head"], materials)
    build_tail_chamber(collections["tail"], materials)
    build_camera_and_lighting(collections["lighting"])
    bpy.context.view_layer.update()
    return validate_scene(collections)


def main() -> None:
    """Build, validate, save, export, render, and print machine-readable evidence."""

    args = parse_args()
    export_path, blend_path, render_path = resolve_outputs(args)
    evidence = build_scene(render_path)
    evidence["scene_sha256"] = canonical_scene_signature()

    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path), check_existing=False, compress=False)
    bpy.ops.export_scene.gltf(
        filepath=str(export_path),
        export_format="GLB",
        export_apply=True,
        export_yup=True,
        export_cameras=True,
        export_lights=True,
        export_materials="EXPORT",
    )
    bpy.context.scene.render.filepath = str(render_path)
    bpy.ops.render.render(write_still=True)

    print("PHASE1_BUILD_OK")
    for key in sorted(evidence):
        print(f"CHECK {key}={evidence[key]}")
    print(f"OUTPUT blend={blend_path}")
    print(f"OUTPUT glb={export_path}")
    print(f"OUTPUT render={render_path}")


if __name__ == "__main__":
    main()
