# 开发记录

## 2026-07-14 — PHASE 1

- 目标：以用户提供的《技术规格》为唯一事实来源，生成可无界面重建的回转窑 Blender 模型。
- 范围：`model/build_kiln.py`、`model/kiln.blend`、`model/kiln.glb`、`model/render.png` 及 PHASE 1 验收证据。
- 非目标：Three.js、DXF、最终交付整理。
- 关键决策：用户批准 `1A 2A 3A 4A`；轮带尺寸冲突采用选项 A 解决，保持 4.9 m 外径并令实体径向厚度为 0.41 m。
- 风险控制：所有未给定的表现参数在 `MODEL_PARAMETERS.md` 标为 `[假设]`；脚本先清场再构建并内置 fail-closed 自检。
- 实现结果：生成 21 个场景对象，其中 17 个 Mesh；包含 3 个轮带、6 个托轮、3 个基础、1 个 200 齿外观齿圈、窑头罩、燃烧器和窑尾烟室。
- 验证结果：实际 Mesh 顶点反算、`.blend` 重新打开、`.glb` 清场重导入和视觉 QA 均通过。两次完整重建的源场景 canonical signature 一致；两份 GLB 重导入后的内容 signature 一致；两张 PNG 解码像素完全相同。
- 修复记录：首轮 Blender 5.1 的 Eevee engine identifier 不兼容，已由 `BLENDER_EEVEE_NEXT` 修正为 `BLENDER_EEVEE`；首轮构图过暗且端部略裁切，已调整固定相机和三点布光。
- 测试夹具记录：首次 GLB 重导入计数包含 factory-startup 默认 Cube，清空默认场景后验证交付 GLB 为准确的 17 个 Mesh。
- 确定性测试记录：最初使用文件容器 SHA 判断所有产物一致并不严谨，因为 `.blend` 含内部会话数据，GLB/PNG 容器也可能有非内容差异；已改用 canonical scene/content signature 和 PNG 解码像素比较。`LC_ALL=C` 仅用于修复本机 `shasum` locale，不再传给 Blender，以免改变 Eevee headless 渲染结果。
- 已知限制：GLB 导出器不支持 Blender Area Light，三点布光完整保留在 `.blend` 并用于 `render.png`，GLB 保留模型、材质和相机但不包含三盏 Area Light。
- 视觉优化：收到“塑料感”反馈后，提高钢材粗糙度，加入确定性程序化色差与微表面凹凸；混凝土使用独立颗粒尺度；三点光改为更克制的中性工业光。主几何和规格参数未改变。

## 2026-07-14 — PHASE 2

- 目标：生成与 PHASE 1 数值一致、双击可运行的 Three.js 单文件样机。
- 实现：Three.js r185 和 OrbitControls 通过 esbuild 完全内联；程序化建立筒体、轮带、200 齿 InstancedMesh、托轮、基础、罩体、燃烧器、烟室和四段温度带。
- 控制：开始/暂停、0.4–4.0 r/min、剖切、火焰、视角复位；支持 reduced-motion、ARIA 和响应式布局。
- 事实边界：四段长度未给，按四等分做 `[演示假设]`，界面常驻披露；只显示已给出的 1450 ℃峰值。
- 性能：Metal 路径 120 帧样本约 119.99 fps；软件路径自动关闭阴影、降低内部像素比，同机约 42.48 fps。
- 验证：`file://` 与 HTTP 两种打开方式均通过 Playwright；无外部脚本、console error 或 page error。

## 2026-07-14 — PHASE 3

- 目标：生成 R2018、mm、A1、1:100 的回转窑 GA DXF。
- 实现：纵向立面、A-A 轮带支撑断面、七个业务图层、十个 DIMENSION、A1 图框/标题栏和 paperspace viewport。
- 事实边界：耐火层厚度未给，只标内表面材料界面；标题栏审核状态为 PENDING。
- 验证：保存后重新打开，audit 0；逐层计数；十项实测与规格完全一致；内容签名 `6ba3d45afdb0bd15d626921c072b6e23e63dbe7e51c777c912edbd330d0aaccb`。
- 预览：使用 ezdxf drawing add-on 渲染 A1 图纸空间，输出 2977 × 2104 PNG。

## 2026-07-14 — PHASE 4

- 整理 `/model /web /drawing /docs`，保留工作区内原有无关目录不动。
- 新增 README、完整验收自检表、CHANGELOG、图层说明、30 秒和 3 分钟演示脚本。
- 进行最终跨产物规格、再生成、浏览器和 DXF 回归。
- 当前状态：1.0.0 最终交付通过；工程审核签字仍为 PENDING。
