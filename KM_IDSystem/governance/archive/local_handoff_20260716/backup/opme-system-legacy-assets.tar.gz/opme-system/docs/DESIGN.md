---
name: Kiln Digital Delivery
description: A restrained industrial control surface for inspecting and demonstrating a rotary kiln digital twin.
colors:
  control-bg: "oklch(0.105 0 0)"
  control-surface: "oklch(0.165 0.012 113)"
  control-surface-raised: "oklch(0.215 0.016 113)"
  control-ink: "oklch(0.94 0.012 113)"
  control-muted: "oklch(0.71 0.018 113)"
  safety-olive: "oklch(0.78 0.16 113)"
  kiln-heat: "oklch(0.50 0.18 38)"
  divider: "oklch(0.31 0.014 113)"
typography:
  title:
    fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif"
    fontSize: "24px"
    fontWeight: 650
    lineHeight: 1.15
    letterSpacing: "-0.02em"
  body:
    fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif"
    fontSize: "14px"
    fontWeight: 450
    lineHeight: 1.5
  label:
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace"
    fontSize: "12px"
    fontWeight: 600
    lineHeight: 1.2
rounded:
  sm: "6px"
  md: "10px"
spacing:
  xs: "6px"
  sm: "10px"
  md: "16px"
  lg: "24px"
components:
  control-button:
    backgroundColor: "{colors.control-surface-raised}"
    textColor: "{colors.control-ink}"
    rounded: "{rounded.sm}"
    padding: "9px 12px"
  control-button-active:
    backgroundColor: "{colors.safety-olive}"
    textColor: "{colors.control-bg}"
    rounded: "{rounded.sm}"
    padding: "9px 12px"
  spec-chip:
    backgroundColor: "{colors.control-surface}"
    textColor: "{colors.control-ink}"
    rounded: "{rounded.sm}"
    padding: "6px 9px"
---

# Design System: Kiln Digital Delivery

## Overview

**Creative North Star: "Shift-change kiln control room"**

界面服务于昏暗会议室和厂区评审屏：三维设备占据视觉主体，控制与数据贴近边缘，像可靠仪表而不是营销网页。重量感来自哑光金属、混凝土、热色与受控光照。禁止塑料镜面、霓虹科幻和卡片堆叠。

**Key Characteristics:**

- 设备优先，UI 不遮挡关键几何。
- 单一安全橄榄色承担交互状态，热橙只表示温度与燃烧。
- 结构性分隔优于浮动阴影，短促状态过渡优于装饰动画。

## Colors

近黑控制背景承载三维场景，安全橄榄色用于可操作状态，窑炉热橙只用于工艺热区。

**The Instrument Color Rule.** 安全橄榄色只用于当前选择、主要控制和焦点，不用于装饰。

**The Heat Means Heat Rule.** 热橙只能代表火焰、烧成带和高温状态。

## Typography

**Display Font:** Inter（系统无此字体时回退到 `system-ui`）  
**Body Font:** Inter / system-ui  
**Label/Mono Font:** SFMono-Regular / Menlo / monospace

标题保持紧凑、可信；参数与状态使用等宽标签，便于快速核对数字。正文不超过 70ch。

**The No-Theatre Type Rule.** 禁止超大展示标题和无意义全大写眉题；这是操作样机，不是发布会海报。

## Elevation

默认采用平面与色阶分层。只有控制条使用轻微结构阴影以脱离 WebGL 画面，不使用宽模糊“幽灵卡片”阴影。

**The Flat Instrument Rule.** 静态表面保持平整；焦点和激活状态通过颜色、描边和短距离位移表达。

## Components

### Buttons

- **Shape:** 小型工程控制键（6px 圆角）。
- **Primary:** 激活时使用安全橄榄色；未激活时使用抬升控制面。
- **Hover / Focus:** 160ms 状态过渡；键盘焦点使用 2px 外轮廓。

### Chips

- **Style:** 紧凑规格标签，等宽数字，低对比背景。
- **State:** 只读，不伪装成可点击按钮。

### Cards / Containers

- **Corner Style:** 最大 10px。
- **Background:** 控制表面色；避免透明玻璃层叠。
- **Shadow Strategy:** 仅控制条允许小于 8px 模糊的结构阴影。

### Inputs / Fields

- **Style:** 原生范围输入，橄榄色轨道进度，明确数值输出。
- **Focus:** 2px 高对比轮廓；不隐藏浏览器键盘焦点。

### Navigation

本阶段没有页面导航。所有控制处于单一底部操作区，保持一屏演示闭环。

## Do's and Don'ts

### Do:

- **Do** 让设备占据至少 70% 可视面积。
- **Do** 使用 `prefers-reduced-motion` 停止非必要旋转和过渡。
- **Do** 让每个按钮状态同时通过文字和颜色表达。
- **Do** 保持所有规格值与模型参数源一致。

### Don't:

- **Don't** 制作“玩具般的塑料 PBR”。
- **Don't** 使用“泛化深色 SaaS 仪表盘”的浮动卡片、紫色霓虹或玻璃模糊。
- **Don't** 添加“科幻控制室噪声”的装饰刻度和闪烁状态。
- **Don't** 用漂亮但不可核验的模型替代规格事实。
