# PHASE 3 AutoCAD DXF 总装图报告

## 交付结果

- `drawing/gen_dxf.py` 使用 ezdxf 1.4.4 从空文档确定性建立总装图。
- `drawing/kiln_GA.dxf` 为 AutoCAD R2018 DXF，模型空间单位 mm；图纸空间为 A1 横式 841 × 594 mm，viewport 为 1:100。
- 纵向立面图包含 60 m 筒体、三档轮带/托轮/基础、大齿圈、窑头罩、燃烧器和窑尾烟室。
- A-A 断面位于第一档轮带，显示 Φ4900 轮带、轮带处 40 mm 筒体、Φ4000 内径、两只 Φ1400 托轮、3200 中心距和 6000 × 3000 基础断面。
- 规格未给耐火内衬厚度，因此断面只标内表面材料界面，并明确写出“不生成厚度几何”。
- A1 图框标题栏包含图名、图号 `KILN-GA-001`、比例、单位、生成日期、设计/审核状态；审核栏保持 `PENDING`，未伪造人工审核。

## 真实 DIMENSION 交叉验证

脚本保存后重新打开 DXF，执行 audit 并从带 `KILN_SPEC` XDATA 的 DIMENSION 实体读取测量值：

| 尺寸 | 实测 | 规格 | 结果 |
|---|---:|---:|---|
| 窑体总长 | 60000 mm | 60000 mm | 通过 |
| 窑头至轮带 1 | 12000 mm | 12000 mm | 通过 |
| 轮带 1–2 | 21000 mm | 21000 mm | 通过 |
| 轮带 2–3 | 18000 mm | 18000 mm | 通过 |
| 轮带 3 至窑尾 | 9000 mm | 9000 mm | 通过 |
| 窑头至齿圈 | 22000 mm | 22000 mm | 通过 |
| 燃烧器总长 | 10000 mm | 10000 mm | 通过 |
| 窑体内径 | 4000 mm | 4000 mm | 通过 |
| 轮带外径 | 4900 mm | 4900 mm | 通过 |
| 托轮中心距 | 3200 mm | 3200 mm | 通过 |

## 实体与图层统计

```text
audit_error_count = 0
GA_OUTLINE = 35 modelspace entities
GA_CENTER = 8 modelspace entities
GA_DIMENSIONS = 10 modelspace DIMENSION entities
GA_TEXT = 19 modelspace entities
GA_HATCH = 2 modelspace entities
GA_BORDER_TITLE = 20 paperspace entities
GA_VIEWPORT = 1 paperspace entity
canonical content signature = 6ba3d45afdb0bd15d626921c072b6e23e63dbe7e51c777c912edbd330d0aaccb
```

完整颜色、线型和线宽见 `drawing/LAYER_LIST.md`。

## PHASE 3 自检表

| 验收项 | 结果 | 说明 |
|---|---|---|
| mm 单位、规范图层/线型/线宽 | 通过 | `$INSUNITS=4`；七个业务图层全部存在。 |
| 纵向立面图 | 通过 | 主设备、三档支撑、头尾装置齐全。 |
| A-A 筒体/内衬断面 | 通过 | 轮带与筒体实体剖面完整；内衬厚度未给，按材料界面明示。 |
| 1:100 与 A1 图框标题栏 | 通过 | 500 mm 纸面 viewport 对应 50000 mm 模型高度；标题栏字段齐全。 |
| 完整尺寸与斜度标注 | 通过 | 10 个真实 DIMENSION 实体；3.5% 斜度文字和方向标注。 |
| 预览 PNG | 通过 | 2977 × 2104 RGBA，渲染 A1 图纸空间和 viewport。 |
| 确定性、注释和规格同源 | 通过 | 参数集中；内容签名稳定；未给定项显式说明。 |
| 重开统计与关键尺寸交叉验证 | 通过 | audit 0 错误，逐层计数和 10 项实测全部通过。 |
