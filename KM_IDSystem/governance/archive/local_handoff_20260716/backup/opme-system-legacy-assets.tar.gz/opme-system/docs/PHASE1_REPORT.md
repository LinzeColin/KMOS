# PHASE 1 回转窑 Blender 模型报告

## 我做了什么

- 编写 `model/build_kiln.py`，所有规格参数集中在文件顶部，运行前清空场景，确定性重建完整回转窑。
- 分函数建立窑体、三档轮带、大齿圈、六个托轮、三座基础、窑头罩、燃烧器和窑尾烟室。
- 使用 `kiln_shell`、`tyre_1`、`girth_gear` 等稳定名称，并放入 8 个分类 Collection 和 1 个根 Collection。
- 创建钢筒、轮带钢、齿轮钢、耐火内衬、混凝土、罩体钢和燃烧器钢共 7 个 PBR 材质；根据反馈增加程序化粗糙度、微表面凹凸与轻微色差，降低均匀高光造成的塑料感。
- 创建 1 台相机和 Key / Fill / Rim 三点面积光，使用克制的暖主光/冷填充/轮廓光生成 1920 × 1080 渲染图。
- 使用 Blender 5.1.2 无界面生成 `kiln.blend`、`kiln.glb` 和 `render.png`。

## 参数取值

完整参数和 `[假设]` 见 `MODEL_PARAMETERS.md`。关键规格如下：

| 部件 | 本阶段采用值 |
|---|---|
| 窑体 | 内径 4.0 m；长 60 m；斜度 3.5%；普通壁厚 0.025 m；轮带段壁厚 0.040 m |
| 轮带 | 3 个；位置 12 / 33 / 51 m；外径 4.9 m；宽 1.0 m；实体径向厚度 0.41 m（用户批准选项 A） |
| 大齿圈 | 位置 22 m；外径 4.6 m；宽 0.7 m；200 个外观齿 |
| 托轮 | 每档 2 个；中心距 3.2 m；直径 1.4 m；长 1.0 m |
| 基础 | 每档 1 座；高 3.0 m × 轴向长 5.0 m × 横向宽 6.0 m |
| 窑头罩 | 轴向 6.0 m × 宽 7.5 m × 高 7.5 m |
| 燃烧器 | 长 10 m；直径 0.9 m；窑内段 8 m；窑外段 2 m |
| 窑尾烟室 | 轴向 7.0 m × 宽 7.0 m × 高 8.0 m |

## 执行命令

```bash
/Applications/Blender.app/Contents/MacOS/Blender \
  --background --python model/build_kiln.py -- --export model/kiln.glb
```

也可在 `blender` 已加入 PATH 的环境执行用户指定命令：

```bash
blender --background --python model/build_kiln.py -- --export model/kiln.glb
```

## PHASE 1 自检表

| 第 6 节模型验收项 | 结果 | 证据与说明 |
|---|---|---|
| ① 主尺寸与规格一致，参数驱动、零误差 | 通过 | 全部输入参数集中定义；脚本对实际 Mesh 顶点反算。参数值无偏差；Blender 单精度 Mesh 存储的最大观察误差为 0.000008 m（8 µm）：内径 3.999998 m、长度 60.000008 m、轮带段筒体外径 4.080001 m。 |
| ② 单位米；命名规范；Collection 分组 | 通过 | Scene unit=`METRIC`、scale=1；21 个对象使用稳定名称；8 个分类 Collection + 根 Collection。 |
| ③ 无冗余几何、材质合理、可 headless 重跑再生 | 通过 | 17 个非空 Mesh，无空对象/重复占位几何；7 个 PBR 材质；两次相同 headless 命令成功，场景/GLB canonical signature 一致，PNG 解码像素完全一致。 |
| ④ 未给定项显式标注 `[假设]`，不得静默编造 | 通过 | 耐火层实体厚度、罩体板厚、齿圈齿根/内孔、绝对标高、相机与灯光等均在代码和 `MODEL_PARAMETERS.md` 明示。 |

## 结构自检结果

```text
PHASE1_BUILD_OK
objects=21
mesh_objects=17
collections=9（根 1 + 分类 8）
materials=7
tyres=3
support_rollers=6
foundations=3
unit_system=METRIC
BLEND_REOPEN_OK
GLB_REIMPORT_OK meshes=17 rollers=6 foundations=3
```

## 确定性证据

两次相同命令分别从空场景重建：

```text
源场景 canonical SHA-256（两次一致）
4a292dc568847f89a78535cea84e565d1c20f621b3f0cc730006f18d76ce3558

GLB 清场重导入后的 canonical content SHA-256（两次一致）
7c7280224cdca7127221a9f9e970a1a849e4c79fd8e2de22ee778f740ff84593

PNG 解码像素比较
max channel difference = 0
RMS = 0 / 0 / 0
changed pixels = 0 / 2,073,600
```

`.blend`、GLB 和 PNG 文件容器可能包含 Blender 内部会话或非内容型数据，因此不以容器字节摘要作为重复运行的唯一证明；验证依据是实际场景内容、GLB 重导入内容和解码像素。

## 最终文件快照（SHA-256，仅用于交付完整性）

```text
model/build_kiln.py  3fb1dcf57da4595c1c81c343f2dfad37fa2fe8473e6b866bac5c04081f0e281f
model/kiln.blend     ef2f0a02eb9769652c6d71031e4a86b3512d4c38a39565c2233f18cd32c0730e
model/kiln.glb       539bc5f4982a36634bb5e51604f338faa6dfa5a80ed1e6ccd8f2a88b186b6035
model/render.png     96b78ebbb4e41be22179d4b4223a86d161a78844b272a9aeb9ca97706a9bfc49
```

## 已知限制

- Blender glTF 导出器报告不支持导出 `AREA` Light。三点布光完整保存在 `kiln.blend` 并用于 `render.png`；`kiln.glb` 已验证可重新导入，包含模型、材质与相机，但不含三盏 Area Light。
- 当前模型是参数化工业展示模型，不是施工图或工程强度计算模型。
- 本模型是工业展示/总装沟通模型，不替代制造、土建、耐火或结构计算施工图。
