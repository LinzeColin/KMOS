# 完整功能清单

| ID | 阶段 | 功能 | 验收方式 | 状态 |
|---|---|---|---|---|
| P1-01 | Blender | 顶部集中维护全部规格参数 | 代码审查 | 通过 |
| P1-02 | Blender | 参数化筒体及轮带段加厚 | 实际 Mesh 顶点反算 | 通过 |
| P1-03 | Blender | 三档轮带、六托轮、三基础 | 名称/数量/位置/尺寸自检 | 通过 |
| P1-04 | Blender | 200 齿外观大齿圈 | 齿数/外径/位置自检 | 通过 |
| P1-05 | Blender | 窑头罩、燃烧器、窑尾烟室 | 包络和插入长度自检 | 通过 |
| P1-06 | Blender | 工业 PBR、相机和三点光 | 节点/对象/渲染复核 | 通过 |
| P1-07 | Blender | headless BLEND/GLB/PNG 再生 | background 命令与重开 | 通过 |
| P2-01 | Web | Three.js r185 + OrbitControls 单文件离线样机 | file:// / HTTP 浏览器测试 | 通过 |
| P2-02 | Web | 筒体/轮带/齿圈旋转和 0.4–4.0 r/min | 控件与内部状态测试 | 通过 |
| P2-03 | Web | 剖切、四段温度带、火焰、复位 | 自动交互与截图复核 | 通过 |
| P2-04 | Web | 规格浮层、图例、响应式和无障碍 | DOM/ARIA/视口检查 | 通过 |
| P2-05 | Web | 60fps 目标与软件渲染降级 | Metal/SwiftShader 帧采样 | 通过 |
| P3-01 | DXF | R2018、mm、A1、1:100、规范图层 | reopen header/layout/layer 检查 | 通过 |
| P3-02 | DXF | 纵向立面与 A-A 断面 | 实体和预览复核 | 通过 |
| P3-03 | DXF | 10 项真实 DIMENSION 与斜度 | XDATA + get_measurement | 通过 |
| P3-04 | DXF | 标题栏、审核状态和 PNG 预览 | paperspace/文件检查 | 通过 |
| P3-05 | DXF | audit、逐层计数与内容签名 | 自检输出 | 通过 |
| P4-01 | 文档 | 四目录、README、依赖和一键命令 | 目录/文档检查 | 通过 |
| P4-02 | 文档 | 完整验收表、CHANGELOG、3 分钟演示 | 文档检查 | 通过 |
| P4-03 | 总体验收 | 跨产物规格、命名、假设和可再生性 | 最终回归 | 通过 |
