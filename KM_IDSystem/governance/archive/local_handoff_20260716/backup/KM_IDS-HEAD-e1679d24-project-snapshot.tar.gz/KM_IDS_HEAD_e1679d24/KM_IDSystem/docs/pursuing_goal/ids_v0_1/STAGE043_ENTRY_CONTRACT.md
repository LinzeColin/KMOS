# STAGE-043 Phase 1 Entry Contract

## Identity

- Stage: `STAGE-043 · Worker 崩溃恢复`
- Task: `IDS-V0_1-STAGE043-P1`
- Acceptance: `ACC-STAGE-043`
- Local code: `D07-S007`
- Domain: `D07 · 任务编排与机器控制`
- Entrance: `IDS 系统运营入口`
- Contract: `ids.worker_crash_recovery.v0_1.stage043.p1`
- State: `PHASE1_ENGINEERING_CONTRACT_RUNTIME_DISABLED`
- Next gate: `IDS-STAGE043-P2-GATE`

## Goal

Define an executable, testable, and rollback-safe engineering contract for
detecting worker-process loss, preserving durable task identity and state,
classifying legal crash dispositions, and protecting checkpoints and partial
outputs. Phase 1 composes the reviewed STAGE-037 through STAGE-042 contracts;
it does not terminate or restart a process, persist recovery state, resume a
job, or claim that state survives a real worker crash.

## Source Binding

The unique task-pack member
`IDS_v0_1_Final_Chinese_Revised/stages/STAGE-043_Worker崩溃恢复.md` was read
from the approved v0.1-only archive. Its member SHA256 is
`e1d5169cbc30515930a7224743b860d9b577ccfbf9e0f913ec254d2ea060317b`.
The archive, Roadmap, instruction, reviewed STAGE-037 through STAGE-042
artifact hashes, and reviewed STAGE-042 commit are recorded in the machine
contract. No IDS business source or raw metadata content was read.

## Entry Preconditions

- STAGE-037 `ids.job_state.v1` remains authoritative; no state or transition
  is added and terminal history remains immutable.
- STAGE-038 remains the queue and worker transport owner. Its reviewed task
  `RuntimeError` proves a task exception only, not worker-process loss.
- STAGE-039 remains the retry/dead-letter policy owner.
- STAGE-040 remains the resource-pressure and backpressure policy owner.
- STAGE-041 remains the claim, lease, lock, and fencing owner.
- STAGE-042 remains the automatic lifecycle owner; pressure clearing alone
  cannot authorize crash recovery.
- The metadata root remains a path-only configuration value and is untouched.
- Owner-authored dirty files and root `.DS_Store` remain outside this task.

## Phase 1 Deliverables

1. This entry contract.
2. `STAGE043_PHASE1_WORKER_CRASH_RECOVERY_SCOPE_BOUNDARY.md`.
3. `worker_crash_recovery/stage043_worker_crash_recovery_contract.json`.
4. `scripts/check_worker_crash_recovery.py`.
5. `tests/test_stage043_worker_crash_recovery.py`.
6. `BATCH041_050_UPLOAD_LOCK.yaml` and minimal governance routing.

## Acceptance Interpretation

`ACC-STAGE-043` permits an executable/testable/rollback engineering contract
at this phase. It does not permit a claim that crash recovery is operational.
Current truth remains:

- `current_persistent_recovery_state_available=false`
- `state_survival_verified=false`
- `actual_process_crash_induced=false`
- `worker_restart_performed=false`
- `automatic_job_resume_performed=false`

## Stop Boundary

`Phase 2 must run separately`. This run stops at:

- `NO_PHASE2`
- `NO_PROCESS_TERMINATION`
- `NO_WORKER_RESTART`
- `NO_AUTOMATIC_JOB_RESUME`
- `NO_PERSISTENT_RECOVERY_STATE_WRITE`
- `NO_QUEUE_OR_WORKER_RUNTIME`
- `NO_RETRY_SCHEDULER`
- `NO_LOCK_RUNTIME`
- `NO_CLEANUP_OR_DELETE`
- `NO_POSTGRES_CONNECTION`
- `NO_SCHEMA_CHANGE`
- `NO_RUNTIME_OUTPUT`
- `NO_RAW_METADATA_ACCESS`
- `NO_FAKE_IDS_BUSINESS_DATA`
- `NO_GITHUB_UPLOAD`
- `NO_APP_REINSTALL`

`push_allowed=false`. The next task is only `IDS-V0_1-STAGE043-P2` in a
separate run.

## Rollback

Revert only STAGE-043 Phase 1 artifacts and its governance transition. Do not
touch earlier Stages, the raw metadata root, databases, runtime outputs,
reports, owner-authored dirty files, GitHub state, or app entries.
