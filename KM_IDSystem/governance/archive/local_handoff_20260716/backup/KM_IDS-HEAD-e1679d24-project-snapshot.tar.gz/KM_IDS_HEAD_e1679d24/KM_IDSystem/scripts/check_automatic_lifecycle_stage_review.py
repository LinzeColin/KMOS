#!/usr/bin/env python3
"""Build the fail-closed STAGE-042 whole-stage review report."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
from typing import Any, Mapping, Optional
import zipfile


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent
PURSUE_ROOT = PROJECT_ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
LIFECYCLE_ROOT = PURSUE_ROOT / "automatic_lifecycle"

ARCHIVE_PATH = Path(
    "/Users/linzezhang/Downloads/IDS_Taskpack_v0_1_only_中文修订版.zip"
)
ROADMAP_SOURCE_PATH = Path(
    "/Users/linzezhang/Downloads/IDS_Codex开发Roadmap_v0_1_only_中文修订版.txt"
)
INSTRUCTIONS_SOURCE_PATH = Path(
    "/Users/linzezhang/Downloads/IDS_Codex使用说明_v0_1_only_中文修订版.txt"
)
SOURCE_MEMBER = (
    "IDS_v0_1_Final_Chinese_Revised/stages/"
    "STAGE-042_自动运行、暂停、恢复与关闭.md"
)
EXPECTED_SOURCE_HASHES = {
    "archive_sha256_exact": (
        ARCHIVE_PATH,
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3",
    ),
    "roadmap_sha256_exact": (
        ROADMAP_SOURCE_PATH,
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6",
    ),
    "instructions_sha256_exact": (
        INSTRUCTIONS_SOURCE_PATH,
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8",
    ),
}
EXPECTED_MEMBER_SHA256 = (
    "78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08"
)

PHASE_CHECKERS = {
    "phase1": PROJECT_ROOT / "scripts" / "check_automatic_lifecycle.py",
    "phase2": PROJECT_ROOT / "scripts" / "check_automatic_lifecycle_runtime.py",
    "phase3": PROJECT_ROOT / "scripts" / "check_automatic_lifecycle_scenarios.py",
    "phase4": PROJECT_ROOT / "scripts" / "check_automatic_lifecycle_delivery.py",
}
REVIEW_ARTIFACT_PATH = PURSUE_ROOT / "STAGE042_STAGE_REVIEW.md"
BATCH_PATH = PURSUE_ROOT / "BATCH041_050_UPLOAD_LOCK.yaml"
ROADMAP_PATH = PROJECT_ROOT / "docs" / "governance" / "roadmap.yaml"
EVENTS_PATH = PROJECT_ROOT / "docs" / "governance" / "events.jsonl"
MODEL_SPEC_PATH = PROJECT_ROOT / "docs" / "governance" / "MODEL_SPEC.md"

TASK_ID = "IDS-V0_1-STAGE042-REVIEW"
ACCEPTANCE_ID = "ACC-STAGE-042"
REVIEW_GATE = "IDS-STAGE042-REVIEW-GATE"
NEXT_GATE = "IDS-STAGE043-P1-GATE"
PASS_RESULT = "PASS_REVIEWED_LOCAL_PRODUCTION_DISABLED"
REVIEW_EVENT_ID = "EVT-IDS-V0_1-STAGE042-REVIEW-20260715-001"

REVIEW_SOURCE_PATHS = (
    PURSUE_ROOT / "STAGE042_ENTRY_CONTRACT.md",
    PURSUE_ROOT / "STAGE042_PHASE1_AUTOMATIC_LIFECYCLE_SCOPE_BOUNDARY.md",
    LIFECYCLE_ROOT / "stage042_automatic_lifecycle_contract.json",
    PHASE_CHECKERS["phase1"],
    PURSUE_ROOT / "tests" / "test_stage042_automatic_lifecycle.py",
    PURSUE_ROOT / "STAGE042_PHASE2_AUTOMATIC_LIFECYCLE_SLICE.md",
    LIFECYCLE_ROOT / "stage042_automatic_lifecycle_runtime_contract.json",
    PHASE_CHECKERS["phase2"],
    PURSUE_ROOT / "tests" / "test_stage042_automatic_lifecycle_runtime.py",
    PURSUE_ROOT / "STAGE042_PHASE3_SCENARIO_VALIDATION.md",
    LIFECYCLE_ROOT / "stage042_automatic_lifecycle_scenarios.json",
    PHASE_CHECKERS["phase3"],
    PURSUE_ROOT / "tests" / "test_stage042_automatic_lifecycle_scenarios.py",
    PURSUE_ROOT / "STAGE042_PHASE4_CLOSEOUT.md",
    LIFECYCLE_ROOT / "stage042_automatic_lifecycle_delivery_contract.json",
    PHASE_CHECKERS["phase4"],
    PURSUE_ROOT / "tests" / "test_stage042_automatic_lifecycle_delivery.py",
    PURSUE_ROOT / "tests" / "test_stage041_lock_registry_runtime.py",
    PURSUE_ROOT / "tests" / "test_stage038_worker_queue_runtime.py",
    PURSUE_ROOT / "tests" / "test_stage038_worker_queue_scenarios.py",
    PURSUE_ROOT / "tests" / "test_stage038_worker_queue_delivery.py",
    PURSUE_ROOT / "tests" / "test_stage039_retry_dead_letter_review.py",
    PURSUE_ROOT / "lock_registry" / "stage041_lock_registry_scenarios.json",
    PROJECT_ROOT / "scripts" / "check_lock_registry_scenarios.py",
    PURSUE_ROOT / "lock_registry" / "stage041_lock_registry_delivery_contract.json",
    PROJECT_ROOT / "scripts" / "check_lock_registry_delivery.py",
    MODEL_SPEC_PATH,
    REVIEW_ARTIFACT_PATH,
    Path(__file__).resolve(),
    PURSUE_ROOT / "tests" / "test_stage042_automatic_lifecycle_review.py",
    PURSUE_ROOT / "validate_stage005_governance_regression.py",
    PURSUE_ROOT / "tests" / "test_stage005_governance_regression.py",
    BATCH_PATH,
    ROADMAP_PATH,
    EVENTS_PATH,
    PROJECT_ROOT / "docs" / "governance" / "project.yaml",
    PROJECT_ROOT / "docs" / "HANDOFF.md",
    PROJECT_ROOT / "CHANGELOG.md",
    PROJECT_ROOT / "功能清单.md",
    PROJECT_ROOT / "开发记录.md",
    PROJECT_ROOT / "模型参数文件.md",
)


def _load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"unable to load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _source_integrity_checks() -> dict[str, bool]:
    checks: dict[str, bool] = {}
    for name, (path, expected) in EXPECTED_SOURCE_HASHES.items():
        try:
            checks[name] = path.is_file() and _sha256_file(path) == expected
        except OSError:
            checks[name] = False
    try:
        with zipfile.ZipFile(ARCHIVE_PATH) as archive:
            matches = [name for name in archive.namelist() if name == SOURCE_MEMBER]
            member = archive.read(SOURCE_MEMBER) if len(matches) == 1 else b""
    except (OSError, KeyError, zipfile.BadZipFile, RuntimeError):
        matches = []
        member = b""
    checks["source_member_unique"] = len(matches) == 1
    checks["source_member_sha256_exact"] = (
        bool(member) and hashlib.sha256(member).hexdigest() == EXPECTED_MEMBER_SHA256
    )
    return checks


def _phase_results() -> dict[str, bool]:
    try:
        phase1 = _load_module(PHASE_CHECKERS["phase1"], "stage042_review_phase1")
        phase2 = _load_module(PHASE_CHECKERS["phase2"], "stage042_review_phase2")
        phase3 = _load_module(PHASE_CHECKERS["phase3"], "stage042_review_phase3")
        phase4 = _load_module(PHASE_CHECKERS["phase4"], "stage042_review_phase4")
        p1_report = phase1.build_stage042_phase1_report()
        p2_report = phase2.build_stage042_phase2_report()
        p3_report = phase3.build_stage042_phase3_report()
        p4_report = phase4.build_stage042_phase4_delivery_report()
    except Exception:
        return {
            "phase1_contract_valid": False,
            "phase2_slice_valid": False,
            "phase3_scenarios_valid": False,
            "phase4_delivery_valid": False,
        }
    return {
        "phase1_contract_valid": p1_report.get("phase1_contract_valid") is True,
        "phase2_slice_valid": p2_report.get("phase2_slice_valid") is True,
        "phase3_scenarios_valid": p3_report.get("scenario_validation_valid") is True,
        "phase4_delivery_valid": p4_report.get("delivery_contract_valid") is True,
    }


def _evaluate(runtime: Any, snapshot: Mapping[str, Any], **request_args: Any) -> dict[str, Any]:
    request = runtime.build_lifecycle_request(snapshot, **request_args)
    return runtime.IsolatedAutomaticLifecycle(runtime.load_contract()).evaluate(
        snapshot, request
    )


def _canonical_finding_checks() -> dict[str, bool]:
    try:
        runtime = _load_module(
            PHASE_CHECKERS["phase2"], "stage042_review_runtime_findings"
        )
        claimed = runtime.build_control_snapshot("CLAIMED", 100)
        claimed_result = _evaluate(
            runtime, claimed, intent="AUTO_START", logical_now=110
        )

        active_pause = runtime.build_control_snapshot(
            "PAUSE_REQUESTED",
            100,
            pause_requested_at=100,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            active_writer=True,
        )
        active_pause_result = _evaluate(
            runtime,
            active_pause,
            intent="COMPLETE_PAUSE",
            logical_now=110,
            checkpoint_ref="checkpoint:sha256:" + "a" * 64,
        )

        locked_pause = runtime.build_control_snapshot(
            "PAUSED",
            100,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            safe_close_started_at=100,
        )
        locked_close_result = _evaluate(
            runtime, locked_pause, intent="SAFE_CLOSE", logical_now=110
        )

        future_owner = runtime.build_control_snapshot(
            "PAUSED", 0, owner_evaluated_at=999, resource_gates_clear_since=0
        )
        future_owner_result = _evaluate(
            runtime, future_owner, intent="AUTO_RESUME", logical_now=100
        )
        future_resource = runtime.build_control_snapshot(
            "PAUSED", 0, owner_evaluated_at=100, resource_gates_clear_since=999
        )
        future_resource_result = _evaluate(
            runtime, future_resource, intent="AUTO_RESUME", logical_now=100
        )

        zero_pause = runtime.build_control_snapshot(
            "PAUSE_REQUESTED",
            0,
            pause_requested_at=0,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            active_writer=True,
        )
        zero_pause_result = _evaluate(
            runtime, zero_pause, intent="COMPLETE_PAUSE", logical_now=31
        )
        zero_close = runtime.build_control_snapshot(
            "RUNNING",
            0,
            safe_close_started_at=0,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            active_writer=True,
        )
        zero_close_result = _evaluate(
            runtime, zero_close, intent="SAFE_CLOSE", logical_now=36
        )

        count_pattern = re.compile(
            r"\b(model_count|formula_count|parameter_count)\s*:\s*(\d+)\b"
        )
        count_matches = count_pattern.findall(
            MODEL_SPEC_PATH.read_text(encoding="utf-8")
        )
    except Exception:
        return {
            "snapshot_guard_consistency_repaired": False,
            "writer_quiescence_repaired": False,
            "safe_close_claim_release_repaired": False,
            "future_logical_evidence_repaired": False,
            "zero_epoch_timeout_repaired": False,
            "model_spec_current_counts_unambiguous": False,
        }
    return {
        "snapshot_guard_consistency_repaired": (
            claimed_result.get("result_code") == "SNAPSHOT_GUARD_MISMATCH"
            and claimed_result.get("decision_valid") is False
            and claimed_result.get("transition") is None
        ),
        "writer_quiescence_repaired": (
            active_pause_result.get("result_code") == "WRITER_QUIESCENCE_REQUIRED"
            and active_pause_result.get("transition") is None
        ),
        "safe_close_claim_release_repaired": (
            locked_close_result.get("result_code")
            == "SAFE_CLOSE_ACTIVE_CLAIM_OR_LOCK"
            and locked_close_result.get("decision_valid") is False
            and locked_close_result.get("candidate_snapshot") is None
        ),
        "future_logical_evidence_repaired": (
            future_owner_result.get("result_code")
            == "OWNER_EVIDENCE_TIME_INVALID"
            and future_owner_result.get("decision_valid") is False
            and future_resource_result.get("result_code")
            == "RESOURCE_GATE_TIME_INVALID"
            and future_resource_result.get("decision_valid") is False
        ),
        "zero_epoch_timeout_repaired": (
            zero_pause_result.get("result_code")
            == "PAUSE_ACKNOWLEDGEMENT_TIMEOUT"
            and zero_close_result.get("result_code")
            == "SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER"
        ),
        "model_spec_current_counts_unambiguous": count_matches
        == [
            ("model_count", "11"),
            ("formula_count", "11"),
            ("parameter_count", "76"),
        ],
    }


def _governance_checks() -> dict[str, bool]:
    try:
        batch = BATCH_PATH.read_text(encoding="utf-8")
        roadmap = ROADMAP_PATH.read_text(encoding="utf-8")
        review = REVIEW_ARTIFACT_PATH.read_text(encoding="utf-8")
        events = [
            json.loads(line)
            for line in EVENTS_PATH.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
    except (OSError, json.JSONDecodeError):
        return {"governance_files_parse": False}
    matching = [event for event in events if event.get("event_id") == REVIEW_EVENT_ID]
    return {
        "governance_files_parse": True,
        "batch_reviewed_local_exact": all(
            term in batch
            for term in (
                'status: "stage042_completed_reviewed_local"',
                'review_status: "passed"',
                'current_task_id: "IDS-V0_1-STAGE042-REVIEW"',
                'next_allowed_task_id: "IDS-V0_1-STAGE043-P1"',
                'next_gate: "IDS-STAGE043-P1-GATE"',
                "push_allowed: false",
                "batch_review_performed: false",
            )
        ),
        "roadmap_reviewed_local_exact": all(
            term in roadmap
            for term in (
                'current_phase_id: "IDS-STAGE042-REVIEW"',
                'current_task_id: "IDS-V0_1-STAGE042-REVIEW"',
                'next_gate_id: "IDS-STAGE043-P1-GATE"',
                'status: "completed_reviewed_local"',
            )
        ),
        "review_event_exact": len(matching) == 1
        and matching[0].get("event_type") == "stage_review"
        and matching[0].get("task_id") == TASK_ID
        and matching[0].get("acceptance_ids") == [ACCEPTANCE_ID],
        "review_markers_exact": all(
            term in review
            for term in (
                "STAGE042-REVIEW-F1",
                "STAGE042-REVIEW-F2",
                "STAGE042-REVIEW-F3",
                "STAGE042-REVIEW-F4",
                "STAGE042-REVIEW-F5",
                "STAGE042-REVIEW-F6",
                "NO_STAGE043_THIS_RUN",
                "NO_BATCH_REVIEW_THIS_RUN",
                "NO_GITHUB_UPLOAD",
                "NO_APP_REINSTALL",
            )
        ),
    }


def _git_source_binding_checks() -> dict[str, bool]:
    tracked: list[bool] = []
    index_matches: list[bool] = []
    for path in REVIEW_SOURCE_PATHS:
        try:
            relative = path.resolve().relative_to(REPO_ROOT).as_posix()
        except ValueError:
            tracked.append(False)
            index_matches.append(False)
            continue
        tracked_result = subprocess.run(
            ["git", "ls-files", "--error-unmatch", "--", relative],
            cwd=REPO_ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        tracked.append(path.is_file() and tracked_result.returncode == 0)
        index_result = subprocess.run(
            ["git", "diff", "--quiet", "--", relative],
            cwd=REPO_ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        index_matches.append(tracked[-1] and index_result.returncode == 0)
    return {
        "all_review_sources_git_tracked": bool(tracked) and all(tracked),
        "all_review_sources_match_git_index": bool(index_matches)
        and all(index_matches),
    }


def build_stage042_review_report(
    *, finding_checks: Optional[Mapping[str, Any]] = None
) -> dict[str, Any]:
    source_checks = _source_integrity_checks()
    phase_results = _phase_results()
    canonical_findings = _canonical_finding_checks()
    effective_findings = (
        dict(finding_checks)
        if isinstance(finding_checks, Mapping)
        else canonical_findings
    )
    governance_checks = _governance_checks()
    source_binding_checks = _git_source_binding_checks()
    review_valid = all(
        bool(checks) and all(value is True for value in checks.values())
        for checks in (
            source_checks,
            phase_results,
            effective_findings,
            governance_checks,
            source_binding_checks,
        )
    )
    return {
        "schema_version": "ids.stage042.automatic_lifecycle.stage_review.v1",
        "stage": "STAGE-042",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "review_valid": review_valid,
        "result": PASS_RESULT if review_valid else "FAIL_CLOSED",
        "stage_review_status": (
            "completed_reviewed_local" if review_valid else "review_blocked"
        ),
        "next_gate": NEXT_GATE if review_valid else REVIEW_GATE,
        "source_integrity_valid": bool(source_checks)
        and all(source_checks.values()),
        "source_integrity_checks": source_checks,
        "phase_results": phase_results,
        "finding_count": 6,
        "finding_counts": {"Critical": 2, "Important": 3, "Minor": 1},
        "finding_checks": effective_findings,
        "governance_checks": governance_checks,
        "source_binding_checks": source_binding_checks,
        "production_runtime_activation_performed": False,
        "raw_metadata_content_accessed": False,
        "fake_ids_business_data_used": False,
        "stage043_started": False,
        "batch_review_performed": False,
        "github_upload_allowed": False,
        "app_reinstall_allowed": False,
    }


def main() -> int:
    report = build_stage042_review_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["review_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
