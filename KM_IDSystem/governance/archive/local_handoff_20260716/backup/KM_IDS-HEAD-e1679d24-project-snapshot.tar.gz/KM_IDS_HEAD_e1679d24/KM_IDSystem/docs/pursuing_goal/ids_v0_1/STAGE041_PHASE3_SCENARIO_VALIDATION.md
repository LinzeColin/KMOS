# STAGE-041 Phase 3 - Lock Registry Scenario Validation

## Contract Identity

- Stage: `STAGE-041 · 锁注册与竞态控制`
- Task: `IDS-V0_1-STAGE041-P3`
- Acceptance: `ACC-STAGE-041` remains `in_progress`
- Policy: `ids.lock_registry_policy.v0_1.stage041.p2`
- Mode: `ISOLATED_NON_PRODUCTION_LOCK_REGISTRY_SCENARIOS`
- Scenario contract:
  `lock_registry/stage041_lock_registry_scenarios.json`
- Checker: `KM_IDSystem/scripts/check_lock_registry_scenarios.py`
- Next separate gate: `IDS-STAGE041-P4-GATE`

The approved taskpack archive, unique Stage041 member, roadmap, and instructions
were rehashed before implementation. The Phase 3 contract binds committed Phase
2 commit `7295065f344fcf286be419153788a774b271d42f` plus exact hashes for the
Phase 2 contract, checker, evidence, tests, and the reviewed Stage040 scenario
contract/checker.

## Scenario Evidence

| Scenario | Controlled result | Physical or production action |
|---|---|---|
| duplicate click | one canonical two-key lock set; exact replay keeps fence `1` and one ledger entry | no queue, retry, job, or persistent write |
| worker exception boundary | replay one actual reviewed isolated `RuntimeError`; the orphaned lease blocks before expiry+grace, then successor takeover fences the stale holder | no process termination; crash recovery stays with `STAGE-043` |
| external drive offline | reviewed Stage040 resource gate pauses before any lock acquire | no physical drive removal |
| disk pressure | actual project-filesystem free space is observed read-only; an exact controlled low-disk boundary pauses before lock acquire | no disk allocation |
| external API budget | reviewed zero-budget control metadata pauses before lock acquire | no external API call |
| same-source cross-operation | one `source_identity_ref` is paired with five distinct operation identities; `FILE_PROCESSING` owns one complete lock set and four other families conflict on the shared source lock with no partial operation lock | no production lock runtime |
| duplicate operation families | file processing, archive extraction, index build, index switch, and report generation each acquire once, replay idempotently, and reject a second holder | no duplicate business operation executes |
| renewal/takeover/fencing | renewal preserves fence and versions; pre-grace takeover is denied; eligible takeover advances fence and both versions atomically; stale or malformed fencing, backward time, and stale release are denied | logical clock only; no sleep or persistence |
| protected cleanup | fact source, manifest, evidence ledger, report snapshot, and audit log are Git tracked and return `PROTECTED_ARTIFACT` | no delete function, attempt, or cleanup runtime |

The worker evidence is an actual isolated exception, not a process crash. Drive,
low-disk, and API states are bounded control metadata; only project filesystem
free space is actually observed. The checker exposes no delete API and never
starts queue, worker, retry, resume, recovery, cleanup, database, or production
runtime.

## Scope Proof

- no read, list, hash, open, copy, move, delete, mutation, dump, or scan of
  `/Users/linzezhang/Downloads/IDS_MetaData` content;
- no real IDS business source/job and no fake IDS business data;
- no process termination, physical drive removal, disk allocation, external API
  call, cleanup/delete, database connection, persistent lock, runtime output, or
  production activation;
- automatic resume remains with `STAGE-042`, process crash recovery with
  `STAGE-043`, and cleanup execution with `STAGE-044`;
- no Phase 4, whole-stage review, batch review/upload, GitHub/PR/issue/merge, or
  app reinstall; `push_allowed=false`.

## Verification State

- TDD RED first failed on the deliberately absent Phase 3 checker, then the
  completed test surface narrowed RED to the missing evidence and governance
  transition only.
- Core GREEN: `22/22` contract checks and `9/9` isolated scenarios passed.
- Final layered validation: focused `17/17`, Stage005 `157/157`, Stage039 review
  `6/6`, Stage040-041 aggregate `97/97`, and full IDS v0.1 discovery `777/777`.
  Events parsed `198` records with zero duplicates and exactly one P3 event;
  owner render drift/reference `0/0`; scoped Stage005 `valid=true`; changed-only
  governance `0 errors / 0 warnings`. Full semantic validation returned the
  expected `30` sparse root/unrelated-project diagnostics and zero
  `KM_IDSystem` project errors.
- Self-review repaired non-object contract fallback, added source-level checks
  against write/delete/sleep/network/process-control APIs, and extended only the
  exact historical Stage039 allowlist for `STAGE041-P3 -> P4`.

## Rollback

Revert only the Phase 3 scenario contract, checker, tests, evidence, and exact
governance transition. Preserve Phase 1-2, Stage037-040, owner-authored dirty
files, raw metadata, databases, runtime paths, GitHub state, and app entries.
