#!/usr/bin/env python3
"""Validate the STAGE-042 Phase 1 automatic-lifecycle contract."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent
CONTRACT_PATH = (
    PROJECT_ROOT
    / "docs"
    / "pursuing_goal"
    / "ids_v0_1"
    / "automatic_lifecycle"
    / "stage042_automatic_lifecycle_contract.json"
)

EXPECTED_ROOT_KEYS = {
    "schema_version",
    "stage",
    "phase",
    "task_id",
    "acceptance_id",
    "local_code",
    "domain",
    "entrance",
    "pursuing_goal",
    "automatic_lifecycle_contract_id",
    "contract_state",
    "execution_ready",
    "next_gate",
    "source_binding",
    "upstream_bindings",
    "state_model_inheritance",
    "automatic_start_contract",
    "automatic_pause_contract",
    "automatic_resume_contract",
    "retry_resume_contract",
    "safe_close_contract",
    "idempotency_contract",
    "worker_and_lock_boundary",
    "backpressure_boundary",
    "partial_output_cleanup_boundary",
    "parameter_contract",
    "ownership_matrix",
    "human_status_projection",
    "phase2_entry_gate",
    "truth_flags",
}

EXPECTED_SECTION_KEYS = {
    "source_binding": {
        "source_archive_path",
        "source_archive_sha256",
        "source_member",
        "source_member_match_count",
        "source_member_integrity",
        "source_member_sha256",
        "roadmap_sha256",
        "instructions_sha256",
        "source_verification_status",
    },
    "state_model_inheritance": {
        "state_model_version",
        "job_types",
        "terminal_states",
        "inherited_transition_count",
        "new_job_state_defined",
        "terminal_state_mutation_allowed",
        "terminal_state_automatic_reopen_allowed",
        "transition_compare_and_set_fields",
        "append_only_audit_required",
    },
    "automatic_start_contract": {
        "ordered_edges",
        "compare_and_set_required_each_edge",
        "edge_audit_required",
        "input_refs_required_before_queue",
        "candidate_claim_required_before_worker",
        "worker_invocation_before_claim_allowed",
        "automatic_start_runtime_performed",
    },
    "automatic_pause_contract": {
        "resource_pause_signals",
        "pre_admission_edge",
        "active_pause_request_edges",
        "pause_completion_edge",
        "edge_guard_requirements",
        "pause_reason_and_resource_gate_refs_required",
        "checkpoint_or_quarantine_required_before_paused",
        "deactivation_revokes_lease_and_lock",
        "deactivation_advances_fencing_token",
        "stale_worker_commit_allowed",
        "force_process_termination_allowed",
        "automatic_pause_runtime_performed",
    },
    "automatic_resume_contract": {
        "edge",
        "required_guard_facts",
        "eligible_pause_reasons",
        "required_owner_evidence_fields",
        "required_authorization_state",
        "fresh_evaluation_required",
        "owner_evidence_reference_only",
        "owner_evidence_policy_version_required",
        "resource_gate_refs_required",
        "compare_and_set_required",
        "idempotency_check_required",
        "cached_gate_result_allowed",
        "unknown_evidence_action",
        "terminal_state_resume_allowed",
        "automatic_resume_runtime_performed",
    },
    "retry_resume_contract": {
        "edge",
        "required_guard_facts",
        "stage039_required_conditions",
        "retry_and_dead_letter_policy_owner",
        "retry_budget_or_error_allowlist_redefined",
        "terminal_manual_rerun_creates_linked_new_job_only",
        "terminal_history_reopen_allowed",
        "retry_scheduler_performed",
    },
    "safe_close_contract": {
        "close_mode",
        "controller_states",
        "controller_state_is_job_state",
        "ordered_steps",
        "queued_and_retry_wait_jobs_use_legal_pause_edges",
        "active_jobs_use_pause_request_then_paused",
        "already_paused_jobs_remain_paused",
        "terminal_jobs_remain_immutable",
        "force_kill_allowed",
        "forced_terminal_transition_allowed",
        "terminal_history_reopen_allowed",
        "persistent_crash_recovery_claimed",
        "protected_artifacts_preserved",
        "safe_close_runtime_performed",
    },
    "idempotency_contract": {
        "derivation",
        "required_components",
        "exact_replay_returns_existing_decision",
        "same_key_different_intent_action",
        "compare_and_set_required",
        "reference_only",
        "raw_path_or_payload_allowed",
        "hash_algorithm",
    },
    "worker_and_lock_boundary": {
        "queue_and_worker_transport_owner",
        "lock_lease_and_fencing_owner",
        "mandatory_shared_guard_namespace",
        "claim_requires_lock_and_lease",
        "resume_requires_no_active_claim_or_lock",
        "lock_granularity_redefined",
        "persistent_worker_or_lock_registry_created",
        "process_crash_recovery_owner",
    },
    "backpressure_boundary": {
        "policy_owner",
        "resource_signals",
        "blocked_signal_effect",
        "cleared_signal_effect",
        "all_resource_gates_revalidated_together",
        "cached_or_partial_clear_allowed",
        "thresholds_redefined",
        "backpressure_runtime_performed",
    },
    "partial_output_cleanup_boundary": {
        "eligible_candidate_classes",
        "protected_artifact_classes",
        "candidate_manifest_reference_only",
        "candidate_requires_checkpoint_and_writer_quiescence",
        "cleanup_execution_runtime_owner",
        "delete_execution_allowed",
        "cleanup_runtime_performed",
    },
    "parameter_contract": {
        "numeric_values_assigned",
        "deferred_parameters",
        "phase2_selection_requirements",
        "implicit_default_allowed",
        "production_calibrated",
    },
    "ownership_matrix": {
        "job_state_model",
        "queue_and_worker_transport",
        "retry_and_dead_letter_policy",
        "backpressure_decision_policy",
        "lock_lease_and_fencing",
        "automatic_lifecycle_runtime",
        "worker_crash_recovery",
        "cleanup_execution_runtime",
    },
    "phase2_entry_gate": {
        "entry_authorized",
        "required_task_id",
        "required_gate",
        "separate_run_required",
        "required_work",
    },
}

EXPECTED_SOURCE_BINDING = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-042_自动运行、暂停、恢复与关闭.md"
    ),
    "source_member_match_count": 1,
    "source_member_integrity": "OK",
    "source_member_sha256": (
        "78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}

EXPECTED_UPSTREAM = {
    "stage037_state_index_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "job_state_model/stage037_job_state_model_index.json",
        "b70bf72ebe4212f45d380c13fbfe429791e1f4a5c73dccbba81211b7adc1c2d3",
    ),
    "stage038_delivery_contract_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "worker_queue_baseline/stage038_worker_queue_delivery_contract.json",
        "a4067c25b46340c33bee5017c286d6867d2b72e8fa208430c005d6b1a342c7e4",
    ),
    "stage039_delivery_contract_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "retry_dead_letter/stage039_retry_dead_letter_delivery_contract.json",
        "c4aad64a9283de683067aff07026d723c708285c57eef8a0eac4ee1b13f5cb96",
    ),
    "stage040_delivery_contract_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "backpressure_policy/stage040_backpressure_delivery_contract.json",
        "84f3d69f4bda15e0042631d9b049c8988c1375be632d96e366e57cf0b1ab0ac2",
    ),
    "stage041_delivery_contract_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "lock_registry/stage041_lock_registry_delivery_contract.json",
        "a4ae34a249bc7fc6a54434f611f83214f8dc5d8c526aea60e468963f91a9fd75",
    ),
}

JOB_TYPES = ["IMPORT", "ARCHIVE", "PARSE", "OCR", "CHUNK", "EMBED", "INDEX", "REPORT"]
TERMINAL_STATES = ["SUCCEEDED", "FAILED", "DEAD_LETTERED", "CANCELLED"]
RESOURCE_SIGNALS = [
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
]
PAUSE_EDGE_GUARDS = {
    "QUEUED->PAUSED": ["resource_gate_blocked", "no_active_claim_or_lock"],
    "CLAIMED->PAUSE_REQUESTED": [
        "live_lease_valid",
        "fencing_token_matches",
        "pause_intent_recorded",
    ],
    "RUNNING->PAUSE_REQUESTED": [
        "live_lease_valid",
        "fencing_token_matches",
        "pause_intent_recorded",
    ],
    "PAUSE_REQUESTED->PAUSED": [
        "lease_valid_or_expiry_evidence",
        "fencing_token_matches",
        "checkpoint_or_quarantine_complete",
    ],
}
OWNER_EVIDENCE_FIELDS = [
    "owner_ref",
    "authorization_state",
    "owner_policy_version",
    "evaluated_at_ref",
    "evidence_ref",
]
IDEMPOTENCY_COMPONENTS = [
    "job_id",
    "expected_state",
    "expected_state_version",
    "action",
    "policy_version",
    "canonical_intent_ref",
]
HUMAN_STATUS_PROJECTION = {
    "START_EVALUATING": "正在检查运行条件",
    "RUNNING": "运行中",
    "PAUSE_REQUESTED": "正在安全暂停",
    "PAUSED": "已暂停",
    "WAITING_RESUME_GATES": "等待恢复条件",
    "RESUME_EVALUATING": "正在重新检查恢复条件",
    "SAFE_CLOSING": "正在安全关闭",
    "SAFE_CLOSED": "已安全关闭",
    "MANUAL_REVIEW_REQUIRED": "需要人工处理",
    "RUNTIME_DISABLED": "自动生命周期运行时未启用",
}
PHASE2_REQUIRED_WORK = [
    "source and register every numeric lifecycle parameter",
    "implement one isolated non-production lifecycle decision slice",
    "map machine decisions to restrained Chinese owner status",
    "record reference-only input output error and checkpoint evidence",
    "keep persistence production crash recovery and cleanup execution disabled",
]
FALSE_RUNTIME_FLAGS = {
    "ids_business_source_read_performed",
    "raw_metadata_content_accessed",
    "automatic_lifecycle_runtime_performed",
    "automatic_start_runtime_performed",
    "automatic_pause_runtime_performed",
    "automatic_resume_runtime_performed",
    "safe_close_runtime_performed",
    "queue_runtime_performed",
    "worker_runtime_performed",
    "retry_scheduler_performed",
    "backpressure_runtime_performed",
    "lock_runtime_performed",
    "crash_recovery_runtime_performed",
    "cleanup_runtime_performed",
    "database_connection_performed",
    "schema_change_performed",
    "state_registry_write_performed",
    "runtime_output_written",
    "real_ids_business_job_created",
    "fake_ids_business_data_used",
    "external_api_call_performed",
    "github_upload_allowed",
    "app_reinstall_allowed",
}


def _exact_keys(value: Any, expected: set[str]) -> bool:
    return isinstance(value, dict) and set(value) == expected


def _upstream_bindings_valid(value: Any, verify_files: bool) -> bool:
    if not isinstance(value, dict) or set(value) != set(EXPECTED_UPSTREAM):
        return False
    for key, (relative, expected_sha) in EXPECTED_UPSTREAM.items():
        binding = value.get(key)
        if binding != {"ref": relative, "sha256": expected_sha}:
            return False
        if verify_files:
            path = REPO_ROOT / relative
            if not path.is_file():
                return False
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha:
                return False
    return True


def evaluate_contract(contract: Any, verify_files: bool = False) -> dict[str, bool]:
    if not isinstance(contract, dict):
        return {"contract_is_object": False}

    state = contract.get("state_model_inheritance", {})
    start = contract.get("automatic_start_contract", {})
    pause = contract.get("automatic_pause_contract", {})
    resume = contract.get("automatic_resume_contract", {})
    retry = contract.get("retry_resume_contract", {})
    close = contract.get("safe_close_contract", {})
    idempotency = contract.get("idempotency_contract", {})
    worker_lock = contract.get("worker_and_lock_boundary", {})
    backpressure = contract.get("backpressure_boundary", {})
    cleanup = contract.get("partial_output_cleanup_boundary", {})
    parameters = contract.get("parameter_contract", {})
    ownership = contract.get("ownership_matrix", {})
    phase2 = contract.get("phase2_entry_gate", {})
    truth = contract.get("truth_flags", {})

    section_shapes = all(
        _exact_keys(contract.get(name), keys)
        for name, keys in EXPECTED_SECTION_KEYS.items()
    )
    section_shapes = section_shapes and _exact_keys(
        contract.get("human_status_projection"),
        {
            "START_EVALUATING",
            "RUNNING",
            "PAUSE_REQUESTED",
            "PAUSED",
            "WAITING_RESUME_GATES",
            "RESUME_EVALUATING",
            "SAFE_CLOSING",
            "SAFE_CLOSED",
            "MANUAL_REVIEW_REQUIRED",
            "RUNTIME_DISABLED",
        },
    )
    section_shapes = section_shapes and _exact_keys(
        truth, FALSE_RUNTIME_FLAGS | {"taskpack_source_read_performed"}
    )

    checks = {
        "root_shape_exact": set(contract) == EXPECTED_ROOT_KEYS,
        "section_shapes_exact": section_shapes,
        "identity_exact": (
            contract.get("schema_version") == "1.0.0"
            and contract.get("stage") == "STAGE-042"
            and contract.get("phase") == "Phase 1"
            and contract.get("task_id") == "IDS-V0_1-STAGE042-P1"
            and contract.get("acceptance_id") == "ACC-STAGE-042"
            and contract.get("local_code") == "D07-S006"
            and contract.get("automatic_lifecycle_contract_id")
            == "ids.automatic_lifecycle.v0_1.stage042.p1"
            and contract.get("contract_state")
            == "PHASE1_ENGINEERING_CONTRACT_RUNTIME_DISABLED"
            and contract.get("execution_ready") is False
            and contract.get("next_gate") == "IDS-STAGE042-P2-GATE"
        ),
        "source_binding_exact": contract.get("source_binding") == EXPECTED_SOURCE_BINDING,
        "upstream_bindings_exact": _upstream_bindings_valid(
            contract.get("upstream_bindings"), verify_files
        ),
        "state_model_inherited": (
            state.get("state_model_version") == "ids.job_state.v1"
            and state.get("job_types") == JOB_TYPES
            and state.get("terminal_states") == TERMINAL_STATES
            and state.get("inherited_transition_count") == 21
            and state.get("new_job_state_defined") is False
            and state.get("terminal_state_mutation_allowed") is False
            and state.get("terminal_state_automatic_reopen_allowed") is False
            and state.get("transition_compare_and_set_fields")
            == ["job_id", "expected_state", "expected_state_version"]
            and state.get("append_only_audit_required") is True
        ),
        "automatic_start_fail_closed": (
            start.get("ordered_edges")
            == {
                "CREATED->QUEUED": [
                    "identity_idempotency_valid",
                    "admission_gates_passed",
                    "no_active_claim_or_lock",
                ],
                "QUEUED->CLAIMED": [
                    "admission_gates_passed",
                    "claim_lease_and_lock_acquired",
                ],
                "CLAIMED->RUNNING": ["live_lease_valid", "fencing_token_matches"],
            }
            and start.get("compare_and_set_required_each_edge") is True
            and start.get("edge_audit_required") is True
            and start.get("input_refs_required_before_queue") is True
            and start.get("candidate_claim_required_before_worker") is True
            and start.get("worker_invocation_before_claim_allowed") is False
            and start.get("automatic_start_runtime_performed") is False
        ),
        "automatic_pause_fail_closed": (
            pause.get("resource_pause_signals") == RESOURCE_SIGNALS
            and pause.get("pre_admission_edge") == "QUEUED->PAUSED"
            and pause.get("active_pause_request_edges")
            == ["CLAIMED->PAUSE_REQUESTED", "RUNNING->PAUSE_REQUESTED"]
            and pause.get("pause_completion_edge") == "PAUSE_REQUESTED->PAUSED"
            and pause.get("edge_guard_requirements") == PAUSE_EDGE_GUARDS
            and pause.get("pause_reason_and_resource_gate_refs_required") is True
            and pause.get("checkpoint_or_quarantine_required_before_paused") is True
            and pause.get("deactivation_revokes_lease_and_lock") is True
            and pause.get("deactivation_advances_fencing_token") is True
            and pause.get("stale_worker_commit_allowed") is False
            and pause.get("force_process_termination_allowed") is False
            and pause.get("automatic_pause_runtime_performed") is False
        ),
        "automatic_resume_fail_closed": (
            resume.get("edge") == "PAUSED->QUEUED"
            and resume.get("required_guard_facts")
            == ["owner_revalidated", "resource_gates_passed", "no_active_claim_or_lock"]
            and resume.get("eligible_pause_reasons") == RESOURCE_SIGNALS
            and resume.get("required_owner_evidence_fields")
            == OWNER_EVIDENCE_FIELDS
            and resume.get("required_authorization_state") == "ACTIVE"
            and resume.get("fresh_evaluation_required") is True
            and resume.get("owner_evidence_reference_only") is True
            and resume.get("owner_evidence_policy_version_required") is True
            and resume.get("resource_gate_refs_required") is True
            and resume.get("compare_and_set_required") is True
            and resume.get("idempotency_check_required") is True
            and resume.get("cached_gate_result_allowed") is False
            and resume.get("unknown_evidence_action") == "REQUIRE_MANUAL_REVIEW"
            and resume.get("terminal_state_resume_allowed") is False
            and resume.get("automatic_resume_runtime_performed") is False
        ),
        "retry_policy_preserved": (
            retry.get("edge") == "RETRY_WAIT->QUEUED"
            and retry.get("required_guard_facts")
            == ["next_eligible_reached", "resource_gates_passed", "no_active_claim_or_lock"]
            and retry.get("stage039_required_conditions")
            == [
                "EXACT_VERSIONED_POLICY",
                "EXACT_SAFE_ERROR_CODE_ALLOWLIST_MATCH",
                "RETRY_BUDGET_AVAILABLE",
                "RESOURCE_GATES_PASS",
                "COMPARE_AND_SET_PASS",
                "IDEMPOTENCY_KEY_PASS",
            ]
            and retry.get("retry_and_dead_letter_policy_owner") == "STAGE-039"
            and retry.get("retry_budget_or_error_allowlist_redefined") is False
            and retry.get("terminal_manual_rerun_creates_linked_new_job_only") is True
            and retry.get("terminal_history_reopen_allowed") is False
            and retry.get("retry_scheduler_performed") is False
        ),
        "safe_close_cooperative": (
            close.get("close_mode") == "COOPERATIVE_FAIL_CLOSED"
            and close.get("controller_states") == ["OPEN", "CLOSING", "CLOSED"]
            and close.get("controller_state_is_job_state") is False
            and close.get("ordered_steps")
            == [
                "STOP_NEW_ADMISSION_DECISIONS",
                "STOP_NEW_CLAIM_AND_LOCK_DECISIONS",
                "STOP_NEW_RETRY_ADMISSIONS",
                "ISSUE_PAUSE_INTENT_FOR_ACTIVE_JOBS",
                "WAIT_FOR_CHECKPOINT_OR_QUARANTINE_EVIDENCE",
                "TRANSITION_TO_PAUSED_WHEN_LEGAL",
                "RELEASE_CURRENT_LEASES_AND_LOCKS_WITH_FENCING",
                "PRESERVE_AUDIT_AND_STATE_EVIDENCE",
                "VERIFY_NO_ACTIVE_WRITER",
                "MARK_LIFECYCLE_CONTROLLER_CLOSED",
            ]
            and close.get("queued_and_retry_wait_jobs_use_legal_pause_edges") is True
            and close.get("active_jobs_use_pause_request_then_paused") is True
            and close.get("already_paused_jobs_remain_paused") is True
            and close.get("terminal_jobs_remain_immutable") is True
            and close.get("force_kill_allowed") is False
            and close.get("forced_terminal_transition_allowed") is False
            and close.get("terminal_history_reopen_allowed") is False
            and close.get("persistent_crash_recovery_claimed") is False
            and close.get("protected_artifacts_preserved") is True
            and close.get("safe_close_runtime_performed") is False
        ),
        "idempotency_fail_closed": (
            idempotency.get("derivation")
            == "SHA256_JOB_EXPECTED_STATE_VERSION_ACTION_POLICY_VERSION_CANONICAL_INTENT_REF"
            and idempotency.get("required_components") == IDEMPOTENCY_COMPONENTS
            and idempotency.get("exact_replay_returns_existing_decision") is True
            and idempotency.get("same_key_different_intent_action")
            == "REJECT_IDEMPOTENCY_KEY_INPUT_CONFLICT"
            and idempotency.get("compare_and_set_required") is True
            and idempotency.get("reference_only") is True
            and idempotency.get("raw_path_or_payload_allowed") is False
            and idempotency.get("hash_algorithm") == "SHA-256"
        ),
        "worker_lock_boundaries_preserved": (
            worker_lock.get("queue_and_worker_transport_owner") == "STAGE-038"
            and worker_lock.get("lock_lease_and_fencing_owner") == "STAGE-041"
            and worker_lock.get("mandatory_shared_guard_namespace") == "SOURCE_PIPELINE"
            and worker_lock.get("claim_requires_lock_and_lease") is True
            and worker_lock.get("resume_requires_no_active_claim_or_lock") is True
            and worker_lock.get("lock_granularity_redefined") is False
            and worker_lock.get("persistent_worker_or_lock_registry_created") is False
            and worker_lock.get("process_crash_recovery_owner") == "STAGE-043"
        ),
        "backpressure_boundary_preserved": (
            backpressure.get("policy_owner") == "STAGE-040"
            and backpressure.get("resource_signals") == RESOURCE_SIGNALS
            and backpressure.get("blocked_signal_effect") == "LEGAL_PAUSE_TRANSITION_ONLY"
            and backpressure.get("cleared_signal_effect")
            == "FRESH_RESUME_EVALUATION_CANDIDATE_ONLY"
            and backpressure.get("all_resource_gates_revalidated_together") is True
            and backpressure.get("cached_or_partial_clear_allowed") is False
            and backpressure.get("thresholds_redefined") is False
            and backpressure.get("backpressure_runtime_performed") is False
        ),
        "cleanup_non_destructive": (
            cleanup.get("eligible_candidate_classes")
            == ["TEMPORARY_PARTIAL_OUTPUT", "REBUILDABLE_CACHE"]
            and cleanup.get("protected_artifact_classes")
            == [
                "ORIGINAL_RAW_DATA",
                "FACT_SOURCE",
                "MANIFEST",
                "EVIDENCE_LEDGER",
                "REPORT_SNAPSHOT",
                "AUDIT_LOG",
                "ACTIVE_INDEX",
                "REQUIRED_CHECKPOINT",
            ]
            and cleanup.get("candidate_manifest_reference_only") is True
            and cleanup.get("candidate_requires_checkpoint_and_writer_quiescence") is True
            and cleanup.get("cleanup_execution_runtime_owner") == "STAGE-044"
            and cleanup.get("delete_execution_allowed") is False
            and cleanup.get("cleanup_runtime_performed") is False
        ),
        "parameters_deferred": (
            parameters.get("numeric_values_assigned") is False
            and parameters.get("deferred_parameters")
            == [
                "lifecycle_evaluation_interval",
                "pause_acknowledgement_timeout",
                "safe_close_timeout",
                "owner_revalidation_ttl",
                "resource_gate_stability_window",
            ]
            and parameters.get("phase2_selection_requirements")
            == ["source", "rationale", "unit", "policy_version", "validation_evidence", "rollback"]
            and parameters.get("implicit_default_allowed") is False
            and parameters.get("production_calibrated") is False
        ),
        "ownership_preserved": (
            ownership
            == {
                "job_state_model": "STAGE-037",
                "queue_and_worker_transport": "STAGE-038",
                "retry_and_dead_letter_policy": "STAGE-039",
                "backpressure_decision_policy": "STAGE-040",
                "lock_lease_and_fencing": "STAGE-041",
                "automatic_lifecycle_runtime": "STAGE-042",
                "worker_crash_recovery": "STAGE-043",
                "cleanup_execution_runtime": "STAGE-044",
            }
        ),
        "human_status_projection_exact": (
            contract.get("human_status_projection") == HUMAN_STATUS_PROJECTION
        ),
        "phase2_separate": (
            phase2.get("entry_authorized") is True
            and phase2.get("required_task_id") == "IDS-V0_1-STAGE042-P2"
            and phase2.get("required_gate") == "IDS-STAGE042-P2-GATE"
            and phase2.get("separate_run_required") is True
            and phase2.get("required_work") == PHASE2_REQUIRED_WORK
        ),
        "truth_flags_fail_closed": (
            truth.get("taskpack_source_read_performed") is True
            and all(truth.get(flag) is False for flag in FALSE_RUNTIME_FLAGS)
        ),
    }
    return checks


def load_contract() -> dict[str, Any]:
    return json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))


def build_stage042_phase1_report() -> dict[str, Any]:
    contract = load_contract()
    checks = evaluate_contract(contract, verify_files=True)
    truth = contract.get("truth_flags", {})
    return {
        "stage": contract.get("stage"),
        "phase": contract.get("phase"),
        "task_id": contract.get("task_id"),
        "acceptance_id": contract.get("acceptance_id"),
        "contract_state": contract.get("contract_state"),
        "next_gate": contract.get("next_gate"),
        "phase1_contract_valid": bool(checks) and all(checks.values()),
        "contract_checks": checks,
        **truth,
    }


def main() -> int:
    report = build_stage042_phase1_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["phase1_contract_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
