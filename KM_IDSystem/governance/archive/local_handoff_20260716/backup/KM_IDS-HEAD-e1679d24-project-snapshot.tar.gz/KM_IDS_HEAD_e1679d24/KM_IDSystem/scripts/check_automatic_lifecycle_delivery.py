#!/usr/bin/env python3
"""Build and validate STAGE-042 Phase 4 isolated closeout evidence."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
from typing import Any, Mapping, Optional
import zipfile


REPO_ROOT = Path(__file__).resolve().parents[2]
PROJECT_ROOT = Path(__file__).resolve().parents[1]
BASE = PROJECT_ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
CONTRACT_PATH = (
    BASE
    / "automatic_lifecycle"
    / "stage042_automatic_lifecycle_delivery_contract.json"
)
STATE_INDEX_PATH = BASE / "job_state_model" / "stage037_job_state_model_index.json"
P1_CONTRACT_PATH = (
    BASE
    / "automatic_lifecycle"
    / "stage042_automatic_lifecycle_contract.json"
)
STAGE039_CHECKER = PROJECT_ROOT / "scripts" / "check_retry_dead_letter_delivery.py"
STAGE040_CHECKER = PROJECT_ROOT / "scripts" / "check_backpressure_delivery.py"
STAGE041_CHECKER = PROJECT_ROOT / "scripts" / "check_lock_registry_delivery.py"
P2_CHECKER = PROJECT_ROOT / "scripts" / "check_automatic_lifecycle_runtime.py"
P3_CHECKER = PROJECT_ROOT / "scripts" / "check_automatic_lifecycle_scenarios.py"

TASK_ID = "IDS-V0_1-STAGE042-P4"
ACCEPTANCE_ID = "ACC-STAGE-042"
POLICY_VERSION = "ids.automatic_lifecycle_policy.v0_1.stage042.p2"
EXECUTION_MODE = "ISOLATED_NON_PRODUCTION_CLOSEOUT_EVIDENCE"
VALID_RESULT = "PASS_ISOLATED_CLOSEOUT_PRODUCTION_DISABLED"
PHASE4_GATE = "IDS-STAGE042-P4-GATE"
REVIEW_GATE = "IDS-STAGE042-REVIEW-GATE"
PHASE3_COMMIT = "bba58cc9e4fb676929960be5ef23f70e89563986"
PHASE3_SUBJECT = "feat(ids): validate stage042 lifecycle scenarios"

LIFECYCLE_INTENTS = [
    "AUTO_START",
    "RESOURCE_PAUSE",
    "COMPLETE_PAUSE",
    "AUTO_RESUME",
    "SAFE_CLOSE",
]
RESOURCE_PAUSE_SIGNALS = [
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
]
PRESSURE_SIGNALS = [
    "QUEUE_SOFT_PRESSURE",
    "QUEUE_HARD_CAPACITY",
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
    "JOB_TYPE_CONCURRENCY_LIMIT_REACHED",
    "SAME_SOURCE_CONFLICT",
]
OPERATION_FAMILIES = [
    "FILE_PROCESSING",
    "ARCHIVE_EXTRACTION",
    "INDEX_BUILD",
    "INDEX_SWITCH",
    "REPORT_GENERATION",
]
CLEANUP_CLASSES = ["TEMPORARY_PARTIAL_OUTPUT", "REBUILDABLE_CACHE"]
PROTECTED_CLASSES = [
    "ORIGINAL_RAW_DATA",
    "FACT_SOURCE",
    "MANIFEST",
    "EVIDENCE_LEDGER",
    "REPORT_SNAPSHOT",
    "AUDIT_LOG",
    "ACTIVE_INDEX",
    "REQUIRED_CHECKPOINT",
]
CLEANUP_PRECONDITIONS = [
    "APPROVED_ROOT_IDENTITY",
    "ROOT_RELATIVE_PATH",
    "IMMUTABLE_LSTAT_IDENTITY",
    "SYMLINK_BLOCKED",
    "EXCLUSIVE_NAMESPACE_LOCK",
    "WRITER_QUIESCENCE",
    "NO_FOLLOW_TRAVERSAL",
]
ISOLATED_CONTINUATION_CANDIDATES = [
    "RESOURCE_PAUSED_JOB_AFTER_FRESH_OWNER_AND_STABLE_RESOURCE_GATES",
    "RETRY_WAIT_SAFE_FAILURE_AFTER_STAGE039_EXACT_GATES",
]
RESUME_GUARDS = [
    "FRESH_OWNER_REVALIDATION",
    "ALL_RESOURCE_GATES_STABLE",
    "NO_ACTIVE_CLAIM_OR_LOCK",
    "COMPARE_AND_SET_PASS",
    "IDEMPOTENCY_KEY_PASS",
]
RETRY_RESUME_GUARDS = [
    "EXACT_VERSIONED_POLICY",
    "EXACT_SAFE_ERROR_CODE_ALLOWLIST_MATCH",
    "RETRY_BUDGET_AVAILABLE",
    "RESOURCE_GATES_PASS",
    "COMPARE_AND_SET_PASS",
    "IDEMPOTENCY_KEY_PASS",
]
MANUAL_ACTION_CASES = [
    "IDEMPOTENCY_KEY_INPUT_CONFLICT",
    "WORKER_OR_PROCESS_LOSS",
    "STALE_OWNER_EVIDENCE",
    "UNSTABLE_RESOURCE_GATES",
    "SAME_SOURCE_CONTENTION",
    "ACTIVE_WRITER_SAFE_CLOSE_TIMEOUT",
    "RETRY_EXHAUSTED_OR_DEAD_LETTERED",
    "TERMINAL_JOB_RESTART",
    "INVALID_OR_MISSING_CONTRACT",
    "UNCALIBRATED_LIFECYCLE_POLICY",
    "PERSISTENT_STATE_RECONSTRUCTION",
    "PROTECTED_CLEANUP_REQUEST",
]
SHUTDOWN_STEPS = [
    "STOP_NEW_ADMISSION_DECISIONS",
    "STOP_NEW_CLAIM_AND_LOCK_DECISIONS",
    "STOP_NEW_RETRY_ADMISSIONS",
    "ISSUE_PAUSE_INTENT_FOR_ACTIVE_JOBS",
    "WAIT_FOR_CHECKPOINT_OR_QUARANTINE_EVIDENCE",
    "TRANSITION_TO_PAUSED_WHEN_LEGAL",
    "RELEASE_CURRENT_LEASES_AND_LOCKS_WITH_FENCING",
    "PRESERVE_AUDIT_AND_STATE_EVIDENCE",
    "VERIFY_NO_ACTIVE_WRITER",
    "MARK_LIFECYCLE_CONTROLLER_CLOSED",
]
RECOVERY_STEPS = [
    "VERIFY_EXACT_SOURCE_POLICY_AND_UPSTREAM_HASHES",
    "REVALIDATE_OWNER_AND_RESOURCE_GATES",
    "REVALIDATE_RETRY_POLICY_BUDGET_AND_SAFE_ERROR_CODE",
    "REACQUIRE_CURRENT_CLAIM_LOCK_AND_FENCING_EVIDENCE",
    "REPLAY_ONLY_IDEMPOTENT_REFERENCE_BOUND_DECISIONS",
    "REQUIRE_MANUAL_REVIEW_FOR_UNKNOWN_OR_MISSING_EVIDENCE",
    "DEFER_PROCESS_CRASH_RECOVERY_TO_STAGE043",
    "DEFER_CLEANUP_EXECUTION_TO_STAGE044",
]
ROLLBACK_STEPS = [
    "STOP_ON_INVALID_DELIVERY_CONTRACT",
    "DISABLE_ISOLATED_LIFECYCLE",
    "DENY_NEW_AUTOMATIC_START_RESUME_AND_CLOSE_DECISIONS",
    "REVERT_PHASE4_FILES_ONLY",
    "PRESERVE_PHASE1_PHASE3_EVIDENCE",
    "PRESERVE_RAW_DATA_AND_DURABLE_EVIDENCE",
]
KNOWN_LIMITS = [
    "NO_PERSISTENT_LIFECYCLE_STATE",
    "NO_PRODUCTION_AUTOMATIC_START_PAUSE_RESUME_OR_CLOSE",
    "NO_PRODUCTION_CALIBRATION",
    "NO_QUEUE_WORKER_RETRY_SCHEDULER_OR_LOCK_RUNTIME",
    "NO_PROCESS_CRASH_RECOVERY",
    "NO_CLEANUP_RUNTIME",
    "NO_DATABASE_OR_RAW_SOURCE_ACCESS",
    "STATIC_CLOSEOUT_IS_NOT_PRODUCTION_READINESS",
]

EXPECTED_SOURCE = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-042_自动运行、暂停、恢复与关闭.md"
    ),
    "source_member_match_count": 1,
    "source_member_sha256": (
        "78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08"
    ),
    "roadmap_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Codex开发Roadmap_v0_1_only_中文修订版.txt"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Codex使用说明_v0_1_only_中文修订版.txt"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}
EXPECTED_UPSTREAM = {
    "stage037_state_index": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/job_state_model/"
        "stage037_job_state_model_index.json",
        "b70bf72ebe4212f45d380c13fbfe429791e1f4a5c73dccbba81211b7adc1c2d3",
    ),
    "stage039_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/retry_dead_letter/"
        "stage039_retry_dead_letter_delivery_contract.json",
        "c4aad64a9283de683067aff07026d723c708285c57eef8a0eac4ee1b13f5cb96",
    ),
    "stage039_delivery_checker": (
        "KM_IDSystem/scripts/check_retry_dead_letter_delivery.py",
        "babff5f0be9e6be06508cbe4efbe355c354a65324d0895e7c9c5f3322621e4da",
    ),
    "stage039_review_artifact": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE039_STAGE_REVIEW.md",
        "32e621db9d7d4ad87ff4f6788e1de22d7ada9c0f57ce756a76a9608a864c4b9b",
    ),
    "stage040_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
        "stage040_backpressure_delivery_contract.json",
        "84f3d69f4bda15e0042631d9b049c8988c1375be632d96e366e57cf0b1ab0ac2",
    ),
    "stage040_delivery_checker": (
        "KM_IDSystem/scripts/check_backpressure_delivery.py",
        "8a16e7b079de9a05ed43029b6c6a858af8d293f49df9a2c4ceaff196cd35b4c9",
    ),
    "stage040_review_artifact": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE040_STAGE_REVIEW.md",
        "ea1a6dacacc862d66de60883dd10ee2dbf23d3adc72efbf9586ba2ccf6c223f0",
    ),
    "stage041_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_delivery_contract.json",
        "a4ae34a249bc7fc6a54434f611f83214f8dc5d8c526aea60e468963f91a9fd75",
    ),
    "stage041_delivery_checker": (
        "KM_IDSystem/scripts/check_lock_registry_delivery.py",
        "4d4f5186e0f704b62d0d30bffcd320bddd05ed8e0bf520d9c30944cf945e1168",
    ),
    "stage041_review_artifact": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE041_STAGE_REVIEW.md",
        "a829c4fb097d566a13f503bf39bf5a0276ee4bc859775c7cf1ef4e28aea72bee",
    ),
    "stage042_phase1_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
        "stage042_automatic_lifecycle_contract.json",
        "9a964ca89c3fab9c58755856374813be811677579eefae96ed9ff34200d972f0",
    ),
    "stage042_phase1_checker": (
        "KM_IDSystem/scripts/check_automatic_lifecycle.py",
        "1a37eb363865890002e5aac94950063bfec07ff666a7e8819686e8476e34b3f9",
    ),
    "stage042_phase1_evidence": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE042_PHASE1_AUTOMATIC_LIFECYCLE_SCOPE_BOUNDARY.md",
        "d6ea9cbd0848c1eda4ce7e38fbbb3b403533669009b625efa01cee8a8cd56aae",
    ),
    "stage042_phase1_tests": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
        "test_stage042_automatic_lifecycle.py",
        "7ed118872bab84769d4e866cfa4380bc40e9c99d8df51ae5a6e39d8a57de4d37",
    ),
    "stage042_phase2_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
        "stage042_automatic_lifecycle_runtime_contract.json",
        "bfc15281dc37d173ccac70ae82e02d98d71175864362823a37f326fa81962463",
    ),
    "stage042_phase2_checker": (
        "KM_IDSystem/scripts/check_automatic_lifecycle_runtime.py",
        "30d03349fcf1ccfaa5fc20372d88307eb186f235b7e28e11683718ff4c6cafe0",
    ),
    "stage042_phase2_evidence": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE042_PHASE2_AUTOMATIC_LIFECYCLE_SLICE.md",
        "87bb937e4fd12b7dfdc68d8a25f3a048ba5fdd3c1521cc1f253b4fbd240648fe",
    ),
    "stage042_phase2_tests": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
        "test_stage042_automatic_lifecycle_runtime.py",
        "6efe77bc842b9df47ffb61c78d25c188cdcc56f5cf21423469f2f453e9c505a4",
    ),
    "stage042_phase3_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
        "stage042_automatic_lifecycle_scenarios.json",
        "6503e3c7ad592b1aafb2e679024a0001668c997f5c36f856d970a6d54e787758",
    ),
    "stage042_phase3_checker": (
        "KM_IDSystem/scripts/check_automatic_lifecycle_scenarios.py",
        "966815ddde87c97367efffb9796b521bb4a77a6d919fc91d4fda9d05811070ff",
    ),
    "stage042_phase3_evidence": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE042_PHASE3_SCENARIO_VALIDATION.md",
        "9a858f4bc1c472f1a774bfdfc452648e98aeebad346ac69eaffa4b207f059e8a",
    ),
    "stage042_phase3_tests": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
        "test_stage042_automatic_lifecycle_scenarios.py",
        "4971e14a9422c31a548d247a1d2093aaa8e61a96439dd32b473da1caad66d644",
    ),
}

POSITIVE_TRUTH_FLAGS = {
    "taskpack_source_read_performed",
    "job_state_graph_replayed",
    "reviewed_failure_retry_log_replayed",
    "reviewed_backpressure_proof_replayed",
    "reviewed_lock_proof_replayed",
    "stage042_phase2_slice_replayed",
    "stage042_phase3_scenarios_replayed",
    "actual_isolated_worker_exception_replayed",
    "actual_disk_observation_replayed",
    "isolated_safe_close_candidate_replayed",
    "protected_refs_git_tracked",
}
FALSE_TRUTH_FLAGS = {
    "ids_business_source_read_performed",
    "raw_metadata_content_accessed",
    "fake_ids_business_data_used",
    "real_ids_business_job_created",
    "process_termination_performed",
    "physical_drive_removal_performed",
    "disk_allocation_performed",
    "external_api_call_performed",
    "cleanup_runtime_performed",
    "protected_ref_delete_performed",
    "queue_runtime_performed",
    "worker_runtime_performed",
    "retry_scheduler_performed",
    "persistent_lifecycle_runtime_performed",
    "production_lock_runtime_performed",
    "automatic_resume_production_performed",
    "safe_close_production_performed",
    "force_kill_performed",
    "process_crash_recovery_performed",
    "production_runtime_activation_performed",
    "persistent_state_write_performed",
    "database_connection_performed",
    "runtime_output_written",
    "whole_stage_review_performed",
    "batch_review_performed",
    "github_upload_allowed",
    "app_reinstall_allowed",
}
EXPECTED_ROOT_KEYS = {
    "schema_version",
    "stage",
    "phase",
    "task_id",
    "acceptance_id",
    "execution_mode",
    "valid_result",
    "contract_state",
    "stage_review_status",
    "next_gate",
    "source_binding",
    "phase3_commit_binding",
    "upstream_bindings",
    "delivery_contract",
    "cleanup_allowlist",
    "recovery_handling",
    "safe_shutdown_and_recovery",
    "rollback_contract",
    "known_limits",
    "owner_feedback_contract",
    "review_gate",
    "truth_flags",
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _exact_keys(value: Any, expected: set[str]) -> bool:
    return isinstance(value, Mapping) and set(value) == expected


def _load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected object: {path}")
    return value


def load_delivery_contract() -> dict[str, Any]:
    return _load_json(CONTRACT_PATH)


def _git_tracked(path: Path) -> bool:
    try:
        relative = path.resolve().relative_to(REPO_ROOT.resolve()).as_posix()
    except ValueError:
        return False
    result = subprocess.run(
        ["git", "ls-files", "--error-unmatch", "--", relative],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _source_binding_current(value: Any) -> bool:
    if value != EXPECTED_SOURCE:
        return False
    try:
        archive = Path(EXPECTED_SOURCE["source_archive_path"])
        roadmap = Path(EXPECTED_SOURCE["roadmap_path"])
        instructions = Path(EXPECTED_SOURCE["instructions_path"])
        if sha256_file(archive) != EXPECTED_SOURCE["source_archive_sha256"]:
            return False
        if sha256_file(roadmap) != EXPECTED_SOURCE["roadmap_sha256"]:
            return False
        if sha256_file(instructions) != EXPECTED_SOURCE["instructions_sha256"]:
            return False
        with zipfile.ZipFile(archive) as source_zip:
            matches = [
                name
                for name in source_zip.namelist()
                if name == EXPECTED_SOURCE["source_member"]
            ]
            if len(matches) != EXPECTED_SOURCE["source_member_match_count"]:
                return False
            member_digest = hashlib.sha256(source_zip.read(matches[0])).hexdigest()
        return member_digest == EXPECTED_SOURCE["source_member_sha256"]
    except (OSError, KeyError, ValueError, zipfile.BadZipFile):
        return False


def _phase3_commit_current(value: Any) -> bool:
    expected = {
        "commit": PHASE3_COMMIT,
        "subject": PHASE3_SUBJECT,
        "required_ancestor_of_head": True,
    }
    if value != expected:
        return False
    ancestor = subprocess.run(
        ["git", "merge-base", "--is-ancestor", PHASE3_COMMIT, "HEAD"],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    subject = subprocess.run(
        ["git", "show", "-s", "--format=%s", PHASE3_COMMIT],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    return (
        ancestor.returncode == 0
        and subject.returncode == 0
        and subject.stdout.strip() == PHASE3_SUBJECT
    )


def _upstream_current(value: Any) -> bool:
    if not isinstance(value, Mapping) or set(value) != set(EXPECTED_UPSTREAM):
        return False
    for key, (ref, digest) in EXPECTED_UPSTREAM.items():
        if value.get(key) != {"ref": ref, "sha256": digest}:
            return False
        path = REPO_ROOT / ref
        if not path.is_file() or not _git_tracked(path) or sha256_file(path) != digest:
            return False
    return True


def validate_delivery_contract(contract: Any) -> dict[str, bool]:
    if not isinstance(contract, Mapping):
        return {"contract_object": False}
    delivery = contract.get("delivery_contract")
    cleanup = contract.get("cleanup_allowlist")
    recovery = contract.get("recovery_handling")
    shutdown = contract.get("safe_shutdown_and_recovery")
    rollback = contract.get("rollback_contract")
    owner = contract.get("owner_feedback_contract")
    review = contract.get("review_gate")
    truth = contract.get("truth_flags")
    checks = {
        "contract_shape": set(contract) == EXPECTED_ROOT_KEYS,
        "identity_exact": (
            contract.get("schema_version")
            == "ids.stage042.automatic_lifecycle.phase4.delivery.v1"
            and contract.get("stage") == "STAGE-042"
            and contract.get("phase") == "Phase 4"
            and contract.get("task_id") == TASK_ID
            and contract.get("acceptance_id") == ACCEPTANCE_ID
            and contract.get("execution_mode") == EXECUTION_MODE
            and contract.get("valid_result") == VALID_RESULT
            and contract.get("contract_state")
            == "PHASE4_CLOSEOUT_EVIDENCE_REVIEW_PENDING"
            and contract.get("stage_review_status") == "pending_next_run"
            and contract.get("next_gate") == REVIEW_GATE
        ),
        "source_binding_current": _source_binding_current(
            contract.get("source_binding")
        ),
        "phase3_commit_current": _phase3_commit_current(
            contract.get("phase3_commit_binding")
        ),
        "upstream_bindings_current": _upstream_current(
            contract.get("upstream_bindings")
        ),
        "delivery_contract_exact": (
            _exact_keys(
                delivery,
                {
                    "policy_version",
                    "state_model_version",
                    "required_job_type_count",
                    "required_job_state_count",
                    "required_terminal_state_count",
                    "required_transition_count",
                    "required_lifecycle_intents",
                    "required_resource_pause_signals",
                    "required_pressure_signals",
                    "required_operation_families",
                    "failure_retry_log_source",
                    "expected_attempt_count",
                    "expected_retry_count",
                    "expected_max_retries",
                    "expected_final_state",
                    "required_phase3_scenario_count",
                    "actual_project_disk_observation_required",
                    "production_calibrated",
                    "stage_review_must_run_separately",
                },
            )
            and delivery.get("policy_version") == POLICY_VERSION
            and delivery.get("state_model_version") == "ids.job_state.v1"
            and delivery.get("required_job_type_count") == 8
            and delivery.get("required_job_state_count") == 11
            and delivery.get("required_terminal_state_count") == 4
            and delivery.get("required_transition_count") == 21
            and delivery.get("required_lifecycle_intents") == LIFECYCLE_INTENTS
            and delivery.get("required_resource_pause_signals")
            == RESOURCE_PAUSE_SIGNALS
            and delivery.get("required_pressure_signals") == PRESSURE_SIGNALS
            and delivery.get("required_operation_families") == OPERATION_FAMILIES
            and delivery.get("failure_retry_log_source")
            == "STAGE039_REVIEWED_PHASE4_ACTUAL_ISOLATED_CONTROL_METADATA"
            and delivery.get("expected_attempt_count") == 3
            and delivery.get("expected_retry_count") == 2
            and delivery.get("expected_max_retries") == 2
            and delivery.get("expected_final_state") == "DEAD_LETTERED"
            and delivery.get("required_phase3_scenario_count") == 10
            and delivery.get("actual_project_disk_observation_required") is True
            and delivery.get("production_calibrated") is False
            and delivery.get("stage_review_must_run_separately") is True
        ),
        "cleanup_allowlist_exact": (
            _exact_keys(
                cleanup,
                {
                    "cleanup_eligible_classes",
                    "protected_artifact_classes",
                    "cleanup_manifest_required",
                    "required_preconditions",
                    "runtime_owner",
                    "delete_execution_allowed",
                },
            )
            and cleanup.get("cleanup_eligible_classes") == CLEANUP_CLASSES
            and cleanup.get("protected_artifact_classes") == PROTECTED_CLASSES
            and cleanup.get("cleanup_manifest_required") is True
            and cleanup.get("required_preconditions") == CLEANUP_PRECONDITIONS
            and cleanup.get("runtime_owner") == "STAGE-044"
            and cleanup.get("delete_execution_allowed") is False
        ),
        "recovery_classification_exact": (
            _exact_keys(
                recovery,
                {
                    "isolated_automatic_continuation_candidate_cases",
                    "production_automatic_recovery_eligible_cases",
                    "successful_production_automatic_recovery_cases_observed",
                    "required_resume_guards",
                    "required_retry_resume_guards",
                    "manual_action_required_cases",
                    "automatic_resume_production_allowed",
                    "process_crash_recovery_runtime_owner",
                    "cleanup_execution_runtime_owner",
                },
            )
            and recovery.get("isolated_automatic_continuation_candidate_cases")
            == ISOLATED_CONTINUATION_CANDIDATES
            and recovery.get("production_automatic_recovery_eligible_cases") == []
            and recovery.get(
                "successful_production_automatic_recovery_cases_observed"
            )
            == []
            and recovery.get("required_resume_guards") == RESUME_GUARDS
            and recovery.get("required_retry_resume_guards") == RETRY_RESUME_GUARDS
            and recovery.get("manual_action_required_cases") == MANUAL_ACTION_CASES
            and recovery.get("automatic_resume_production_allowed") is False
            and recovery.get("process_crash_recovery_runtime_owner") == "STAGE-043"
            and recovery.get("cleanup_execution_runtime_owner") == "STAGE-044"
        ),
        "safe_shutdown_and_recovery_exact": (
            _exact_keys(
                shutdown,
                {
                    "shutdown_steps",
                    "recovery_steps",
                    "persistent_lifecycle_state_available_after_exit",
                    "process_termination_allowed",
                    "force_kill_allowed",
                    "automatic_process_recovery_allowed",
                },
            )
            and shutdown.get("shutdown_steps") == SHUTDOWN_STEPS
            and shutdown.get("recovery_steps") == RECOVERY_STEPS
            and shutdown.get("persistent_lifecycle_state_available_after_exit")
            is False
            and shutdown.get("process_termination_allowed") is False
            and shutdown.get("force_kill_allowed") is False
            and shutdown.get("automatic_process_recovery_allowed") is False
        ),
        "rollback_exact": (
            _exact_keys(rollback, {"steps", "destructive_rollback_allowed"})
            and rollback.get("steps") == ROLLBACK_STEPS
            and rollback.get("destructive_rollback_allowed") is False
        ),
        "known_limits_exact": contract.get("known_limits") == KNOWN_LIMITS,
        "owner_feedback_exact": (
            _exact_keys(
                owner,
                {
                    "status_zh",
                    "automatic_candidate_zh",
                    "manual_action_zh",
                    "limit_zh",
                },
            )
            and all(
                isinstance(owner.get(key), str) and owner.get(key)
                for key in (
                    "status_zh",
                    "automatic_candidate_zh",
                    "manual_action_zh",
                    "limit_zh",
                )
            )
        ),
        "review_gate_exact": (
            _exact_keys(
                review,
                {
                    "next_task_id",
                    "must_run_separately",
                    "phase4_may_mark_stage_reviewed",
                    "batch_review_allowed",
                    "stage043_entry_allowed",
                    "github_upload_allowed",
                    "app_reinstall_allowed",
                },
            )
            and review.get("next_task_id") == "IDS-V0_1-STAGE042-REVIEW"
            and review.get("must_run_separately") is True
            and review.get("phase4_may_mark_stage_reviewed") is False
            and review.get("batch_review_allowed") is False
            and review.get("stage043_entry_allowed") is False
            and review.get("github_upload_allowed") is False
            and review.get("app_reinstall_allowed") is False
        ),
        "truth_flags_exact": (
            _exact_keys(truth, POSITIVE_TRUTH_FLAGS | FALSE_TRUTH_FLAGS)
            and all(truth.get(key) is True for key in POSITIVE_TRUTH_FLAGS)
            and all(truth.get(key) is False for key in FALSE_TRUTH_FLAGS)
        ),
    }
    return checks


def _job_state_graph() -> dict[str, Any]:
    index = _load_json(STATE_INDEX_PATH)
    state = index["state_model"]
    transitions = state["allowed_transitions"]
    transition_count = sum(len(targets) for targets in transitions.values())
    lines = ["stateDiagram-v2"]
    for source, targets in transitions.items():
        lines.extend(f"  {source} --> {target}" for target in targets)
    return {
        "state_model_version": state["state_model_version"],
        "job_types": copy.deepcopy(state["job_types"]),
        "job_states": copy.deepcopy(state["job_states"]),
        "terminal_states": copy.deepcopy(state["terminal_states"]),
        "allowed_transitions": copy.deepcopy(transitions),
        "allowed_transition_count": transition_count,
        "new_job_state_defined": False,
        "terminal_state_automatic_reopen_allowed": False,
        "mermaid_state_diagram": "\n".join(lines),
    }


def _failure_retry_log(stage040: Mapping[str, Any]) -> dict[str, Any]:
    return copy.deepcopy(stage040["failure_retry_log"])


def _backpressure_trigger_proof(stage040: Mapping[str, Any]) -> dict[str, Any]:
    return copy.deepcopy(stage040["backpressure_trigger_proof"])


def _lock_control_proof(stage041: Mapping[str, Any]) -> dict[str, Any]:
    return copy.deepcopy(stage041["lock_control_proof"])


def _lifecycle_scenario_proof(phase3: Mapping[str, Any]) -> dict[str, Any]:
    results = phase3["scenario_results"]
    resume = results["resume_requires_fresh_owner_and_stable_resources"]
    close = results["safe_close_active_writer_times_out_without_force_kill"]
    return {
        "scenario_count": phase3["scenario_count"],
        "passed_scenario_count": phase3["passed_scenario_count"],
        "scenario_names": list(results),
        "actual_isolated_worker_exception_performed": phase3[
            "actual_isolated_worker_exception_performed"
        ],
        "actual_disk_observation_performed": phase3[
            "actual_disk_observation_performed"
        ],
        "guarded_resume_result_code": resume["ready_result_code"],
        "guarded_resume_transition": resume["ready_transition"],
        "stale_owner_result_code": resume["stale_owner_result_code"],
        "unstable_resource_result_code": resume["unstable_resource_result_code"],
        "active_writer_close_result_code": close["result_code"],
        "active_writer_close_action": close["decision_action"],
        "force_kill_performed": close["force_kill_performed"],
        "production_lifecycle_runtime_performed": False,
    }


def _cleanup_allowlist(
    contract: Mapping[str, Any], phase3: Mapping[str, Any]
) -> dict[str, Any]:
    cleanup = contract["cleanup_allowlist"]
    protected = phase3["scenario_results"]["protected_cleanup_denied"]
    checks = {
        key: value == "PROTECTED_ARTIFACT"
        for key, value in protected["category_decisions"].items()
    }
    return {
        "cleanup_eligible_classes": copy.deepcopy(
            cleanup["cleanup_eligible_classes"]
        ),
        "protected_artifact_classes": copy.deepcopy(
            cleanup["protected_artifact_classes"]
        ),
        "cleanup_manifest_required": cleanup["cleanup_manifest_required"],
        "required_preconditions": copy.deepcopy(cleanup["required_preconditions"]),
        "protected_ref_count": protected["protected_ref_count"],
        "phase3_protected_ref_checks": checks,
        "cleanup_runtime_performed": False,
        "delete_attempt_performed": False,
        "runtime_owner": cleanup["runtime_owner"],
    }


def _recovery_handling(
    contract: Mapping[str, Any],
    stage039: Mapping[str, Any],
    phase3: Mapping[str, Any],
) -> dict[str, Any]:
    recovery = contract["recovery_handling"]
    retry = stage039["recovery_handling"]
    scenarios = phase3["scenario_results"]
    resume = scenarios["resume_requires_fresh_owner_and_stable_resources"]
    return {
        "isolated_automatic_continuation_candidate_cases": copy.deepcopy(
            recovery["isolated_automatic_continuation_candidate_cases"]
        ),
        "production_automatic_recovery_eligible_cases": [],
        "successful_production_automatic_recovery_cases_observed": [],
        "required_resume_guards": copy.deepcopy(recovery["required_resume_guards"]),
        "required_retry_resume_guards": copy.deepcopy(
            recovery["required_retry_resume_guards"]
        ),
        "manual_action_required_cases": copy.deepcopy(
            recovery["manual_action_required_cases"]
        ),
        "isolated_guarded_resume_candidate_observed": (
            resume.get("ready_result_code") == "RESUME_QUEUED_CANDIDATE"
            and resume.get("ready_transition") == "PAUSED->QUEUED"
        ),
        "isolated_controlled_retry_admission_observed": (
            retry.get("controlled_retry_admission_observed") is True
        ),
        "automatic_resume_production_performed": False,
        "process_crash_recovery_performed": False,
        "process_crash_recovery_runtime_owner": recovery[
            "process_crash_recovery_runtime_owner"
        ],
        "cleanup_execution_runtime_owner": recovery[
            "cleanup_execution_runtime_owner"
        ],
    }


def _safe_shutdown_and_recovery(
    contract: Mapping[str, Any], phase2: Any, phase3: Mapping[str, Any]
) -> dict[str, Any]:
    phase2_contract = phase2.load_contract()
    engine = phase2.IsolatedAutomaticLifecycle(phase2_contract)
    queued = phase2.build_control_snapshot(
        "QUEUED", 100, safe_close_started_at=100
    )
    close = engine.evaluate(
        queued,
        phase2.build_lifecycle_request(queued, intent="SAFE_CLOSE", logical_now=110),
    )
    timeout = phase3["scenario_results"][
        "safe_close_active_writer_times_out_without_force_kill"
    ]
    shutdown = contract["safe_shutdown_and_recovery"]
    return {
        "shutdown_steps": copy.deepcopy(shutdown["shutdown_steps"]),
        "recovery_steps": copy.deepcopy(shutdown["recovery_steps"]),
        "safe_close_result_code": close.get("result_code"),
        "safe_close_transition": close.get("transition"),
        "controller_state": close.get("candidate_snapshot", {}).get(
            "controller_state"
        ),
        "active_writer_timeout_result_code": timeout.get("result_code"),
        "active_writer_timeout_action": timeout.get("decision_action"),
        "persistent_lifecycle_state_available_after_exit": False,
        "force_kill_performed": False,
        "process_termination_performed": False,
        "automatic_process_recovery_performed": False,
        "safe_close_production_performed": False,
    }


def _delivery_checks(
    graph: Mapping[str, Any],
    log: Mapping[str, Any],
    pressure: Mapping[str, Any],
    locks: Mapping[str, Any],
    scenarios: Mapping[str, Any],
    cleanup: Mapping[str, Any],
    recovery: Mapping[str, Any],
    shutdown: Mapping[str, Any],
) -> dict[str, bool]:
    return {
        "job_state_graph_exact": (
            graph.get("state_model_version") == "ids.job_state.v1"
            and len(graph.get("job_types", [])) == 8
            and len(graph.get("job_states", [])) == 11
            and len(graph.get("terminal_states", [])) == 4
            and graph.get("allowed_transition_count") == 21
            and graph.get("new_job_state_defined") is False
            and graph.get("terminal_state_automatic_reopen_allowed") is False
        ),
        "reviewed_failure_retry_log_exact": (
            log.get("source")
            == "STAGE039_REVIEWED_PHASE4_ACTUAL_ISOLATED_CONTROL_METADATA"
            and log.get("attempt_count") == 3
            and log.get("retry_count") == 2
            and log.get("max_retries") == 2
            and log.get("final_state") == "DEAD_LETTERED"
            and log.get("reviewed_stage039_delivery_valid") is True
            and log.get("persisted") is False
        ),
        "reviewed_backpressure_proof_exact": (
            set(pressure) == set(PRESSURE_SIGNALS)
            and pressure.get("QUEUE_HARD_CAPACITY", {}).get("decision_action")
            == "DENY_NEW_ADMISSION"
            and all(
                pressure.get(signal, {}).get("decision_action")
                == "PAUSE_RESOURCE_GATE"
                for signal in RESOURCE_PAUSE_SIGNALS
            )
        ),
        "reviewed_lock_proof_exact": (
            locks.get("operation_families") == OPERATION_FAMILIES
            and locks.get("operation_acquired_count") == 5
            and locks.get("operation_duplicate_conflict_count") == 5
            and locks.get("same_source_cross_operation_conflict_count") == 4
            and locks.get("stale_commit_result_code") == "STALE_FENCING_TOKEN"
            and locks.get("persistent_lock_write_performed") is False
        ),
        "phase3_lifecycle_scenarios_exact": (
            scenarios.get("scenario_count") == 10
            and scenarios.get("passed_scenario_count") == 10
            and scenarios.get("actual_isolated_worker_exception_performed") is True
            and scenarios.get("actual_disk_observation_performed") is True
            and scenarios.get("guarded_resume_result_code")
            == "RESUME_QUEUED_CANDIDATE"
            and scenarios.get("active_writer_close_result_code")
            == "SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER"
            and scenarios.get("force_kill_performed") is False
        ),
        "cleanup_allowlist_narrow_and_protected": (
            cleanup.get("cleanup_eligible_classes") == CLEANUP_CLASSES
            and cleanup.get("protected_artifact_classes") == PROTECTED_CLASSES
            and cleanup.get("protected_ref_count") == 5
            and all(cleanup.get("phase3_protected_ref_checks", {}).values())
            and cleanup.get("cleanup_runtime_performed") is False
            and cleanup.get("delete_attempt_performed") is False
        ),
        "automatic_and_manual_handling_truthful": (
            recovery.get("isolated_automatic_continuation_candidate_cases")
            == ISOLATED_CONTINUATION_CANDIDATES
            and recovery.get("production_automatic_recovery_eligible_cases") == []
            and recovery.get(
                "successful_production_automatic_recovery_cases_observed"
            )
            == []
            and recovery.get("manual_action_required_cases") == MANUAL_ACTION_CASES
            and recovery.get("isolated_guarded_resume_candidate_observed") is True
            and recovery.get("isolated_controlled_retry_admission_observed") is True
            and recovery.get("automatic_resume_production_performed") is False
            and recovery.get("process_crash_recovery_performed") is False
        ),
        "safe_shutdown_and_recovery_fail_closed": (
            shutdown.get("shutdown_steps") == SHUTDOWN_STEPS
            and shutdown.get("recovery_steps") == RECOVERY_STEPS
            and shutdown.get("safe_close_result_code") == "SAFE_CLOSE_COMPLETED"
            and shutdown.get("safe_close_transition") == "QUEUED->PAUSED"
            and shutdown.get("controller_state") == "CLOSED"
            and shutdown.get("active_writer_timeout_result_code")
            == "SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER"
            and shutdown.get("force_kill_performed") is False
            and shutdown.get("process_termination_performed") is False
            and shutdown.get("persistent_lifecycle_state_available_after_exit")
            is False
        ),
    }


def _blank_report(
    contract: Mapping[str, Any], checks: Mapping[str, bool]
) -> dict[str, Any]:
    return {
        "schema_version": "ids.stage042.automatic_lifecycle.phase4.report.v1",
        "stage": "STAGE-042",
        "phase": "Phase 4",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "execution_mode": EXECUTION_MODE,
        "policy_version": POLICY_VERSION,
        "contract_checks": dict(checks),
        "contract_valid": bool(checks) and all(checks.values()),
        "delivery_checks_performed": False,
        "delivery_checks": {},
        "delivery_contract_valid": False,
        "result": "BLOCKED_INVALID_OR_UNCHECKED_DELIVERY_CONTRACT",
        "stage_review_status": "blocked_invalid_delivery_contract",
        "next_gate": PHASE4_GATE,
        "execution_ready": False,
        "job_state_graph": {},
        "failure_retry_log": {},
        "backpressure_trigger_proof": {},
        "lock_control_proof": {},
        "lifecycle_scenario_proof": {},
        "cleanup_allowlist": {},
        "recovery_handling": {},
        "safe_shutdown_and_recovery": {},
        "rollback_steps": copy.deepcopy(ROLLBACK_STEPS),
        "known_limits": copy.deepcopy(KNOWN_LIMITS),
        "source_error_type": None,
        **{key: False for key in POSITIVE_TRUTH_FLAGS | FALSE_TRUTH_FLAGS},
        "owner_feedback_zh": "交付合同未通过；保持停止并返回 Phase 4 修复。",
    }


def build_stage042_phase4_delivery_report(
    *,
    contract: Optional[Any] = None,
    execute_delivery_checks: bool = True,
) -> dict[str, Any]:
    try:
        contract_value = (
            copy.deepcopy(contract) if contract is not None else load_delivery_contract()
        )
    except (OSError, ValueError, json.JSONDecodeError):
        contract_value = {}
    checks = validate_delivery_contract(contract_value)
    safe_contract = contract_value if isinstance(contract_value, dict) else {}
    report = _blank_report(safe_contract, checks)
    if not report["contract_valid"] or not execute_delivery_checks:
        if report["contract_valid"]:
            report["stage_review_status"] = "blocked_delivery_checks_not_executed"
        return report

    try:
        stage039 = _load_module(
            STAGE039_CHECKER, "stage039_retry_delivery_for_stage042"
        ).build_stage039_phase4_delivery_report()
        stage040 = _load_module(
            STAGE040_CHECKER, "stage040_backpressure_delivery_for_stage042"
        ).build_stage040_phase4_delivery_report()
        stage041 = _load_module(
            STAGE041_CHECKER, "stage041_lock_delivery_for_stage042"
        ).build_stage041_phase4_delivery_report()
        phase2 = _load_module(P2_CHECKER, "stage042_lifecycle_runtime_for_delivery")
        phase2_report = phase2.build_stage042_phase2_report()
        phase3 = _load_module(
            P3_CHECKER, "stage042_lifecycle_scenarios_for_delivery"
        ).build_stage042_phase3_report()
        if stage039.get("delivery_contract_valid") is not True:
            raise RuntimeError("invalid reviewed Stage039 delivery prerequisite")
        if stage040.get("delivery_contract_valid") is not True:
            raise RuntimeError("invalid reviewed Stage040 delivery prerequisite")
        if stage041.get("delivery_contract_valid") is not True:
            raise RuntimeError("invalid reviewed Stage041 delivery prerequisite")
        if phase2_report.get("phase2_slice_valid") is not True:
            raise RuntimeError("invalid Stage042 Phase 2 prerequisite")
        if phase3.get("scenario_validation_valid") is not True:
            raise RuntimeError("invalid Stage042 Phase 3 prerequisite")

        graph = _job_state_graph()
        log = _failure_retry_log(stage040)
        pressure = _backpressure_trigger_proof(stage040)
        locks = _lock_control_proof(stage041)
        scenarios = _lifecycle_scenario_proof(phase3)
        cleanup = _cleanup_allowlist(safe_contract, phase3)
        recovery = _recovery_handling(safe_contract, stage039, phase3)
        shutdown = _safe_shutdown_and_recovery(safe_contract, phase2, phase3)
        delivery_checks = _delivery_checks(
            graph,
            log,
            pressure,
            locks,
            scenarios,
            cleanup,
            recovery,
            shutdown,
        )
    except Exception as exc:
        report["source_error_type"] = type(exc).__name__
        report["stage_review_status"] = "blocked_upstream_or_delivery_failure"
        report["owner_feedback_zh"] = (
            "上游或交付检查失败；保持停止并返回 Phase 4 修复。"
        )
        return report

    valid = bool(delivery_checks) and all(delivery_checks.values())
    owner = safe_contract["owner_feedback_contract"]
    truth = safe_contract["truth_flags"]
    report.update(
        {
            "delivery_checks_performed": True,
            "delivery_checks": delivery_checks,
            "delivery_contract_valid": valid,
            "result": VALID_RESULT if valid else "FAIL_CLOSEOUT_CHECKS",
            "stage_review_status": (
                "pending_next_run" if valid else "blocked_delivery_check_failure"
            ),
            "next_gate": REVIEW_GATE if valid else PHASE4_GATE,
            "job_state_graph": graph,
            "failure_retry_log": log,
            "backpressure_trigger_proof": pressure,
            "lock_control_proof": locks,
            "lifecycle_scenario_proof": scenarios,
            "cleanup_allowlist": cleanup,
            "recovery_handling": recovery,
            "safe_shutdown_and_recovery": shutdown,
            **{key: bool(truth[key]) for key in POSITIVE_TRUTH_FLAGS},
            **{key: bool(truth[key]) for key in FALSE_TRUTH_FLAGS},
            "owner_feedback_zh": " ".join(
                [
                    owner["status_zh"],
                    owner["automatic_candidate_zh"],
                    owner["manual_action_zh"],
                    owner["limit_zh"],
                ]
            ),
        }
    )
    return report


def main() -> int:
    report = build_stage042_phase4_delivery_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["delivery_contract_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
