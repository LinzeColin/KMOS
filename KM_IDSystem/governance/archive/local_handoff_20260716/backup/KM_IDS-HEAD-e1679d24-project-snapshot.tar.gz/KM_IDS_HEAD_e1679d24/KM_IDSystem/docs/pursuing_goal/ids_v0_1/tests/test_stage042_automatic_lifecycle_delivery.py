import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parents[4]
REPO_ROOT = ROOT.parent
BASE = ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
CONTRACT = (
    BASE
    / "automatic_lifecycle"
    / "stage042_automatic_lifecycle_delivery_contract.json"
)
EVIDENCE = BASE / "STAGE042_PHASE4_CLOSEOUT.md"
CHECKER = ROOT / "scripts" / "check_automatic_lifecycle_delivery.py"
CURRENT_BATCH = BASE / "BATCH041_050_UPLOAD_LOCK.yaml"
ROADMAP = ROOT / "docs" / "governance" / "roadmap.yaml"
EVENTS = ROOT / "docs" / "governance" / "events.jsonl"

EXPECTED_OPERATION_FAMILIES = {
    "FILE_PROCESSING",
    "ARCHIVE_EXTRACTION",
    "INDEX_BUILD",
    "INDEX_SWITCH",
    "REPORT_GENERATION",
}
EXPECTED_PRESSURE_SIGNALS = {
    "QUEUE_SOFT_PRESSURE",
    "QUEUE_HARD_CAPACITY",
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
    "JOB_TYPE_CONCURRENCY_LIMIT_REACHED",
    "SAME_SOURCE_CONFLICT",
}
EXPECTED_CLEANUP_CLASSES = {
    "TEMPORARY_PARTIAL_OUTPUT",
    "REBUILDABLE_CACHE",
}
EXPECTED_PROTECTED_CLASSES = {
    "ORIGINAL_RAW_DATA",
    "FACT_SOURCE",
    "MANIFEST",
    "EVIDENCE_LEDGER",
    "REPORT_SNAPSHOT",
    "AUDIT_LOG",
    "ACTIVE_INDEX",
    "REQUIRED_CHECKPOINT",
}
EXPECTED_ISOLATED_CONTINUATION_CANDIDATES = {
    "RESOURCE_PAUSED_JOB_AFTER_FRESH_OWNER_AND_STABLE_RESOURCE_GATES",
    "RETRY_WAIT_SAFE_FAILURE_AFTER_STAGE039_EXACT_GATES",
}


class Stage042AutomaticLifecycleDeliveryTests(unittest.TestCase):
    def _module(self):
        self.assertTrue(CHECKER.is_file(), f"missing Phase 4 checker: {CHECKER}")
        spec = importlib.util.spec_from_file_location(
            "stage042_automatic_lifecycle_delivery", CHECKER
        )
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def _contract(self):
        self.assertTrue(CONTRACT.is_file(), f"missing Phase 4 contract: {CONTRACT}")
        return json.loads(CONTRACT.read_text(encoding="utf-8"))

    def _report(self):
        return self._module().build_stage042_phase4_delivery_report()

    def test_phase4_contract_sources_and_fail_closed_tampering(self):
        module = self._module()
        contract = self._contract()
        self.assertTrue(EVIDENCE.is_file(), f"missing Phase 4 evidence: {EVIDENCE}")
        checks = module.validate_delivery_contract(contract)
        self.assertTrue(all(checks.values()), checks)
        self.assertEqual("IDS-V0_1-STAGE042-P4", contract["task_id"])
        self.assertEqual("ACC-STAGE-042", contract["acceptance_id"])
        for binding in contract["upstream_bindings"].values():
            path = REPO_ROOT / binding["ref"]
            self.assertTrue(path.is_file(), path)
            self.assertEqual(binding["sha256"], module.sha256_file(path))

        mutations = []
        for mutate in (
            lambda value: value.update({"unknown_root": True}),
            lambda value: value.update({"delivery_contract": []}),
            lambda value: value["delivery_contract"][
                "required_pressure_signals"
            ].append("UNREGISTERED_PRESSURE"),
            lambda value: value["cleanup_allowlist"][
                "cleanup_eligible_classes"
            ].append("FACT_SOURCE"),
            lambda value: value["recovery_handling"].update(
                {"successful_production_automatic_recovery_cases_observed": ["FAKE"]}
            ),
            lambda value: value["review_gate"].update(
                {"phase4_may_mark_stage_reviewed": True}
            ),
            lambda value: value["truth_flags"].update(
                {"production_runtime_activation_performed": True}
            ),
        ):
            candidate = copy.deepcopy(contract)
            mutate(candidate)
            mutations.append(candidate)
        for candidate in mutations:
            with self.subTest(candidate=candidate):
                blocked = module.build_stage042_phase4_delivery_report(
                    contract=candidate, execute_delivery_checks=True
                )
                self.assertFalse(blocked["contract_valid"], blocked)
                self.assertFalse(blocked["delivery_checks_performed"], blocked)
                self.assertEqual("IDS-STAGE042-P4-GATE", blocked["next_gate"])
        for candidate in ([], "not-an-object"):
            with self.subTest(non_object=candidate):
                blocked = module.build_stage042_phase4_delivery_report(
                    contract=candidate, execute_delivery_checks=True
                )
                self.assertFalse(blocked["contract_valid"], blocked)
                self.assertFalse(blocked["delivery_checks_performed"], blocked)

        source = CHECKER.read_text(encoding="utf-8")
        for forbidden_api in (
            "os.remove(",
            ".unlink(",
            "shutil.rmtree(",
            "sqlite3.connect(",
            "psycopg.connect(",
            "requests.",
            ".write_text(",
            ".write_bytes(",
        ):
            with self.subTest(forbidden_api=forbidden_api):
                self.assertNotIn(forbidden_api, source)

    def test_job_state_graph_is_exact_and_replayable(self):
        graph = self._report()["job_state_graph"]
        self.assertEqual("ids.job_state.v1", graph["state_model_version"])
        self.assertEqual(8, len(graph["job_types"]))
        self.assertEqual(11, len(graph["job_states"]))
        self.assertEqual(4, len(graph["terminal_states"]))
        self.assertEqual(21, graph["allowed_transition_count"])
        self.assertIn("stateDiagram-v2", graph["mermaid_state_diagram"])
        self.assertFalse(graph["new_job_state_defined"])
        self.assertFalse(graph["terminal_state_automatic_reopen_allowed"])

    def test_failure_retry_and_backpressure_evidence_is_reviewed(self):
        report = self._report()
        log = report["failure_retry_log"]
        pressure = report["backpressure_trigger_proof"]
        self.assertEqual(3, log["attempt_count"])
        self.assertEqual(2, log["retry_count"])
        self.assertEqual(2, log["max_retries"])
        self.assertEqual("DEAD_LETTERED", log["final_state"])
        self.assertEqual([], log["output_refs"])
        self.assertTrue(log["reviewed_stage039_delivery_valid"])
        self.assertFalse(log["persisted"])
        self.assertEqual(EXPECTED_PRESSURE_SIGNALS, set(pressure))
        self.assertEqual(
            "DENY_NEW_ADMISSION",
            pressure["QUEUE_HARD_CAPACITY"]["decision_action"],
        )
        for signal in (
            "EXTERNAL_DRIVE_OFFLINE",
            "DISK_SPACE_INSUFFICIENT",
            "EXTERNAL_API_BUDGET_INSUFFICIENT",
        ):
            with self.subTest(signal=signal):
                self.assertEqual(
                    "PAUSE_RESOURCE_GATE", pressure[signal]["decision_action"]
                )

    def test_lock_and_lifecycle_scenario_proofs_are_complete(self):
        report = self._report()
        locks = report["lock_control_proof"]
        scenarios = report["lifecycle_scenario_proof"]
        self.assertEqual(EXPECTED_OPERATION_FAMILIES, set(locks["operation_families"]))
        self.assertEqual(5, locks["operation_acquired_count"])
        self.assertEqual(5, locks["operation_duplicate_conflict_count"])
        self.assertEqual(4, locks["same_source_cross_operation_conflict_count"])
        self.assertEqual("STALE_FENCING_TOKEN", locks["stale_commit_result_code"])
        self.assertFalse(locks["persistent_lock_write_performed"])
        self.assertEqual(10, scenarios["scenario_count"])
        self.assertEqual(10, scenarios["passed_scenario_count"])
        self.assertTrue(scenarios["actual_isolated_worker_exception_performed"])
        self.assertTrue(scenarios["actual_disk_observation_performed"])
        self.assertEqual(
            "RESUME_QUEUED_CANDIDATE",
            scenarios["guarded_resume_result_code"],
        )
        self.assertEqual(
            "SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER",
            scenarios["active_writer_close_result_code"],
        )

    def test_cleanup_allowlist_is_narrow_and_protected(self):
        cleanup = self._report()["cleanup_allowlist"]
        self.assertEqual(
            EXPECTED_CLEANUP_CLASSES, set(cleanup["cleanup_eligible_classes"])
        )
        self.assertEqual(
            EXPECTED_PROTECTED_CLASSES,
            set(cleanup["protected_artifact_classes"]),
        )
        self.assertEqual(5, cleanup["protected_ref_count"])
        self.assertTrue(all(cleanup["phase3_protected_ref_checks"].values()))
        self.assertTrue(cleanup["cleanup_manifest_required"])
        self.assertFalse(cleanup["cleanup_runtime_performed"])
        self.assertFalse(cleanup["delete_attempt_performed"])
        self.assertEqual("STAGE-044", cleanup["runtime_owner"])

    def test_recovery_classification_does_not_overclaim_production(self):
        recovery = self._report()["recovery_handling"]
        self.assertEqual(
            EXPECTED_ISOLATED_CONTINUATION_CANDIDATES,
            set(recovery["isolated_automatic_continuation_candidate_cases"]),
        )
        self.assertEqual([], recovery["production_automatic_recovery_eligible_cases"])
        self.assertEqual(
            [], recovery["successful_production_automatic_recovery_cases_observed"]
        )
        self.assertIn(
            "WORKER_OR_PROCESS_LOSS", recovery["manual_action_required_cases"]
        )
        self.assertIn(
            "ACTIVE_WRITER_SAFE_CLOSE_TIMEOUT",
            recovery["manual_action_required_cases"],
        )
        self.assertIn(
            "PROTECTED_CLEANUP_REQUEST", recovery["manual_action_required_cases"]
        )
        self.assertFalse(recovery["automatic_resume_production_performed"])
        self.assertFalse(recovery["process_crash_recovery_performed"])
        self.assertEqual("STAGE-043", recovery["process_crash_recovery_runtime_owner"])

    def test_safe_shutdown_recovery_and_rollback_are_explicit(self):
        report = self._report()
        shutdown = report["safe_shutdown_and_recovery"]
        self.assertEqual("SAFE_CLOSE_COMPLETED", shutdown["safe_close_result_code"])
        self.assertEqual("QUEUED->PAUSED", shutdown["safe_close_transition"])
        self.assertEqual("CLOSED", shutdown["controller_state"])
        self.assertEqual(
            "SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER",
            shutdown["active_writer_timeout_result_code"],
        )
        self.assertFalse(shutdown["force_kill_performed"])
        self.assertFalse(shutdown["process_termination_performed"])
        self.assertFalse(shutdown["persistent_lifecycle_state_available_after_exit"])
        self.assertIn("STOP_NEW_ADMISSION_DECISIONS", shutdown["shutdown_steps"])
        self.assertIn("REVALIDATE_OWNER_AND_RESOURCE_GATES", shutdown["recovery_steps"])
        self.assertIn("DEFER_PROCESS_CRASH_RECOVERY_TO_STAGE043", shutdown["recovery_steps"])
        self.assertGreaterEqual(len(report["rollback_steps"]), 6)
        self.assertIn("DISABLE_ISOLATED_LIFECYCLE", report["rollback_steps"])

    def test_delivery_truth_and_chinese_feedback_stop_at_review(self):
        report = self._report()
        self.assertEqual("PASS_ISOLATED_CLOSEOUT_PRODUCTION_DISABLED", report["result"])
        self.assertEqual("pending_next_run", report["stage_review_status"])
        self.assertEqual("IDS-STAGE042-REVIEW-GATE", report["next_gate"])
        self.assertFalse(report["execution_ready"])
        for flag in (
            "production_runtime_activation_performed",
            "persistent_lifecycle_runtime_performed",
            "database_connection_performed",
            "runtime_output_written",
            "ids_business_source_read_performed",
            "raw_metadata_content_accessed",
            "fake_ids_business_data_used",
            "real_ids_business_job_created",
            "automatic_resume_production_performed",
            "safe_close_production_performed",
            "force_kill_performed",
            "process_crash_recovery_performed",
            "cleanup_runtime_performed",
            "whole_stage_review_performed",
            "batch_review_performed",
            "github_upload_allowed",
            "app_reinstall_allowed",
        ):
            with self.subTest(flag=flag):
                self.assertFalse(report[flag])
        self.assertIn("仅形成隔离候选", report["owner_feedback_zh"])
        self.assertIn("需要人工处理", report["owner_feedback_zh"])
        self.assertIn("不是生产运行或生产就绪证明", report["owner_feedback_zh"])

    def test_phase4_governance_routes_only_to_whole_stage_review(self):
        self.assertTrue(EVIDENCE.is_file(), f"missing closeout: {EVIDENCE}")
        current_batch = CURRENT_BATCH.read_text(encoding="utf-8")
        roadmap = ROADMAP.read_text(encoding="utf-8")
        self.assertIn(
            'stage042_phase4_state:\n'
            '    status: "stage042_phase4_completed_review_pending"\n'
            '    current_task_id: "IDS-V0_1-STAGE042-P4"\n'
            '    next_allowed_task_id: "IDS-V0_1-STAGE042-REVIEW"',
            current_batch,
        )
        self.assertIn('status: "stage042_completed_reviewed_local"', current_batch)
        self.assertIn('next_gate: "IDS-STAGE043-P1-GATE"', current_batch)
        self.assertIn('current_task_id: "IDS-V0_1-STAGE042-REVIEW"', current_batch)
        self.assertIn('stage_review_entry_authorized: false', current_batch)
        self.assertIn('push_allowed: false', current_batch)
        self.assertIn(
            'stage042_phase4_state:\n'
            '    current_stage_id: "IDS-STAGE042"\n'
            '    current_phase_id: "IDS-STAGE042-P4"\n'
            '    current_task_id: "IDS-V0_1-STAGE042-P4"\n'
            '    next_gate_id: "IDS-STAGE042-REVIEW-GATE"',
            roadmap,
        )
        self.assertIn('current_phase_id: "IDS-STAGE042-REVIEW"', roadmap)
        self.assertIn('current_task_id: "IDS-V0_1-STAGE042-REVIEW"', roadmap)
        self.assertIn('next_gate_id: "IDS-STAGE043-P1-GATE"', roadmap)
        self.assertIn('entry_authorized: false', roadmap)

        events = [
            json.loads(line)
            for line in EVENTS.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        matching = [
            item
            for item in events
            if item.get("event_id") == "EVT-IDS-V0_1-STAGE042-P4-20260715-001"
        ]
        self.assertEqual(1, len(matching), matching)
        self.assertEqual("phase_completed", matching[0]["event_type"])
        self.assertEqual("IDS-V0_1-STAGE042-P4", matching[0]["task_id"])
        self.assertIn("whole_stage_review_performed=false", matching[0]["notes"])
        self.assertIn("batch_review_performed=false", matching[0]["notes"])
        self.assertIn("push_allowed=false", matching[0]["notes"])

    def test_cli_returns_exact_machine_report(self):
        module = self._module()
        completed = subprocess.run(
            [sys.executable, "-B", str(CHECKER)],
            cwd=REPO_ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
        self.assertEqual("", completed.stderr)
        payload = json.loads(completed.stdout)
        self.assertTrue(payload["delivery_contract_valid"], payload)
        self.assertEqual("IDS-STAGE042-REVIEW-GATE", payload["next_gate"])
        self.assertEqual(module.VALID_RESULT, payload["result"])


if __name__ == "__main__":
    unittest.main()
