#!/usr/bin/env python3
"""Run and validate the STAGE-042 Phase 2 isolated lifecycle slice."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Optional


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent
CONTRACT_PATH = (
    PROJECT_ROOT
    / "docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
    "stage042_automatic_lifecycle_runtime_contract.json"
)
POLICY_VERSION = "ids.automatic_lifecycle_policy.v0_1.stage042.p2"
TASK_ID = "IDS-V0_1-STAGE042-P2"
ACCEPTANCE_ID = "ACC-STAGE-042"

PARAMETERS = {
    "lifecycle_evaluation_interval": 10,
    "pause_acknowledgement_timeout": 30,
    "safe_close_timeout": 35,
    "owner_revalidation_ttl": 30,
    "resource_gate_stability_window": 60,
}
CONTROL_REFS = [
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE042_ENTRY_CONTRACT.md",
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE042_PHASE1_AUTOMATIC_LIFECYCLE_SCOPE_BOUNDARY.md",
]
SOURCE_BINDING = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-042_自动运行、暂停、恢复与关闭.md"
    ),
    "source_member_match_count": 1,
    "source_member_integrity": "OK",
    "source_member_sha256": (
        "78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}
UPSTREAM_BINDINGS = {
    "phase1_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
        "stage042_automatic_lifecycle_contract.json",
        "9a964ca89c3fab9c58755856374813be811677579eefae96ed9ff34200d972f0",
    ),
    "stage037_state_index": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/job_state_model/"
        "stage037_job_state_model_index.json",
        "b70bf72ebe4212f45d380c13fbfe429791e1f4a5c73dccbba81211b7adc1c2d3",
    ),
    "stage039_retry_runtime": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/retry_dead_letter/"
        "stage039_retry_dead_letter_runtime_contract.json",
        "5fc9b49b0ede0fdbc87311f3280ffc69e8ec8e59f219b17a04a2ccae1e9124c0",
    ),
    "stage040_backpressure_runtime": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
        "stage040_backpressure_runtime_contract.json",
        "3db2409b082b9f788e061dfbb3a8e33ad8459c8e56a863e21fe0faeca8581b5c",
    ),
    "stage041_lock_runtime": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_runtime_contract.json",
        "935c0d7358b4125ba96cbd1d53b869acdc831ab2b6e3b4fd21f155f07a585a7c",
    ),
}
PROVENANCE = {
    "lifecycle_evaluation_interval": (
        10,
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_runtime_contract.json#/policy/parameters/"
        "renewal_interval_seconds",
        UPSTREAM_BINDINGS["stage041_lock_runtime"][1],
        "DIRECT_REUSE_OF_STAGE041_RENEWAL_INTERVAL",
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
        "test_stage041_lock_registry_runtime.py",
    ),
    "pause_acknowledgement_timeout": (
        30,
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_runtime_contract.json#/policy/parameters/"
        "lease_duration_seconds",
        UPSTREAM_BINDINGS["stage041_lock_runtime"][1],
        "DIRECT_REUSE_OF_STAGE041_LEASE_DURATION",
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
        "test_stage041_lock_registry_runtime.py",
    ),
    "safe_close_timeout": (
        35,
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_runtime_contract.json#/policy/parameters",
        UPSTREAM_BINDINGS["stage041_lock_runtime"][1],
        "STAGE041_LEASE_DURATION_30_PLUS_EXPIRY_GRACE_5",
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
        "test_stage041_lock_registry_runtime.py",
    ),
    "owner_revalidation_ttl": (
        30,
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
        "stage040_backpressure_runtime_contract.json#/policy/parameters/"
        "observation_ttl_seconds",
        UPSTREAM_BINDINGS["stage040_backpressure_runtime"][1],
        "DIRECT_REUSE_OF_STAGE040_OBSERVATION_TTL",
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
        "test_stage040_backpressure_runtime.py",
    ),
    "resource_gate_stability_window": (
        60,
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
        "stage040_backpressure_runtime_contract.json#/policy/parameters/"
        "external_api_budget_window_seconds",
        UPSTREAM_BINDINGS["stage040_backpressure_runtime"][1],
        "DIRECT_REUSE_OF_STAGE040_API_BUDGET_WINDOW",
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
        "test_stage040_backpressure_runtime.py",
    ),
}
JOB_TYPES = ["IMPORT", "ARCHIVE", "PARSE", "OCR", "CHUNK", "EMBED", "INDEX", "REPORT"]
JOB_STATES = {
    "CREATED",
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "PAUSE_REQUESTED",
    "PAUSED",
    "RETRY_WAIT",
    "SUCCEEDED",
    "FAILED",
    "DEAD_LETTERED",
    "CANCELLED",
}
TERMINAL_STATES = {"SUCCEEDED", "FAILED", "DEAD_LETTERED", "CANCELLED"}
PAUSE_REASONS = {
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
}
GUARD_FACTS = {
    "identity_idempotency_valid",
    "admission_gates_passed",
    "no_active_claim_or_lock",
    "claim_lease_and_lock_acquired",
    "live_lease_valid",
    "fencing_token_matches",
    "pause_intent_recorded",
    "resource_gate_blocked",
    "lease_valid_or_expiry_evidence",
    "checkpoint_or_quarantine_complete",
    "owner_revalidated",
    "resource_gates_passed",
    "no_active_writer",
    "audit_ref_present",
}
SNAPSHOT_FIELDS = {
    "evaluation_mode",
    "job_id",
    "job_type",
    "job_state",
    "state_version",
    "last_evaluated_at",
    "pause_requested_at",
    "safe_close_started_at",
    "owner_evaluated_at",
    "resource_gates_clear_since",
    "lease_active",
    "lock_active",
    "fencing_token",
    "active_writer",
    "pause_reason_code",
    "input_refs",
    "output_refs",
    "checkpoint_ref",
    "quarantine_ref",
    "error_ref",
    "controller_state",
}
REQUEST_FIELDS = {
    "request_id",
    "intent",
    "expected_state",
    "expected_state_version",
    "logical_now",
    "actor_ref",
    "reason_code",
    "guard_facts",
    "input_refs",
    "resource_gate_refs",
    "owner_evidence_ref",
    "owner_policy_version",
    "owner_authorization_state",
    "checkpoint_ref",
    "quarantine_ref",
    "error_ref",
    "canonical_intent_ref",
    "pause_reason_code",
    "candidate_fencing_token",
}
INTENTS = {"AUTO_START", "RESOURCE_PAUSE", "COMPLETE_PAUSE", "AUTO_RESUME", "SAFE_CLOSE"}
HUMAN_STATUS = {
    "START_EVALUATING": {
        "label_zh": "正在检查运行条件",
        "owner_action_zh": "无需操作",
        "owner_attention_required": False,
    },
    "PAUSE_REQUESTED": {
        "label_zh": "正在安全暂停",
        "owner_action_zh": "等待 checkpoint 或隔离证据",
        "owner_attention_required": True,
    },
    "PAUSED": {
        "label_zh": "已暂停",
        "owner_action_zh": "检查资源状态",
        "owner_attention_required": True,
    },
    "RESUME_EVALUATING": {
        "label_zh": "正在重新检查恢复条件",
        "owner_action_zh": "确认 owner 与资源门禁",
        "owner_attention_required": False,
    },
    "SAFE_CLOSED": {
        "label_zh": "已安全关闭",
        "owner_action_zh": "无需操作",
        "owner_attention_required": False,
    },
    "WAITING": {
        "label_zh": "等待安全条件",
        "owner_action_zh": "等待门禁满足",
        "owner_attention_required": False,
    },
    "MANUAL_REVIEW_REQUIRED": {
        "label_zh": "需要人工处理",
        "owner_action_zh": "检查控制证据并决定后续动作",
        "owner_attention_required": True,
    },
}
TRUE_FLAGS = {
    "parameter_values_assigned",
    "isolated_lifecycle_decision_runtime_performed",
    "isolated_control_metadata_evaluated",
    "automatic_start_candidate_evaluated",
    "automatic_pause_candidate_evaluated",
    "automatic_resume_candidate_evaluated",
    "safe_close_candidate_evaluated",
}
FALSE_FLAGS = {
    "persistent_lifecycle_runtime_performed",
    "queue_runtime_performed",
    "worker_runtime_performed",
    "retry_scheduler_performed",
    "lock_runtime_performed",
    "automatic_resume_production_performed",
    "safe_close_production_performed",
    "crash_recovery_runtime_performed",
    "cleanup_runtime_performed",
    "database_connection_performed",
    "schema_change_performed",
    "state_registry_write_performed",
    "runtime_output_written",
    "external_api_call_performed",
    "ids_business_source_read_performed",
    "raw_metadata_content_accessed",
    "fake_ids_business_data_used",
    "real_ids_business_job_created",
    "production_runtime_activation_performed",
    "phase3_executed",
    "whole_stage_review_performed",
    "github_upload_allowed",
    "app_reinstall_allowed",
}
ROOT_FIELDS = {
    "schema_version",
    "stage",
    "phase",
    "task_id",
    "acceptance_id",
    "execution_mode",
    "lifecycle_policy_version",
    "contract_state",
    "next_gate",
    "source_binding",
    "upstream_bindings",
    "parameter_policy",
    "control_metadata_contract",
    "state_transition_contract",
    "decision_contract",
    "idempotency_contract",
    "reference_record_contract",
    "human_status_projection",
    "ownership_matrix",
    "registry_binding",
    "runtime_boundary",
    "rollback",
    "truth_flags",
}


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, dict) else {}


def _exact_keys(value: Any, fields: set[str]) -> bool:
    return isinstance(value, dict) and set(value) == fields


def _integer(value: Any, *, minimum: int = 0) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= minimum


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _digest(value: Any) -> str:
    try:
        encoded = json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError):
        encoded = b"INVALID_NON_JSON_CONTROL_METADATA"
    return hashlib.sha256(encoded).hexdigest()


def _repo_ref_path(value: Any) -> Optional[Path]:
    if not isinstance(value, str) or not value.startswith("repo:") or "\\" in value:
        return None
    relative = value.removeprefix("repo:").split("#", 1)[0]
    pure = PurePosixPath(relative)
    if (
        pure.is_absolute()
        or ".." in pure.parts
        or not pure.as_posix().startswith("KM_IDSystem/")
        or "ids_metadata" in pure.as_posix().lower()
    ):
        return None
    path = REPO_ROOT / pure.as_posix()
    return path if path.is_file() else None


def _control_refs_valid(values: Any, *, allow_empty: bool = False) -> bool:
    return (
        isinstance(values, list)
        and (allow_empty or bool(values))
        and len(values) == len(set(values))
        and all(_repo_ref_path(value) is not None for value in values)
    )


def _record_ref(value: Any, prefix: str, *, optional: bool = True) -> bool:
    if value is None:
        return optional
    if not isinstance(value, str):
        return False
    if prefix == "error:":
        suffix = value.removeprefix(prefix)
        return value.startswith(prefix) and bool(suffix) and suffix.replace("_", "").isalnum()
    expected = prefix + "sha256:"
    digest = value.removeprefix(expected)
    return value.startswith(expected) and len(digest) == 64 and all(c in "0123456789abcdef" for c in digest)


def _upstream_valid(value: Any, verify_files: bool) -> bool:
    if not isinstance(value, dict) or set(value) != set(UPSTREAM_BINDINGS):
        return False
    for name, (relative, expected_hash) in UPSTREAM_BINDINGS.items():
        if value.get(name) != {"ref": relative, "sha256": expected_hash}:
            return False
        if verify_files:
            path = REPO_ROOT / relative
            if not path.is_file() or _sha256(path) != expected_hash:
                return False
    return True


def _provenance_valid(value: Any) -> bool:
    if not isinstance(value, dict) or set(value) != set(PROVENANCE):
        return False
    fields = {
        "value",
        "unit",
        "policy_version",
        "source_ref",
        "source_sha256",
        "derivation",
        "rationale",
        "validation_evidence_ref",
        "rollback",
    }
    for name, expected in PROVENANCE.items():
        item = value.get(name)
        if not _exact_keys(item, fields):
            return False
        expected_value, source_ref, source_hash, derivation, evidence_ref = expected
        if not (
            item.get("value") == expected_value
            and item.get("unit") == "seconds"
            and item.get("policy_version") == POLICY_VERSION
            and item.get("source_ref") == source_ref
            and item.get("source_sha256") == source_hash
            and item.get("derivation") == derivation
            and isinstance(item.get("rationale"), str)
            and len(item.get("rationale", "")) >= 40
            and item.get("validation_evidence_ref") == evidence_ref
            and item.get("rollback")
            == "DISABLE_ISOLATED_LIFECYCLE_AND_REQUIRE_MANUAL_REVIEW"
            and _repo_ref_path(source_ref) is not None
            and _repo_ref_path(evidence_ref) is not None
        ):
            return False
    return True


def evaluate_contract(contract: Any, verify_files: bool = False) -> dict[str, bool]:
    if not isinstance(contract, dict):
        return {"contract_is_object": False}
    policy = _mapping(contract.get("parameter_policy"))
    control = _mapping(contract.get("control_metadata_contract"))
    state = _mapping(contract.get("state_transition_contract"))
    decision = _mapping(contract.get("decision_contract"))
    idempotency = _mapping(contract.get("idempotency_contract"))
    references = _mapping(contract.get("reference_record_contract"))
    runtime = _mapping(contract.get("runtime_boundary"))
    rollback = _mapping(contract.get("rollback"))
    truth = _mapping(contract.get("truth_flags"))
    return {
        "root_shape_exact": set(contract) == ROOT_FIELDS,
        "identity_exact": (
            contract.get("schema_version")
            == "ids.stage042.automatic_lifecycle.phase2.v1"
            and contract.get("stage") == "STAGE-042"
            and contract.get("phase") == "Phase 2"
            and contract.get("task_id") == TASK_ID
            and contract.get("acceptance_id") == ACCEPTANCE_ID
            and contract.get("execution_mode")
            == "ISOLATED_NON_PRODUCTION_LIFECYCLE_DECISION_SLICE"
            and contract.get("lifecycle_policy_version") == POLICY_VERSION
            and contract.get("contract_state")
            == "PHASE2_ISOLATED_DECISION_SLICE_ENABLED_PRODUCTION_DISABLED"
            and contract.get("next_gate") == "IDS-STAGE042-P3-GATE"
        ),
        "source_binding_exact": contract.get("source_binding") == SOURCE_BINDING,
        "upstream_bindings_exact": _upstream_valid(
            contract.get("upstream_bindings"), verify_files
        ),
        "parameter_policy_complete": (
            _exact_keys(
                policy,
                {
                    "policy_version",
                    "parameters",
                    "provenance",
                    "fact_level",
                    "production_calibrated",
                    "production_calibration_required",
                    "production_calibration_task_id",
                    "implicit_default_allowed",
                },
            )
            and policy.get("policy_version") == POLICY_VERSION
            and policy.get("parameters") == PARAMETERS
            and _provenance_valid(policy.get("provenance"))
            and policy.get("fact_level") == "PROPOSED"
            and policy.get("production_calibrated") is False
            and policy.get("production_calibration_required") is True
            and policy.get("production_calibration_task_id") == "TASK-OPME-B-001"
            and policy.get("implicit_default_allowed") is False
            and PARAMETERS["safe_close_timeout"] == 30 + 5
        ),
        "control_metadata_reference_only": (
            _exact_keys(
                control,
                {
                    "evaluation_mode",
                    "subject_kind",
                    "input_refs",
                    "input_refs_must_exist_and_be_git_tracked",
                    "snapshot_required_fields",
                    "request_required_fields",
                    "logical_time_only",
                    "raw_path_allowed",
                    "raw_body_allowed",
                    "payload_copy_allowed",
                    "ids_business_job_created",
                },
            )
            and control.get("evaluation_mode") == "ISOLATED_CONTROL_METADATA_ONLY"
            and control.get("subject_kind") == "GIT_TRACKED_CONTROL_DOCUMENT"
            and control.get("input_refs") == CONTROL_REFS
            and all(_repo_ref_path(ref) is not None for ref in CONTROL_REFS)
            and control.get("input_refs_must_exist_and_be_git_tracked") is True
            and set(control.get("snapshot_required_fields", [])) == SNAPSHOT_FIELDS
            and set(control.get("request_required_fields", [])) == REQUEST_FIELDS
            and control.get("logical_time_only") is True
            and control.get("raw_path_allowed") is False
            and control.get("raw_body_allowed") is False
            and control.get("payload_copy_allowed") is False
            and control.get("ids_business_job_created") is False
        ),
        "state_transition_candidate_only": (
            _exact_keys(
                state,
                {
                    "state_model_version",
                    "job_types",
                    "terminal_states",
                    "intent_edges",
                    "compare_and_set_fields",
                    "state_version_increment",
                    "terminal_state_mutation_allowed",
                    "candidate_only",
                    "persistent_state_write_allowed",
                    "append_only_audit_ref_required",
                },
            )
            and state.get("state_model_version") == "ids.job_state.v1"
            and state.get("job_types") == JOB_TYPES
            and state.get("terminal_states")
            == ["SUCCEEDED", "FAILED", "DEAD_LETTERED", "CANCELLED"]
            and state.get("intent_edges")
            == {
                "AUTO_START": [
                    "CREATED->QUEUED",
                    "QUEUED->CLAIMED",
                    "CLAIMED->RUNNING",
                ],
                "RESOURCE_PAUSE": [
                    "QUEUED->PAUSED",
                    "CLAIMED->PAUSE_REQUESTED",
                    "RUNNING->PAUSE_REQUESTED",
                ],
                "COMPLETE_PAUSE": ["PAUSE_REQUESTED->PAUSED"],
                "AUTO_RESUME": ["PAUSED->QUEUED"],
                "SAFE_CLOSE": [
                    "QUEUED->PAUSED",
                    "RETRY_WAIT->PAUSED",
                    "CLAIMED->PAUSE_REQUESTED",
                    "RUNNING->PAUSE_REQUESTED",
                ],
            }
            and state.get("compare_and_set_fields")
            == ["job_id", "expected_state", "expected_state_version"]
            and state.get("state_version_increment") == 1
            and state.get("terminal_state_mutation_allowed") is False
            and state.get("candidate_only") is True
            and state.get("persistent_state_write_allowed") is False
            and state.get("append_only_audit_ref_required") is True
        ),
        "decision_guards_fail_closed": (
            _exact_keys(
                decision,
                {
                    "guard_facts",
                    "resource_pause_reasons",
                    "owner_authorization_state_required",
                    "evaluation_interval_enforced",
                    "pause_timeout_action",
                    "safe_close_timeout_action",
                    "resume_requires_fresh_owner_and_stable_resources",
                    "guard_facts_must_match_snapshot_evidence",
                    "writer_quiescence_required_before_paused",
                    "future_logical_evidence_allowed",
                    "zero_epoch_timestamp_valid",
                    "safe_close_requires_no_active_claim_or_lock",
                    "unknown_or_invalid_action",
                    "force_kill_allowed",
                    "crash_recovery_claimed",
                    "cleanup_or_delete_allowed",
                },
            )
            and set(decision.get("guard_facts", [])) == GUARD_FACTS
            and set(decision.get("resource_pause_reasons", [])) == PAUSE_REASONS
            and decision.get("owner_authorization_state_required") == "ACTIVE"
            and decision.get("evaluation_interval_enforced") is True
            and decision.get("pause_timeout_action")
            == "REQUIRE_MANUAL_REVIEW_NO_FORCE_KILL"
            and decision.get("safe_close_timeout_action")
            == "REQUIRE_MANUAL_REVIEW_NO_FORCE_KILL"
            and decision.get("resume_requires_fresh_owner_and_stable_resources") is True
            and decision.get("guard_facts_must_match_snapshot_evidence") is True
            and decision.get("writer_quiescence_required_before_paused") is True
            and decision.get("future_logical_evidence_allowed") is False
            and decision.get("zero_epoch_timestamp_valid") is True
            and decision.get("safe_close_requires_no_active_claim_or_lock") is True
            and decision.get("unknown_or_invalid_action") == "REQUIRE_MANUAL_REVIEW"
            and decision.get("force_kill_allowed") is False
            and decision.get("crash_recovery_claimed") is False
            and decision.get("cleanup_or_delete_allowed") is False
        ),
        "idempotency_in_memory_only": (
            idempotency
            == {
                "derivation": (
                    "sha256(job_id|expected_state|expected_state_version|intent|"
                    "policy_version|canonical_intent_ref)"
                ),
                "ledger_mode": "IN_MEMORY_DECISION_REPLAY_ONLY",
                "exact_replay_returns_original": True,
                "same_request_id_different_payload_action": (
                    "REJECT_IDEMPOTENCY_KEY_INPUT_CONFLICT"
                ),
                "persistent_ledger_allowed": False,
            }
        ),
        "reference_records_exact": (
            references
            == {
                "input_ref_format": "repo:<git-tracked-control-path>",
                "output_ref_format": "decision:sha256:<canonical-decision-digest>",
                "error_ref_format": "error:<safe-control-reason-code>",
                "checkpoint_ref_format": "checkpoint:sha256:<canonical-decision-digest>",
                "audit_ref_format": "audit:sha256:<canonical-decision-digest>",
                "raw_payload_record_allowed": False,
                "runtime_file_write_allowed": False,
            }
        ),
        "human_status_exact": contract.get("human_status_projection") == HUMAN_STATUS,
        "ownership_preserved": contract.get("ownership_matrix")
        == {
            "job_state_model": "STAGE-037",
            "queue_and_worker_transport": "STAGE-038",
            "retry_and_dead_letter_policy": "STAGE-039",
            "backpressure_decision_policy": "STAGE-040",
            "lock_lease_and_fencing": "STAGE-041",
            "isolated_lifecycle_decision": "STAGE-042",
            "process_crash_recovery": "STAGE-043",
            "cleanup_execution": "STAGE-044",
        },
        "registry_binding_exact": contract.get("registry_binding")
        == {
            "model_id": "MOD-011",
            "formula_id": "FORM-011",
            "parameter_ids": [
                "PARAM-072",
                "PARAM-073",
                "PARAM-074",
                "PARAM-075",
                "PARAM-076",
            ],
            "production_calibration_task_id": "TASK-OPME-B-001",
        },
        "runtime_boundary_fail_closed": (
            _exact_keys(
                runtime,
                {
                    "isolated_decision_runtime_allowed",
                    "process_local_replay_ledger_allowed",
                    "persistent_lifecycle_runtime_allowed",
                    "persistent_state_write_allowed",
                    "queue_runtime_allowed",
                    "worker_runtime_allowed",
                    "retry_scheduler_allowed",
                    "lock_runtime_allowed",
                    "automatic_resume_production_allowed",
                    "safe_close_production_allowed",
                    "crash_recovery_allowed",
                    "cleanup_runtime_allowed",
                    "delete_allowed",
                    "database_allowed",
                    "schema_change_allowed",
                    "runtime_output_write_allowed",
                    "external_api_allowed",
                    "raw_metadata_access_allowed",
                    "ids_business_job_allowed",
                    "fake_ids_business_data_allowed",
                    "production_activation_allowed",
                },
            )
            and runtime.get("isolated_decision_runtime_allowed") is True
            and runtime.get("process_local_replay_ledger_allowed") is True
            and all(
                runtime.get(name) is False
                for name in set(runtime)
                - {
                    "isolated_decision_runtime_allowed",
                    "process_local_replay_ledger_allowed",
                }
            )
        ),
        "rollback_preserves_sources": (
            rollback
            == {
                "trigger": "INVALID_CONTRACT_PARAMETER_REFERENCE_GUARD_OR_UPSTREAM_BINDING",
                "action": (
                    "DISABLE_ISOLATED_LIFECYCLE_REQUIRE_MANUAL_REVIEW_AND_"
                    "REVERT_PHASE2_FILES_ONLY"
                ),
                "preserve_phase1": True,
                "preserve_reviewed_stage037_stage041": True,
                "preserve_raw_data_and_evidence": True,
                "github_action_allowed": False,
            }
        ),
        "truth_flags_exact": (
            set(truth) == TRUE_FLAGS | FALSE_FLAGS
            and all(truth.get(name) is True for name in TRUE_FLAGS)
            and all(truth.get(name) is False for name in FALSE_FLAGS)
        ),
    }


def load_contract(path: Path = CONTRACT_PATH) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    return value if isinstance(value, dict) else {}


def build_control_snapshot(
    state: str = "CREATED",
    logical_time: int = 100,
    **overrides: Any,
) -> dict[str, Any]:
    if state not in JOB_STATES or not _integer(logical_time):
        raise ValueError("invalid control snapshot seed")
    job_digest = _digest({"refs": CONTROL_REFS, "subject": "STAGE042_PHASE2"})
    snapshot = {
        "evaluation_mode": "ISOLATED_CONTROL_METADATA_ONLY",
        "job_id": f"control-job:sha256:{job_digest}",
        "job_type": "REPORT",
        "job_state": state,
        "state_version": 0,
        "last_evaluated_at": logical_time,
        "pause_requested_at": None,
        "safe_close_started_at": None,
        "owner_evaluated_at": logical_time,
        "resource_gates_clear_since": logical_time,
        "lease_active": False,
        "lock_active": False,
        "fencing_token": None,
        "active_writer": False,
        "pause_reason_code": None,
        "input_refs": copy.deepcopy(CONTROL_REFS),
        "output_refs": [],
        "checkpoint_ref": None,
        "quarantine_ref": None,
        "error_ref": None,
        "controller_state": "OPEN",
    }
    unknown = set(overrides) - SNAPSHOT_FIELDS
    if unknown:
        raise ValueError(f"unknown control snapshot fields: {sorted(unknown)}")
    snapshot.update(overrides)
    return snapshot


def _expected_request_id(
    *,
    job_id: Any,
    expected_state: Any,
    expected_state_version: Any,
    intent: Any,
    canonical_intent_ref: Any,
) -> str:
    parts = (
        job_id,
        expected_state,
        expected_state_version,
        intent,
        POLICY_VERSION,
        canonical_intent_ref,
    )
    if not all(isinstance(item, (str, int)) and not isinstance(item, bool) for item in parts):
        return ""
    encoded = "|".join(str(item) for item in parts).encode("utf-8")
    return f"lifecycle-request:sha256:{hashlib.sha256(encoded).hexdigest()}"


def build_lifecycle_request(
    snapshot: Mapping[str, Any],
    *,
    intent: str,
    logical_now: int,
    pause_reason_code: Optional[str] = None,
    checkpoint_ref: Optional[str] = None,
    quarantine_ref: Optional[str] = None,
    **overrides: Any,
) -> dict[str, Any]:
    if intent not in INTENTS or not _integer(logical_now):
        raise ValueError("invalid lifecycle request seed")
    guard_facts = {name: False for name in GUARD_FACTS}
    state = snapshot.get("job_state")
    guard_facts["audit_ref_present"] = True
    if intent == "AUTO_START":
        if state == "CREATED":
            guard_facts.update(
                {
                    "identity_idempotency_valid": True,
                    "admission_gates_passed": True,
                    "no_active_claim_or_lock": True,
                }
            )
        elif state == "QUEUED":
            guard_facts.update(
                {
                    "admission_gates_passed": True,
                    "claim_lease_and_lock_acquired": True,
                }
            )
        elif state == "CLAIMED":
            guard_facts.update(
                {"live_lease_valid": True, "fencing_token_matches": True}
            )
    elif intent == "RESOURCE_PAUSE":
        guard_facts["resource_gate_blocked"] = pause_reason_code in PAUSE_REASONS
        if state == "QUEUED":
            guard_facts["no_active_claim_or_lock"] = True
        elif state in {"CLAIMED", "RUNNING"}:
            guard_facts.update(
                {
                    "live_lease_valid": True,
                    "fencing_token_matches": True,
                    "pause_intent_recorded": True,
                }
            )
    elif intent == "COMPLETE_PAUSE":
        guard_facts.update(
            {
                "lease_valid_or_expiry_evidence": True,
                "fencing_token_matches": snapshot.get("fencing_token") is not None,
                "checkpoint_or_quarantine_complete": bool(
                    checkpoint_ref or quarantine_ref
                ),
            }
        )
    elif intent == "AUTO_RESUME":
        guard_facts.update(
            {
                "owner_revalidated": True,
                "resource_gates_passed": True,
                "no_active_claim_or_lock": not snapshot.get("lease_active")
                and not snapshot.get("lock_active"),
            }
        )
    elif intent == "SAFE_CLOSE":
        guard_facts["no_active_writer"] = not bool(snapshot.get("active_writer"))
        if state in {"QUEUED", "RETRY_WAIT"}:
            guard_facts["no_active_claim_or_lock"] = True
        elif state in {"CLAIMED", "RUNNING"}:
            guard_facts.update(
                {
                    "live_lease_valid": True,
                    "fencing_token_matches": True,
                    "pause_intent_recorded": True,
                }
            )
    canonical_intent_ref = CONTROL_REFS[1]
    request = {
        "request_id": _expected_request_id(
            job_id=snapshot.get("job_id"),
            expected_state=state,
            expected_state_version=snapshot.get("state_version"),
            intent=intent,
            canonical_intent_ref=canonical_intent_ref,
        ),
        "intent": intent,
        "expected_state": state,
        "expected_state_version": snapshot.get("state_version"),
        "logical_now": logical_now,
        "actor_ref": CONTROL_REFS[0],
        "reason_code": f"{intent}_EVALUATION",
        "guard_facts": guard_facts,
        "input_refs": copy.deepcopy(CONTROL_REFS),
        "resource_gate_refs": [CONTROL_REFS[1]],
        "owner_evidence_ref": CONTROL_REFS[0],
        "owner_policy_version": POLICY_VERSION,
        "owner_authorization_state": "ACTIVE",
        "checkpoint_ref": checkpoint_ref,
        "quarantine_ref": quarantine_ref,
        "error_ref": None,
        "canonical_intent_ref": canonical_intent_ref,
        "pause_reason_code": pause_reason_code,
        "candidate_fencing_token": snapshot.get("fencing_token") or 1,
    }
    unknown = set(overrides) - REQUEST_FIELDS
    if unknown:
        raise ValueError(f"unknown lifecycle request fields: {sorted(unknown)}")
    request.update(overrides)
    if "request_id" not in overrides:
        request["request_id"] = _expected_request_id(
            job_id=snapshot.get("job_id"),
            expected_state=request.get("expected_state"),
            expected_state_version=request.get("expected_state_version"),
            intent=request.get("intent"),
            canonical_intent_ref=request.get("canonical_intent_ref"),
        )
    return request


def _snapshot_valid(snapshot: Any) -> bool:
    if not _exact_keys(snapshot, SNAPSHOT_FIELDS):
        return False
    value = _mapping(snapshot)
    optional_times = (
        value.get("pause_requested_at"),
        value.get("safe_close_started_at"),
        value.get("owner_evaluated_at"),
        value.get("resource_gates_clear_since"),
    )
    return (
        value.get("evaluation_mode") == "ISOLATED_CONTROL_METADATA_ONLY"
        and isinstance(value.get("job_id"), str)
        and value.get("job_id", "").startswith("control-job:sha256:")
        and value.get("job_type") in JOB_TYPES
        and value.get("job_state") in JOB_STATES
        and _integer(value.get("state_version"))
        and _integer(value.get("last_evaluated_at"))
        and all(item is None or _integer(item) for item in optional_times)
        and isinstance(value.get("lease_active"), bool)
        and isinstance(value.get("lock_active"), bool)
        and (
            value.get("fencing_token") is None
            or _integer(value.get("fencing_token"), minimum=1)
        )
        and isinstance(value.get("active_writer"), bool)
        and (
            value.get("pause_reason_code") is None
            or value.get("pause_reason_code") in PAUSE_REASONS
        )
        and value.get("input_refs") == CONTROL_REFS
        and _control_refs_valid(value.get("input_refs"))
        and isinstance(value.get("output_refs"), list)
        and all(_record_ref(item, "decision:", optional=False) for item in value.get("output_refs", []))
        and _record_ref(value.get("checkpoint_ref"), "checkpoint:")
        and _record_ref(value.get("quarantine_ref"), "checkpoint:")
        and _record_ref(value.get("error_ref"), "error:")
        and value.get("controller_state") in {"OPEN", "CLOSING", "CLOSED"}
    )


def _request_valid(request: Any) -> bool:
    if not _exact_keys(request, REQUEST_FIELDS):
        return False
    value = _mapping(request)
    guards = value.get("guard_facts")
    return (
        isinstance(value.get("request_id"), str)
        and value.get("request_id", "").startswith("lifecycle-request:sha256:")
        and value.get("intent") in INTENTS
        and value.get("expected_state") in JOB_STATES
        and _integer(value.get("expected_state_version"))
        and _integer(value.get("logical_now"))
        and _repo_ref_path(value.get("actor_ref")) is not None
        and isinstance(value.get("reason_code"), str)
        and bool(value.get("reason_code"))
        and _exact_keys(guards, GUARD_FACTS)
        and all(isinstance(item, bool) for item in _mapping(guards).values())
        and value.get("input_refs") == CONTROL_REFS
        and _control_refs_valid(value.get("input_refs"))
        and _control_refs_valid(value.get("resource_gate_refs"))
        and _repo_ref_path(value.get("owner_evidence_ref")) is not None
        and value.get("owner_policy_version") == POLICY_VERSION
        and value.get("owner_authorization_state") in {"ACTIVE", "INACTIVE", "UNKNOWN"}
        and _record_ref(value.get("checkpoint_ref"), "checkpoint:")
        and _record_ref(value.get("quarantine_ref"), "checkpoint:")
        and _record_ref(value.get("error_ref"), "error:")
        and _repo_ref_path(value.get("canonical_intent_ref")) is not None
        and (
            value.get("pause_reason_code") is None
            or value.get("pause_reason_code") in PAUSE_REASONS
        )
        and _integer(value.get("candidate_fencing_token"), minimum=1)
    )


class IsolatedAutomaticLifecycle:
    """Evaluate reference-only lifecycle candidates with a process-local replay ledger."""

    def __init__(self, contract: Mapping[str, Any]):
        self.contract = copy.deepcopy(dict(contract))
        self.contract_checks = evaluate_contract(self.contract, verify_files=True)
        self.contract_valid = bool(self.contract_checks) and all(
            self.contract_checks.values()
        )
        self._ledger: dict[str, tuple[str, dict[str, Any]]] = {}

    def _result(
        self,
        *,
        result_code: str,
        decision_action: str,
        status_key: str,
        transition: Optional[str] = None,
        candidate_snapshot: Optional[dict[str, Any]] = None,
        error: bool = False,
        decision_valid: bool = True,
        seed: Optional[Mapping[str, Any]] = None,
    ) -> dict[str, Any]:
        digest = _digest(
            {
                "policy_version": POLICY_VERSION,
                "result_code": result_code,
                "decision_action": decision_action,
                "transition": transition,
                "seed": dict(seed or {}),
            }
        )
        output_ref = f"decision:sha256:{digest}"
        checkpoint_ref = f"checkpoint:sha256:{digest}"
        audit_ref = f"audit:sha256:{digest}"
        if candidate_snapshot is not None:
            candidate_snapshot["output_refs"] = [output_ref]
            if candidate_snapshot.get("checkpoint_ref") is None:
                candidate_snapshot["checkpoint_ref"] = checkpoint_ref
            candidate_snapshot["error_ref"] = None
        return {
            "decision_valid": decision_valid,
            "policy_version": POLICY_VERSION,
            "result_code": result_code,
            "decision_action": decision_action,
            "transition": transition,
            "candidate_snapshot": candidate_snapshot,
            "input_refs": copy.deepcopy(CONTROL_REFS),
            "output_refs": [output_ref],
            "error_ref": f"error:{result_code}" if error else None,
            "checkpoint_ref": checkpoint_ref,
            "audit_ref": audit_ref,
            "human_status": copy.deepcopy(HUMAN_STATUS[status_key]),
            "persistent_state_write_performed": False,
            "queue_runtime_performed": False,
            "worker_runtime_performed": False,
            "retry_scheduler_performed": False,
            "lock_runtime_performed": False,
            "force_kill_performed": False,
            "crash_recovery_performed": False,
            "cleanup_or_delete_performed": False,
            "database_connection_performed": False,
            "runtime_output_written": False,
            "ids_business_job_created": False,
        }

    def _transition(
        self,
        snapshot: Mapping[str, Any],
        request: Mapping[str, Any],
        target_state: str,
        *,
        result_code: str,
        status_key: str,
        controller_state: Optional[str] = None,
    ) -> dict[str, Any]:
        candidate = copy.deepcopy(dict(snapshot))
        source_state = str(snapshot.get("job_state"))
        candidate["job_state"] = target_state
        candidate["state_version"] = int(snapshot.get("state_version", 0)) + 1
        candidate["last_evaluated_at"] = request.get("logical_now")
        if controller_state is not None:
            candidate["controller_state"] = controller_state
        intent = request.get("intent")
        if target_state == "PAUSE_REQUESTED":
            candidate["pause_requested_at"] = request.get("logical_now")
            candidate["pause_reason_code"] = request.get("pause_reason_code")
            if intent == "SAFE_CLOSE":
                candidate["controller_state"] = "CLOSING"
        elif target_state == "PAUSED":
            candidate["lease_active"] = False
            candidate["lock_active"] = False
            candidate["active_writer"] = False
            candidate["pause_reason_code"] = request.get("pause_reason_code") or snapshot.get(
                "pause_reason_code"
            )
            token = snapshot.get("fencing_token")
            if _integer(token, minimum=1):
                candidate["fencing_token"] = int(token) + 1
            if request.get("checkpoint_ref") is not None:
                candidate["checkpoint_ref"] = request.get("checkpoint_ref")
            if request.get("quarantine_ref") is not None:
                candidate["quarantine_ref"] = request.get("quarantine_ref")
        elif target_state == "QUEUED":
            candidate["pause_requested_at"] = None
            candidate["pause_reason_code"] = None
            candidate["lease_active"] = False
            candidate["lock_active"] = False
            candidate["active_writer"] = False
            candidate["controller_state"] = "OPEN"
        elif target_state == "CLAIMED":
            candidate["lease_active"] = True
            candidate["lock_active"] = True
            candidate["fencing_token"] = request.get("candidate_fencing_token")
        transition = f"{source_state}->{target_state}"
        return self._result(
            result_code=result_code,
            decision_action="TRANSITION_CANDIDATE",
            status_key=status_key,
            transition=transition,
            candidate_snapshot=candidate,
            seed={"snapshot": dict(snapshot), "request": dict(request)},
        )

    @staticmethod
    def _guards(request: Mapping[str, Any], required: set[str]) -> bool:
        guards = _mapping(request.get("guard_facts"))
        return all(guards.get(name) is True for name in required)

    @staticmethod
    def _guard_facts_match_snapshot(
        snapshot: Mapping[str, Any], request: Mapping[str, Any]
    ) -> bool:
        guards = _mapping(request.get("guard_facts"))
        lease_active = snapshot.get("lease_active") is True
        lock_active = snapshot.get("lock_active") is True
        fencing_token = snapshot.get("fencing_token")
        return all(
            (
                not guards.get("no_active_claim_or_lock")
                or (not lease_active and not lock_active),
                not guards.get("live_lease_valid")
                or (lease_active and lock_active),
                not guards.get("fencing_token_matches")
                or (
                    _integer(fencing_token, minimum=1)
                    and request.get("candidate_fencing_token") == fencing_token
                ),
                not guards.get("no_active_writer")
                or snapshot.get("active_writer") is False,
                not guards.get("checkpoint_or_quarantine_complete")
                or bool(
                    request.get("checkpoint_ref")
                    or request.get("quarantine_ref")
                ),
            )
        )

    def _evaluate_valid(
        self,
        snapshot: Mapping[str, Any],
        request: Mapping[str, Any],
    ) -> dict[str, Any]:
        state = str(snapshot.get("job_state"))
        intent = str(request.get("intent"))
        logical_now = int(request.get("logical_now", 0))
        if state in TERMINAL_STATES:
            return self._result(
                result_code="TERMINAL_STATE_IMMUTABLE",
                decision_action="REQUIRE_MANUAL_REVIEW",
                status_key="MANUAL_REVIEW_REQUIRED",
                error=True,
                seed={"state": state, "intent": intent},
            )
        if (
            request.get("expected_state") != state
            or request.get("expected_state_version") != snapshot.get("state_version")
        ):
            return self._result(
                result_code="COMPARE_AND_SET_MISMATCH",
                decision_action="REQUIRE_MANUAL_REVIEW",
                status_key="MANUAL_REVIEW_REQUIRED",
                error=True,
                seed={"state": state, "intent": intent},
            )
        if logical_now - int(snapshot.get("last_evaluated_at", 0)) < PARAMETERS[
            "lifecycle_evaluation_interval"
        ]:
            return self._result(
                result_code="EVALUATION_NOT_DUE",
                decision_action="WAIT_FOR_EVALUATION_INTERVAL",
                status_key="WAITING",
                seed={"state": state, "intent": intent, "logical_now": logical_now},
            )
        if not self._guard_facts_match_snapshot(snapshot, request):
            return self._result(
                result_code="SNAPSHOT_GUARD_MISMATCH",
                decision_action="REQUIRE_MANUAL_REVIEW",
                status_key="MANUAL_REVIEW_REQUIRED",
                error=True,
                decision_valid=False,
                seed={"state": state, "intent": intent},
            )

        if intent == "AUTO_START":
            if state == "CREATED" and self._guards(
                request,
                {
                    "identity_idempotency_valid",
                    "admission_gates_passed",
                    "no_active_claim_or_lock",
                    "audit_ref_present",
                },
            ):
                return self._transition(
                    snapshot,
                    request,
                    "QUEUED",
                    result_code="START_QUEUED",
                    status_key="START_EVALUATING",
                )
            if state == "QUEUED" and self._guards(
                request,
                {
                    "admission_gates_passed",
                    "claim_lease_and_lock_acquired",
                    "audit_ref_present",
                },
            ):
                return self._transition(
                    snapshot,
                    request,
                    "CLAIMED",
                    result_code="START_CLAIMED_CANDIDATE",
                    status_key="START_EVALUATING",
                )
            if state == "CLAIMED" and self._guards(
                request,
                {"live_lease_valid", "fencing_token_matches", "audit_ref_present"},
            ):
                return self._transition(
                    snapshot,
                    request,
                    "RUNNING",
                    result_code="START_RUNNING_CANDIDATE",
                    status_key="START_EVALUATING",
                )

        if intent == "RESOURCE_PAUSE":
            if request.get("pause_reason_code") not in PAUSE_REASONS:
                return self._result(
                    result_code="INVALID_PAUSE_REASON",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    status_key="MANUAL_REVIEW_REQUIRED",
                    error=True,
                    seed={"state": state, "intent": intent},
                )
            if state == "QUEUED" and self._guards(
                request,
                {"resource_gate_blocked", "no_active_claim_or_lock", "audit_ref_present"},
            ):
                return self._transition(
                    snapshot,
                    request,
                    "PAUSED",
                    result_code="RESOURCE_PAUSED_BEFORE_CLAIM",
                    status_key="PAUSED",
                )
            if state in {"CLAIMED", "RUNNING"} and self._guards(
                request,
                {
                    "resource_gate_blocked",
                    "live_lease_valid",
                    "fencing_token_matches",
                    "pause_intent_recorded",
                    "audit_ref_present",
                },
            ):
                return self._transition(
                    snapshot,
                    request,
                    "PAUSE_REQUESTED",
                    result_code="RESOURCE_PAUSE_REQUESTED",
                    status_key="PAUSE_REQUESTED",
                )

        if intent == "COMPLETE_PAUSE" and state == "PAUSE_REQUESTED":
            pause_started = snapshot.get("pause_requested_at")
            elapsed = logical_now - int(
                pause_started if pause_started is not None else logical_now
            )
            has_checkpoint = bool(
                request.get("checkpoint_ref") or request.get("quarantine_ref")
            )
            if (
                (not has_checkpoint or snapshot.get("active_writer"))
                and elapsed > PARAMETERS["pause_acknowledgement_timeout"]
            ):
                return self._result(
                    result_code="PAUSE_ACKNOWLEDGEMENT_TIMEOUT",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    status_key="MANUAL_REVIEW_REQUIRED",
                    error=True,
                    seed={"state": state, "intent": intent, "elapsed": elapsed},
                )
            if snapshot.get("active_writer"):
                return self._result(
                    result_code="WRITER_QUIESCENCE_REQUIRED",
                    decision_action="WAIT_FOR_WRITER_QUIESCENCE",
                    status_key="WAITING",
                    seed={"state": state, "intent": intent, "elapsed": elapsed},
                )
            if not has_checkpoint:
                return self._result(
                    result_code="WAITING_FOR_CHECKPOINT_OR_QUARANTINE",
                    decision_action="WAIT_FOR_CHECKPOINT",
                    status_key="WAITING",
                    seed={"state": state, "intent": intent, "elapsed": elapsed},
                )
            if self._guards(
                request,
                {
                    "lease_valid_or_expiry_evidence",
                    "fencing_token_matches",
                    "checkpoint_or_quarantine_complete",
                    "audit_ref_present",
                },
            ):
                return self._transition(
                    snapshot,
                    request,
                    "PAUSED",
                    result_code="PAUSE_COMPLETED",
                    status_key="PAUSED",
                )

        if intent == "AUTO_RESUME" and state == "PAUSED":
            owner_time = snapshot.get("owner_evaluated_at")
            if owner_time is not None and int(owner_time) > logical_now:
                return self._result(
                    result_code="OWNER_EVIDENCE_TIME_INVALID",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    status_key="MANUAL_REVIEW_REQUIRED",
                    error=True,
                    decision_valid=False,
                    seed={"state": state, "intent": intent},
                )
            if (
                request.get("owner_authorization_state") != "ACTIVE"
                or owner_time is None
                or logical_now - int(owner_time) > PARAMETERS["owner_revalidation_ttl"]
            ):
                return self._result(
                    result_code="OWNER_EVIDENCE_STALE",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    status_key="MANUAL_REVIEW_REQUIRED",
                    error=True,
                    seed={"state": state, "intent": intent},
                )
            clear_since = snapshot.get("resource_gates_clear_since")
            if clear_since is not None and int(clear_since) > logical_now:
                return self._result(
                    result_code="RESOURCE_GATE_TIME_INVALID",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    status_key="MANUAL_REVIEW_REQUIRED",
                    error=True,
                    decision_valid=False,
                    seed={"state": state, "intent": intent},
                )
            if (
                clear_since is None
                or logical_now - int(clear_since)
                < PARAMETERS["resource_gate_stability_window"]
            ):
                return self._result(
                    result_code="RESOURCE_GATES_NOT_STABLE",
                    decision_action="WAIT_FOR_RESOURCE_STABILITY",
                    status_key="WAITING",
                    seed={"state": state, "intent": intent},
                )
            if self._guards(
                request,
                {
                    "owner_revalidated",
                    "resource_gates_passed",
                    "no_active_claim_or_lock",
                    "audit_ref_present",
                },
            ) and not snapshot.get("lease_active") and not snapshot.get("lock_active"):
                return self._transition(
                    snapshot,
                    request,
                    "QUEUED",
                    result_code="RESUME_QUEUED_CANDIDATE",
                    status_key="RESUME_EVALUATING",
                )

        if intent == "SAFE_CLOSE":
            close_started = snapshot.get("safe_close_started_at")
            elapsed = logical_now - int(
                close_started if close_started is not None else logical_now
            )
            if snapshot.get("active_writer") and elapsed > PARAMETERS["safe_close_timeout"]:
                return self._result(
                    result_code="SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    status_key="MANUAL_REVIEW_REQUIRED",
                    error=True,
                    seed={"state": state, "intent": intent, "elapsed": elapsed},
                )
            if state in {"QUEUED", "RETRY_WAIT"} and self._guards(
                request,
                {"no_active_claim_or_lock", "no_active_writer", "audit_ref_present"},
            ):
                return self._transition(
                    snapshot,
                    request,
                    "PAUSED",
                    result_code="SAFE_CLOSE_COMPLETED",
                    status_key="SAFE_CLOSED",
                    controller_state="CLOSED",
                )
            if state in {"CLAIMED", "RUNNING"} and self._guards(
                request,
                {
                    "live_lease_valid",
                    "fencing_token_matches",
                    "pause_intent_recorded",
                    "audit_ref_present",
                },
            ):
                return self._transition(
                    snapshot,
                    request,
                    "PAUSE_REQUESTED",
                    result_code="SAFE_CLOSE_PAUSE_REQUESTED",
                    status_key="PAUSE_REQUESTED",
                    controller_state="CLOSING",
                )
            if state == "PAUSED" and (
                snapshot.get("active_writer")
                or snapshot.get("lease_active")
                or snapshot.get("lock_active")
            ):
                return self._result(
                    result_code="SAFE_CLOSE_ACTIVE_CLAIM_OR_LOCK",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    status_key="MANUAL_REVIEW_REQUIRED",
                    error=True,
                    decision_valid=False,
                    seed={"state": state, "intent": intent},
                )
            if state == "PAUSED":
                candidate = copy.deepcopy(dict(snapshot))
                candidate["controller_state"] = "CLOSED"
                candidate["last_evaluated_at"] = logical_now
                return self._result(
                    result_code="SAFE_CLOSE_COMPLETED_ALREADY_PAUSED",
                    decision_action="CONTROLLER_CLOSE_CANDIDATE",
                    status_key="SAFE_CLOSED",
                    candidate_snapshot=candidate,
                    seed={"state": state, "intent": intent},
                )

        return self._result(
            result_code="GUARD_OR_EDGE_NOT_SATISFIED",
            decision_action="REQUIRE_MANUAL_REVIEW",
            status_key="MANUAL_REVIEW_REQUIRED",
            error=True,
            seed={"state": state, "intent": intent},
        )

    def evaluate(self, snapshot: Any, request: Any) -> dict[str, Any]:
        if not self.contract_valid or not _snapshot_valid(snapshot) or not _request_valid(request):
            return self._result(
                result_code="INVALID_CONTROL_REQUEST",
                decision_action="REQUIRE_MANUAL_REVIEW",
                status_key="MANUAL_REVIEW_REQUIRED",
                error=True,
                decision_valid=False,
                seed={"invalid": True},
            )
        request_id = str(request.get("request_id"))
        payload_digest = _digest({"snapshot": snapshot, "request": request})
        previous = self._ledger.get(request_id)
        if previous is not None:
            previous_digest, previous_result = previous
            if previous_digest == payload_digest:
                return copy.deepcopy(previous_result)
            return self._result(
                result_code="REJECT_IDEMPOTENCY_KEY_INPUT_CONFLICT",
                decision_action="REQUIRE_MANUAL_REVIEW",
                status_key="MANUAL_REVIEW_REQUIRED",
                error=True,
                seed={"request_id": request_id},
            )
        expected_request_id = _expected_request_id(
            job_id=snapshot.get("job_id"),
            expected_state=request.get("expected_state"),
            expected_state_version=request.get("expected_state_version"),
            intent=request.get("intent"),
            canonical_intent_ref=request.get("canonical_intent_ref"),
        )
        if request_id != expected_request_id:
            return self._result(
                result_code="INVALID_CONTROL_REQUEST",
                decision_action="REQUIRE_MANUAL_REVIEW",
                status_key="MANUAL_REVIEW_REQUIRED",
                error=True,
                decision_valid=False,
                seed={"invalid_request_id": True},
            )
        result = self._evaluate_valid(snapshot, request)
        self._ledger[request_id] = (payload_digest, copy.deepcopy(result))
        return result


def build_stage042_phase2_report() -> dict[str, Any]:
    contract = load_contract()
    contract_checks = evaluate_contract(contract, verify_files=True)
    engine = IsolatedAutomaticLifecycle(contract)

    created = build_control_snapshot("CREATED", 100)
    start = engine.evaluate(
        created,
        build_lifecycle_request(created, intent="AUTO_START", logical_now=110),
    )
    running = build_control_snapshot(
        "RUNNING",
        100,
        lease_active=True,
        lock_active=True,
        fencing_token=7,
        active_writer=True,
    )
    pause = engine.evaluate(
        running,
        build_lifecycle_request(
            running,
            intent="RESOURCE_PAUSE",
            logical_now=110,
            pause_reason_code="EXTERNAL_DRIVE_OFFLINE",
        ),
    )
    requested = pause.get("candidate_snapshot") or {}
    quiesced = copy.deepcopy(requested)
    quiesced["active_writer"] = False
    pause_complete = engine.evaluate(
        quiesced,
        build_lifecycle_request(
            quiesced,
            intent="COMPLETE_PAUSE",
            logical_now=120,
            checkpoint_ref="checkpoint:sha256:" + "a" * 64,
        ),
    )
    paused = build_control_snapshot(
        "PAUSED",
        100,
        owner_evaluated_at=190,
        resource_gates_clear_since=150,
        pause_reason_code="EXTERNAL_DRIVE_OFFLINE",
    )
    resume = engine.evaluate(
        paused,
        build_lifecycle_request(paused, intent="AUTO_RESUME", logical_now=210),
    )
    queued = build_control_snapshot("QUEUED", 100, safe_close_started_at=100)
    safe_close = engine.evaluate(
        queued,
        build_lifecycle_request(queued, intent="SAFE_CLOSE", logical_now=110),
    )
    slice_checks = {
        "automatic_start_candidate": start.get("transition") == "CREATED->QUEUED",
        "resource_pause_candidate": pause.get("transition")
        == "RUNNING->PAUSE_REQUESTED",
        "checkpoint_pause_completion": pause_complete.get("transition")
        == "PAUSE_REQUESTED->PAUSED",
        "guarded_resume_candidate": resume.get("transition") == "PAUSED->QUEUED",
        "cooperative_safe_close_candidate": safe_close.get("transition")
        == "QUEUED->PAUSED",
        "reference_only_records": all(
            result.get("input_refs") == CONTROL_REFS
            and _record_ref(result.get("output_refs", [None])[0], "decision:", optional=False)
            and _record_ref(result.get("checkpoint_ref"), "checkpoint:", optional=False)
            and _record_ref(result.get("audit_ref"), "audit:", optional=False)
            for result in (start, pause, pause_complete, resume, safe_close)
        ),
        "no_persistent_or_production_side_effect": all(
            not result.get("persistent_state_write_performed")
            and not result.get("queue_runtime_performed")
            and not result.get("worker_runtime_performed")
            and not result.get("lock_runtime_performed")
            and not result.get("database_connection_performed")
            and not result.get("runtime_output_written")
            and not result.get("ids_business_job_created")
            for result in (start, pause, pause_complete, resume, safe_close)
        ),
    }
    truth = _mapping(contract.get("truth_flags"))
    valid = (
        bool(contract_checks)
        and all(contract_checks.values())
        and bool(slice_checks)
        and all(slice_checks.values())
    )
    return {
        "stage": contract.get("stage"),
        "phase": contract.get("phase"),
        "task_id": contract.get("task_id"),
        "acceptance_id": contract.get("acceptance_id"),
        "lifecycle_policy_version": contract.get("lifecycle_policy_version"),
        "contract_state": contract.get("contract_state"),
        "next_gate": contract.get("next_gate"),
        "phase2_slice_valid": valid,
        "contract_checks": contract_checks,
        "slice_checks": slice_checks,
        **truth,
    }


def main() -> int:
    report = build_stage042_phase2_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["phase2_slice_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
