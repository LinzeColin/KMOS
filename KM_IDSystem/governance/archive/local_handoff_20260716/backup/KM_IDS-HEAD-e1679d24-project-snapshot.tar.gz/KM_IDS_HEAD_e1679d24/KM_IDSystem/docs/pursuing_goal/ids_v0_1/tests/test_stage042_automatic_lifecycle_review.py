import importlib.util
import json
from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[4]
PURSUE_ROOT = ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
RUNTIME_CHECKER = ROOT / "scripts" / "check_automatic_lifecycle_runtime.py"
REVIEW_CHECKER = ROOT / "scripts" / "check_automatic_lifecycle_stage_review.py"
REVIEW_ARTIFACT = PURSUE_ROOT / "STAGE042_STAGE_REVIEW.md"
MODEL_SPEC = ROOT / "docs" / "governance" / "MODEL_SPEC.md"


class Stage042AutomaticLifecycleReviewTests(unittest.TestCase):
    def _load_module(self, path: Path, name: str):
        self.assertTrue(path.is_file(), f"missing module: {path}")
        spec = importlib.util.spec_from_file_location(name, path)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def _runtime(self):
        return self._load_module(RUNTIME_CHECKER, "stage042_runtime_for_review")

    def _review_checker(self):
        return self._load_module(REVIEW_CHECKER, "stage042_lifecycle_review")

    def _evaluate(self, snapshot, *, intent, logical_now, **request_overrides):
        module = self._runtime()
        engine = module.IsolatedAutomaticLifecycle(module.load_contract())
        request = module.build_lifecycle_request(
            snapshot,
            intent=intent,
            logical_now=logical_now,
            **request_overrides,
        )
        return engine.evaluate(snapshot, request)

    def test_review_artifacts_exist(self):
        self.assertTrue(REVIEW_ARTIFACT.is_file(), REVIEW_ARTIFACT)
        self.assertTrue(REVIEW_CHECKER.is_file(), REVIEW_CHECKER)

    def test_claimed_job_without_live_lease_lock_or_fence_cannot_run(self):
        module = self._runtime()
        snapshot = module.build_control_snapshot("CLAIMED", 100)

        result = self._evaluate(snapshot, intent="AUTO_START", logical_now=110)

        self.assertFalse(result["decision_valid"], result)
        self.assertEqual("SNAPSHOT_GUARD_MISMATCH", result["result_code"])
        self.assertIsNone(result["transition"])

    def test_pause_completion_requires_actual_writer_quiescence(self):
        module = self._runtime()
        snapshot = module.build_control_snapshot(
            "PAUSE_REQUESTED",
            100,
            pause_requested_at=100,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            active_writer=True,
        )

        result = self._evaluate(
            snapshot,
            intent="COMPLETE_PAUSE",
            logical_now=110,
            checkpoint_ref="checkpoint:sha256:" + "a" * 64,
        )

        self.assertEqual("WRITER_QUIESCENCE_REQUIRED", result["result_code"])
        self.assertIsNone(result["transition"])

    def test_already_paused_close_rejects_active_lease_or_lock(self):
        module = self._runtime()
        snapshot = module.build_control_snapshot(
            "PAUSED",
            100,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            active_writer=False,
            safe_close_started_at=100,
        )

        result = self._evaluate(snapshot, intent="SAFE_CLOSE", logical_now=110)

        self.assertFalse(result["decision_valid"], result)
        self.assertEqual("SAFE_CLOSE_ACTIVE_CLAIM_OR_LOCK", result["result_code"])
        self.assertIsNone(result["candidate_snapshot"])

    def test_future_owner_evidence_timestamp_cannot_authorize_resume(self):
        module = self._runtime()
        snapshot = module.build_control_snapshot(
            "PAUSED",
            0,
            owner_evaluated_at=999,
            resource_gates_clear_since=0,
            pause_reason_code="EXTERNAL_DRIVE_OFFLINE",
        )

        result = self._evaluate(snapshot, intent="AUTO_RESUME", logical_now=100)

        self.assertFalse(result["decision_valid"], result)
        self.assertEqual("OWNER_EVIDENCE_TIME_INVALID", result["result_code"])
        self.assertIsNone(result["transition"])

        resource_snapshot = module.build_control_snapshot(
            "PAUSED",
            0,
            owner_evaluated_at=100,
            resource_gates_clear_since=999,
        )
        resource_result = self._evaluate(
            resource_snapshot, intent="AUTO_RESUME", logical_now=100
        )
        self.assertFalse(resource_result["decision_valid"], resource_result)
        self.assertEqual(
            "RESOURCE_GATE_TIME_INVALID", resource_result["result_code"]
        )

    def test_zero_origin_pause_and_close_timestamps_still_timeout(self):
        module = self._runtime()
        pause_snapshot = module.build_control_snapshot(
            "PAUSE_REQUESTED",
            0,
            pause_requested_at=0,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            active_writer=True,
        )
        close_snapshot = module.build_control_snapshot(
            "RUNNING",
            0,
            safe_close_started_at=0,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            active_writer=True,
        )

        pause_result = self._evaluate(
            pause_snapshot,
            intent="COMPLETE_PAUSE",
            logical_now=31,
        )
        close_result = self._evaluate(
            close_snapshot,
            intent="SAFE_CLOSE",
            logical_now=36,
        )

        self.assertEqual(
            "PAUSE_ACKNOWLEDGEMENT_TIMEOUT", pause_result["result_code"]
        )
        self.assertEqual(
            "SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER", close_result["result_code"]
        )

    def test_model_spec_current_count_tokens_are_unambiguous(self):
        pattern = re.compile(
            r"\b(model_count|formula_count|parameter_count)\s*:\s*(\d+)\b"
        )
        matches = pattern.findall(MODEL_SPEC.read_text(encoding="utf-8"))

        self.assertEqual(
            [
                ("model_count", "11"),
                ("formula_count", "11"),
                ("parameter_count", "76"),
            ],
            matches,
        )

    def test_review_reverifies_sources_phases_and_all_six_repairs(self):
        report = self._review_checker().build_stage042_review_report()

        self.assertTrue(report["source_integrity_valid"], report)
        self.assertTrue(all(report["source_integrity_checks"].values()), report)
        self.assertTrue(all(report["phase_results"].values()), report)
        self.assertTrue(all(report["finding_checks"].values()), report)
        self.assertEqual(
            {"Critical": 2, "Important": 3, "Minor": 1},
            report["finding_counts"],
        )

    def test_invalid_review_finding_fails_closed(self):
        module = self._review_checker()
        valid = module.build_stage042_review_report()
        tampered = dict(valid["finding_checks"])
        tampered["writer_quiescence_repaired"] = False

        blocked = module.build_stage042_review_report(finding_checks=tampered)

        self.assertFalse(blocked["review_valid"], blocked)
        self.assertEqual("FAIL_CLOSED", blocked["result"])
        self.assertEqual("review_blocked", blocked["stage_review_status"])
        self.assertEqual("IDS-STAGE042-REVIEW-GATE", blocked["next_gate"])
        self.assertFalse(blocked["github_upload_allowed"])

    def test_governance_closes_only_to_separate_stage043_entry(self):
        report = self._review_checker().build_stage042_review_report()
        self.assertTrue(report["review_valid"], report)
        self.assertEqual("completed_reviewed_local", report["stage_review_status"])
        self.assertEqual("IDS-STAGE043-P1-GATE", report["next_gate"])
        self.assertFalse(report["stage043_started"])
        self.assertFalse(report["batch_review_performed"])
        self.assertFalse(report["github_upload_allowed"])
        self.assertFalse(report["app_reinstall_allowed"])

        batch = (PURSUE_ROOT / "BATCH041_050_UPLOAD_LOCK.yaml").read_text(
            encoding="utf-8"
        )
        roadmap = (ROOT / "docs" / "governance" / "roadmap.yaml").read_text(
            encoding="utf-8"
        )
        self.assertIn('status: "stage042_completed_reviewed_local"', batch)
        self.assertIn('next_allowed_task_id: "IDS-V0_1-STAGE043-P1"', batch)
        self.assertIn("push_allowed: false", batch)
        self.assertIn('current_phase_id: "IDS-STAGE042-REVIEW"', roadmap)
        self.assertIn('next_gate_id: "IDS-STAGE043-P1-GATE"', roadmap)

        events_path = ROOT / "docs" / "governance" / "events.jsonl"
        events = [
            json.loads(line)
            for line in events_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        matching = [
            event
            for event in events
            if event.get("event_id")
            == "EVT-IDS-V0_1-STAGE042-REVIEW-20260715-001"
        ]
        self.assertEqual(1, len(matching), matching)
        self.assertEqual("stage_review", matching[0]["event_type"])
        self.assertEqual("IDS-V0_1-STAGE042-REVIEW", matching[0]["task_id"])


if __name__ == "__main__":
    unittest.main()
