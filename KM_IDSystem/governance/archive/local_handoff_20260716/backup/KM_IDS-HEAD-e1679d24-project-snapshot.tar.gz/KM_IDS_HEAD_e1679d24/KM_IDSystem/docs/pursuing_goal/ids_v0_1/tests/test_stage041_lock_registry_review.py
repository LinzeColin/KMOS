import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parents[4]
PURSUE_ROOT = ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
RUNTIME_CHECKER = ROOT / "scripts" / "check_lock_registry_runtime.py"
REVIEW_CHECKER = ROOT / "scripts" / "check_lock_registry_stage_review.py"
REVIEW = PURSUE_ROOT / "STAGE041_STAGE_REVIEW.md"
BATCH = PURSUE_ROOT / "BATCH041_050_UPLOAD_LOCK.yaml"
ROADMAP = ROOT / "docs" / "governance" / "roadmap.yaml"
EVENTS = ROOT / "docs" / "governance" / "events.jsonl"
SOURCE_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md"
)
INDEX_VERSION_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
    "stage041_lock_registry_runtime_contract.json"
)
INDEX_NAMESPACE_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md"
)


class Stage041LockRegistryStageReviewTests(unittest.TestCase):
    def _load_module(self, path: Path, name: str):
        self.assertTrue(path.is_file(), f"missing module: {path}")
        spec = importlib.util.spec_from_file_location(name, path)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def _runtime(self):
        return self._load_module(RUNTIME_CHECKER, "stage041_runtime_for_review")

    def _review_checker(self):
        return self._load_module(REVIEW_CHECKER, "stage041_lock_registry_review")

    def _request(
        self,
        module,
        *,
        operation: str,
        operation_ref: str,
        role: str,
        now: int,
    ):
        return module.build_control_request(
            SOURCE_REF,
            operation_identity_ref=operation_ref,
            operation_family=operation,
            holder_role=role,
            requested_at_epoch_seconds=now,
        )

    def test_review_artifacts_exist(self):
        self.assertTrue(REVIEW.is_file(), f"missing review artifact: {REVIEW}")
        self.assertTrue(
            REVIEW_CHECKER.is_file(), f"missing review checker: {REVIEW_CHECKER}"
        )

    def test_shared_source_guard_survives_distinct_operation_granularities(self):
        module = self._runtime()
        registry = module.IsolatedLockRegistry(module.load_contract())
        index_build = self._request(
            module,
            operation="INDEX_BUILD",
            operation_ref=INDEX_VERSION_REF,
            role="index-build",
            now=1000,
        )
        index_switch = self._request(
            module,
            operation="INDEX_SWITCH",
            operation_ref=INDEX_NAMESPACE_REF,
            role="index-switch",
            now=1001,
        )

        acquired = registry.acquire(index_build)
        conflict = registry.acquire(index_switch)

        self.assertEqual("LOCK_SET_ACQUIRED", acquired["result_code"])
        self.assertEqual("RESOURCE_CONFLICT_ACTIVE", conflict["result_code"])
        self.assertEqual("PAUSE_BEFORE_QUEUE_ADMISSION", conflict["decision_action"])
        self.assertEqual(2, len(registry.snapshot()["locks"]))
        self.assertEqual(
            SOURCE_REF,
            next(iter(registry.snapshot()["locks"].values()))[
                "source_identity_ref"
            ],
        )

    def test_same_idempotency_key_with_different_input_is_rejected(self):
        module = self._runtime()
        registry = module.IsolatedLockRegistry(module.load_contract())
        first = self._request(
            module,
            operation="FILE_PROCESSING",
            operation_ref=INDEX_VERSION_REF,
            role="first",
            now=1000,
        )
        changed = self._request(
            module,
            operation="REPORT_GENERATION",
            operation_ref=INDEX_NAMESPACE_REF,
            role="changed",
            now=1001,
        )
        changed["idempotency_key"] = first["idempotency_key"]

        self.assertEqual("LOCK_SET_ACQUIRED", registry.acquire(first)["result_code"])
        rejected = registry.acquire(changed)

        self.assertEqual("IDEMPOTENCY_KEY_INPUT_CONFLICT", rejected["result_code"])
        self.assertEqual("REJECT_CONFLICT", rejected["decision_action"])
        self.assertFalse(rejected["decision_valid"])
        self.assertEqual([], rejected["input_refs"])
        self.assertEqual(2, len(registry.snapshot()["locks"]))

    def test_boolean_and_float_fencing_evidence_fail_closed(self):
        module = self._runtime()
        for invalid_value in (True, 1.0):
            with self.subTest(invalid_value=invalid_value):
                registry = module.IsolatedLockRegistry(module.load_contract())
                request = self._request(
                    module,
                    operation="FILE_PROCESSING",
                    operation_ref=INDEX_VERSION_REF,
                    role="fence-holder",
                    now=1000,
                )
                acquired = registry.acquire(request)
                forged = copy.deepcopy(acquired)
                forged["fencing_token"] = invalid_value
                forged["lock_versions"] = {
                    key: invalid_value for key in acquired["lock_versions"]
                }
                commit_request = self._request(
                    module,
                    operation="FILE_PROCESSING",
                    operation_ref=INDEX_VERSION_REF,
                    role="fence-holder",
                    now=1001,
                )

                result = registry.can_commit(commit_request, forged)

                self.assertEqual("INVALID_FENCING_EVIDENCE", result["result_code"])
                self.assertEqual("REJECT_COMMIT", result["decision_action"])
                json.dumps(result)

    def test_backward_logical_clock_cannot_renew_or_commit(self):
        module = self._runtime()
        registry = module.IsolatedLockRegistry(module.load_contract())
        request = self._request(
            module,
            operation="FILE_PROCESSING",
            operation_ref=INDEX_VERSION_REF,
            role="clock-holder",
            now=1000,
        )
        acquired = registry.acquire(request)
        backward = self._request(
            module,
            operation="FILE_PROCESSING",
            operation_ref=INDEX_VERSION_REF,
            role="clock-holder",
            now=999,
        )

        renewed = registry.renew(backward, acquired)
        committed = registry.can_commit(backward, acquired)

        self.assertEqual("NON_MONOTONIC_LOGICAL_TIME", renewed["result_code"])
        self.assertEqual("NON_MONOTONIC_LOGICAL_TIME", committed["result_code"])
        self.assertEqual(1030, min(
            item["lease_expires_at"] for item in registry.snapshot()["locks"].values()
        ))

    def test_stale_release_uses_explicit_rejection_action(self):
        module = self._runtime()
        registry = module.IsolatedLockRegistry(module.load_contract())
        primary = self._request(
            module,
            operation="INDEX_BUILD",
            operation_ref=INDEX_VERSION_REF,
            role="primary",
            now=1000,
        )
        acquired = registry.acquire(primary)
        successor = self._request(
            module,
            operation="INDEX_BUILD",
            operation_ref=INDEX_VERSION_REF,
            role="successor",
            now=1035,
        )
        registry.takeover(successor)
        stale = self._request(
            module,
            operation="INDEX_BUILD",
            operation_ref=INDEX_VERSION_REF,
            role="primary",
            now=1036,
        )

        result = registry.release(stale, acquired)

        self.assertEqual("STALE_FENCING_TOKEN", result["result_code"])
        self.assertEqual("REJECT_STALE_RELEASE", result["decision_action"])

    def test_review_reverifies_external_sources_and_all_four_phases(self):
        report = self._review_checker().build_stage041_review_report()

        self.assertTrue(report["source_integrity_valid"], report)
        self.assertTrue(all(report["source_integrity_checks"].values()), report)
        self.assertTrue(all(report["phase_results"].values()), report)
        self.assertTrue(all(report["finding_checks"].values()), report)
        self.assertEqual(
            {"Critical": 2, "Important": 2, "Minor": 1},
            report["finding_counts"],
        )

    def test_invalid_review_finding_fails_closed(self):
        module = self._review_checker()
        valid = module.build_stage041_review_report()
        tampered = dict(valid["finding_checks"])
        tampered["strict_fencing_evidence_repaired"] = False

        blocked = module.build_stage041_review_report(finding_checks=tampered)

        self.assertFalse(blocked["review_valid"], blocked)
        self.assertEqual("FAIL_CLOSED", blocked["result"])
        self.assertEqual("review_blocked", blocked["stage_review_status"])
        self.assertEqual("IDS-STAGE041-REVIEW-GATE", blocked["next_gate"])
        self.assertFalse(blocked["github_upload_allowed"])

    def test_governance_closes_only_to_separate_stage042_entry(self):
        report = self._review_checker().build_stage041_review_report()
        self.assertTrue(report["review_valid"], report)
        self.assertEqual("completed_reviewed_local", report["stage_review_status"])
        self.assertEqual("IDS-STAGE042-P1-GATE", report["next_gate"])
        self.assertFalse(report["stage042_started"])
        self.assertFalse(report["batch_review_performed"])
        self.assertFalse(report["github_upload_allowed"])
        self.assertFalse(report["app_reinstall_allowed"])

        batch = BATCH.read_text(encoding="utf-8")
        roadmap = ROADMAP.read_text(encoding="utf-8")
        self.assertIn('status: "stage041_completed_reviewed_local"', batch)
        self.assertIn('next_allowed_task_id: "IDS-V0_1-STAGE042-P1"', batch)
        self.assertIn("push_allowed: false", batch)
        self.assertIn('current_phase_id: "IDS-STAGE041-REVIEW"', roadmap)
        self.assertIn('next_gate_id: "IDS-STAGE042-P1-GATE"', roadmap)

        events = [
            json.loads(line)
            for line in EVENTS.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        matching = [
            event
            for event in events
            if event.get("event_id")
            == "EVT-IDS-V0_1-STAGE041-REVIEW-20260715-001"
        ]
        self.assertEqual(1, len(matching), matching)
        self.assertEqual("stage_review", matching[0]["event_type"])
        self.assertEqual("IDS-V0_1-STAGE041-REVIEW", matching[0]["task_id"])

    def test_review_sources_match_git_index(self):
        report = self._review_checker().build_stage041_review_report()
        binding = report["source_binding_checks"]
        self.assertTrue(binding["all_review_sources_git_tracked"], binding)
        self.assertTrue(binding["all_review_sources_match_git_index"], binding)

    def test_cli_emits_reviewed_local_report(self):
        completed = subprocess.run(
            [sys.executable, "-B", str(REVIEW_CHECKER)],
            cwd=ROOT.parent,
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
        self.assertEqual("", completed.stderr)
        payload = json.loads(completed.stdout)
        self.assertTrue(payload["review_valid"], payload)
        self.assertEqual("completed_reviewed_local", payload["stage_review_status"])
        self.assertEqual("IDS-STAGE042-P1-GATE", payload["next_gate"])


if __name__ == "__main__":
    unittest.main()
