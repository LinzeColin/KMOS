from __future__ import annotations

import copy
import importlib.util
import json
import subprocess
import unittest
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[5]
PROJECT_ROOT = REPO_ROOT / "KM_IDSystem"
CHECKER_PATH = PROJECT_ROOT / "scripts/check_automatic_lifecycle_scenarios.py"
CONTRACT_PATH = (
    PROJECT_ROOT
    / "docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
    "stage042_automatic_lifecycle_scenarios.json"
)
EVIDENCE_PATH = (
    PROJECT_ROOT
    / "docs/pursuing_goal/ids_v0_1/"
    "STAGE042_PHASE3_SCENARIO_VALIDATION.md"
)
ROADMAP_PATH = PROJECT_ROOT / "docs/governance/roadmap.yaml"
BATCH_PATH = (
    PROJECT_ROOT
    / "docs/pursuing_goal/ids_v0_1/BATCH041_050_UPLOAD_LOCK.yaml"
)
EVENTS_PATH = PROJECT_ROOT / "docs/governance/events.jsonl"

P2_COMMIT = "205f33d2049de8e9174f50a8cbeb7e2898af44ed"
EVENT_ID = "EVT-IDS-V0_1-STAGE042-P3-20260715-001"
SCENARIOS = [
    "duplicate_lifecycle_request_replay_and_conflict",
    "worker_exception_requires_manual_recovery",
    "external_drive_offline_requests_pause",
    "actual_disk_observation_and_low_disk_pause",
    "external_api_budget_requests_pause",
    "same_source_concurrency_blocks_start_admission",
    "operation_lock_duplicate_prevention",
    "resume_requires_fresh_owner_and_stable_resources",
    "safe_close_active_writer_times_out_without_force_kill",
    "protected_cleanup_denied",
]
OPERATION_FAMILIES = [
    "FILE_PROCESSING",
    "ARCHIVE_EXTRACTION",
    "INDEX_BUILD",
    "INDEX_SWITCH",
    "REPORT_GENERATION",
]


def _load_checker() -> Any:
    spec = importlib.util.spec_from_file_location(
        "stage042_automatic_lifecycle_scenarios", CHECKER_PATH
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("unable to load Stage042 Phase 3 checker")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Stage042AutomaticLifecycleScenarioTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.checker = _load_checker()
        cls.contract = cls.checker.load_scenario_contract()
        cls.report = cls.checker.build_stage042_phase3_report()

    def test_phase3_artifacts_and_identity_exist(self):
        self.assertTrue(CHECKER_PATH.is_file())
        self.assertTrue(CONTRACT_PATH.is_file())
        self.assertTrue(EVIDENCE_PATH.is_file())
        self.assertEqual(
            "ids.stage042.automatic_lifecycle.phase3.v1",
            self.contract["schema_version"],
        )
        self.assertEqual("STAGE-042", self.contract["stage"])
        self.assertEqual("Phase 3", self.contract["phase"])
        self.assertEqual("IDS-V0_1-STAGE042-P3", self.contract["task_id"])
        self.assertEqual("ACC-STAGE-042", self.contract["acceptance_id"])
        self.assertEqual(
            "ISOLATED_NON_PRODUCTION_AUTOMATIC_LIFECYCLE_SCENARIOS",
            self.contract["execution_mode"],
        )
        self.assertEqual(
            "PHASE3_SCENARIOS_ENABLED_PRODUCTION_DISABLED",
            self.contract["contract_state"],
        )
        self.assertEqual("IDS-STAGE042-P4-GATE", self.contract["next_gate"])

    def test_source_and_phase2_commit_bindings_are_exact(self):
        source = self.contract["source_binding"]
        self.assertEqual(1, source["source_member_match_count"])
        self.assertEqual(
            "78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08",
            source["source_member_sha256"],
        )
        self.assertEqual("SOURCE_VERIFIED", source["source_verification_status"])
        binding = self.contract["phase2_commit_binding"]
        self.assertEqual(P2_COMMIT, binding["commit"])
        self.assertEqual("COMMITTED_LOCAL_PHASE2", binding["binding_mode"])
        ancestor = subprocess.run(
            ["git", "merge-base", "--is-ancestor", P2_COMMIT, "HEAD"],
            cwd=REPO_ROOT,
            check=False,
        )
        self.assertEqual(0, ancestor.returncode)

    def test_upstream_hashes_are_exact_and_git_tracked(self):
        checks = self.checker.validate_scenario_contract(self.contract)
        self.assertTrue(checks["phase2_commit_is_ancestor"])
        self.assertTrue(checks["upstream_bindings_exact"])
        self.assertTrue(checks["upstream_refs_git_tracked"])
        self.assertTrue(checks["upstream_hashes_current"])
        self.assertEqual(
            {
                "phase2_contract",
                "phase2_checker",
                "phase2_evidence",
                "phase2_tests",
                "stage041_scenario_contract",
                "stage041_scenario_checker",
            },
            set(self.contract["upstream_bindings"]),
        )

    def test_scenario_and_physical_action_contracts_are_exact(self):
        self.assertEqual(SCENARIOS, self.contract["scenario_catalog"])
        self.assertEqual(
            set(SCENARIOS), set(self.contract["scenario_expectations"])
        )
        boundary = self.contract["physical_action_boundary"]
        allowed_true = {
            "stage041_scenario_replay_allowed",
            "stage042_isolated_lifecycle_scenarios_allowed",
            "actual_project_disk_observation_allowed",
        }
        self.assertEqual(
            allowed_true, {key for key, value in boundary.items() if value}
        )
        self.assertTrue(
            all(
                value is False
                for key, value in boundary.items()
                if key not in allowed_true
            )
        )

    def test_report_passes_all_contract_checks_and_ten_scenarios(self):
        self.assertTrue(self.report["contract_valid"])
        self.assertTrue(all(self.report["contract_checks"].values()))
        self.assertTrue(self.report["scenario_runtime_performed"])
        self.assertTrue(self.report["scenario_validation_valid"])
        self.assertEqual(10, self.report["scenario_count"])
        self.assertEqual(10, self.report["passed_scenario_count"])
        self.assertEqual(SCENARIOS, list(self.report["scenario_results"]))
        self.assertTrue(
            all(
                item["status"] == "PASS"
                for item in self.report["scenario_results"].values()
            )
        )

    def test_duplicate_request_replays_once_and_conflicting_input_is_rejected(self):
        result = self.report["scenario_results"][
            "duplicate_lifecycle_request_replay_and_conflict"
        ]
        self.assertEqual("START_QUEUED", result["first_result_code"])
        self.assertTrue(result["second_is_exact_replay"])
        self.assertEqual(
            "REJECT_IDEMPOTENCY_KEY_INPUT_CONFLICT",
            result["input_conflict_result_code"],
        )
        self.assertEqual("REQUIRE_MANUAL_REVIEW", result["input_conflict_action"])
        self.assertEqual(1, result["ledger_record_count"])
        self.assertFalse(result["persistent_state_write_performed"])

    def test_worker_exception_never_claims_process_crash_recovery(self):
        result = self.report["scenario_results"][
            "worker_exception_requires_manual_recovery"
        ]
        self.assertTrue(result["actual_isolated_worker_exception_performed"])
        self.assertEqual("error:RuntimeError", result["worker_error_ref"])
        self.assertEqual(
            "PAUSE_ACKNOWLEDGEMENT_TIMEOUT", result["lifecycle_result_code"]
        )
        self.assertEqual("REQUIRE_MANUAL_REVIEW", result["decision_action"])
        self.assertFalse(result["process_termination_performed"])
        self.assertFalse(result["crash_recovery_runtime_performed"])
        self.assertEqual("STAGE-043", result["crash_recovery_owner"])

    def test_drive_disk_and_api_failures_request_legal_pause_transitions(self):
        results = self.report["scenario_results"]
        drive = results["external_drive_offline_requests_pause"]
        self.assertEqual("EXTERNAL_DRIVE_OFFLINE", drive["signal_code"])
        self.assertEqual("RUNNING->PAUSE_REQUESTED", drive["transition"])
        self.assertFalse(drive["physical_drive_removal_performed"])

        disk = results["actual_disk_observation_and_low_disk_pause"]
        self.assertGreater(disk["actual_disk_free_bytes"], 0)
        self.assertTrue(disk["actual_disk_decision_matches_formula"])
        self.assertEqual("DISK_SPACE_INSUFFICIENT", disk["signal_code"])
        self.assertEqual("QUEUED->PAUSED", disk["transition"])
        self.assertFalse(disk["disk_allocation_performed"])

        api = results["external_api_budget_requests_pause"]
        self.assertEqual("EXTERNAL_API_BUDGET_INSUFFICIENT", api["signal_code"])
        self.assertEqual("CLAIMED->PAUSE_REQUESTED", api["transition"])
        self.assertFalse(api["external_api_call_performed"])
        self.assertTrue(self.checker._positive_int(1))
        self.assertFalse(self.checker._positive_int(True))
        self.assertFalse(self.checker._positive_int(1.0))
        self.assertFalse(self.checker._positive_int(0))

    def test_same_source_lock_contention_blocks_lifecycle_start(self):
        result = self.report["scenario_results"][
            "same_source_concurrency_blocks_start_admission"
        ]
        self.assertEqual(4, result["resource_conflict_count"])
        self.assertEqual(0, result["partial_operation_lock_count"])
        self.assertEqual(
            "GUARD_OR_EDGE_NOT_SATISFIED", result["lifecycle_result_code"]
        )
        self.assertEqual("REQUIRE_MANUAL_REVIEW", result["decision_action"])
        self.assertFalse(result["queue_record_created"])

    def test_each_operation_family_blocks_duplicate_processing(self):
        result = self.report["scenario_results"][
            "operation_lock_duplicate_prevention"
        ]
        self.assertEqual(OPERATION_FAMILIES, result["operation_families"])
        self.assertEqual(5, result["acquired_count"])
        self.assertEqual(5, result["duplicate_conflict_count"])
        self.assertEqual(5, result["idempotent_replay_count"])
        self.assertEqual(0, result["partial_lock_count"])
        self.assertFalse(result["duplicate_processing_performed"])

    def test_resume_requires_fresh_owner_and_stable_resources(self):
        result = self.report["scenario_results"][
            "resume_requires_fresh_owner_and_stable_resources"
        ]
        self.assertEqual("OWNER_EVIDENCE_STALE", result["stale_owner_result_code"])
        self.assertEqual(
            "RESOURCE_GATES_NOT_STABLE", result["unstable_resource_result_code"]
        )
        self.assertEqual("RESUME_QUEUED_CANDIDATE", result["ready_result_code"])
        self.assertEqual("PAUSED->QUEUED", result["ready_transition"])
        self.assertFalse(result["automatic_resume_production_performed"])

    def test_safe_close_timeout_never_force_kills_writer(self):
        result = self.report["scenario_results"][
            "safe_close_active_writer_times_out_without_force_kill"
        ]
        self.assertEqual(
            "SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER", result["result_code"]
        )
        self.assertEqual("REQUIRE_MANUAL_REVIEW", result["decision_action"])
        self.assertFalse(result["force_kill_performed"])
        self.assertFalse(result["process_termination_performed"])
        self.assertFalse(result["safe_close_production_performed"])

    def test_protected_cleanup_is_decision_only_and_denies_all_categories(self):
        result = self.report["scenario_results"]["protected_cleanup_denied"]
        self.assertEqual(5, result["protected_ref_count"])
        self.assertEqual(5, result["git_tracked_ref_count"])
        self.assertEqual(5, result["denied_delete_count"])
        self.assertEqual(
            {
                "FACT_SOURCE",
                "MANIFEST",
                "EVIDENCE_LEDGER",
                "REPORT_SNAPSHOT",
                "AUDIT_LOG",
            },
            set(result["category_decisions"]),
        )
        self.assertTrue(
            all(
                value == "PROTECTED_ARTIFACT"
                for value in result["category_decisions"].values()
            )
        )
        self.assertFalse(result["delete_function_exposed"])
        self.assertFalse(result["delete_attempt_performed"])

    def test_truth_flags_and_next_gate_stop_at_phase4(self):
        self.assertTrue(self.report["taskpack_source_read_performed"])
        self.assertTrue(self.report["stage041_scenario_replay_performed"])
        self.assertTrue(self.report["actual_isolated_worker_exception_performed"])
        self.assertTrue(self.report["actual_disk_observation_performed"])
        self.assertTrue(self.report["isolated_lifecycle_scenarios_evaluated"])
        self.assertTrue(self.report["protected_refs_git_tracked"])
        self.assertEqual("IDS-STAGE042-P4-GATE", self.report["next_gate"])
        for key in self.checker.FALSE_TRUTH_FLAGS:
            self.assertFalse(self.report[key], key)

    def test_checker_exposes_no_side_effect_api(self):
        source = CHECKER_PATH.read_text(encoding="utf-8")
        forbidden_tokens = [
            "unlink(",
            "write_text(",
            "write_bytes(",
            "rmtree(",
            "os.remove(",
            "time.sleep(",
            "socket.",
            "requests.",
            "urllib.",
            ".kill(",
            ".terminate(",
            "subprocess.Popen(",
            "subprocess.check_call(",
        ]
        for token in forbidden_tokens:
            with self.subTest(token=token):
                self.assertNotIn(token, source)
        self.assertEqual(2, source.count("subprocess.run("))
        self.assertIn('["git", "ls-files", "--error-unmatch"', source)
        self.assertIn('["git", "merge-base", "--is-ancestor"', source)

    def test_invalid_contract_variants_fail_closed_without_running_scenarios(self):
        non_object = self.checker.build_stage042_phase3_report([])
        self.assertFalse(non_object["contract_valid"])
        self.assertFalse(non_object["scenario_runtime_performed"])
        self.assertFalse(non_object["scenario_validation_valid"])
        self.assertEqual(
            "BLOCKED_INVALID_SCENARIO_CONTRACT", non_object["contract_state"]
        )
        mutators = [
            lambda value: value.update({"task_id": "IDS-V0_1-STAGE042-P4"}),
            lambda value: value["phase2_commit_binding"].update(
                {"commit": "0" * 40}
            ),
            lambda value: value["upstream_bindings"]["phase2_checker"].update(
                {"sha256": "0" * 64}
            ),
            lambda value: value["scenario_catalog"].append("UNAUTHORIZED"),
            lambda value: value["physical_action_boundary"].update(
                {"process_termination_allowed": True}
            ),
            lambda value: value["protected_artifact_contract"].update(
                {"delete_attempt_allowed": True}
            ),
            lambda value: value["truth_flags"].update(
                {"production_runtime_activation_performed": True}
            ),
        ]
        for mutate in mutators:
            with self.subTest(mutate=mutate):
                invalid = copy.deepcopy(self.contract)
                mutate(invalid)
                report = self.checker.build_stage042_phase3_report(invalid)
                self.assertFalse(report["scenario_validation_valid"])
                self.assertFalse(report["scenario_runtime_performed"])
                self.assertEqual(
                    "BLOCKED_INVALID_SCENARIO_CONTRACT", report["contract_state"]
                )
                self.assertEqual("IDS-STAGE042-P3-GATE", report["next_gate"])

    def test_governance_records_phase3_once_and_preserves_no_upload(self):
        roadmap = ROADMAP_PATH.read_text(encoding="utf-8")
        batch = BATCH_PATH.read_text(encoding="utf-8")
        events = [
            json.loads(line)
            for line in EVENTS_PATH.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        matches = [event for event in events if event.get("event_id") == EVENT_ID]
        self.assertEqual(1, len(matches))
        event = matches[0]
        self.assertEqual("IDS-V0_1-STAGE042-P3", event["task_id"])
        self.assertEqual(["ACC-STAGE-042"], event["acceptance_ids"])
        self.assertIn("push_allowed=false", event["notes"])
        self.assertIn('current_phase_id: "IDS-STAGE042-P3"', roadmap)
        self.assertIn('current_task_id: "IDS-V0_1-STAGE042-P3"', roadmap)
        self.assertIn('next_gate_id: "IDS-STAGE042-P4-GATE"', roadmap)
        self.assertIn('status: "stage042_phase3_completed"', batch)
        self.assertIn('next_allowed_task_id: "IDS-V0_1-STAGE042-P4"', batch)
        self.assertIn("github_upload_allowed: false", batch)


if __name__ == "__main__":
    unittest.main()
