#!/usr/bin/env python3
"""Build and validate STAGE-041 Phase 4 isolated closeout evidence."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
from typing import Any, Mapping, Optional
import zipfile


REPO_ROOT = Path(__file__).resolve().parents[2]
PROJECT_ROOT = Path(__file__).resolve().parents[1]
BASE = PROJECT_ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
CONTRACT_PATH = (
    BASE / "lock_registry" / "stage041_lock_registry_delivery_contract.json"
)
STATE_INDEX_PATH = BASE / "job_state_model" / "stage037_job_state_model_index.json"
PHASE1_CONTRACT_PATH = (
    BASE / "lock_registry" / "stage041_lock_registry_contract.json"
)
PHASE3_CHECKER = PROJECT_ROOT / "scripts" / "check_lock_registry_scenarios.py"
STAGE039_DELIVERY_CHECKER = (
    PROJECT_ROOT / "scripts" / "check_retry_dead_letter_delivery.py"
)
STAGE040_DELIVERY_CHECKER = PROJECT_ROOT / "scripts" / "check_backpressure_delivery.py"

TASK_ID = "IDS-V0_1-STAGE041-P4"
ACCEPTANCE_ID = "ACC-STAGE-041"
POLICY_VERSION = "ids.lock_registry_policy.v0_1.stage041.p2"
EXECUTION_MODE = "ISOLATED_NON_PRODUCTION_CLOSEOUT_EVIDENCE"
VALID_RESULT = "PASS_ISOLATED_CLOSEOUT_PRODUCTION_DISABLED"
PHASE4_GATE = "IDS-STAGE041-P4-GATE"
REVIEW_GATE = "IDS-STAGE041-REVIEW-GATE"
PHASE3_COMMIT = "c1e8de9c798b533cb93f68a39db00d81b11f68b8"

OPERATION_FAMILIES = [
    "FILE_PROCESSING",
    "ARCHIVE_EXTRACTION",
    "INDEX_BUILD",
    "INDEX_SWITCH",
    "REPORT_GENERATION",
]
LOCK_PROOFS = [
    "IDEMPOTENT_DUPLICATE_REPLAY",
    "IDEMPOTENCY_INPUT_CONFLICT_REJECTION",
    "SAME_SOURCE_CROSS_OPERATION_CONTENTION",
    "SEPARATE_SOURCE_AND_OPERATION_IDENTITIES",
    "FIVE_OPERATION_FAMILY_DUPLICATE_BARRIERS",
    "LEASE_RENEWAL_NO_FENCE_ADVANCE",
    "EXPIRY_GRACE_ATOMIC_TAKEOVER",
    "STALE_FENCING_COMMIT_DENIAL",
    "STRICT_JSON_INTEGER_FENCING_EVIDENCE",
    "MONOTONIC_LOGICAL_CLOCK",
    "EXPLICIT_STALE_RELEASE_REJECTION",
]
PRESSURE_SIGNALS = [
    "QUEUE_SOFT_PRESSURE",
    "QUEUE_HARD_CAPACITY",
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
    "JOB_TYPE_CONCURRENCY_LIMIT_REACHED",
    "SAME_SOURCE_CONFLICT",
]
EXPECTED_STATE_HISTORY = [
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "RETRY_WAIT",
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "RETRY_WAIT",
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "RETRY_WAIT",
    "DEAD_LETTERED",
]
CLEANUP_CLASSES = ["TEMP_STAGING_OUTPUT", "INCOMPLETE_DERIVATIVE_OUTPUT"]
PROTECTED_CLASSES = [
    "FACT_SOURCE",
    "MANIFEST",
    "EVIDENCE_LEDGER",
    "REPORT_SNAPSHOT",
    "AUDIT_LOG",
]
CLEANUP_PRECONDITIONS = [
    "APPROVED_ROOT_IDENTITY",
    "ROOT_RELATIVE_PATH",
    "IMMUTABLE_LSTAT_IDENTITY",
    "SYMLINK_BLOCKED",
    "EXCLUSIVE_NAMESPACE_LOCK",
    "WRITER_QUIESCENCE",
    "NO_FOLLOW_TRAVERSAL",
]
CONTROLLED_TAKEOVER_CANDIDATES = [
    "EXPIRED_LEASE_AFTER_GRACE_REQUIRES_FRESH_EXACT_GATE_REVALIDATION"
]
MANUAL_ACTION_CASES = [
    "UNKNOWN_OR_STALE_LOCK_EVIDENCE",
    "ACTIVE_LEASE_CONTENTION",
    "RESOURCE_GATE_OWNER_REVALIDATION",
    "WORKER_OR_PROCESS_LOSS",
    "STALE_HOLDER_COMMIT_OR_RELEASE",
    "TERMINAL_JOB_RESTART",
    "UNCALIBRATED_LOCK_POLICY",
    "INVALID_OR_MISSING_CONTRACT",
    "PERSISTENT_REGISTRY_RECONSTRUCTION",
    "PROTECTED_CLEANUP_REQUEST",
]
SHUTDOWN_STEPS = [
    "STOP_NEW_LOCK_ACQUISITIONS",
    "STOP_RENEW_AND_TAKEOVER_DECISIONS",
    "FREEZE_LOGICAL_CLOCK_SNAPSHOT",
    "COMPLETE_OR_RELEASE_ACCEPTED_ISOLATED_EVALUATIONS",
    "PRESERVE_CONTRACT_EVIDENCE_AND_AUDIT_REFS",
    "DISCARD_PROCESS_LOCAL_LOCK_REGISTRY",
    "VERIFY_NO_PERSISTENT_OR_RUNTIME_OUTPUT",
]
RECOVERY_STEPS = [
    "VERIFY_EXACT_SOURCE_POLICY_AND_UPSTREAM_HASHES",
    "REVALIDATE_RESOURCE_AND_BACKPRESSURE_GATES",
    "REBUILD_ONLY_FROM_DURABLE_JOB_AND_CHECKPOINT_EVIDENCE",
    "REJECT_STALE_FENCING_TOKENS",
    "REACQUIRE_CANONICAL_FULL_LOCK_SET",
    "REQUIRE_MANUAL_REVIEW_FOR_UNKNOWN_OR_MISSING_EVIDENCE",
    "DEFER_AUTOMATIC_RESUME_TO_STAGE042",
    "DEFER_PROCESS_CRASH_RECOVERY_TO_STAGE043",
]
ROLLBACK_STEPS = [
    "STOP_ON_INVALID_DELIVERY_CONTRACT",
    "DISABLE_ISOLATED_LOCK_RUNTIME",
    "REJECT_NEW_LOCK_ACQUIRE_RENEW_TAKEOVER",
    "REVERT_PHASE4_FILES_ONLY",
    "PRESERVE_PHASE1_PHASE3_EVIDENCE",
    "PRESERVE_RAW_DATA_AND_DURABLE_EVIDENCE",
]
KNOWN_LIMITS = [
    "NO_PERSISTENT_LOCK_REGISTRY",
    "NO_PRODUCTION_LOCK_LEASE_OR_FENCING_RUNTIME",
    "NO_PRODUCTION_CALIBRATION",
    "NO_QUEUE_WORKER_OR_RETRY_SCHEDULER_RUNTIME",
    "NO_AUTOMATIC_RESUME_OR_LIFECYCLE_RUNTIME",
    "NO_PROCESS_CRASH_RECOVERY",
    "NO_CLEANUP_RUNTIME",
    "NO_DATABASE_OR_RAW_SOURCE_ACCESS",
    "STATIC_CLOSEOUT_IS_NOT_PRODUCTION_READINESS",
]

EXPECTED_SOURCE = {
    "source_archive_path": "/Users/linzezhang/Downloads/IDS_Taskpack_v0_1_only_中文修订版.zip",
    "source_archive_sha256": "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3",
    "source_member": "IDS_v0_1_Final_Chinese_Revised/stages/STAGE-041_锁注册与竞态控制.md",
    "source_member_match_count": 1,
    "source_member_sha256": "2258a7b57c6c2881f208f43fbe2862c7815a2794c908d6fef108a1a4b5a2ad36",
    "roadmap_path": "/Users/linzezhang/Downloads/IDS_Codex开发Roadmap_v0_1_only_中文修订版.txt",
    "roadmap_sha256": "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6",
    "instructions_path": "/Users/linzezhang/Downloads/IDS_Codex使用说明_v0_1_only_中文修订版.txt",
    "instructions_sha256": "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8",
    "source_verification_status": "SOURCE_VERIFIED",
}
EXPECTED_UPSTREAM = {
    "stage037_state_index": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/job_state_model/stage037_job_state_model_index.json",
        "b70bf72ebe4212f45d380c13fbfe429791e1f4a5c73dccbba81211b7adc1c2d3",
    ),
    "stage039_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/retry_dead_letter/stage039_retry_dead_letter_delivery_contract.json",
        "c4aad64a9283de683067aff07026d723c708285c57eef8a0eac4ee1b13f5cb96",
    ),
    "stage039_delivery_checker": (
        "KM_IDSystem/scripts/check_retry_dead_letter_delivery.py",
        "babff5f0be9e6be06508cbe4efbe355c354a65324d0895e7c9c5f3322621e4da",
    ),
    "stage039_review_artifact": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE039_STAGE_REVIEW.md",
        "32e621db9d7d4ad87ff4f6788e1de22d7ada9c0f57ce756a76a9608a864c4b9b",
    ),
    "stage040_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/stage040_backpressure_delivery_contract.json",
        "84f3d69f4bda15e0042631d9b049c8988c1375be632d96e366e57cf0b1ab0ac2",
    ),
    "stage040_delivery_checker": (
        "KM_IDSystem/scripts/check_backpressure_delivery.py",
        "8a16e7b079de9a05ed43029b6c6a858af8d293f49df9a2c4ceaff196cd35b4c9",
    ),
    "stage040_review_artifact": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE040_STAGE_REVIEW.md",
        "ea1a6dacacc862d66de60883dd10ee2dbf23d3adc72efbf9586ba2ccf6c223f0",
    ),
    "stage041_phase1_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/stage041_lock_registry_contract.json",
        "3b8c753dd277dab7d55a611f548e9dd14fd299a6123a8c5a25547ac169b33c0e",
    ),
    "stage041_phase1_evidence": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md",
        "d8f2852f01a096c67460da34fab8e372f994cb13e10f93e8faf406d570a94483",
    ),
    "stage041_phase2_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/stage041_lock_registry_runtime_contract.json",
        "935c0d7358b4125ba96cbd1d53b869acdc831ab2b6e3b4fd21f155f07a585a7c",
    ),
    "stage041_phase2_checker": (
        "KM_IDSystem/scripts/check_lock_registry_runtime.py",
        "ad8cca376f6932300ecc90f7c78f67536b229d5c4bb40d9ebfa163de37f2108c",
    ),
    "stage041_phase2_evidence": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md",
        "96dce06ec536109e74a3a756c4dafcc1ca417fc9ae8076794d80f9ba52e57fba",
    ),
    "stage041_phase2_tests": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/test_stage041_lock_registry_runtime.py",
        "ab3f4ea46510f4da6289f81ba1cb5c1dd395b6ed13e579d7aed5c2801e2a4a10",
    ),
    "stage041_phase3_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/stage041_lock_registry_scenarios.json",
        "c365809037e377c90e34eadcd1a64e94490c774ee90cc19b99d56ac4b3026f82",
    ),
    "stage041_phase3_checker": (
        "KM_IDSystem/scripts/check_lock_registry_scenarios.py",
        "8283e89c7157528974e94cf75e5e59edf625be4b727f9dd3ab3c7c5abe8c3c51",
    ),
    "stage041_phase3_evidence": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE041_PHASE3_SCENARIO_VALIDATION.md",
        "0e0ea5ead983197bd156d041fdb627713f3d11aab70c11e02dba18a97645ccbb",
    ),
    "stage041_phase3_tests": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/test_stage041_lock_registry_scenarios.py",
        "f31859d86d1612045c75d2a210584e6c66cc5ad7ea64f769c4a2a4acd95e52e0",
    ),
}
POSITIVE_TRUTH_FLAGS = {
    "taskpack_source_read_performed",
    "isolated_lock_decision_runtime_replayed",
    "lock_scenario_replay_performed",
    "actual_disk_observation_replayed",
    "actual_isolated_worker_exception_replayed",
    "reviewed_failure_retry_log_replayed",
    "reviewed_backpressure_proof_replayed",
}
FALSE_TRUTH_FLAGS = {
    "ids_business_source_read_performed",
    "raw_metadata_content_accessed",
    "fake_ids_business_data_used",
    "real_ids_business_job_created",
    "process_termination_performed",
    "physical_drive_removal_performed",
    "disk_allocation_performed",
    "external_api_call_performed",
    "cleanup_runtime_performed",
    "protected_ref_delete_performed",
    "queue_runtime_performed",
    "worker_runtime_performed",
    "retry_scheduler_performed",
    "persistent_queue_write_performed",
    "database_connection_performed",
    "runtime_output_written",
    "production_lock_runtime_performed",
    "persistent_lock_write_performed",
    "automatic_resume_performed",
    "process_crash_recovery_performed",
    "production_runtime_activation_performed",
    "whole_stage_review_performed",
    "batch_review_performed",
    "github_upload_allowed",
    "app_reinstall_allowed",
}
EXPECTED_ROOT_KEYS = {
    "schema_version",
    "stage",
    "phase",
    "task_id",
    "acceptance_id",
    "execution_mode",
    "valid_result",
    "contract_state",
    "stage_review_status",
    "next_gate",
    "source_binding",
    "phase3_commit_binding",
    "upstream_bindings",
    "delivery_contract",
    "cleanup_allowlist",
    "recovery_handling",
    "safe_shutdown_and_recovery",
    "rollback_contract",
    "known_limits",
    "owner_feedback_contract",
    "review_gate",
    "truth_flags",
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _phase3_module() -> Any:
    return _load_module(PHASE3_CHECKER, "stage041_phase3_for_delivery")


def _stage039_delivery_module() -> Any:
    return _load_module(STAGE039_DELIVERY_CHECKER, "stage039_for_stage041_delivery")


def _stage040_delivery_module() -> Any:
    return _load_module(STAGE040_DELIVERY_CHECKER, "stage040_for_stage041_delivery")


def _load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def load_delivery_contract() -> dict[str, Any]:
    return _load_json(CONTRACT_PATH)


def _git_tracked(path: Path) -> bool:
    try:
        relative = path.resolve().relative_to(REPO_ROOT.resolve())
    except ValueError:
        return False
    completed = subprocess.run(
        ["git", "ls-files", "--error-unmatch", "--", relative.as_posix()],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    return completed.returncode == 0


def _source_binding_current(value: Any) -> bool:
    if value != EXPECTED_SOURCE:
        return False
    try:
        archive = Path(value["source_archive_path"])
        roadmap = Path(value["roadmap_path"])
        instructions = Path(value["instructions_path"])
        if sha256_file(archive) != value["source_archive_sha256"]:
            return False
        if sha256_file(roadmap) != value["roadmap_sha256"]:
            return False
        if sha256_file(instructions) != value["instructions_sha256"]:
            return False
        with zipfile.ZipFile(archive) as bundle:
            matches = [
                name for name in bundle.namelist() if name == value["source_member"]
            ]
            return (
                len(matches) == value["source_member_match_count"] == 1
                and hashlib.sha256(bundle.read(matches[0])).hexdigest()
                == value["source_member_sha256"]
            )
    except (OSError, KeyError, TypeError, zipfile.BadZipFile):
        return False


def _phase3_commit_is_ancestor(value: Any) -> bool:
    if value != {"commit": PHASE3_COMMIT, "required_ancestor_of_head": True}:
        return False
    completed = subprocess.run(
        ["git", "merge-base", "--is-ancestor", PHASE3_COMMIT, "HEAD"],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    return completed.returncode == 0


def _upstream_valid(value: Any) -> bool:
    if not isinstance(value, dict) or set(value) != set(EXPECTED_UPSTREAM):
        return False
    for name, (ref, digest) in EXPECTED_UPSTREAM.items():
        if value.get(name) != {"ref": ref, "sha256": digest}:
            return False
        path = REPO_ROOT / ref
        if not path.is_file() or sha256_file(path) != digest or not _git_tracked(path):
            return False
    return True


def validate_delivery_contract(contract: Any) -> dict[str, bool]:
    if not isinstance(contract, dict):
        return {"contract_is_object": False}
    delivery = contract.get("delivery_contract")
    cleanup = contract.get("cleanup_allowlist")
    recovery = contract.get("recovery_handling")
    shutdown = contract.get("safe_shutdown_and_recovery")
    rollback = contract.get("rollback_contract")
    owner = contract.get("owner_feedback_contract")
    review = contract.get("review_gate")
    truth = contract.get("truth_flags")
    return {
        "root_shape_exact": set(contract) == EXPECTED_ROOT_KEYS,
        "identity_exact": (
            contract.get("schema_version")
            == "ids.stage041.lock_registry.phase4.delivery.v1"
            and contract.get("stage") == "STAGE-041"
            and contract.get("phase") == "Phase 4"
            and contract.get("task_id") == TASK_ID
            and contract.get("acceptance_id") == ACCEPTANCE_ID
            and contract.get("execution_mode") == EXECUTION_MODE
            and contract.get("valid_result") == VALID_RESULT
            and contract.get("contract_state")
            == "PHASE4_CLOSEOUT_EVIDENCE_REVIEW_PENDING"
            and contract.get("stage_review_status") == "pending_next_run"
            and contract.get("next_gate") == REVIEW_GATE
        ),
        "source_binding_current": _source_binding_current(
            contract.get("source_binding")
        ),
        "phase3_commit_bound": _phase3_commit_is_ancestor(
            contract.get("phase3_commit_binding")
        ),
        "upstream_bindings_current": _upstream_valid(
            contract.get("upstream_bindings")
        ),
        "delivery_contract_exact": delivery
        == {
            "policy_version": POLICY_VERSION,
            "state_model_version": "ids.job_state.v1",
            "required_job_type_count": 8,
            "required_job_state_count": 11,
            "required_terminal_state_count": 4,
            "required_transition_count": 21,
            "required_operation_families": OPERATION_FAMILIES,
            "required_shared_guard_namespace": "SOURCE_PIPELINE",
            "required_lock_count_per_operation": 2,
            "required_lock_proofs": LOCK_PROOFS,
            "required_pressure_signals": PRESSURE_SIGNALS,
            "failure_retry_log_source": "STAGE039_REVIEWED_PHASE4_ACTUAL_ISOLATED_CONTROL_METADATA",
            "expected_attempt_count": 3,
            "expected_retry_count": 2,
            "expected_max_retries": 2,
            "expected_final_state": "DEAD_LETTERED",
            "actual_project_disk_observation_required": True,
            "production_calibrated": False,
            "stage_review_must_run_separately": True,
        },
        "cleanup_allowlist_exact": cleanup
        == {
            "cleanup_eligible_classes": CLEANUP_CLASSES,
            "protected_artifact_classes": PROTECTED_CLASSES,
            "cleanup_manifest_required": True,
            "required_preconditions": CLEANUP_PRECONDITIONS,
            "runtime_owner": "STAGE-044",
            "delete_execution_allowed": False,
        },
        "recovery_handling_exact": recovery
        == {
            "automatic_recovery_eligible_cases": [],
            "successful_automatic_recovery_cases_observed": [],
            "controlled_takeover_candidates": CONTROLLED_TAKEOVER_CANDIDATES,
            "manual_action_required_cases": MANUAL_ACTION_CASES,
            "automatic_resume_allowed": False,
            "automatic_resume_runtime_owner": "STAGE-042",
            "process_crash_recovery_runtime_owner": "STAGE-043",
        },
        "safe_shutdown_recovery_exact": shutdown
        == {
            "shutdown_steps": SHUTDOWN_STEPS,
            "recovery_steps": RECOVERY_STEPS,
            "persistent_lock_registry_available_after_exit": False,
            "process_termination_allowed": False,
            "automatic_process_recovery_allowed": False,
        },
        "rollback_exact": rollback
        == {"steps": ROLLBACK_STEPS, "destructive_rollback_allowed": False},
        "known_limits_exact": contract.get("known_limits") == KNOWN_LIMITS,
        "owner_feedback_exact": (
            isinstance(owner, dict)
            and set(owner)
            == {"status_zh", "automatic_eligibility_zh", "manual_action_zh", "limit_zh"}
            and all(isinstance(value, str) and value for value in owner.values())
            and "未观察到自动恢复成功" in owner["automatic_eligibility_zh"]
            and "不是生产运行或生产就绪证明" in owner["limit_zh"]
        ),
        "review_gate_exact": review
        == {
            "next_task_id": "IDS-V0_1-STAGE041-REVIEW",
            "must_run_separately": True,
            "phase4_may_mark_stage_reviewed": False,
            "batch_review_allowed": False,
            "stage042_entry_allowed": False,
            "github_upload_allowed": False,
            "app_reinstall_allowed": False,
        },
        "truth_flags_exact": (
            isinstance(truth, dict)
            and set(truth) == POSITIVE_TRUTH_FLAGS | FALSE_TRUTH_FLAGS
            and all(truth.get(key) is True for key in POSITIVE_TRUTH_FLAGS)
            and all(truth.get(key) is False for key in FALSE_TRUTH_FLAGS)
        ),
    }


def _flatten_transitions(value: Mapping[str, Any]) -> list[str]:
    return [
        f"{source}->{target}"
        for source, targets in value.items()
        for target in targets
    ]


def _state_lock_graph(contract: Mapping[str, Any]) -> dict[str, Any]:
    state_model = _load_json(STATE_INDEX_PATH)["state_model"]
    phase1 = _load_json(PHASE1_CONTRACT_PATH)
    transitions = state_model["allowed_transitions"]
    flat = _flatten_transitions(transitions)
    operation_contract = phase1["operation_scope_contract"]
    acquisition = phase1["acquisition_contract"]
    state_lines = ["stateDiagram-v2"] + [
        f"    {item.replace('->', ' --> ')}" for item in flat
    ]
    lock_lines = [
        "flowchart TD",
        '    R["Operation request"] --> V{"Exact resource evidence?"}',
        '    V -->|No| M["REQUIRE_MANUAL_REVIEW"]',
        '    V -->|Yes| G{"Resource gates pass?"}',
        '    G -->|No| P["PAUSE_RESOURCE_GATE before lock"]',
        '    G -->|Yes| K["Derive SOURCE_PIPELINE and operation keys"]',
        '    K --> C["Canonical lexicographic order"]',
        '    C --> A{"Atomic all-or-none CAS"}',
        '    A -->|Conflict| P2["PAUSE_BEFORE_QUEUE_ADMISSION"]',
        '    A -->|Acquired| F["Issue monotonic fencing token"]',
        '    F --> W{"Current holder, version, token and lease?"}',
        '    W -->|No| S["REJECT_STALE_FENCING_TOKEN"]',
        '    W -->|Yes| O["Guard output, state, checkpoint and evidence"]',
    ]
    return {
        "state_model_version": state_model["state_model_version"],
        "job_types": copy.deepcopy(state_model["job_types"]),
        "job_states": copy.deepcopy(state_model["job_states"]),
        "terminal_states": copy.deepcopy(state_model["terminal_states"]),
        "allowed_transitions": copy.deepcopy(transitions),
        "allowed_transitions_flat": flat,
        "allowed_transition_count": len(flat),
        "operation_families": copy.deepcopy(
            contract["delivery_contract"]["required_operation_families"]
        ),
        "shared_guard_namespace": operation_contract[
            "mandatory_shared_guard_namespace"
        ],
        "required_lock_count_per_operation": contract["delivery_contract"][
            "required_lock_count_per_operation"
        ],
        "multi_lock_atomicity": acquisition["multi_lock_atomicity"],
        "multi_lock_order": phase1["lock_key_contract"]["multi_lock_order"],
        "mermaid_state_diagram": "\n".join(state_lines),
        "mermaid_lock_flow": "\n".join(lock_lines),
        "state_registry_write_performed": False,
    }


def _failure_retry_log(stage039: Mapping[str, Any]) -> dict[str, Any]:
    source = copy.deepcopy(stage039["failure_retry_dead_letter_log"])
    source["source"] = "STAGE039_REVIEWED_PHASE4_ACTUAL_ISOLATED_CONTROL_METADATA"
    source["reviewed_stage039_delivery_valid"] = (
        stage039.get("delivery_contract_valid") is True
        and stage039.get("result") == VALID_RESULT
        and stage039.get("next_gate") == "IDS-STAGE039-REVIEW-GATE"
    )
    return source


def _backpressure_trigger_proof(
    stage040: Mapping[str, Any], phase3: Mapping[str, Any]
) -> dict[str, Any]:
    proof = copy.deepcopy(stage040["backpressure_trigger_proof"])
    scenarios = phase3["scenario_results"]
    resource_map = {
        "EXTERNAL_DRIVE_OFFLINE": "external_drive_offline_pause_before_lock",
        "DISK_SPACE_INSUFFICIENT": "actual_disk_observation_and_low_disk_pause_before_lock",
        "EXTERNAL_API_BUDGET_INSUFFICIENT": "external_api_budget_pause_before_lock",
    }
    for signal, scenario_name in resource_map.items():
        proof[signal]["lock_acquire_attempted"] = scenarios[scenario_name][
            "lock_acquire_attempted"
        ]
    return proof


def _lock_control_proof(phase3: Mapping[str, Any]) -> dict[str, Any]:
    scenarios = phase3["scenario_results"]
    duplicate = scenarios["duplicate_click_lock_replay"]
    source = scenarios["same_source_cross_operation_contention"]
    operations = scenarios["operation_family_duplicate_prevention"]
    fencing = scenarios["renewal_takeover_and_stale_fencing"]
    orphan = scenarios["worker_exception_orphaned_lease_boundary"]
    return {
        "operation_families": copy.deepcopy(operations["operation_families"]),
        "idempotent_duplicate_replay": duplicate["second_is_exact_replay"],
        "idempotency_input_conflict_result_code": duplicate[
            "idempotency_input_conflict_result_code"
        ],
        "idempotency_input_conflict_action": duplicate[
            "idempotency_input_conflict_action"
        ],
        "operation_acquired_count": operations["acquired_count"],
        "operation_duplicate_conflict_count": operations[
            "duplicate_conflict_count"
        ],
        "same_source_cross_operation_conflict_count": source[
            "resource_conflict_count"
        ],
        "same_source_identity_count": source["source_identity_count"],
        "distinct_operation_identity_count": source[
            "distinct_operation_identity_count"
        ],
        "partial_lock_count": operations["partial_lock_count"],
        "renew_preserved_fence_and_versions": fencing[
            "renew_preserved_fence_and_versions"
        ],
        "takeover_advanced_fence_and_versions_atomically": fencing[
            "takeover_advanced_fence_and_versions_atomically"
        ],
        "early_takeover_result_code": fencing["early_takeover_result_code"],
        "eligible_takeover_result_code": fencing["eligible_takeover_result_code"],
        "stale_commit_result_code": fencing["stale_commit_result_code"],
        "forged_fencing_result_code": fencing["forged_fencing_result_code"],
        "backward_clock_result_code": fencing["backward_clock_result_code"],
        "stale_release_action": fencing["stale_release_action"],
        "orphan_successor_fencing_token_advanced": (
            orphan["successor_fencing_token"] > orphan["orphaned_fencing_token"]
        ),
        "persistent_lock_write_performed": False,
        "production_lock_runtime_performed": False,
    }


def _cleanup_allowlist(
    contract: Mapping[str, Any], phase3: Mapping[str, Any]
) -> dict[str, Any]:
    configured = contract["cleanup_allowlist"]
    protected = phase3["scenario_results"]["protected_cleanup_denied"]
    checks = {
        name: decision == "PROTECTED_ARTIFACT"
        for name, decision in protected["category_decisions"].items()
    }
    return {
        "cleanup_eligible_classes": copy.deepcopy(
            configured["cleanup_eligible_classes"]
        ),
        "protected_artifact_classes": copy.deepcopy(
            configured["protected_artifact_classes"]
        ),
        "cleanup_manifest_required": configured["cleanup_manifest_required"],
        "required_preconditions": copy.deepcopy(configured["required_preconditions"]),
        "protected_ref_count": protected["protected_ref_count"],
        "phase3_protected_ref_checks": checks,
        "cleanup_runtime_performed": protected["cleanup_runtime_performed"],
        "delete_attempt_performed": protected["delete_attempt_performed"],
        "runtime_owner": protected["cleanup_runtime_owner"],
    }


def _recovery_handling(
    contract: Mapping[str, Any], phase3: Mapping[str, Any]
) -> dict[str, Any]:
    configured = contract["recovery_handling"]
    takeover = phase3["scenario_results"]["renewal_takeover_and_stale_fencing"]
    return {
        "automatic_recovery_eligible_cases": [],
        "successful_automatic_recovery_cases_observed": [],
        "controlled_takeover_candidates": copy.deepcopy(
            configured["controlled_takeover_candidates"]
        ),
        "controlled_takeover_candidate_observed": (
            takeover["early_takeover_result_code"] == "LEASE_NOT_TAKEOVER_ELIGIBLE"
            and takeover["eligible_takeover_result_code"] == "TAKEOVER_ACQUIRED"
        ),
        "manual_action_required_cases": copy.deepcopy(
            configured["manual_action_required_cases"]
        ),
        "automatic_resume_allowed": configured["automatic_resume_allowed"],
        "automatic_resume_performed": False,
        "automatic_resume_runtime_owner": configured[
            "automatic_resume_runtime_owner"
        ],
        "process_crash_recovery_performed": False,
        "process_crash_recovery_runtime_owner": configured[
            "process_crash_recovery_runtime_owner"
        ],
    }


def _safe_shutdown_and_recovery(contract: Mapping[str, Any]) -> dict[str, Any]:
    configured = contract["safe_shutdown_and_recovery"]
    return {
        "shutdown_steps": copy.deepcopy(configured["shutdown_steps"]),
        "recovery_steps": copy.deepcopy(configured["recovery_steps"]),
        "persistent_lock_registry_available_after_exit": configured[
            "persistent_lock_registry_available_after_exit"
        ],
        "process_termination_performed": False,
        "automatic_process_recovery_performed": False,
    }


def _delivery_checks(
    graph: Mapping[str, Any],
    log: Mapping[str, Any],
    pressure: Mapping[str, Any],
    locks: Mapping[str, Any],
    cleanup: Mapping[str, Any],
    recovery: Mapping[str, Any],
    shutdown: Mapping[str, Any],
) -> dict[str, bool]:
    return {
        "state_and_lock_graph_exact": (
            graph.get("state_model_version") == "ids.job_state.v1"
            and len(graph.get("job_types", [])) == 8
            and len(graph.get("job_states", [])) == 11
            and len(graph.get("terminal_states", [])) == 4
            and graph.get("allowed_transition_count") == 21
            and graph.get("operation_families") == OPERATION_FAMILIES
            and graph.get("shared_guard_namespace") == "SOURCE_PIPELINE"
            and graph.get("required_lock_count_per_operation") == 2
            and graph.get("multi_lock_atomicity") == "ALL_OR_NONE_CAS"
        ),
        "failure_retry_log_reviewed_actual_bounded": (
            log.get("source")
            == "STAGE039_REVIEWED_PHASE4_ACTUAL_ISOLATED_CONTROL_METADATA"
            and log.get("reviewed_stage039_delivery_valid") is True
            and log.get("state_history") == EXPECTED_STATE_HISTORY
            and log.get("attempt_count") == 3
            and log.get("retry_count") == 2
            and log.get("max_retries") == 2
            and log.get("final_state") == "DEAD_LETTERED"
            and log.get("persisted") is False
        ),
        "backpressure_proof_exact": (
            set(pressure) == set(PRESSURE_SIGNALS)
            and pressure.get("QUEUE_SOFT_PRESSURE", {}).get("decision_action")
            == "THROTTLE_ADMISSION"
            and pressure.get("QUEUE_HARD_CAPACITY", {}).get("decision_action")
            == "DENY_NEW_ADMISSION"
            and all(
                pressure.get(signal, {}).get("decision_action")
                == "PAUSE_RESOURCE_GATE"
                and pressure.get(signal, {}).get("lock_acquire_attempted") is False
                for signal in (
                    "EXTERNAL_DRIVE_OFFLINE",
                    "DISK_SPACE_INSUFFICIENT",
                    "EXTERNAL_API_BUDGET_INSUFFICIENT",
                )
            )
        ),
        "duplicate_and_contention_proof_exact": (
            locks.get("operation_families") == OPERATION_FAMILIES
            and locks.get("idempotent_duplicate_replay") is True
            and locks.get("idempotency_input_conflict_result_code")
            == "IDEMPOTENCY_KEY_INPUT_CONFLICT"
            and locks.get("idempotency_input_conflict_action") == "REJECT_CONFLICT"
            and locks.get("operation_acquired_count") == 5
            and locks.get("operation_duplicate_conflict_count") == 5
            and locks.get("same_source_cross_operation_conflict_count") == 4
            and locks.get("same_source_identity_count") == 1
            and locks.get("distinct_operation_identity_count") == 5
            and locks.get("partial_lock_count") == 0
        ),
        "renew_takeover_and_stale_fencing_exact": (
            locks.get("renew_preserved_fence_and_versions") is True
            and locks.get("takeover_advanced_fence_and_versions_atomically") is True
            and locks.get("early_takeover_result_code")
            == "LEASE_NOT_TAKEOVER_ELIGIBLE"
            and locks.get("eligible_takeover_result_code") == "TAKEOVER_ACQUIRED"
            and locks.get("stale_commit_result_code") == "STALE_FENCING_TOKEN"
            and locks.get("forged_fencing_result_code")
            == "INVALID_FENCING_EVIDENCE"
            and locks.get("backward_clock_result_code")
            == "NON_MONOTONIC_LOGICAL_TIME"
            and locks.get("stale_release_action") == "REJECT_STALE_RELEASE"
            and locks.get("orphan_successor_fencing_token_advanced") is True
            and locks.get("persistent_lock_write_performed") is False
        ),
        "cleanup_allowlist_narrow_and_protected": (
            cleanup.get("cleanup_eligible_classes") == CLEANUP_CLASSES
            and cleanup.get("protected_artifact_classes") == PROTECTED_CLASSES
            and cleanup.get("protected_ref_count") == 5
            and all(cleanup.get("phase3_protected_ref_checks", {}).values())
            and cleanup.get("cleanup_runtime_performed") is False
            and cleanup.get("delete_attempt_performed") is False
        ),
        "automatic_and_manual_handling_truthful": (
            recovery.get("automatic_recovery_eligible_cases") == []
            and recovery.get("successful_automatic_recovery_cases_observed") == []
            and recovery.get("controlled_takeover_candidates")
            == CONTROLLED_TAKEOVER_CANDIDATES
            and recovery.get("controlled_takeover_candidate_observed") is True
            and recovery.get("manual_action_required_cases") == MANUAL_ACTION_CASES
            and recovery.get("automatic_resume_allowed") is False
            and recovery.get("automatic_resume_performed") is False
            and recovery.get("process_crash_recovery_performed") is False
        ),
        "safe_shutdown_and_recovery_fail_closed": (
            shutdown.get("shutdown_steps") == SHUTDOWN_STEPS
            and shutdown.get("recovery_steps") == RECOVERY_STEPS
            and shutdown.get("persistent_lock_registry_available_after_exit")
            is False
            and shutdown.get("process_termination_performed") is False
            and shutdown.get("automatic_process_recovery_performed") is False
        ),
    }


def _blank_report(
    contract: Mapping[str, Any], checks: Mapping[str, bool]
) -> dict[str, Any]:
    truth = contract.get("truth_flags")
    truth = truth if isinstance(truth, dict) else {}
    return {
        "schema_version": "ids.stage041.lock_registry.phase4.report.v1",
        "stage": "STAGE-041",
        "phase": "Phase 4",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "execution_mode": EXECUTION_MODE,
        "policy_version": POLICY_VERSION,
        "contract_checks": dict(checks),
        "contract_valid": bool(checks) and all(checks.values()),
        "delivery_checks_performed": False,
        "delivery_checks": {},
        "delivery_contract_valid": False,
        "result": "BLOCKED_INVALID_OR_UNCHECKED_DELIVERY_CONTRACT",
        "stage_review_status": "blocked_invalid_delivery_contract",
        "next_gate": PHASE4_GATE,
        "execution_ready": False,
        "state_lock_graph": {},
        "failure_retry_log": {},
        "backpressure_trigger_proof": {},
        "lock_control_proof": {},
        "cleanup_allowlist": {},
        "recovery_handling": {},
        "safe_shutdown_and_recovery": {},
        "rollback_steps": copy.deepcopy(ROLLBACK_STEPS),
        "known_limits": copy.deepcopy(KNOWN_LIMITS),
        "source_error_type": None,
        **{key: bool(truth.get(key, False)) for key in POSITIVE_TRUTH_FLAGS},
        **{key: bool(truth.get(key, False)) for key in FALSE_TRUTH_FLAGS},
        "owner_feedback_zh": "交付合同未通过；保持停止并返回 Phase 4 修复。",
    }


def build_stage041_phase4_delivery_report(
    *,
    contract: Optional[Any] = None,
    execute_delivery_checks: bool = True,
) -> dict[str, Any]:
    try:
        contract_value = (
            copy.deepcopy(contract) if contract is not None else load_delivery_contract()
        )
    except (OSError, ValueError, json.JSONDecodeError):
        contract_value = {}
    checks = validate_delivery_contract(contract_value)
    safe_contract = contract_value if isinstance(contract_value, dict) else {}
    report = _blank_report(safe_contract, checks)
    if not report["contract_valid"] or not execute_delivery_checks:
        if report["contract_valid"]:
            report["stage_review_status"] = "blocked_delivery_checks_not_executed"
        return report

    try:
        phase3 = _phase3_module().build_stage041_phase3_report()
        stage039 = _stage039_delivery_module().build_stage039_phase4_delivery_report()
        stage040 = _stage040_delivery_module().build_stage040_phase4_delivery_report()
        if phase3.get("scenario_validation_valid") is not True:
            raise RuntimeError("invalid Stage041 Phase 3 prerequisite")
        if stage039.get("delivery_contract_valid") is not True:
            raise RuntimeError("invalid reviewed Stage039 delivery prerequisite")
        if stage040.get("delivery_contract_valid") is not True:
            raise RuntimeError("invalid reviewed Stage040 delivery prerequisite")

        graph = _state_lock_graph(safe_contract)
        log = _failure_retry_log(stage039)
        pressure = _backpressure_trigger_proof(stage040, phase3)
        locks = _lock_control_proof(phase3)
        cleanup = _cleanup_allowlist(safe_contract, phase3)
        recovery = _recovery_handling(safe_contract, phase3)
        shutdown = _safe_shutdown_and_recovery(safe_contract)
        delivery_checks = _delivery_checks(
            graph, log, pressure, locks, cleanup, recovery, shutdown
        )
    except Exception as exc:
        report["source_error_type"] = type(exc).__name__
        report["stage_review_status"] = "blocked_upstream_or_delivery_failure"
        report["owner_feedback_zh"] = (
            "上游或交付检查失败；保持停止并返回 Phase 4 修复。"
        )
        return report

    valid = bool(delivery_checks) and all(delivery_checks.values())
    owner = safe_contract["owner_feedback_contract"]
    report.update(
        {
            "delivery_checks_performed": True,
            "delivery_checks": delivery_checks,
            "delivery_contract_valid": valid,
            "result": VALID_RESULT if valid else "FAIL_CLOSEOUT_CHECKS",
            "stage_review_status": (
                "pending_next_run" if valid else "blocked_delivery_check_failure"
            ),
            "next_gate": REVIEW_GATE if valid else PHASE4_GATE,
            "state_lock_graph": graph,
            "failure_retry_log": log,
            "backpressure_trigger_proof": pressure,
            "lock_control_proof": locks,
            "cleanup_allowlist": cleanup,
            "recovery_handling": recovery,
            "safe_shutdown_and_recovery": shutdown,
            "owner_feedback_zh": " ".join(
                [
                    owner["status_zh"],
                    owner["automatic_eligibility_zh"],
                    owner["manual_action_zh"],
                    owner["limit_zh"],
                ]
            ),
        }
    )
    return report


def main() -> int:
    report = build_stage041_phase4_delivery_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["delivery_contract_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
