"""Core configuration."""

