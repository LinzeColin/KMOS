import copy
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[4]
REPO_ROOT = ROOT.parent
BASE = ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
CONTRACT = (
    BASE
    / "automatic_lifecycle"
    / "stage042_automatic_lifecycle_runtime_contract.json"
)
EVIDENCE = BASE / "STAGE042_PHASE2_AUTOMATIC_LIFECYCLE_SLICE.md"
CHECKER = ROOT / "scripts" / "check_automatic_lifecycle_runtime.py"
PHASE1_CONTRACT = (
    BASE
    / "automatic_lifecycle"
    / "stage042_automatic_lifecycle_contract.json"
)
BATCH = BASE / "BATCH041_050_UPLOAD_LOCK.yaml"
ROADMAP = ROOT / "docs" / "governance" / "roadmap.yaml"
EVENTS = ROOT / "docs" / "governance" / "events.jsonl"
MODEL_REGISTRY = ROOT / "docs" / "governance" / "model_registry.yaml"
FORMULA_REGISTRY = ROOT / "docs" / "governance" / "formula_registry.yaml"
PARAMETER_REGISTRY = ROOT / "docs" / "governance" / "parameter_registry.csv"
MODEL_SPEC = ROOT / "docs" / "governance" / "MODEL_SPEC.md"

POLICY_VERSION = "ids.automatic_lifecycle_policy.v0_1.stage042.p2"
PARAMETERS = {
    "lifecycle_evaluation_interval": 10,
    "pause_acknowledgement_timeout": 30,
    "safe_close_timeout": 35,
    "owner_revalidation_ttl": 30,
    "resource_gate_stability_window": 60,
}
PARAMETER_IDS = [f"PARAM-{value:03d}" for value in range(72, 77)]
CONTROL_REFS = [
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE042_ENTRY_CONTRACT.md",
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE042_PHASE1_AUTOMATIC_LIFECYCLE_SCOPE_BOUNDARY.md",
]
UPSTREAM_BINDINGS = {
    "phase1_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
        "stage042_automatic_lifecycle_contract.json",
        "9a964ca89c3fab9c58755856374813be811677579eefae96ed9ff34200d972f0",
    ),
    "stage037_state_index": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/job_state_model/"
        "stage037_job_state_model_index.json",
        "b70bf72ebe4212f45d380c13fbfe429791e1f4a5c73dccbba81211b7adc1c2d3",
    ),
    "stage039_retry_runtime": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/retry_dead_letter/"
        "stage039_retry_dead_letter_runtime_contract.json",
        "5fc9b49b0ede0fdbc87311f3280ffc69e8ec8e59f219b17a04a2ccae1e9124c0",
    ),
    "stage040_backpressure_runtime": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
        "stage040_backpressure_runtime_contract.json",
        "3db2409b082b9f788e061dfbb3a8e33ad8459c8e56a863e21fe0faeca8581b5c",
    ),
    "stage041_lock_runtime": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_runtime_contract.json",
        "935c0d7358b4125ba96cbd1d53b869acdc831ab2b6e3b4fd21f155f07a585a7c",
    ),
}


class Stage042AutomaticLifecycleRuntimeTests(unittest.TestCase):
    def _module(self):
        self.assertTrue(CHECKER.is_file(), f"missing checker: {CHECKER}")
        spec = importlib.util.spec_from_file_location(
            "stage042_automatic_lifecycle_runtime", CHECKER
        )
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def _contract(self):
        self.assertTrue(CONTRACT.is_file(), f"missing contract: {CONTRACT}")
        return json.loads(CONTRACT.read_text(encoding="utf-8"))

    def _snapshot(self, state="CREATED", logical_time=100, **overrides):
        return self._module().build_control_snapshot(
            state=state,
            logical_time=logical_time,
            **overrides,
        )

    def _request(self, snapshot, intent, logical_now, **overrides):
        return self._module().build_lifecycle_request(
            snapshot,
            intent=intent,
            logical_now=logical_now,
            **overrides,
        )

    def test_phase2_artifacts_and_identity_exist(self):
        for path in (CONTRACT, EVIDENCE, CHECKER):
            with self.subTest(path=path):
                self.assertTrue(path.is_file(), f"missing Phase 2 artifact: {path}")
        contract = self._contract()
        self.assertEqual(
            "ids.stage042.automatic_lifecycle.phase2.v1",
            contract["schema_version"],
        )
        self.assertEqual("STAGE-042", contract["stage"])
        self.assertEqual("Phase 2", contract["phase"])
        self.assertEqual("IDS-V0_1-STAGE042-P2", contract["task_id"])
        self.assertEqual("ACC-STAGE-042", contract["acceptance_id"])
        self.assertEqual(POLICY_VERSION, contract["lifecycle_policy_version"])
        self.assertEqual("IDS-STAGE042-P3-GATE", contract["next_gate"])

    def test_source_and_reviewed_upstream_bindings_are_exact(self):
        contract = self._contract()
        self.assertEqual(
            json.loads(PHASE1_CONTRACT.read_text(encoding="utf-8"))["source_binding"],
            contract["source_binding"],
        )
        self.assertEqual(set(UPSTREAM_BINDINGS), set(contract["upstream_bindings"]))
        for key, (relative, expected_sha) in UPSTREAM_BINDINGS.items():
            with self.subTest(binding=key):
                binding = contract["upstream_bindings"][key]
                self.assertEqual({"ref": relative, "sha256": expected_sha}, binding)
                observed = hashlib.sha256((REPO_ROOT / relative).read_bytes()).hexdigest()
                self.assertEqual(expected_sha, observed)

    def test_parameters_have_exact_source_rationale_unit_version_evidence_and_rollback(self):
        policy = self._contract()["parameter_policy"]
        self.assertEqual(POLICY_VERSION, policy["policy_version"])
        self.assertEqual(PARAMETERS, policy["parameters"])
        self.assertEqual(set(PARAMETERS), set(policy["provenance"]))
        self.assertEqual("PROPOSED", policy["fact_level"])
        self.assertFalse(policy["production_calibrated"])
        self.assertTrue(policy["production_calibration_required"])
        self.assertEqual("TASK-OPME-B-001", policy["production_calibration_task_id"])
        for name, expected_value in PARAMETERS.items():
            item = policy["provenance"][name]
            with self.subTest(parameter=name):
                self.assertEqual(expected_value, item["value"])
                self.assertEqual("seconds", item["unit"])
                self.assertEqual(POLICY_VERSION, item["policy_version"])
                self.assertTrue(item["source_ref"].startswith("repo:KM_IDSystem/"))
                self.assertRegex(item["source_sha256"], r"^[0-9a-f]{64}$")
                self.assertTrue(item["rationale"])
                self.assertTrue(item["validation_evidence_ref"].startswith("repo:"))
                self.assertEqual(
                    "DISABLE_ISOLATED_LIFECYCLE_AND_REQUIRE_MANUAL_REVIEW",
                    item["rollback"],
                )
        self.assertEqual(
            PARAMETERS["safe_close_timeout"],
            30 + 5,
        )

    def test_registry_entries_cover_model_formula_and_five_parameters(self):
        binding = self._contract()["registry_binding"]
        self.assertEqual("MOD-011", binding["model_id"])
        self.assertEqual("FORM-011", binding["formula_id"])
        self.assertEqual(PARAMETER_IDS, binding["parameter_ids"])
        self.assertIn('model_id: "MOD-011"', MODEL_REGISTRY.read_text(encoding="utf-8"))
        self.assertIn('formula_id: "FORM-011"', FORMULA_REGISTRY.read_text(encoding="utf-8"))
        with PARAMETER_REGISTRY.open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        selected = {
            row["parameter_id"]: row
            for row in rows
            if row["parameter_id"] in PARAMETER_IDS
        }
        self.assertEqual(set(PARAMETER_IDS), set(selected))
        for parameter_id, (symbol, value) in zip(PARAMETER_IDS, PARAMETERS.items()):
            with self.subTest(parameter_id=parameter_id):
                self.assertEqual(symbol, selected[parameter_id]["symbol"])
                self.assertEqual(str(value), selected[parameter_id]["active_value"])
                self.assertEqual("planned", selected[parameter_id]["status"])
                self.assertEqual("PROPOSED", selected[parameter_id]["fact_level"])
        spec = MODEL_SPEC.read_text(encoding="utf-8")
        self.assertIn("- model_count: 11", spec)
        self.assertIn("- formula_count: 11", spec)
        self.assertIn("- parameter_count: 76", spec)
        self.assertIn("- active_model_count: 7", spec)
        self.assertIn("- active_parameter_count: 49", spec)

    def test_control_subject_uses_real_tracked_refs_without_business_data(self):
        contract = self._contract()
        self.assertEqual(CONTROL_REFS, contract["control_metadata_contract"]["input_refs"])
        for ref in CONTROL_REFS:
            relative = ref.removeprefix("repo:")
            self.assertTrue((REPO_ROOT / relative).is_file())
        self.assertFalse(contract["control_metadata_contract"]["raw_body_allowed"])
        self.assertFalse(contract["runtime_boundary"]["ids_business_job_allowed"])
        self.assertFalse(contract["runtime_boundary"]["fake_ids_business_data_allowed"])

    def test_automatic_start_uses_only_reviewed_edges_and_cas(self):
        module = self._module()
        engine = module.IsolatedAutomaticLifecycle(self._contract())
        snapshot = self._snapshot("CREATED", 100)
        result = engine.evaluate(snapshot, self._request(snapshot, "AUTO_START", 110))
        self.assertTrue(result["decision_valid"], result)
        self.assertEqual("CREATED->QUEUED", result["transition"])
        self.assertEqual("TRANSITION_CANDIDATE", result["decision_action"])
        self.assertEqual("QUEUED", result["candidate_snapshot"]["job_state"])
        self.assertEqual(1, result["candidate_snapshot"]["state_version"])
        self.assertEqual("正在检查运行条件", result["human_status"]["label_zh"])
        self.assertFalse(result["persistent_state_write_performed"])

        too_soon = self._request(snapshot, "AUTO_START", 109)
        waiting = module.IsolatedAutomaticLifecycle(self._contract()).evaluate(
            snapshot,
            too_soon,
        )
        self.assertEqual("EVALUATION_NOT_DUE", waiting["result_code"])
        self.assertIsNone(waiting["transition"])

    def test_resource_pause_and_checkpoint_completion_are_guarded(self):
        module = self._module()
        engine = module.IsolatedAutomaticLifecycle(self._contract())
        running = self._snapshot(
            "RUNNING",
            100,
            lease_active=True,
            lock_active=True,
            fencing_token=7,
            active_writer=True,
        )
        pause = engine.evaluate(
            running,
            self._request(
                running,
                "RESOURCE_PAUSE",
                110,
                pause_reason_code="EXTERNAL_DRIVE_OFFLINE",
            ),
        )
        self.assertEqual("RUNNING->PAUSE_REQUESTED", pause["transition"])
        self.assertEqual("正在安全暂停", pause["human_status"]["label_zh"])
        requested = pause["candidate_snapshot"]
        quiesced = copy.deepcopy(requested)
        quiesced["active_writer"] = False
        checkpoint = "checkpoint:sha256:" + "a" * 64
        completed = engine.evaluate(
            quiesced,
            self._request(
                quiesced,
                "COMPLETE_PAUSE",
                120,
                checkpoint_ref=checkpoint,
            ),
        )
        self.assertEqual("PAUSE_REQUESTED->PAUSED", completed["transition"])
        self.assertEqual("PAUSED", completed["candidate_snapshot"]["job_state"])
        self.assertFalse(completed["candidate_snapshot"]["lease_active"])
        self.assertFalse(completed["candidate_snapshot"]["lock_active"])
        self.assertEqual(8, completed["candidate_snapshot"]["fencing_token"])
        self.assertEqual(checkpoint, completed["candidate_snapshot"]["checkpoint_ref"])

    def test_pause_timeout_never_force_kills_or_fabricates_crash_recovery(self):
        module = self._module()
        engine = module.IsolatedAutomaticLifecycle(self._contract())
        requested = self._snapshot(
            "PAUSE_REQUESTED",
            100,
            pause_requested_at=100,
            lease_active=True,
            lock_active=True,
            fencing_token=3,
            active_writer=True,
        )
        result = engine.evaluate(
            requested,
            self._request(requested, "COMPLETE_PAUSE", 131),
        )
        self.assertEqual("PAUSE_ACKNOWLEDGEMENT_TIMEOUT", result["result_code"])
        self.assertEqual("REQUIRE_MANUAL_REVIEW", result["decision_action"])
        self.assertIsNone(result["transition"])
        self.assertFalse(result["force_kill_performed"])
        self.assertFalse(result["crash_recovery_performed"])

    def test_resume_requires_fresh_owner_and_stable_resource_gates(self):
        module = self._module()
        paused = self._snapshot(
            "PAUSED",
            100,
            owner_evaluated_at=190,
            resource_gates_clear_since=150,
            pause_reason_code="EXTERNAL_DRIVE_OFFLINE",
        )
        engine = module.IsolatedAutomaticLifecycle(self._contract())
        resumed = engine.evaluate(
            paused,
            self._request(paused, "AUTO_RESUME", 210),
        )
        self.assertEqual("PAUSED->QUEUED", resumed["transition"])
        self.assertEqual("正在重新检查恢复条件", resumed["human_status"]["label_zh"])

        stale_owner = copy.deepcopy(paused)
        stale_owner["owner_evaluated_at"] = 179
        blocked = module.IsolatedAutomaticLifecycle(self._contract()).evaluate(
            stale_owner,
            self._request(stale_owner, "AUTO_RESUME", 210),
        )
        self.assertEqual("OWNER_EVIDENCE_STALE", blocked["result_code"])
        self.assertEqual("REQUIRE_MANUAL_REVIEW", blocked["decision_action"])

        unstable = copy.deepcopy(paused)
        unstable["resource_gates_clear_since"] = 151
        waiting = module.IsolatedAutomaticLifecycle(self._contract()).evaluate(
            unstable,
            self._request(unstable, "AUTO_RESUME", 210),
        )
        self.assertEqual("RESOURCE_GATES_NOT_STABLE", waiting["result_code"])
        self.assertEqual("WAIT_FOR_RESOURCE_STABILITY", waiting["decision_action"])

    def test_safe_close_is_cooperative_and_timeout_fails_closed(self):
        module = self._module()
        engine = module.IsolatedAutomaticLifecycle(self._contract())
        queued = self._snapshot("QUEUED", 100, safe_close_started_at=100)
        closed = engine.evaluate(
            queued,
            self._request(queued, "SAFE_CLOSE", 110),
        )
        self.assertEqual("QUEUED->PAUSED", closed["transition"])
        self.assertEqual("CLOSED", closed["candidate_snapshot"]["controller_state"])
        self.assertEqual("已安全关闭", closed["human_status"]["label_zh"])

        running = self._snapshot(
            "RUNNING",
            100,
            safe_close_started_at=100,
            lease_active=True,
            lock_active=True,
            fencing_token=5,
            active_writer=True,
        )
        timed_out = engine.evaluate(
            running,
            self._request(running, "SAFE_CLOSE", 136),
        )
        self.assertEqual("SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER", timed_out["result_code"])
        self.assertEqual("REQUIRE_MANUAL_REVIEW", timed_out["decision_action"])
        self.assertFalse(timed_out["force_kill_performed"])

    def test_idempotent_replay_and_payload_conflict_fail_closed(self):
        module = self._module()
        engine = module.IsolatedAutomaticLifecycle(self._contract())
        snapshot = self._snapshot("CREATED", 100)
        request = self._request(snapshot, "AUTO_START", 110)
        first = engine.evaluate(snapshot, request)
        replay = engine.evaluate(copy.deepcopy(snapshot), copy.deepcopy(request))
        self.assertEqual(first, replay)
        conflict = copy.deepcopy(request)
        conflict["intent"] = "SAFE_CLOSE"
        rejected = engine.evaluate(snapshot, conflict)
        self.assertEqual(
            "REJECT_IDEMPOTENCY_KEY_INPUT_CONFLICT",
            rejected["result_code"],
        )
        self.assertEqual("REQUIRE_MANUAL_REVIEW", rejected["decision_action"])
        self.assertIsNone(rejected["transition"])

        fresh_engine = module.IsolatedAutomaticLifecycle(self._contract())
        malformed = copy.deepcopy(request)
        malformed["request_id"] = "lifecycle-request:sha256:" + "0" * 64
        invalid = fresh_engine.evaluate(snapshot, malformed)
        self.assertEqual("INVALID_CONTROL_REQUEST", invalid["result_code"])
        self.assertFalse(invalid["decision_valid"])

    def test_invalid_terminal_and_cas_inputs_fail_closed_without_raw_echo(self):
        module = self._module()
        engine = module.IsolatedAutomaticLifecycle(self._contract())
        terminal = self._snapshot("SUCCEEDED", 100)
        terminal_result = engine.evaluate(
            terminal,
            self._request(terminal, "AUTO_RESUME", 110),
        )
        self.assertEqual("TERMINAL_STATE_IMMUTABLE", terminal_result["result_code"])
        self.assertIsNone(terminal_result["transition"])

        created = self._snapshot("CREATED", 100)
        stale = self._request(
            created,
            "AUTO_START",
            110,
            expected_state_version=99,
        )
        stale_result = engine.evaluate(created, stale)
        self.assertEqual("COMPARE_AND_SET_MISMATCH", stale_result["result_code"])

        invalid = self._request(created, "AUTO_START", 110)
        invalid["input_refs"] = ["/Users/linzezhang/Downloads/IDS_MetaData/raw"]
        invalid_result = engine.evaluate(created, invalid)
        self.assertEqual("INVALID_CONTROL_REQUEST", invalid_result["result_code"])
        self.assertNotIn("IDS_MetaData", json.dumps(invalid_result, ensure_ascii=False))

    def test_decision_records_are_reference_only_and_human_status_is_restrained(self):
        module = self._module()
        engine = module.IsolatedAutomaticLifecycle(self._contract())
        snapshot = self._snapshot("CREATED", 100)
        result = engine.evaluate(snapshot, self._request(snapshot, "AUTO_START", 110))
        self.assertEqual(CONTROL_REFS, result["input_refs"])
        self.assertEqual(1, len(result["output_refs"]))
        self.assertRegex(result["output_refs"][0], r"^decision:sha256:[0-9a-f]{64}$")
        self.assertRegex(result["checkpoint_ref"], r"^checkpoint:sha256:[0-9a-f]{64}$")
        self.assertRegex(result["audit_ref"], r"^audit:sha256:[0-9a-f]{64}$")
        self.assertIsNone(result["error_ref"])
        self.assertEqual(
            {"label_zh", "owner_action_zh", "owner_attention_required"},
            set(result["human_status"]),
        )

    def test_contract_and_source_side_effect_guards_reject_tampering(self):
        module = self._module()
        original = self._contract()
        mutations = []
        for mutate in (
            lambda item: item.update({"unknown_root_field": True}),
            lambda item: item["parameter_policy"]["parameters"].update(
                {"safe_close_timeout": 34}
            ),
            lambda item: item["runtime_boundary"].update(
                {"persistent_state_write_allowed": True}
            ),
            lambda item: item["truth_flags"].update(
                {"raw_metadata_content_accessed": True}
            ),
        ):
            candidate = copy.deepcopy(original)
            mutate(candidate)
            mutations.append(candidate)
        for candidate in mutations:
            with self.subTest(candidate=candidate):
                self.assertFalse(all(module.evaluate_contract(candidate).values()))

        source = CHECKER.read_text(encoding="utf-8")
        for forbidden in (
            "subprocess",
            "sqlite3",
            "requests",
            ".write_text(",
            ".write_bytes(",
            ".unlink(",
            "shutil.rmtree",
        ):
            with self.subTest(forbidden=forbidden):
                self.assertNotIn(forbidden, source)

    def test_report_executes_isolated_slice_without_forbidden_runtime(self):
        report = self._module().build_stage042_phase2_report()
        self.assertTrue(report["phase2_slice_valid"], report)
        self.assertTrue(all(report["contract_checks"].values()), report)
        self.assertTrue(all(report["slice_checks"].values()), report)
        self.assertEqual("IDS-STAGE042-P3-GATE", report["next_gate"])
        self.assertTrue(report["parameter_values_assigned"])
        self.assertTrue(report["isolated_lifecycle_decision_runtime_performed"])
        for key in (
            "persistent_lifecycle_runtime_performed",
            "queue_runtime_performed",
            "worker_runtime_performed",
            "retry_scheduler_performed",
            "lock_runtime_performed",
            "automatic_resume_production_performed",
            "safe_close_production_performed",
            "crash_recovery_runtime_performed",
            "cleanup_runtime_performed",
            "database_connection_performed",
            "state_registry_write_performed",
            "runtime_output_written",
            "external_api_call_performed",
            "ids_business_source_read_performed",
            "raw_metadata_content_accessed",
            "fake_ids_business_data_used",
            "real_ids_business_job_created",
            "production_runtime_activation_performed",
            "github_upload_allowed",
            "app_reinstall_allowed",
        ):
            with self.subTest(flag=key):
                self.assertFalse(report[key])

    def test_governance_stops_at_phase2_and_keeps_upload_locked(self):
        batch = BATCH.read_text(encoding="utf-8")
        roadmap = ROADMAP.read_text(encoding="utf-8")
        events = [
            json.loads(line)
            for line in EVENTS.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        self.assertIn('status: "stage042_phase2_completed"', batch)
        self.assertIn('next_allowed_task_id: "IDS-V0_1-STAGE042-P3"', batch)
        self.assertIn("push_allowed: false", batch)
        self.assertIn('current_phase_id: "IDS-STAGE042-P2"', roadmap)
        self.assertIn('next_gate_id: "IDS-STAGE042-P3-GATE"', roadmap)
        self.assertIn('phase_id: "IDS-STAGE042-P3"', roadmap)
        matching = [
            item
            for item in events
            if item.get("event_id") == "EVT-IDS-V0_1-STAGE042-P2-20260715-001"
        ]
        self.assertEqual(1, len(matching))
        self.assertEqual("IDS-V0_1-STAGE042-P2", matching[0]["task_id"])
        self.assertEqual(["ACC-STAGE-042"], matching[0]["acceptance_ids"])
        self.assertIn("github_upload_allowed=false", matching[0]["notes"])
        self.assertIn("phase3_executed=false", matching[0]["notes"])


if __name__ == "__main__":
    unittest.main()
