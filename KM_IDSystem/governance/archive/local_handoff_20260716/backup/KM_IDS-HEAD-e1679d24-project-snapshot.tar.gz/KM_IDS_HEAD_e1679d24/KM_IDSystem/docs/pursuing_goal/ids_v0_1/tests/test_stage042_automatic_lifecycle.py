import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[4]
REPO_ROOT = ROOT.parent
BASE = ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
CONTRACT = (
    BASE
    / "automatic_lifecycle"
    / "stage042_automatic_lifecycle_contract.json"
)
ENTRY = BASE / "STAGE042_ENTRY_CONTRACT.md"
BOUNDARY = BASE / "STAGE042_PHASE1_AUTOMATIC_LIFECYCLE_SCOPE_BOUNDARY.md"
BATCH = BASE / "BATCH041_050_UPLOAD_LOCK.yaml"
ROADMAP = ROOT / "docs" / "governance" / "roadmap.yaml"
EVENTS = ROOT / "docs" / "governance" / "events.jsonl"
CHECKER = ROOT / "scripts" / "check_automatic_lifecycle.py"

SOURCE_BINDING = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-042_自动运行、暂停、恢复与关闭.md"
    ),
    "source_member_match_count": 1,
    "source_member_integrity": "OK",
    "source_member_sha256": (
        "78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}

UPSTREAM_BINDINGS = {
    "stage037_state_index_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "job_state_model/stage037_job_state_model_index.json",
        "b70bf72ebe4212f45d380c13fbfe429791e1f4a5c73dccbba81211b7adc1c2d3",
    ),
    "stage038_delivery_contract_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "worker_queue_baseline/stage038_worker_queue_delivery_contract.json",
        "a4067c25b46340c33bee5017c286d6867d2b72e8fa208430c005d6b1a342c7e4",
    ),
    "stage039_delivery_contract_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "retry_dead_letter/stage039_retry_dead_letter_delivery_contract.json",
        "c4aad64a9283de683067aff07026d723c708285c57eef8a0eac4ee1b13f5cb96",
    ),
    "stage040_delivery_contract_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "backpressure_policy/stage040_backpressure_delivery_contract.json",
        "84f3d69f4bda15e0042631d9b049c8988c1375be632d96e366e57cf0b1ab0ac2",
    ),
    "stage041_delivery_contract_ref": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "lock_registry/stage041_lock_registry_delivery_contract.json",
        "a4ae34a249bc7fc6a54434f611f83214f8dc5d8c526aea60e468963f91a9fd75",
    ),
}

JOB_TYPES = ["IMPORT", "ARCHIVE", "PARSE", "OCR", "CHUNK", "EMBED", "INDEX", "REPORT"]
TERMINAL_STATES = ["SUCCEEDED", "FAILED", "DEAD_LETTERED", "CANCELLED"]
RESOURCE_PAUSE_SIGNALS = [
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
]
PAUSE_EDGE_GUARDS = {
    "QUEUED->PAUSED": ["resource_gate_blocked", "no_active_claim_or_lock"],
    "CLAIMED->PAUSE_REQUESTED": [
        "live_lease_valid",
        "fencing_token_matches",
        "pause_intent_recorded",
    ],
    "RUNNING->PAUSE_REQUESTED": [
        "live_lease_valid",
        "fencing_token_matches",
        "pause_intent_recorded",
    ],
    "PAUSE_REQUESTED->PAUSED": [
        "lease_valid_or_expiry_evidence",
        "fencing_token_matches",
        "checkpoint_or_quarantine_complete",
    ],
}
OWNER_EVIDENCE_FIELDS = [
    "owner_ref",
    "authorization_state",
    "owner_policy_version",
    "evaluated_at_ref",
    "evidence_ref",
]
IDEMPOTENCY_COMPONENTS = [
    "job_id",
    "expected_state",
    "expected_state_version",
    "action",
    "policy_version",
    "canonical_intent_ref",
]
PROTECTED_ARTIFACTS = [
    "ORIGINAL_RAW_DATA",
    "FACT_SOURCE",
    "MANIFEST",
    "EVIDENCE_LEDGER",
    "REPORT_SNAPSHOT",
    "AUDIT_LOG",
    "ACTIVE_INDEX",
    "REQUIRED_CHECKPOINT",
]


class Stage042AutomaticLifecycleTests(unittest.TestCase):
    def _contract(self):
        self.assertTrue(CONTRACT.is_file(), f"missing contract: {CONTRACT}")
        return json.loads(CONTRACT.read_text(encoding="utf-8"))

    def _checker(self):
        self.assertTrue(CHECKER.is_file(), f"missing checker: {CHECKER}")
        spec = importlib.util.spec_from_file_location(
            "stage042_automatic_lifecycle_checker", CHECKER
        )
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_phase1_artifacts_exist(self):
        for path in (CONTRACT, ENTRY, BOUNDARY, BATCH, CHECKER):
            with self.subTest(path=path):
                self.assertTrue(path.is_file(), f"missing Phase 1 artifact: {path}")

    def test_source_and_reviewed_upstream_bindings_are_exact(self):
        contract = self._contract()
        self.assertEqual(SOURCE_BINDING, contract["source_binding"])
        self.assertEqual(set(UPSTREAM_BINDINGS), set(contract["upstream_bindings"]))
        for key, (relative, expected_sha) in UPSTREAM_BINDINGS.items():
            with self.subTest(binding=key):
                binding = contract["upstream_bindings"][key]
                self.assertEqual(relative, binding["ref"])
                self.assertEqual(expected_sha, binding["sha256"])
                observed = hashlib.sha256((REPO_ROOT / relative).read_bytes()).hexdigest()
                self.assertEqual(expected_sha, observed)

    def test_state_model_is_composed_without_new_job_states(self):
        state = self._contract()["state_model_inheritance"]
        self.assertEqual("ids.job_state.v1", state["state_model_version"])
        self.assertEqual(JOB_TYPES, state["job_types"])
        self.assertEqual(TERMINAL_STATES, state["terminal_states"])
        self.assertFalse(state["new_job_state_defined"])
        self.assertFalse(state["terminal_state_mutation_allowed"])
        self.assertFalse(state["terminal_state_automatic_reopen_allowed"])
        self.assertEqual(21, state["inherited_transition_count"])

    def test_automatic_start_uses_only_existing_guarded_edges(self):
        start = self._contract()["automatic_start_contract"]
        self.assertEqual(
            ["CREATED->QUEUED", "QUEUED->CLAIMED", "CLAIMED->RUNNING"],
            list(start["ordered_edges"]),
        )
        self.assertEqual(
            ["identity_idempotency_valid", "admission_gates_passed", "no_active_claim_or_lock"],
            start["ordered_edges"]["CREATED->QUEUED"],
        )
        self.assertEqual(
            ["admission_gates_passed", "claim_lease_and_lock_acquired"],
            start["ordered_edges"]["QUEUED->CLAIMED"],
        )
        self.assertEqual(
            ["live_lease_valid", "fencing_token_matches"],
            start["ordered_edges"]["CLAIMED->RUNNING"],
        )
        self.assertTrue(start["compare_and_set_required_each_edge"])
        self.assertFalse(start["worker_invocation_before_claim_allowed"])
        self.assertFalse(start["automatic_start_runtime_performed"])

    def test_pause_contract_covers_required_resource_failures(self):
        pause = self._contract()["automatic_pause_contract"]
        self.assertEqual(RESOURCE_PAUSE_SIGNALS, pause["resource_pause_signals"])
        self.assertEqual("QUEUED->PAUSED", pause["pre_admission_edge"])
        self.assertEqual(
            ["CLAIMED->PAUSE_REQUESTED", "RUNNING->PAUSE_REQUESTED"],
            pause["active_pause_request_edges"],
        )
        self.assertEqual("PAUSE_REQUESTED->PAUSED", pause["pause_completion_edge"])
        self.assertEqual(PAUSE_EDGE_GUARDS, pause["edge_guard_requirements"])
        self.assertTrue(pause["checkpoint_or_quarantine_required_before_paused"])
        self.assertTrue(pause["deactivation_revokes_lease_and_lock"])
        self.assertTrue(pause["deactivation_advances_fencing_token"])
        self.assertFalse(pause["force_process_termination_allowed"])

    def test_resume_revalidates_owner_resources_and_lock_state(self):
        resume = self._contract()["automatic_resume_contract"]
        self.assertEqual("PAUSED->QUEUED", resume["edge"])
        self.assertEqual(
            ["owner_revalidated", "resource_gates_passed", "no_active_claim_or_lock"],
            resume["required_guard_facts"],
        )
        self.assertEqual(RESOURCE_PAUSE_SIGNALS, resume["eligible_pause_reasons"])
        self.assertEqual(OWNER_EVIDENCE_FIELDS, resume["required_owner_evidence_fields"])
        self.assertTrue(resume["fresh_evaluation_required"])
        self.assertTrue(resume["owner_evidence_reference_only"])
        self.assertTrue(resume["owner_evidence_policy_version_required"])
        self.assertTrue(resume["compare_and_set_required"])
        self.assertEqual("REQUIRE_MANUAL_REVIEW", resume["unknown_evidence_action"])
        self.assertFalse(resume["cached_gate_result_allowed"])
        self.assertFalse(resume["terminal_state_resume_allowed"])

    def test_retry_resume_and_dead_letter_policy_stay_owned_by_stage039(self):
        retry = self._contract()["retry_resume_contract"]
        self.assertEqual("RETRY_WAIT->QUEUED", retry["edge"])
        self.assertEqual(
            ["next_eligible_reached", "resource_gates_passed", "no_active_claim_or_lock"],
            retry["required_guard_facts"],
        )
        self.assertEqual(
            [
                "EXACT_VERSIONED_POLICY",
                "EXACT_SAFE_ERROR_CODE_ALLOWLIST_MATCH",
                "RETRY_BUDGET_AVAILABLE",
                "RESOURCE_GATES_PASS",
                "COMPARE_AND_SET_PASS",
                "IDEMPOTENCY_KEY_PASS",
            ],
            retry["stage039_required_conditions"],
        )
        self.assertEqual("STAGE-039", retry["retry_and_dead_letter_policy_owner"])
        self.assertFalse(retry["retry_budget_or_error_allowlist_redefined"])

    def test_safe_close_is_cooperative_audited_and_non_destructive(self):
        close = self._contract()["safe_close_contract"]
        self.assertEqual("COOPERATIVE_FAIL_CLOSED", close["close_mode"])
        self.assertEqual(
            [
                "STOP_NEW_ADMISSION_DECISIONS",
                "STOP_NEW_CLAIM_AND_LOCK_DECISIONS",
                "STOP_NEW_RETRY_ADMISSIONS",
                "ISSUE_PAUSE_INTENT_FOR_ACTIVE_JOBS",
                "WAIT_FOR_CHECKPOINT_OR_QUARANTINE_EVIDENCE",
                "TRANSITION_TO_PAUSED_WHEN_LEGAL",
                "RELEASE_CURRENT_LEASES_AND_LOCKS_WITH_FENCING",
                "PRESERVE_AUDIT_AND_STATE_EVIDENCE",
                "VERIFY_NO_ACTIVE_WRITER",
                "MARK_LIFECYCLE_CONTROLLER_CLOSED",
            ],
            close["ordered_steps"],
        )
        self.assertFalse(close["force_kill_allowed"])
        self.assertFalse(close["terminal_history_reopen_allowed"])
        self.assertFalse(close["persistent_crash_recovery_claimed"])
        self.assertTrue(close["protected_artifacts_preserved"])
        self.assertTrue(close["queued_and_retry_wait_jobs_use_legal_pause_edges"])
        self.assertTrue(close["active_jobs_use_pause_request_then_paused"])
        self.assertTrue(close["already_paused_jobs_remain_paused"])
        self.assertTrue(close["terminal_jobs_remain_immutable"])

    def test_idempotency_lock_and_cleanup_boundaries_fail_closed(self):
        contract = self._contract()
        idempotency = contract["idempotency_contract"]
        locks = contract["worker_and_lock_boundary"]
        cleanup = contract["partial_output_cleanup_boundary"]
        self.assertEqual(
            "SHA256_JOB_EXPECTED_STATE_VERSION_ACTION_POLICY_VERSION_CANONICAL_INTENT_REF",
            idempotency["derivation"],
        )
        self.assertEqual(IDEMPOTENCY_COMPONENTS, idempotency["required_components"])
        self.assertTrue(idempotency["exact_replay_returns_existing_decision"])
        self.assertEqual(
            "REJECT_IDEMPOTENCY_KEY_INPUT_CONFLICT",
            idempotency["same_key_different_intent_action"],
        )
        self.assertTrue(idempotency["reference_only"])
        self.assertEqual("STAGE-038", locks["queue_and_worker_transport_owner"])
        self.assertEqual("STAGE-041", locks["lock_lease_and_fencing_owner"])
        self.assertEqual("SOURCE_PIPELINE", locks["mandatory_shared_guard_namespace"])
        self.assertFalse(locks["lock_granularity_redefined"])
        self.assertEqual(
            ["TEMPORARY_PARTIAL_OUTPUT", "REBUILDABLE_CACHE"],
            cleanup["eligible_candidate_classes"],
        )
        self.assertEqual(PROTECTED_ARTIFACTS, cleanup["protected_artifact_classes"])
        self.assertEqual("STAGE-044", cleanup["cleanup_execution_runtime_owner"])
        self.assertFalse(cleanup["delete_execution_allowed"])
        self.assertFalse(cleanup["cleanup_runtime_performed"])

    def test_parameters_and_later_stage_ownership_remain_deferred(self):
        contract = self._contract()
        parameters = contract["parameter_contract"]
        ownership = contract["ownership_matrix"]
        self.assertFalse(parameters["numeric_values_assigned"])
        self.assertFalse(parameters["implicit_default_allowed"])
        self.assertEqual(
            [
                "lifecycle_evaluation_interval",
                "pause_acknowledgement_timeout",
                "safe_close_timeout",
                "owner_revalidation_ttl",
                "resource_gate_stability_window",
            ],
            parameters["deferred_parameters"],
        )
        self.assertEqual("STAGE-042", ownership["automatic_lifecycle_runtime"])
        self.assertEqual("STAGE-043", ownership["worker_crash_recovery"])
        self.assertEqual("STAGE-044", ownership["cleanup_execution_runtime"])

    def test_checker_reports_contract_only_and_rejects_tampering(self):
        checker = self._checker()
        report = checker.build_stage042_phase1_report()
        self.assertTrue(report["phase1_contract_valid"], report)
        self.assertTrue(all(report["contract_checks"].values()), report)
        self.assertEqual("IDS-STAGE042-P2-GATE", report["next_gate"])
        self.assertEqual(
            "PHASE1_ENGINEERING_CONTRACT_RUNTIME_DISABLED",
            report["contract_state"],
        )
        for key in (
            "automatic_start_runtime_performed",
            "automatic_pause_runtime_performed",
            "automatic_resume_runtime_performed",
            "safe_close_runtime_performed",
            "queue_runtime_performed",
            "worker_runtime_performed",
            "retry_scheduler_performed",
            "lock_runtime_performed",
            "crash_recovery_runtime_performed",
            "cleanup_runtime_performed",
            "database_connection_performed",
            "runtime_output_written",
            "raw_metadata_content_accessed",
            "fake_ids_business_data_used",
            "github_upload_allowed",
            "app_reinstall_allowed",
        ):
            with self.subTest(flag=key):
                self.assertFalse(report[key])

        original = self._contract()
        mutations = []
        for mutate in (
            lambda item: item.update({"unknown_root_field": True}),
            lambda item: item["state_model_inheritance"].update(
                {"terminal_state_automatic_reopen_allowed": True}
            ),
            lambda item: item["automatic_start_contract"].update(
                {"worker_invocation_before_claim_allowed": True}
            ),
            lambda item: item["automatic_resume_contract"].update(
                {"cached_gate_result_allowed": True}
            ),
            lambda item: item["automatic_pause_contract"]["edge_guard_requirements"].update(
                {"QUEUED->PAUSED": ["resource_gate_blocked"]}
            ),
            lambda item: item["automatic_resume_contract"].update(
                {"required_owner_evidence_fields": ["owner_ref"]}
            ),
            lambda item: item["safe_close_contract"].update({"force_kill_allowed": True}),
            lambda item: item["safe_close_contract"].update(
                {"terminal_jobs_remain_immutable": False}
            ),
            lambda item: item["idempotency_contract"].update(
                {"required_components": ["job_id"]}
            ),
            lambda item: item["human_status_projection"].update(
                {"SAFE_CLOSED": "已关闭"}
            ),
            lambda item: item["phase2_entry_gate"].update(
                {"required_work": ["skip parameter sourcing"]}
            ),
            lambda item: item["partial_output_cleanup_boundary"].update(
                {"delete_execution_allowed": True}
            ),
            lambda item: item["parameter_contract"].update(
                {"numeric_values_assigned": True}
            ),
            lambda item: item["truth_flags"].update(
                {"raw_metadata_content_accessed": True}
            ),
        ):
            candidate = copy.deepcopy(original)
            mutate(candidate)
            mutations.append(candidate)
        for candidate in mutations:
            with self.subTest(candidate=candidate):
                checks = checker.evaluate_contract(candidate)
                self.assertFalse(all(checks.values()), checks)

    def test_docs_governance_and_event_stop_at_phase1(self):
        entry = ENTRY.read_text(encoding="utf-8")
        boundary = BOUNDARY.read_text(encoding="utf-8")
        batch = BATCH.read_text(encoding="utf-8")
        roadmap = ROADMAP.read_text(encoding="utf-8")
        events = [
            json.loads(line)
            for line in EVENTS.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        for marker in (
            "Phase 2 must run separately",
            "NO_PHASE2",
            "NO_AUTOMATIC_START_RUNTIME",
            "NO_AUTOMATIC_PAUSE_RUNTIME",
            "NO_AUTOMATIC_RESUME_RUNTIME",
            "NO_SAFE_CLOSE_RUNTIME",
            "NO_CRASH_RECOVERY_RUNTIME",
            "NO_CLEANUP_RUNTIME",
            "NO_RAW_METADATA_ACCESS",
            "NO_FAKE_IDS_BUSINESS_DATA",
            "NO_GITHUB_UPLOAD",
            "NO_APP_REINSTALL",
        ):
            with self.subTest(marker=marker):
                self.assertIn(marker, entry + boundary)
        self.assertIn(
            'stage042_phase1_state:\n'
            '    status: "stage042_phase1_completed"\n'
            '    current_task_id: "IDS-V0_1-STAGE042-P1"\n'
            '    next_allowed_task_id: "IDS-V0_1-STAGE042-P2"',
            batch,
        )
        self.assertIn("push_allowed: false", batch)
        self.assertIn(
            'stage042_phase1_state:\n'
            '    current_stage_id: "IDS-STAGE042"\n'
            '    current_phase_id: "IDS-STAGE042-P1"\n'
            '    current_task_id: "IDS-V0_1-STAGE042-P1"\n'
            '    next_gate_id: "IDS-STAGE042-P2-GATE"',
            roadmap,
        )
        matching = [
            item
            for item in events
            if item.get("event_id") == "EVT-IDS-V0_1-STAGE042-P1-20260715-001"
        ]
        self.assertEqual(1, len(matching))
        self.assertEqual("IDS-V0_1-STAGE042-P1", matching[0]["task_id"])
        self.assertEqual(["ACC-STAGE-042"], matching[0]["acceptance_ids"])


if __name__ == "__main__":
    unittest.main()
