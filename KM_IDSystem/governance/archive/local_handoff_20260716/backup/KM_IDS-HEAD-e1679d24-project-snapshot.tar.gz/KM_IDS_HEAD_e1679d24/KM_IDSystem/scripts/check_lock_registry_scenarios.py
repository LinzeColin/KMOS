#!/usr/bin/env python3
"""Validate STAGE-041 Phase 3 lock scenarios without persistent side effects."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import subprocess
import zipfile
from pathlib import Path
from typing import Any, Mapping, Optional


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent
CONTRACT_PATH = (
    PROJECT_ROOT
    / "docs"
    / "pursuing_goal"
    / "ids_v0_1"
    / "lock_registry"
    / "stage041_lock_registry_scenarios.json"
)
P2_CHECKER_PATH = PROJECT_ROOT / "scripts" / "check_lock_registry_runtime.py"
STAGE040_CHECKER_PATH = PROJECT_ROOT / "scripts" / "check_backpressure_scenarios.py"

TASK_ID = "IDS-V0_1-STAGE041-P3"
ACCEPTANCE_ID = "ACC-STAGE-041"
POLICY_VERSION = "ids.lock_registry_policy.v0_1.stage041.p2"
P2_COMMIT = "7295065f344fcf286be419153788a774b271d42f"
CONTROL_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md"
)
OPERATION_REFS = {
    "FILE_PROCESSING": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE041_ENTRY_CONTRACT.md"
    ),
    "ARCHIVE_EXTRACTION": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_contract.json"
    ),
    "INDEX_BUILD": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_runtime_contract.json"
    ),
    "INDEX_SWITCH": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md"
    ),
    "REPORT_GENERATION": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_scenarios.json"
    ),
}

SOURCE_BINDING = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290b"
        "a60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-041_锁注册与竞态控制.md"
    ),
    "source_member_match_count": 1,
    "source_member_sha256": (
        "2258a7b57c6c2881f208f43fbe2862c"
        "7815a2794c908d6fef108a1a4b5a2ad36"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e"
        "5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5"
        "894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}
SOURCE_ROADMAP_PATH = Path(
    "/Users/linzezhang/Downloads/"
    "IDS_Codex开发Roadmap_v0_1_only_中文修订版.txt"
)
SOURCE_INSTRUCTIONS_PATH = Path(
    "/Users/linzezhang/Downloads/"
    "IDS_Codex使用说明_v0_1_only_中文修订版.txt"
)

PHASE2_COMMIT_BINDING = {
    "commit": P2_COMMIT,
    "subject": "feat(ids): implement stage041 lock registry phase2",
    "binding_mode": "COMMITTED_LOCAL_PHASE2",
}
UPSTREAM_BINDINGS = {
    "phase2_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
            "stage041_lock_registry_runtime_contract.json"
        ),
        "sha256": (
            "935c0d7358b4125ba96cbd1d53b869ac"
            "dc831ab2b6e3b4fd21f155f07a585a7c"
        ),
    },
    "phase2_checker": {
        "ref": "KM_IDSystem/scripts/check_lock_registry_runtime.py",
        "sha256": (
            "ad8cca376f6932300ecc90f7c78f6753"
            "6b229d5c4bb40d9ebfa163de37f2108c"
        ),
    },
    "phase2_evidence": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
            "STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md"
        ),
        "sha256": (
            "96dce06ec536109e74a3a756c4dafcc1"
            "ca417fc9ae8076794d80f9ba52e57fba"
        ),
    },
    "phase2_tests": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
            "test_stage041_lock_registry_runtime.py"
        ),
        "sha256": (
            "ab3f4ea46510f4da6289f81ba1cb5c1d"
            "d395b6ed13e579d7aed5c2801e2a4a10"
        ),
    },
    "stage040_scenario_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
            "stage040_backpressure_scenarios.json"
        ),
        "sha256": (
            "59c24c67bf0d8a9a86e44be2634ace9d"
            "b324a24f9696e8f35974069c1908c530"
        ),
    },
    "stage040_scenario_checker": {
        "ref": "KM_IDSystem/scripts/check_backpressure_scenarios.py",
        "sha256": (
            "378534f960c129a2f96568b45615e434"
            "7b0b45f64639a4fe429a3c2b6c54d0a6"
        ),
    },
}

SCENARIO_CATALOG = [
    "duplicate_click_lock_replay",
    "worker_exception_orphaned_lease_boundary",
    "external_drive_offline_pause_before_lock",
    "actual_disk_observation_and_low_disk_pause_before_lock",
    "external_api_budget_pause_before_lock",
    "same_source_cross_operation_contention",
    "operation_family_duplicate_prevention",
    "renewal_takeover_and_stale_fencing",
    "protected_cleanup_denied",
]
SCENARIO_EXPECTATIONS = {
    "duplicate_click_lock_replay": (
        "ONE_CANONICAL_LOCK_SET_ONE_FENCE_IDEMPOTENT_REPLAY"
    ),
    "worker_exception_orphaned_lease_boundary": (
        "ACTUAL_ISOLATED_EXCEPTION_ORPHAN_LEASE_PRE_EXPIRY_"
        "BLOCKED_TAKEOVER_FENCES_STALE"
    ),
    "external_drive_offline_pause_before_lock": (
        "UPSTREAM_PAUSE_NO_LOCK_ACQUIRE_NO_PHYSICAL_REMOVAL"
    ),
    "actual_disk_observation_and_low_disk_pause_before_lock": (
        "ACTUAL_OBSERVATION_PLUS_CONTROLLED_LOW_BOUNDARY_NO_LOCK_NO_ALLOCATION"
    ),
    "external_api_budget_pause_before_lock": (
        "UPSTREAM_PAUSE_NO_LOCK_ACQUIRE_NO_API_CALL"
    ),
    "same_source_cross_operation_contention": (
        "ONE_COMPLETE_LOCK_SET_FOUR_CONFLICTS_NO_PARTIAL_LOCKS"
    ),
    "operation_family_duplicate_prevention": (
        "FIVE_OPERATION_FAMILIES_EACH_ACQUIRE_ONCE_DUPLICATE_BLOCKED"
    ),
    "renewal_takeover_and_stale_fencing": (
        "RENEW_NO_FENCE_ADVANCE_EXPIRY_GRACE_TAKEOVER_ATOMIC_STALE_DENIED"
    ),
    "protected_cleanup_denied": (
        "FIVE_GIT_TRACKED_PROTECTED_REFS_DENIED_NO_DELETE_PATH"
    ),
}
OPERATION_FAMILIES = [
    "FILE_PROCESSING",
    "ARCHIVE_EXTRACTION",
    "INDEX_BUILD",
    "INDEX_SWITCH",
    "REPORT_GENERATION",
]
PHYSICAL_ACTION_BOUNDARY = {
    "stage040_scenario_replay_allowed": True,
    "stage041_isolated_lock_scenarios_allowed": True,
    "actual_project_disk_observation_allowed": True,
    "process_termination_allowed": False,
    "physical_drive_removal_allowed": False,
    "disk_allocation_allowed": False,
    "external_api_call_allowed": False,
    "cleanup_delete_allowed": False,
    "database_allowed": False,
    "persistent_lock_write_allowed": False,
    "runtime_output_write_allowed": False,
    "raw_metadata_access_allowed": False,
    "fake_ids_business_data_allowed": False,
    "production_activation_allowed": False,
    "queue_runtime_allowed": False,
    "worker_runtime_allowed": False,
    "automatic_resume_allowed": False,
    "crash_recovery_allowed": False,
    "cleanup_runtime_allowed": False,
}
RESOURCE_GATE_CONTRACT = {
    "upstream_scenario_contract_id": (
        "ids.backpressure_policy.v0_1.stage040.p3.scenarios"
    ),
    "drive_signal": "EXTERNAL_DRIVE_OFFLINE",
    "disk_signal": "DISK_SPACE_INSUFFICIENT",
    "api_signal": "EXTERNAL_API_BUDGET_INSUFFICIENT",
    "required_decision_action": "PAUSE_RESOURCE_GATE",
    "lock_acquire_on_pause_allowed": False,
    "resource_pause_consumes_retry_budget": False,
    "control_metadata_only": True,
}
DUPLICATE_PREVENTION_CONTRACT = {
    "operation_families": OPERATION_FAMILIES,
    "shared_lock_namespace": "SOURCE_PIPELINE",
    "source_identity_field": "source_identity_ref",
    "operation_identity_field": "operation_identity_ref",
    "distinct_operation_identity_count": 5,
    "first_result_code": "LOCK_SET_ACQUIRED",
    "duplicate_result_code": "RESOURCE_CONFLICT_ACTIVE",
    "duplicate_decision_action": "PAUSE_BEFORE_QUEUE_ADMISSION",
    "partial_lock_retention_allowed": False,
    "queue_record_creation_allowed": False,
    "retry_budget_consumption_allowed": False,
}
PROTECTED_REFS = {
    "FACT_SOURCE": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md"
    ),
    "MANIFEST": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE026_PHASE2_ARCHIVE_MANIFEST_SLICE.md"
    ),
    "EVIDENCE_LEDGER": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_runtime_contract.json"
    ),
    "REPORT_SNAPSHOT": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md"
    ),
    "AUDIT_LOG": "repo:KM_IDSystem/docs/governance/events.jsonl",
}
PROTECTED_ARTIFACT_CONTRACT = {
    "protected_refs": PROTECTED_REFS,
    "all_refs_must_be_git_tracked": True,
    "decision_only": True,
    "delete_attempt_allowed": False,
    "delete_api_call_allowed": False,
    "cleanup_runtime_allowed": False,
    "runtime_owner": "STAGE-044",
}
DOWNSTREAM_OWNERSHIP = {
    "automatic_resume": "STAGE-042",
    "crash_recovery": "STAGE-043",
    "cleanup_execution": "STAGE-044",
    "phase3_process_recovery_claim_allowed": False,
    "phase3_cleanup_execution_claim_allowed": False,
}
HUMAN_STATUS_CONTRACT = {
    "SCENARIOS_PASS": "锁竞态隔离场景已通过，生产锁仍未启用",
    "RESOURCE_PAUSED": "资源条件不满足，未尝试获取锁",
    "DUPLICATE_BLOCKED": "检测到同源任务，重复处理已阻止",
    "STALE_FENCE_REJECTED": "旧锁凭证已失效，禁止提交结果",
    "PROTECTED_ARTIFACT": "受保护资料禁止清理",
    "REQUIRE_MANUAL_REVIEW": "场景证据无效，等待人工复核",
}
PHASE4_ENTRY_GATE = {
    "required_scenario_status": "PASS",
    "required_scenario_count": 9,
    "next_task_id": "IDS-V0_1-STAGE041-P4",
    "next_gate": "IDS-STAGE041-P4-GATE",
    "production_lock_runtime_enabled": False,
    "github_upload_allowed": False,
    "app_reinstall_allowed": False,
}

TRUE_TRUTH_FLAGS = {
    "taskpack_source_read_performed",
    "stage040_scenario_replay_performed",
    "actual_isolated_worker_exception_performed",
    "actual_disk_observation_performed",
    "isolated_lock_scenarios_evaluated",
    "protected_refs_git_tracked",
}
FALSE_TRUTH_FLAGS = {
    "ids_business_source_read_performed",
    "raw_metadata_content_accessed",
    "fake_ids_business_data_used",
    "real_ids_business_job_created",
    "process_termination_performed",
    "physical_drive_removal_performed",
    "disk_allocation_performed",
    "external_api_call_performed",
    "cleanup_runtime_performed",
    "protected_ref_delete_performed",
    "queue_runtime_performed",
    "worker_runtime_performed",
    "automatic_resume_performed",
    "crash_recovery_runtime_performed",
    "production_lock_runtime_performed",
    "production_runtime_activation_performed",
    "persistent_lock_write_performed",
    "database_connection_performed",
    "runtime_output_written",
    "github_upload_allowed",
    "app_reinstall_allowed",
}
TOP_LEVEL_KEYS = {
    "schema_version",
    "stage",
    "phase",
    "task_id",
    "acceptance_id",
    "execution_mode",
    "scenario_contract_id",
    "contract_state",
    "next_gate",
    "source_binding",
    "phase2_commit_binding",
    "upstream_bindings",
    "policy_version",
    "scenario_catalog",
    "scenario_expectations",
    "physical_action_boundary",
    "resource_gate_contract",
    "duplicate_prevention_contract",
    "protected_artifact_contract",
    "downstream_ownership",
    "human_status_contract",
    "phase4_entry_gate",
    "truth_flags",
}


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_module(path: Path, module_name: str) -> Any:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"unable to load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _phase2_module() -> Any:
    return _load_module(P2_CHECKER_PATH, "stage041_lock_registry_runtime")


def _stage040_module() -> Any:
    return _load_module(STAGE040_CHECKER_PATH, "stage040_backpressure_scenarios")


def _keys_exact(value: Any, expected: set[str]) -> bool:
    return isinstance(value, Mapping) and set(value) == expected


def _repo_ref_path(value: Any) -> Optional[Path]:
    if not isinstance(value, str):
        return None
    relative = value[5:] if value.startswith("repo:") else value
    if not relative or relative.startswith("/") or "\\" in relative:
        return None
    path = Path(relative)
    if ".." in path.parts:
        return None
    return REPO_ROOT / path


def _git_tracked(value: Any) -> bool:
    path = _repo_ref_path(value)
    if path is None:
        return False
    relative = str(path.relative_to(REPO_ROOT))
    result = subprocess.run(
        ["git", "ls-files", "--error-unmatch", "--", relative],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _commit_is_ancestor(commit: str) -> bool:
    if len(commit) != 40 or any(char not in "0123456789abcdef" for char in commit):
        return False
    result = subprocess.run(
        ["git", "merge-base", "--is-ancestor", commit, "HEAD"],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _source_binding_current(source: Any) -> bool:
    if source != SOURCE_BINDING:
        return False
    try:
        archive_path = Path(source["source_archive_path"])
        if _sha256(archive_path) != source["source_archive_sha256"]:
            return False
        with zipfile.ZipFile(archive_path) as archive:
            matches = [
                name
                for name in archive.namelist()
                if name == source["source_member"]
            ]
            if len(matches) != source["source_member_match_count"]:
                return False
            if hashlib.sha256(archive.read(matches[0])).hexdigest() != source[
                "source_member_sha256"
            ]:
                return False
        return (
            _sha256(SOURCE_ROADMAP_PATH) == source["roadmap_sha256"]
            and _sha256(SOURCE_INSTRUCTIONS_PATH)
            == source["instructions_sha256"]
        )
    except (OSError, KeyError, TypeError, zipfile.BadZipFile):
        return False


def _upstream_refs_tracked(upstream: Any) -> bool:
    return (
        isinstance(upstream, Mapping)
        and set(upstream) == set(UPSTREAM_BINDINGS)
        and all(
            isinstance(item, Mapping) and _git_tracked(item.get("ref"))
            for item in upstream.values()
        )
    )


def _upstream_hashes_current(upstream: Any) -> bool:
    if not isinstance(upstream, Mapping) or set(upstream) != set(UPSTREAM_BINDINGS):
        return False
    try:
        for item in upstream.values():
            if not isinstance(item, Mapping):
                return False
            path = _repo_ref_path(item.get("ref"))
            if path is None or _sha256(path) != item.get("sha256"):
                return False
        return True
    except OSError:
        return False


def load_scenario_contract(path: Path = CONTRACT_PATH) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Stage041 Phase 3 contract must be a JSON object")
    return value


def validate_scenario_contract(contract: Any) -> dict[str, bool]:
    value = contract if isinstance(contract, Mapping) else {}
    source = value.get("source_binding")
    commit_binding = value.get("phase2_commit_binding")
    upstream = value.get("upstream_bindings")
    protected = value.get("protected_artifact_contract")
    protected_refs = (
        protected.get("protected_refs") if isinstance(protected, Mapping) else {}
    )
    truth = value.get("truth_flags")
    return {
        "contract_object": isinstance(contract, Mapping),
        "top_level_exact": _keys_exact(value, TOP_LEVEL_KEYS),
        "identity_exact": (
            value.get("schema_version") == "ids.stage041.lock_registry.phase3.v1"
            and value.get("stage") == "STAGE-041"
            and value.get("phase") == "Phase 3"
            and value.get("task_id") == TASK_ID
            and value.get("acceptance_id") == ACCEPTANCE_ID
            and value.get("execution_mode")
            == "ISOLATED_NON_PRODUCTION_LOCK_REGISTRY_SCENARIOS"
            and value.get("scenario_contract_id")
            == "ids.lock_registry_policy.v0_1.stage041.p3.scenarios"
            and value.get("contract_state")
            == "PHASE3_SCENARIOS_ENABLED_PRODUCTION_DISABLED"
            and value.get("next_gate") == "IDS-STAGE041-P4-GATE"
        ),
        "source_binding_exact": source == SOURCE_BINDING,
        "source_binding_current": _source_binding_current(source),
        "phase2_commit_binding_exact": commit_binding == PHASE2_COMMIT_BINDING,
        "phase2_commit_is_ancestor": (
            isinstance(commit_binding, Mapping)
            and _commit_is_ancestor(str(commit_binding.get("commit", "")))
        ),
        "upstream_bindings_exact": upstream == UPSTREAM_BINDINGS,
        "upstream_refs_git_tracked": _upstream_refs_tracked(upstream),
        "upstream_hashes_current": _upstream_hashes_current(upstream),
        "policy_version_exact": value.get("policy_version") == POLICY_VERSION,
        "scenario_catalog_exact": value.get("scenario_catalog") == SCENARIO_CATALOG,
        "scenario_expectations_exact": (
            value.get("scenario_expectations") == SCENARIO_EXPECTATIONS
        ),
        "physical_action_boundary_exact": (
            value.get("physical_action_boundary") == PHYSICAL_ACTION_BOUNDARY
        ),
        "resource_gate_contract_exact": (
            value.get("resource_gate_contract") == RESOURCE_GATE_CONTRACT
        ),
        "duplicate_prevention_contract_exact": (
            value.get("duplicate_prevention_contract")
            == DUPLICATE_PREVENTION_CONTRACT
        ),
        "protected_artifact_contract_exact": (
            protected == PROTECTED_ARTIFACT_CONTRACT
        ),
        "protected_refs_git_tracked": (
            isinstance(protected_refs, Mapping)
            and protected_refs == PROTECTED_REFS
            and all(_git_tracked(ref) for ref in protected_refs.values())
        ),
        "downstream_ownership_exact": (
            value.get("downstream_ownership") == DOWNSTREAM_OWNERSHIP
        ),
        "human_status_contract_exact": (
            value.get("human_status_contract") == HUMAN_STATUS_CONTRACT
        ),
        "phase4_entry_gate_exact": (
            value.get("phase4_entry_gate") == PHASE4_ENTRY_GATE
        ),
        "truth_flags_exact": (
            _keys_exact(truth, TRUE_TRUTH_FLAGS | FALSE_TRUTH_FLAGS)
            and all(truth.get(name) is True for name in TRUE_TRUTH_FLAGS)
            and all(truth.get(name) is False for name in FALSE_TRUTH_FLAGS)
        ),
    }


def _duplicate_click_scenario(phase2: Any, p2_contract: Mapping[str, Any]) -> dict[str, Any]:
    registry = phase2.IsolatedLockRegistry(p2_contract)
    request = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["FILE_PROCESSING"],
        operation_family="FILE_PROCESSING",
        holder_role="duplicate-click-primary",
        requested_at_epoch_seconds=1000,
    )
    first = registry.acquire(request)
    second = registry.acquire(copy.deepcopy(request))
    mismatched = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["REPORT_GENERATION"],
        operation_family="REPORT_GENERATION",
        holder_role="duplicate-click-mismatched-input",
        requested_at_epoch_seconds=1001,
    )
    mismatched["idempotency_key"] = request["idempotency_key"]
    idempotency_conflict = registry.acquire(mismatched)
    snapshot = registry.snapshot()
    passed = (
        first.get("result_code") == "LOCK_SET_ACQUIRED"
        and second == first
        and snapshot.get("fencing_counter") == 1
        and len(snapshot.get("locks", {})) == 2
        and snapshot.get("operation_ledger_size") == 1
        and idempotency_conflict.get("result_code")
        == "IDEMPOTENCY_KEY_INPUT_CONFLICT"
        and idempotency_conflict.get("decision_action") == "REJECT_CONFLICT"
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "first_result_code": first.get("result_code"),
        "second_is_exact_replay": second == first,
        "fencing_counter": snapshot.get("fencing_counter"),
        "lock_record_count": len(snapshot.get("locks", {})),
        "operation_ledger_size": snapshot.get("operation_ledger_size"),
        "idempotency_input_conflict_result_code": idempotency_conflict.get(
            "result_code"
        ),
        "idempotency_input_conflict_action": idempotency_conflict.get(
            "decision_action"
        ),
        "queue_record_created": False,
        "retry_budget_consumed": False,
        "persistent_write_performed": False,
    }


def _worker_exception_scenario(
    phase2: Any,
    p2_contract: Mapping[str, Any],
    stage040_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage040_report.get("scenario_results", {}).get(
        "worker_exception_crash_boundary", {}
    )
    registry = phase2.IsolatedLockRegistry(p2_contract)
    primary = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["FILE_PROCESSING"],
        operation_family="FILE_PROCESSING",
        holder_role="worker-exception-primary",
        requested_at_epoch_seconds=1000,
    )
    acquired = registry.acquire(primary)
    contender = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["FILE_PROCESSING"],
        operation_family="FILE_PROCESSING",
        holder_role="worker-exception-contender",
        requested_at_epoch_seconds=1001,
    )
    pre_expiry = registry.acquire(contender)
    successor = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["FILE_PROCESSING"],
        operation_family="FILE_PROCESSING",
        holder_role="worker-exception-successor",
        requested_at_epoch_seconds=1035,
    )
    takeover = registry.takeover(successor)
    stale_request = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["FILE_PROCESSING"],
        operation_family="FILE_PROCESSING",
        holder_role="worker-exception-primary",
        requested_at_epoch_seconds=1036,
    )
    stale = registry.can_commit(stale_request, acquired)
    passed = (
        stage040_report.get("scenario_validation_valid") is True
        and source.get("status") == "PASS"
        and source.get("actual_isolated_worker_exception_performed") is True
        and source.get("worker_error_ref") == "error:RuntimeError"
        and acquired.get("result_code") == "LOCK_SET_ACQUIRED"
        and pre_expiry.get("result_code") == "RESOURCE_CONFLICT_ACTIVE"
        and takeover.get("result_code") == "TAKEOVER_ACQUIRED"
        and stale.get("result_code") == "STALE_FENCING_TOKEN"
        and isinstance(acquired.get("fencing_token"), int)
        and isinstance(takeover.get("fencing_token"), int)
        and takeover["fencing_token"] > acquired["fencing_token"]
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "actual_isolated_worker_exception_performed": bool(
            source.get("actual_isolated_worker_exception_performed")
        ),
        "worker_error_ref": source.get("worker_error_ref"),
        "orphaned_fencing_token": acquired.get("fencing_token"),
        "pre_expiry_result_code": pre_expiry.get("result_code"),
        "takeover_result_code": takeover.get("result_code"),
        "successor_fencing_token": takeover.get("fencing_token"),
        "stale_commit_result_code": stale.get("result_code"),
        "process_termination_performed": False,
        "crash_recovery_runtime_performed": False,
        "crash_recovery_owner": "STAGE-043",
    }


def _empty_registry_snapshot(phase2: Any, p2_contract: Mapping[str, Any]) -> dict[str, Any]:
    return phase2.IsolatedLockRegistry(p2_contract).snapshot()


def _drive_pause_scenario(
    phase2: Any,
    p2_contract: Mapping[str, Any],
    stage040_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage040_report.get("scenario_results", {}).get(
        "external_drive_offline_pause_candidate", {}
    )
    snapshot = _empty_registry_snapshot(phase2, p2_contract)
    passed = (
        source.get("status") == "PASS"
        and source.get("signal_code") == "EXTERNAL_DRIVE_OFFLINE"
        and source.get("decision_action") == "PAUSE_RESOURCE_GATE"
        and source.get("physical_drive_removal_performed") is False
        and len(snapshot.get("locks", {})) == 0
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "signal_code": source.get("signal_code"),
        "decision_action": source.get("decision_action"),
        "lock_acquire_attempted": False,
        "lock_record_count": len(snapshot.get("locks", {})),
        "physical_drive_removal_performed": False,
    }


def _disk_pause_scenario(
    phase2: Any,
    p2_contract: Mapping[str, Any],
    stage040_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage040_report.get("scenario_results", {}).get(
        "actual_disk_observation_and_low_disk_boundary", {}
    )
    snapshot = _empty_registry_snapshot(phase2, p2_contract)
    passed = (
        source.get("status") == "PASS"
        and isinstance(source.get("actual_disk_free_bytes"), int)
        and source.get("actual_disk_free_bytes", 0) > 0
        and source.get("actual_disk_decision_matches_formula") is True
        and source.get("boundary_signal_code") == "DISK_SPACE_INSUFFICIENT"
        and source.get("boundary_decision_action") == "PAUSE_RESOURCE_GATE"
        and source.get("disk_allocation_performed") is False
        and len(snapshot.get("locks", {})) == 0
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "actual_disk_free_bytes": source.get("actual_disk_free_bytes"),
        "actual_disk_signal_code": source.get("actual_disk_signal_code"),
        "actual_disk_decision_matches_formula": source.get(
            "actual_disk_decision_matches_formula"
        ),
        "boundary_signal_code": source.get("boundary_signal_code"),
        "boundary_decision_action": source.get("boundary_decision_action"),
        "lock_acquire_attempted": False,
        "lock_record_count": len(snapshot.get("locks", {})),
        "disk_allocation_performed": False,
    }


def _api_pause_scenario(
    phase2: Any,
    p2_contract: Mapping[str, Any],
    stage040_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage040_report.get("scenario_results", {}).get(
        "external_api_budget_pause_candidate", {}
    )
    snapshot = _empty_registry_snapshot(phase2, p2_contract)
    passed = (
        source.get("status") == "PASS"
        and source.get("signal_code") == "EXTERNAL_API_BUDGET_INSUFFICIENT"
        and source.get("decision_action") == "PAUSE_RESOURCE_GATE"
        and source.get("external_api_call_performed") is False
        and len(snapshot.get("locks", {})) == 0
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "signal_code": source.get("signal_code"),
        "decision_action": source.get("decision_action"),
        "lock_acquire_attempted": False,
        "lock_record_count": len(snapshot.get("locks", {})),
        "external_api_call_performed": False,
    }


def _same_source_scenario(phase2: Any, p2_contract: Mapping[str, Any]) -> dict[str, Any]:
    registry = phase2.IsolatedLockRegistry(p2_contract)
    primary = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["FILE_PROCESSING"],
        operation_family="FILE_PROCESSING",
        holder_role="cross-operation-primary",
        requested_at_epoch_seconds=1000,
    )
    acquired = registry.acquire(primary)
    conflicts: list[dict[str, Any]] = []
    for index, operation_family in enumerate(OPERATION_FAMILIES[1:], start=1):
        request = phase2.build_control_request(
            CONTROL_REF,
            operation_identity_ref=OPERATION_REFS[operation_family],
            operation_family=operation_family,
            holder_role=f"cross-operation-{operation_family.lower()}",
            requested_at_epoch_seconds=1000 + index,
        )
        conflicts.append(registry.acquire(request))
    snapshot = registry.snapshot()
    retained_keys = set(snapshot.get("locks", {}))
    partial_operation_locks = 0
    for result in conflicts:
        specific = [
            key
            for key in result.get("lock_keys", [])
            if not key.startswith("SOURCE_PIPELINE:")
        ]
        partial_operation_locks += sum(key in retained_keys for key in specific)
    resource_conflicts = sum(
        result.get("result_code") == "RESOURCE_CONFLICT_ACTIVE"
        for result in conflicts
    )
    passed = (
        acquired.get("result_code") == "LOCK_SET_ACQUIRED"
        and resource_conflicts == 4
        and partial_operation_locks == 0
        and len(retained_keys) == 2
        and snapshot.get("fencing_counter") == 1
        and len(set(OPERATION_REFS.values())) == len(OPERATION_FAMILIES)
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "operation_families": OPERATION_FAMILIES,
        "acquired_operation_family": "FILE_PROCESSING",
        "resource_conflict_count": resource_conflicts,
        "partial_operation_lock_count": partial_operation_locks,
        "retained_lock_record_count": len(retained_keys),
        "fencing_counter": snapshot.get("fencing_counter"),
        "source_identity_count": 1,
        "distinct_operation_identity_count": len(set(OPERATION_REFS.values())),
        "queue_record_created": False,
        "retry_budget_consumed": False,
    }


def _operation_duplicate_scenario(
    phase2: Any, p2_contract: Mapping[str, Any]
) -> dict[str, Any]:
    acquired_count = 0
    conflict_count = 0
    replay_count = 0
    partial_lock_count = 0
    operation_results: dict[str, dict[str, Any]] = {}
    for index, operation_family in enumerate(OPERATION_FAMILIES):
        registry = phase2.IsolatedLockRegistry(p2_contract)
        primary = phase2.build_control_request(
            CONTROL_REF,
            operation_identity_ref=OPERATION_REFS[operation_family],
            operation_family=operation_family,
            holder_role=f"{operation_family.lower()}-primary",
            requested_at_epoch_seconds=2000 + index * 10,
        )
        acquired = registry.acquire(primary)
        replay = registry.acquire(copy.deepcopy(primary))
        duplicate = phase2.build_control_request(
            CONTROL_REF,
            operation_identity_ref=OPERATION_REFS[operation_family],
            operation_family=operation_family,
            holder_role=f"{operation_family.lower()}-duplicate",
            requested_at_epoch_seconds=2001 + index * 10,
        )
        conflict = registry.acquire(duplicate)
        snapshot = registry.snapshot()
        acquired_count += acquired.get("result_code") == "LOCK_SET_ACQUIRED"
        replay_count += replay == acquired
        conflict_count += conflict.get("result_code") == "RESOURCE_CONFLICT_ACTIVE"
        is_partial = len(snapshot.get("locks", {})) != len(acquired.get("lock_keys", []))
        partial_lock_count += is_partial
        operation_results[operation_family] = {
            "first_result_code": acquired.get("result_code"),
            "duplicate_result_code": conflict.get("result_code"),
            "idempotent_replay": replay == acquired,
            "lock_record_count": len(snapshot.get("locks", {})),
        }
    passed = (
        acquired_count == len(OPERATION_FAMILIES)
        and conflict_count == len(OPERATION_FAMILIES)
        and replay_count == len(OPERATION_FAMILIES)
        and partial_lock_count == 0
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "operation_families": OPERATION_FAMILIES,
        "operation_results": operation_results,
        "acquired_count": acquired_count,
        "duplicate_conflict_count": conflict_count,
        "idempotent_replay_count": replay_count,
        "partial_lock_count": partial_lock_count,
        "duplicate_processing_performed": False,
        "persistent_write_performed": False,
    }


def _renew_takeover_scenario(
    phase2: Any, p2_contract: Mapping[str, Any]
) -> dict[str, Any]:
    registry = phase2.IsolatedLockRegistry(p2_contract)
    primary = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["INDEX_BUILD"],
        operation_family="INDEX_BUILD",
        holder_role="renew-primary",
        requested_at_epoch_seconds=1000,
    )
    acquired = registry.acquire(primary)
    renew_request = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["INDEX_BUILD"],
        operation_family="INDEX_BUILD",
        holder_role="renew-primary",
        requested_at_epoch_seconds=1010,
    )
    renewed = registry.renew(renew_request, acquired)
    early = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["INDEX_BUILD"],
        operation_family="INDEX_BUILD",
        holder_role="renew-successor",
        requested_at_epoch_seconds=1044,
    )
    early_result = registry.takeover(early)
    eligible = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["INDEX_BUILD"],
        operation_family="INDEX_BUILD",
        holder_role="renew-successor",
        requested_at_epoch_seconds=1045,
    )
    takeover = registry.takeover(eligible)
    stale_request = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["INDEX_BUILD"],
        operation_family="INDEX_BUILD",
        holder_role="renew-primary",
        requested_at_epoch_seconds=1046,
    )
    stale = registry.can_commit(stale_request, acquired)
    current_request = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["INDEX_BUILD"],
        operation_family="INDEX_BUILD",
        holder_role="renew-successor",
        requested_at_epoch_seconds=1046,
    )
    current = registry.can_commit(current_request, takeover)
    forged_evidence = copy.deepcopy(takeover)
    forged_evidence["fencing_token"] = True
    forged_evidence["lock_versions"] = {
        key: True for key in takeover.get("lock_versions", {})
    }
    forged_commit = registry.can_commit(current_request, forged_evidence)
    backward_request = phase2.build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_REFS["INDEX_BUILD"],
        operation_family="INDEX_BUILD",
        holder_role="renew-successor",
        requested_at_epoch_seconds=1044,
    )
    backward_commit = registry.can_commit(backward_request, takeover)
    stale_release = registry.release(stale_request, acquired)
    renew_preserved = (
        renewed.get("fencing_token") == acquired.get("fencing_token")
        and renewed.get("lock_versions") == acquired.get("lock_versions")
    )
    acquired_versions = acquired.get("lock_versions", {})
    takeover_versions = takeover.get("lock_versions", {})
    advanced_atomically = (
        isinstance(acquired.get("fencing_token"), int)
        and isinstance(takeover.get("fencing_token"), int)
        and takeover["fencing_token"] == acquired["fencing_token"] + 1
        and set(acquired_versions) == set(takeover_versions)
        and all(
            takeover_versions[key] == acquired_versions[key] + 1
            for key in acquired_versions
        )
    )
    passed = (
        renewed.get("result_code") == "LEASE_RENEWED"
        and renew_preserved
        and early_result.get("result_code") == "LEASE_NOT_TAKEOVER_ELIGIBLE"
        and takeover.get("result_code") == "TAKEOVER_ACQUIRED"
        and advanced_atomically
        and stale.get("result_code") == "STALE_FENCING_TOKEN"
        and current.get("result_code") == "CURRENT_FENCE_VALID"
        and forged_commit.get("result_code") == "INVALID_FENCING_EVIDENCE"
        and backward_commit.get("result_code") == "NON_MONOTONIC_LOGICAL_TIME"
        and stale_release.get("decision_action") == "REJECT_STALE_RELEASE"
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "renew_result_code": renewed.get("result_code"),
        "renew_preserved_fence_and_versions": renew_preserved,
        "early_takeover_result_code": early_result.get("result_code"),
        "eligible_takeover_result_code": takeover.get("result_code"),
        "takeover_advanced_fence_and_versions_atomically": advanced_atomically,
        "stale_commit_result_code": stale.get("result_code"),
        "current_commit_result_code": current.get("result_code"),
        "forged_fencing_result_code": forged_commit.get("result_code"),
        "backward_clock_result_code": backward_commit.get("result_code"),
        "stale_release_action": stale_release.get("decision_action"),
        "logical_clock_only": True,
        "wall_clock_sleep_performed": False,
    }


def evaluate_cleanup_candidate(
    category: Any, ref: Any, contract: Mapping[str, Any]
) -> dict[str, Any]:
    protected = contract.get("protected_artifact_contract", {})
    refs = protected.get("protected_refs", {}) if isinstance(protected, Mapping) else {}
    exact_protected = (
        isinstance(category, str)
        and isinstance(ref, str)
        and isinstance(refs, Mapping)
        and refs.get(category) == ref
        and _git_tracked(ref)
    )
    return {
        "category": category if isinstance(category, str) else None,
        "ref": ref if isinstance(ref, str) else None,
        "decision_action": (
            "PROTECTED_ARTIFACT" if exact_protected else "REQUIRE_MANUAL_REVIEW"
        ),
        "delete_allowed": False,
        "delete_function_exposed": False,
        "delete_attempt_performed": False,
        "cleanup_runtime_performed": False,
    }


def _protected_cleanup_scenario(contract: Mapping[str, Any]) -> dict[str, Any]:
    decisions = {
        category: evaluate_cleanup_candidate(category, ref, contract)
        for category, ref in PROTECTED_REFS.items()
    }
    category_decisions = {
        category: decision["decision_action"]
        for category, decision in decisions.items()
    }
    tracked = sum(_git_tracked(ref) for ref in PROTECTED_REFS.values())
    denied = sum(
        decision["decision_action"] == "PROTECTED_ARTIFACT"
        and decision["delete_allowed"] is False
        for decision in decisions.values()
    )
    passed = tracked == 5 and denied == 5
    return {
        "status": "PASS" if passed else "FAIL",
        "protected_ref_count": len(PROTECTED_REFS),
        "git_tracked_ref_count": tracked,
        "denied_delete_count": denied,
        "category_decisions": category_decisions,
        "delete_function_exposed": False,
        "delete_attempt_performed": False,
        "cleanup_runtime_performed": False,
        "cleanup_runtime_owner": "STAGE-044",
    }


def _run_scenarios(
    contract: Mapping[str, Any]
) -> tuple[dict[str, dict[str, Any]], bool, bool]:
    phase2 = _phase2_module()
    p2_contract = phase2.load_contract()
    p2_report = phase2.build_stage041_phase2_report()
    stage040 = _stage040_module()
    stage040_report = stage040.build_stage040_phase3_report()
    results = {
        "duplicate_click_lock_replay": _duplicate_click_scenario(
            phase2, p2_contract
        ),
        "worker_exception_orphaned_lease_boundary": _worker_exception_scenario(
            phase2, p2_contract, stage040_report
        ),
        "external_drive_offline_pause_before_lock": _drive_pause_scenario(
            phase2, p2_contract, stage040_report
        ),
        "actual_disk_observation_and_low_disk_pause_before_lock": (
            _disk_pause_scenario(phase2, p2_contract, stage040_report)
        ),
        "external_api_budget_pause_before_lock": _api_pause_scenario(
            phase2, p2_contract, stage040_report
        ),
        "same_source_cross_operation_contention": _same_source_scenario(
            phase2, p2_contract
        ),
        "operation_family_duplicate_prevention": _operation_duplicate_scenario(
            phase2, p2_contract
        ),
        "renewal_takeover_and_stale_fencing": _renew_takeover_scenario(
            phase2, p2_contract
        ),
        "protected_cleanup_denied": _protected_cleanup_scenario(contract),
    }
    return (
        results,
        p2_report.get("phase2_slice_valid") is True,
        stage040_report.get("scenario_validation_valid") is True,
    )


def _blank_report(
    contract_checks: Mapping[str, bool], *, load_error: Optional[str]
) -> dict[str, Any]:
    return {
        "schema_version": "ids.stage041.lock_registry.phase3.report.v1",
        "stage": "STAGE-041",
        "phase": "Phase 3",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "policy_version": POLICY_VERSION,
        "contract_valid": False,
        "scenario_runtime_performed": False,
        "scenario_validation_valid": False,
        "contract_checks": dict(contract_checks),
        "scenario_count": 0,
        "passed_scenario_count": 0,
        "scenario_results": {},
        "phase2_slice_valid": False,
        "stage040_scenario_replay_valid": False,
        "execution_mode": "BLOCKED_INVALID_SCENARIO_CONTRACT",
        "contract_state": "BLOCKED_INVALID_SCENARIO_CONTRACT",
        "load_error": load_error,
        "next_gate": "IDS-STAGE041-P3-GATE",
        "owner_feedback_zh": "锁竞态场景合同无效；保持 Phase 3 失败关闭。",
        **{key: False for key in TRUE_TRUTH_FLAGS | FALSE_TRUTH_FLAGS},
    }


def build_stage041_phase3_report(
    contract: Optional[Mapping[str, Any]] = None,
) -> dict[str, Any]:
    try:
        if contract is None:
            contract_value = load_scenario_contract()
        elif isinstance(contract, Mapping):
            contract_value = copy.deepcopy(dict(contract))
        else:
            return _blank_report(
                {"contract_object": False},
                load_error="TypeError: contract must be a mapping",
            )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        return _blank_report(
            {"contract_loadable": False},
            load_error=f"{type(exc).__name__}: {exc}",
        )
    contract_checks = validate_scenario_contract(contract_value)
    contract_valid = bool(contract_checks) and all(contract_checks.values())
    if not contract_valid:
        return _blank_report(contract_checks, load_error=None)
    try:
        results, phase2_valid, stage040_valid = _run_scenarios(contract_value)
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        report = _blank_report(
            contract_checks,
            load_error=f"{type(exc).__name__}: {exc}",
        )
        report["contract_valid"] = True
        report["scenario_runtime_performed"] = True
        report["execution_mode"] = contract_value["execution_mode"]
        report["contract_state"] = "BLOCKED_SCENARIO_EXECUTION_ERROR"
        return report
    passed = sum(item.get("status") == "PASS" for item in results.values())
    scenario_valid = (
        list(results) == SCENARIO_CATALOG
        and len(results) == len(SCENARIO_CATALOG)
        and passed == len(SCENARIO_CATALOG)
        and phase2_valid
        and stage040_valid
    )
    truth = contract_value["truth_flags"]
    worker = results["worker_exception_orphaned_lease_boundary"]
    disk = results[
        "actual_disk_observation_and_low_disk_pause_before_lock"
    ]
    protected = results["protected_cleanup_denied"]
    return {
        "schema_version": "ids.stage041.lock_registry.phase3.report.v1",
        "stage": "STAGE-041",
        "phase": "Phase 3",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "policy_version": POLICY_VERSION,
        "contract_valid": contract_valid,
        "scenario_runtime_performed": True,
        "scenario_validation_valid": scenario_valid,
        "contract_checks": contract_checks,
        "scenario_count": len(results),
        "passed_scenario_count": passed,
        "scenario_results": results,
        "phase2_slice_valid": phase2_valid,
        "stage040_scenario_replay_valid": stage040_valid,
        "execution_mode": contract_value["execution_mode"],
        "contract_state": contract_value["contract_state"],
        "load_error": None,
        "next_gate": (
            "IDS-STAGE041-P4-GATE"
            if scenario_valid
            else "IDS-STAGE041-P3-GATE"
        ),
        "owner_feedback_zh": (
            HUMAN_STATUS_CONTRACT["SCENARIOS_PASS"]
            if scenario_valid
            else HUMAN_STATUS_CONTRACT["REQUIRE_MANUAL_REVIEW"]
        ),
        "taskpack_source_read_performed": truth[
            "taskpack_source_read_performed"
        ],
        "stage040_scenario_replay_performed": (
            stage040_valid and truth["stage040_scenario_replay_performed"]
        ),
        "actual_isolated_worker_exception_performed": (
            worker.get("actual_isolated_worker_exception_performed") is True
            and truth["actual_isolated_worker_exception_performed"]
        ),
        "actual_disk_observation_performed": (
            disk.get("actual_disk_free_bytes", 0) > 0
            and truth["actual_disk_observation_performed"]
        ),
        "isolated_lock_scenarios_evaluated": (
            len(results) == len(SCENARIO_CATALOG)
            and truth["isolated_lock_scenarios_evaluated"]
        ),
        "protected_refs_git_tracked": (
            protected.get("git_tracked_ref_count") == len(PROTECTED_REFS)
            and truth["protected_refs_git_tracked"]
        ),
        **{key: bool(truth.get(key, False)) for key in FALSE_TRUTH_FLAGS},
    }


def main() -> int:
    report = build_stage041_phase3_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["scenario_validation_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
