# STAGE-042 Phase 2 · 隔离自动生命周期决策切片

## Run identity

- Task: `IDS-V0_1-STAGE042-P2`
- Acceptance: `ACC-STAGE-042` remains `in_progress`
- Entry gate: `IDS-STAGE042-P2-GATE`
- Next gate: `IDS-STAGE042-P3-GATE`
- Policy: `ids.automatic_lifecycle_policy.v0_1.stage042.p2`
- Mode: `ISOLATED_NON_PRODUCTION_LIFECYCLE_DECISION_SLICE`

Phase 2 consumes only the two Git-tracked Stage042 control-document references.
It evaluates logical-time metadata in process memory and returns legal transition
candidates plus reference-only input, output, error, checkpoint, and audit
records. It creates no IDS business job and does not read a business payload.

## Parameter provenance

| Parameter | Value | Source and derivation | Status |
|---|---:|---|---|
| `lifecycle_evaluation_interval` | 10 seconds | Direct reuse of reviewed Stage041 `renewal_interval_seconds` | `PROPOSED` |
| `pause_acknowledgement_timeout` | 30 seconds | Direct reuse of reviewed Stage041 `lease_duration_seconds` | `PROPOSED` |
| `safe_close_timeout` | 35 seconds | Stage041 lease duration `30` plus expiry grace `5` | `PROPOSED` |
| `owner_revalidation_ttl` | 30 seconds | Direct reuse of reviewed Stage040 `observation_ttl_seconds` | `PROPOSED` |
| `resource_gate_stability_window` | 60 seconds | Direct reuse of reviewed Stage040 `external_api_budget_window_seconds` | `PROPOSED` |

Every value has an exact source reference and source SHA-256 in the Phase 2
machine contract. All five values require production calibration under
`TASK-OPME-B-001`; no implicit fallback or production default exists. The
per-parameter rollback is
`DISABLE_ISOLATED_LIFECYCLE_AND_REQUIRE_MANUAL_REVIEW`.

## Implemented decision boundary

- `AUTO_START` can emit only `CREATED -> QUEUED`, `QUEUED -> CLAIMED`, or
  `CLAIMED -> RUNNING` candidates with the reviewed CAS and guard facts.
- `RESOURCE_PAUSE` can emit only the reviewed queued or active pause edges for
  external-drive offline, disk-space insufficiency, or API-budget insufficiency.
- `COMPLETE_PAUSE` requires checkpoint or quarantine evidence. Timeout returns
  manual review and never force-kills a process.
- `AUTO_RESUME` requires fresh `ACTIVE` owner evidence, all resource gates clear
  for the stability window, no active claim or lock, CAS, and idempotency.
- `SAFE_CLOSE` is cooperative. A remaining active writer after the timeout
  returns manual review; it does not claim crash recovery, takeover, or forced
  termination.
- Terminal job states are immutable. Unknown fields, malformed references,
  stale CAS, invalid guards, and idempotency payload conflicts fail closed.

The evaluator's candidate snapshot exists only in memory. It does not update a
queue, worker, lock registry, database, schema, job registry, state registry, or
runtime file. Stage038 through Stage041 retain their reviewed ownership;
Stage043 retains process-crash recovery and Stage044 retains cleanup execution.

## Controlled evidence

`python3 -B KM_IDSystem/scripts/check_automatic_lifecycle_runtime.py` executed
the real process-local evaluator against Git-tracked control references. It
reported:

- contract checks: `16/16`
- isolated slice checks: `7/7`
- start candidate: `CREATED -> QUEUED`
- resource pause candidate: `RUNNING -> PAUSE_REQUESTED`
- checkpoint completion: `PAUSE_REQUESTED -> PAUSED`
- guarded resume candidate: `PAUSED -> QUEUED`
- cooperative close candidate: `QUEUED -> PAUSED`

All records use `repo:`, `decision:sha256:`, `error:`,
`checkpoint:sha256:`, or `audit:sha256:` references. No raw payload, absolute
business path, runtime artifact, or fabricated business record is included.

Final layered validation passed focused Phase 2 `16/16`, Stage042 aggregate
`28/28`, Stage004 `3/3`, Stage005 `160/160`, Stage039 review `6/6`, Stage041
runtime plus review `26/26`, Stage040-042 aggregate `146/146`, and full IDS
v0.1 discovery `829/829`. Events parsed `202` records with zero duplicate IDs;
owner render and changed-only governance reported `0/0`.

## Explicit non-actions

- No content under `/Users/linzezhang/Downloads/IDS_MetaData` was listed, read,
  opened, hashed, scanned, copied, moved, deleted, modified, dumped, or normalized.
- No fake IDS business data, fake database row, placeholder corpus, or business
  job was created.
- No persistent lifecycle runtime, queue, worker, retry scheduler, lock runtime,
  production resume, production close, process crash recovery, cleanup/delete,
  database, schema, external API, or runtime output action ran.
- Phase 3, Phase 4, whole-stage review, batch review, GitHub, PR, issue, merge,
  and app reinstall did not run.

## Rollback

Revert only the Phase 2 contract, checker, tests, this evidence file, planned
registry entries, and matching governance/event/owner-view changes. Preserve
Phase 1, reviewed Stage037-041 contracts, raw data, manifests, evidence ledgers,
audit logs, report snapshots, user dirty files, GitHub, and installed apps.
