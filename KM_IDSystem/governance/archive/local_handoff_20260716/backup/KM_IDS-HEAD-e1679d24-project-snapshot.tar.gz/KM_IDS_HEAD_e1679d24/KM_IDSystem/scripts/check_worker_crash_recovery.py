#!/usr/bin/env python3
"""Validate the STAGE-043 Phase 1 worker-crash-recovery contract."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from typing import Any
import zipfile


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent
CONTRACT_PATH = (
    PROJECT_ROOT
    / "docs"
    / "pursuing_goal"
    / "ids_v0_1"
    / "worker_crash_recovery"
    / "stage043_worker_crash_recovery_contract.json"
)
EXPECTED_CANONICAL_SHA256 = (
    "e3f5af4984481bce7b27ff36f241e07ee111cdb27f4721d0e84ab92a0f7419b4"
)

EXPECTED_SOURCE_BINDING = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-043_Worker崩溃恢复.md"
    ),
    "source_member_match_count": 1,
    "source_member_sha256": (
        "e1d5169cbc30515930a7224743b860d9b577ccfbf9e0f913ec254d2ea060317b"
    ),
    "roadmap_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Codex开发Roadmap_v0_1_only_中文修订版.txt"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Codex使用说明_v0_1_only_中文修订版.txt"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}

EXPECTED_UPSTREAM_BINDINGS = {
    "stage037_state_index": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/job_state_model/"
            "stage037_job_state_model_index.json"
        ),
        "sha256": (
            "b70bf72ebe4212f45d380c13fbfe429791e1f4a5c73dccbba81211b7adc1c2d3"
        ),
    },
    "stage038_delivery_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/worker_queue_baseline/"
            "stage038_worker_queue_delivery_contract.json"
        ),
        "sha256": (
            "a4067c25b46340c33bee5017c286d6867d2b72e8fa208430c005d6b1a342c7e4"
        ),
    },
    "stage038_delivery_checker": {
        "ref": "KM_IDSystem/scripts/check_worker_queue_delivery.py",
        "sha256": (
            "305536595643979e34be5b3fdbc8e1c850f9869d4cd656331f4af0c7e2c12fd6"
        ),
    },
    "stage038_review": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
            "STAGE038_STAGE_REVIEW.md"
        ),
        "sha256": (
            "5bb4cb3382f97ded9228d278c4cfb34fc5f0a65b8858263ed0c9bbd6c035eb04"
        ),
    },
    "stage039_delivery_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/retry_dead_letter/"
            "stage039_retry_dead_letter_delivery_contract.json"
        ),
        "sha256": (
            "c4aad64a9283de683067aff07026d723c708285c57eef8a0eac4ee1b13f5cb96"
        ),
    },
    "stage039_delivery_checker": {
        "ref": "KM_IDSystem/scripts/check_retry_dead_letter_delivery.py",
        "sha256": (
            "babff5f0be9e6be06508cbe4efbe355c354a65324d0895e7c9c5f3322621e4da"
        ),
    },
    "stage039_review": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
            "STAGE039_STAGE_REVIEW.md"
        ),
        "sha256": (
            "32e621db9d7d4ad87ff4f6788e1de22d7ada9c0f57ce756a76a9608a864c4b9b"
        ),
    },
    "stage040_delivery_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
            "stage040_backpressure_delivery_contract.json"
        ),
        "sha256": (
            "84f3d69f4bda15e0042631d9b049c8988c1375be632d96e366e57cf0b1ab0ac2"
        ),
    },
    "stage040_delivery_checker": {
        "ref": "KM_IDSystem/scripts/check_backpressure_delivery.py",
        "sha256": (
            "8a16e7b079de9a05ed43029b6c6a858af8d293f49df9a2c4ceaff196cd35b4c9"
        ),
    },
    "stage040_review": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
            "STAGE040_STAGE_REVIEW.md"
        ),
        "sha256": (
            "ea1a6dacacc862d66de60883dd10ee2dbf23d3adc72efbf9586ba2ccf6c223f0"
        ),
    },
    "stage041_delivery_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
            "stage041_lock_registry_delivery_contract.json"
        ),
        "sha256": (
            "a4ae34a249bc7fc6a54434f611f83214f8dc5d8c526aea60e468963f91a9fd75"
        ),
    },
    "stage041_delivery_checker": {
        "ref": "KM_IDSystem/scripts/check_lock_registry_delivery.py",
        "sha256": (
            "4d4f5186e0f704b62d0d30bffcd320bddd05ed8e0bf520d9c30944cf945e1168"
        ),
    },
    "stage041_review": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
            "STAGE041_STAGE_REVIEW.md"
        ),
        "sha256": (
            "a829c4fb097d566a13f503bf39bf5a0276ee4bc859775c7cf1ef4e28aea72bee"
        ),
    },
    "stage042_delivery_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
            "stage042_automatic_lifecycle_delivery_contract.json"
        ),
        "sha256": (
            "3e6a4664cfa28fea368efa86669b61d7eb06cf893c4366a9edcc3132d19ec23a"
        ),
    },
    "stage042_delivery_checker": {
        "ref": "KM_IDSystem/scripts/check_automatic_lifecycle_delivery.py",
        "sha256": (
            "1b9c40e39a0b3fdfd36eb8acdbec1616d50c500d247c8226379dda8da3841879"
        ),
    },
    "stage042_review": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
            "STAGE042_STAGE_REVIEW.md"
        ),
        "sha256": (
            "0b52b1fd4d00ebe1f62a87d1b8c8c401e4d9ad3934e892ee6969b2dbc91efe85"
        ),
    },
}

EXPECTED_REVIEW_COMMIT = {
    "commit": "38ca6b40383b55c8cd3116baae9dea089a9516ce",
    "subject": "fix(ids): complete stage042 lifecycle review",
    "required_ancestor_of_head": True,
}

JOB_TYPES = ["IMPORT", "ARCHIVE", "PARSE", "OCR", "CHUNK", "EMBED", "INDEX", "REPORT"]
JOB_STATES = [
    "CREATED",
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "PAUSE_REQUESTED",
    "PAUSED",
    "RETRY_WAIT",
    "SUCCEEDED",
    "FAILED",
    "DEAD_LETTERED",
    "CANCELLED",
]
TERMINAL_STATES = ["SUCCEEDED", "FAILED", "DEAD_LETTERED", "CANCELLED"]
FALSE_TRUTH_FLAGS = {
    "actual_process_crash_induced",
    "process_termination_performed",
    "worker_restart_performed",
    "automatic_job_resume_performed",
    "persistent_recovery_state_written",
    "state_survival_verified",
    "database_connection_performed",
    "schema_change_performed",
    "state_registry_write_performed",
    "queue_runtime_performed",
    "worker_runtime_performed",
    "retry_scheduler_performed",
    "backpressure_runtime_performed",
    "lock_runtime_performed",
    "cleanup_runtime_performed",
    "runtime_output_written",
    "ids_business_source_read_performed",
    "real_ids_business_job_created",
    "raw_metadata_content_accessed",
    "fake_ids_business_data_used",
    "whole_stage_review_performed",
    "batch_review_performed",
    "phase2_executed",
    "github_upload_allowed",
    "push_allowed",
    "app_reinstall_allowed",
}


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _file_sha256(path: Path) -> str:
    return _sha256_bytes(path.read_bytes())


def _canonical_sha256(value: Any) -> str | None:
    try:
        canonical = json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError):
        return None
    return _sha256_bytes(canonical)


def _run_git(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )


def _source_files_valid(source: Any) -> bool:
    if source != EXPECTED_SOURCE_BINDING:
        return False
    try:
        archive = Path(source["source_archive_path"])
        roadmap = Path(source["roadmap_path"])
        instructions = Path(source["instructions_path"])
        if _file_sha256(archive) != source["source_archive_sha256"]:
            return False
        if _file_sha256(roadmap) != source["roadmap_sha256"]:
            return False
        if _file_sha256(instructions) != source["instructions_sha256"]:
            return False
        with zipfile.ZipFile(archive) as package:
            matches = [
                name
                for name in package.namelist()
                if name == source["source_member"]
            ]
            if len(matches) != source["source_member_match_count"]:
                return False
            member = package.read(matches[0])
        return _sha256_bytes(member) == source["source_member_sha256"]
    except (OSError, KeyError, TypeError, zipfile.BadZipFile):
        return False


def _upstream_bindings_valid(value: Any, verify_files: bool) -> bool:
    if value != EXPECTED_UPSTREAM_BINDINGS:
        return False
    if not verify_files:
        return True
    for binding in EXPECTED_UPSTREAM_BINDINGS.values():
        path = REPO_ROOT / binding["ref"]
        try:
            if _file_sha256(path) != binding["sha256"]:
                return False
        except OSError:
            return False
        if _run_git("ls-files", "--error-unmatch", binding["ref"]).returncode != 0:
            return False
    return True


def _review_commit_valid(value: Any, verify_files: bool) -> bool:
    if value != EXPECTED_REVIEW_COMMIT:
        return False
    if not verify_files:
        return True
    commit = EXPECTED_REVIEW_COMMIT["commit"]
    ancestor = _run_git("merge-base", "--is-ancestor", commit, "HEAD")
    subject = _run_git("show", "-s", "--format=%s", commit)
    return (
        ancestor.returncode == 0
        and subject.returncode == 0
        and subject.stdout.strip() == EXPECTED_REVIEW_COMMIT["subject"]
    )


def evaluate_contract(
    contract: Any, verify_files: bool = False
) -> dict[str, bool]:
    if not isinstance(contract, dict):
        return {"contract_is_object": False}

    state = contract.get("state_model_inheritance", {})
    crash = contract.get("crash_detection_boundary", {})
    durable = contract.get("durable_recovery_preconditions", {})
    recovery = contract.get("recovery_classification_contract", {})
    retry = contract.get("retry_dead_letter_boundary", {})
    pressure = contract.get("backpressure_boundary", {})
    lock = contract.get("claim_lock_fencing_boundary", {})
    checkpoint = contract.get("checkpoint_and_idempotency_contract", {})
    partial = contract.get("partial_output_boundary", {})
    parameters = contract.get("parameter_contract", {})
    phase2 = contract.get("phase2_entry_gate", {})
    truth = contract.get("truth_flags", {})

    return {
        "contract_is_object": True,
        "canonical_contract_exact": (
            _canonical_sha256(contract) == EXPECTED_CANONICAL_SHA256
        ),
        "identity_exact": (
            contract.get("schema_version")
            == "ids.stage043.worker_crash_recovery.phase1.v1"
            and contract.get("stage") == "STAGE-043"
            and contract.get("phase") == "Phase 1"
            and contract.get("task_id") == "IDS-V0_1-STAGE043-P1"
            and contract.get("acceptance_id") == "ACC-STAGE-043"
            and contract.get("local_code") == "D07-S007"
            and contract.get("worker_crash_recovery_contract_id")
            == "ids.worker_crash_recovery.v0_1.stage043.p1"
            and contract.get("contract_state")
            == "PHASE1_ENGINEERING_CONTRACT_RUNTIME_DISABLED"
            and contract.get("execution_ready") is False
            and contract.get("next_gate") == "IDS-STAGE043-P2-GATE"
        ),
        "source_binding_exact": (
            _source_files_valid(contract.get("source_binding"))
            if verify_files
            else contract.get("source_binding") == EXPECTED_SOURCE_BINDING
        ),
        "stage042_review_commit_bound": _review_commit_valid(
            contract.get("stage042_review_commit_binding"), verify_files
        ),
        "upstream_bindings_exact": _upstream_bindings_valid(
            contract.get("upstream_bindings"), verify_files
        ),
        "state_model_inherited": (
            state.get("state_model_version") == "ids.job_state.v1"
            and state.get("job_types") == JOB_TYPES
            and state.get("job_states") == JOB_STATES
            and state.get("terminal_states") == TERMINAL_STATES
            and state.get("inherited_transition_count") == 21
            and state.get("new_job_state_defined") is False
            and state.get("terminal_history_reopen_allowed") is False
            and state.get("compare_and_set_fields")
            == ["job_id", "expected_state", "expected_state_version"]
            and state.get("append_only_audit_required") is True
        ),
        "crash_detection_fails_closed": (
            crash.get("reviewed_runtime_error_classification")
            == "TASK_EXCEPTION_NOT_PROCESS_CRASH"
            and crash.get("task_exception_alone_is_process_crash") is False
            and crash.get("heartbeat_expiry_alone_authorizes_recovery") is False
            and crash.get("classification_rule")
            == "REQUIRE_CORROBORATED_PROCESS_LOSS_EVIDENCE"
            and crash.get("actual_process_crash_induced") is False
        ),
        "durable_state_precedes_recovery": (
            durable.get("process_independent_state_store_required") is True
            and durable.get("transaction_or_fsync_boundary_required") is True
            and durable.get("current_persistent_recovery_state_available") is False
            and durable.get("state_survival_verified") is False
            and durable.get("required_commit_order")
            == [
                "COMMIT_JOB_AND_INPUT_IDENTITY",
                "COMMIT_CLAIM_LEASE_LOCK_AND_FENCING",
                "COMMIT_ATTEMPT_AND_RECOVERY_POLICY",
                "ACKNOWLEDGE_WORKER_INVOCATION",
                "COMMIT_CHECKPOINT_BEFORE_RESTARTABLE_SIDE_EFFECT",
            ]
        ),
        "recovery_classification_fails_closed": (
            recovery.get("legal_crash_disposition_edges")
            == {
                "CLAIMED": ["CLAIMED->RETRY_WAIT"],
                "RUNNING": ["RUNNING->RETRY_WAIT", "RUNNING->FAILED"],
                "PAUSE_REQUESTED": [
                    "PAUSE_REQUESTED->RETRY_WAIT",
                    "PAUSE_REQUESTED->PAUSED",
                ],
            }
            and recovery.get("unknown_evidence_action")
            == "REQUIRE_MANUAL_REVIEW"
            and recovery.get("direct_running_to_queued_allowed") is False
            and recovery.get("automatic_process_restart_allowed") is False
            and recovery.get("automatic_job_resume_performed") is False
        ),
        "upstream_policy_ownership_preserved": (
            retry.get("policy_owner") == "STAGE-039"
            and retry.get("remaining_budget_and_allowlisted_error_required") is True
            and retry.get("retry_budget_or_safe_error_redefined") is False
            and pressure.get("policy_owner") == "STAGE-040"
            and pressure.get("pressure_clear_alone_authorizes_recovery") is False
            and lock.get("policy_owner") == "STAGE-041"
            and lock.get("expired_claim_revalidation_required") is True
            and lock.get("fencing_must_advance_before_new_holder") is True
            and lock.get("stale_worker_commit_allowed") is False
            and lock.get("persistent_lock_runtime_performed") is False
        ),
        "checkpoint_and_partial_outputs_protected": (
            checkpoint.get("hash_algorithm") == "SHA-256"
            and checkpoint.get("exact_replay_returns_existing_decision") is True
            and checkpoint.get("checkpoint_reference_only") is True
            and checkpoint.get("raw_payload_allowed") is False
            and partial.get("cleanup_execution_owner") == "STAGE-044"
            and partial.get("delete_execution_allowed") is False
            and partial.get("cleanup_runtime_performed") is False
        ),
        "parameters_deferred": (
            parameters.get("numeric_values_assigned") is False
            and parameters.get("implicit_default_allowed") is False
            and parameters.get("deferred_parameters")
            == [
                "worker_heartbeat_interval",
                "worker_liveness_timeout",
                "crash_confirmation_window",
                "claim_recovery_grace_period",
                "checkpoint_freshness_ttl",
            ]
        ),
        "phase2_gate_exact": (
            phase2.get("entry_authorized") is True
            and phase2.get("required_task_id") == "IDS-V0_1-STAGE043-P2"
            and phase2.get("required_gate") == "IDS-STAGE043-P2-GATE"
            and phase2.get("separate_run_required") is True
        ),
        "truth_flags_exact": (
            isinstance(truth, dict)
            and set(truth) == FALSE_TRUTH_FLAGS | {"taskpack_source_read_performed"}
            and truth.get("taskpack_source_read_performed") is True
            and all(truth.get(key) is False for key in FALSE_TRUTH_FLAGS)
        ),
    }


def load_contract() -> dict[str, Any]:
    return json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))


def build_stage043_phase1_report() -> dict[str, Any]:
    contract = load_contract()
    checks = evaluate_contract(contract, verify_files=True)
    truth = contract.get("truth_flags", {})
    return {
        "stage": contract.get("stage"),
        "phase": contract.get("phase"),
        "task_id": contract.get("task_id"),
        "acceptance_id": contract.get("acceptance_id"),
        "contract_state": contract.get("contract_state"),
        "execution_ready": contract.get("execution_ready"),
        "next_gate": contract.get("next_gate"),
        "phase1_contract_valid": bool(checks) and all(checks.values()),
        "contract_checks": checks,
        **truth,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    parser.parse_args()
    report = build_stage043_phase1_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["phase1_contract_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
