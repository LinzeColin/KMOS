# STAGE-043 Phase 1 Worker Crash Recovery Scope Boundary

## Crash Evidence Boundary

A task-level exception is not a worker-process crash. The reviewed isolated
`RuntimeError` from earlier stages is classified as
`TASK_EXCEPTION_NOT_PROCESS_CRASH`. A crash candidate requires corroborated
process-loss evidence across worker process exit, heartbeat expiry, and claim
lease expiry without release. Heartbeat expiry alone never authorizes
recovery. Missing, stale, contradictory, malformed, or unknown evidence fails
closed to manual review.

Phase 1 does not induce a crash, terminate a process, restart a worker, or
observe state survival after process loss.

## Durable Recovery Preconditions

Recovery cannot be reliable while job and claim state exist only in worker
memory. Before any future crash-recovery runtime can be enabled, a
process-independent durable store must atomically or durably record:

1. job state and version;
2. reference-only inputs and idempotency key;
3. worker and process-instance references;
4. claim, lease, lock, and fencing state;
5. attempt number, retry policy version, and remaining budget;
6. checkpoint and partial-output manifest references; and
7. an append-only audit reference.

Job/input identity, claim/lock/fencing, and attempt/recovery policy commit
before worker invocation is acknowledged. A restartable external side effect
requires a durable checkpoint boundary first. Phase 1 writes none of these
records and therefore keeps `state_survival_verified=false`.

## State And Disposition Boundary

STAGE-043 inherits all eight job types, eleven states, four terminal states,
and twenty-one legal transitions from STAGE-037. It adds no state, skips no
compare-and-set guard, and never reopens terminal history.

Only these existing edges can classify a crash disposition:

- `CLAIMED -> RETRY_WAIT`
- `RUNNING -> RETRY_WAIT`
- `RUNNING -> FAILED`
- `PAUSE_REQUESTED -> RETRY_WAIT`
- `PAUSE_REQUESTED -> PAUSED`

They are candidate decisions, not executed transitions. Direct
`RUNNING -> QUEUED`, automatic process restart, and automatic job resume are
forbidden. Unknown evidence returns `REQUIRE_MANUAL_REVIEW`.

## Retry, Pressure, Claim, And Fencing Ownership

STAGE-039 owns retry eligibility, safe-error allowlisting, budget accounting,
and dead-letter disposition. A crash candidate cannot broaden the allowlist or
reset a retry budget.

STAGE-040 owns the three required resource pause signals:

- `EXTERNAL_DRIVE_OFFLINE`
- `DISK_SPACE_INSUFFICIENT`
- `EXTERNAL_API_BUDGET_INSUFFICIENT`

A blocked resource permits only pause or manual review. Resource recovery
alone does not authorize job recovery.

STAGE-041 owns claim lease, lock granularity, and fencing. An expired claim
must be revalidated, and fencing must advance before a new holder can commit.
A stale worker can never commit. Phase 1 performs no persistent lock action.

## Checkpoint And Idempotency

The recovery idempotency key is SHA-256 over job ID, expected state/version,
attempt number, worker-process-instance reference, checkpoint reference, and
recovery-policy version. Exact replay returns the existing decision. Reusing a
key with different inputs returns
`REJECT_RECOVERY_IDEMPOTENCY_INPUT_CONFLICT` before any state or side effect.

Checkpoint and output evidence is reference-only. Raw payloads and raw source
content are forbidden.

## Partial-output Boundary

Only `TEMPORARY_PARTIAL_OUTPUT` and `REBUILDABLE_CACHE` may become quarantine
candidates. Phase 1 cannot quarantine or delete them. `ORIGINAL_RAW_DATA`,
`FACT_SOURCE`, `MANIFEST`, `EVIDENCE_LEDGER`, `REPORT_SNAPSHOT`, `AUDIT_LOG`,
`ACTIVE_INDEX`, and `REQUIRED_CHECKPOINT` are protected. Cleanup execution
belongs to STAGE-044.

## Deferred Parameters

Phase 1 assigns no values and permits no implicit defaults for:

- worker heartbeat interval;
- worker liveness timeout;
- crash confirmation window;
- claim recovery grace period; and
- checkpoint freshness TTL.

Phase 2 must bind every value to source, rationale, unit, policy version,
validation evidence, and rollback before an isolated slice can evaluate it.

## Phase 2 Gate

`Phase 2 must run separately`. Its entry may implement only an isolated,
non-production decision slice after durable-state limitations and every
numeric parameter remain explicit. It cannot claim process-crash survival,
production recovery, cleanup execution, or raw metadata access.

The next gate is `IDS-STAGE043-P2-GATE`; `push_allowed=false`.
