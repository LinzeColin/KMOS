#!/usr/bin/env python3
"""Validate STAGE-042 Phase 3 isolated automatic-lifecycle scenarios."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Optional


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent
CONTRACT_PATH = (
    PROJECT_ROOT
    / "docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
    "stage042_automatic_lifecycle_scenarios.json"
)
P2_CHECKER_PATH = PROJECT_ROOT / "scripts/check_automatic_lifecycle_runtime.py"
STAGE041_CHECKER_PATH = PROJECT_ROOT / "scripts/check_lock_registry_scenarios.py"

TASK_ID = "IDS-V0_1-STAGE042-P3"
ACCEPTANCE_ID = "ACC-STAGE-042"
POLICY_VERSION = "ids.automatic_lifecycle_policy.v0_1.stage042.p2"
P2_COMMIT = "205f33d2049de8e9174f50a8cbeb7e2898af44ed"
EXECUTION_MODE = "ISOLATED_NON_PRODUCTION_AUTOMATIC_LIFECYCLE_SCENARIOS"
CONTROL_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE042_PHASE3_SCENARIO_VALIDATION.md"
)

SOURCE_BINDING = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-042_自动运行、暂停、恢复与关闭.md"
    ),
    "source_member_match_count": 1,
    "source_member_sha256": (
        "78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}
PHASE2_COMMIT_BINDING = {
    "commit": P2_COMMIT,
    "subject": "feat(ids): implement stage042 lifecycle decision slice",
    "binding_mode": "COMMITTED_LOCAL_PHASE2",
}
UPSTREAM_BINDINGS = {
    "phase2_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
            "stage042_automatic_lifecycle_runtime_contract.json"
        ),
        "sha256": (
            "bfc15281dc37d173ccac70ae82e02d98d71175864362823a37f326fa81962463"
        ),
    },
    "phase2_checker": {
        "ref": "KM_IDSystem/scripts/check_automatic_lifecycle_runtime.py",
        "sha256": (
            "30d03349fcf1ccfaa5fc20372d88307eb186f235b7e28e11683718ff4c6cafe0"
        ),
    },
    "phase2_evidence": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
            "STAGE042_PHASE2_AUTOMATIC_LIFECYCLE_SLICE.md"
        ),
        "sha256": (
            "87bb937e4fd12b7dfdc68d8a25f3a048ba5fdd3c1521cc1f253b4fbd240648fe"
        ),
    },
    "phase2_tests": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/"
            "test_stage042_automatic_lifecycle_runtime.py"
        ),
        "sha256": (
            "6efe77bc842b9df47ffb61c78d25c188cdcc56f5cf21423469f2f453e9c505a4"
        ),
    },
    "stage041_scenario_contract": {
        "ref": (
            "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
            "stage041_lock_registry_scenarios.json"
        ),
        "sha256": (
            "c365809037e377c90e34eadcd1a64e94490c774ee90cc19b99d56ac4b3026f82"
        ),
    },
    "stage041_scenario_checker": {
        "ref": "KM_IDSystem/scripts/check_lock_registry_scenarios.py",
        "sha256": (
            "8283e89c7157528974e94cf75e5e59edf625be4b727f9dd3ab3c7c5abe8c3c51"
        ),
    },
}
SCENARIO_CATALOG = [
    "duplicate_lifecycle_request_replay_and_conflict",
    "worker_exception_requires_manual_recovery",
    "external_drive_offline_requests_pause",
    "actual_disk_observation_and_low_disk_pause",
    "external_api_budget_requests_pause",
    "same_source_concurrency_blocks_start_admission",
    "operation_lock_duplicate_prevention",
    "resume_requires_fresh_owner_and_stable_resources",
    "safe_close_active_writer_times_out_without_force_kill",
    "protected_cleanup_denied",
]
SCENARIO_EXPECTATIONS = {
    "duplicate_lifecycle_request_replay_and_conflict": (
        "ONE_LEDGER_RECORD_EXACT_REPLAY_CONFLICTING_INPUT_MANUAL_REVIEW"
    ),
    "worker_exception_requires_manual_recovery": (
        "ACTUAL_ISOLATED_EXCEPTION_PAUSE_ACK_TIMEOUT_MANUAL_RECOVERY_ONLY"
    ),
    "external_drive_offline_requests_pause": (
        "RUNNING_TO_PAUSE_REQUESTED_NO_PHYSICAL_REMOVAL"
    ),
    "actual_disk_observation_and_low_disk_pause": (
        "ACTUAL_OBSERVATION_CONTROLLED_LOW_BOUNDARY_QUEUED_TO_PAUSED_NO_ALLOCATION"
    ),
    "external_api_budget_requests_pause": (
        "CLAIMED_TO_PAUSE_REQUESTED_NO_API_CALL"
    ),
    "same_source_concurrency_blocks_start_admission": (
        "FOUR_LOCK_CONFLICTS_NO_PARTIAL_LOCKS_LIFECYCLE_START_BLOCKED"
    ),
    "operation_lock_duplicate_prevention": (
        "FIVE_OPERATION_FAMILIES_EACH_ACQUIRE_ONCE_DUPLICATE_BLOCKED"
    ),
    "resume_requires_fresh_owner_and_stable_resources": (
        "STALE_OWNER_BLOCKED_UNSTABLE_RESOURCE_WAITS_FRESH_STABLE_RESUME_CANDIDATE"
    ),
    "safe_close_active_writer_times_out_without_force_kill": (
        "ACTIVE_WRITER_TIMEOUT_MANUAL_REVIEW_NO_FORCE_KILL"
    ),
    "protected_cleanup_denied": (
        "FIVE_GIT_TRACKED_PROTECTED_REFS_DENIED_NO_DELETE_PATH"
    ),
}
PHYSICAL_ACTION_BOUNDARY = {
    "stage041_scenario_replay_allowed": True,
    "stage042_isolated_lifecycle_scenarios_allowed": True,
    "actual_project_disk_observation_allowed": True,
    "process_termination_allowed": False,
    "physical_drive_removal_allowed": False,
    "disk_allocation_allowed": False,
    "external_api_call_allowed": False,
    "cleanup_delete_allowed": False,
    "database_allowed": False,
    "persistent_state_write_allowed": False,
    "runtime_output_write_allowed": False,
    "raw_metadata_access_allowed": False,
    "fake_ids_business_data_allowed": False,
    "production_activation_allowed": False,
    "queue_runtime_allowed": False,
    "worker_runtime_allowed": False,
    "retry_scheduler_allowed": False,
    "production_lock_runtime_allowed": False,
    "automatic_resume_production_allowed": False,
    "safe_close_production_allowed": False,
    "crash_recovery_allowed": False,
    "cleanup_runtime_allowed": False,
}
LIFECYCLE_SCENARIO_CONTRACT = {
    "control_metadata_only": True,
    "logical_time_only": True,
    "reference_only_records": True,
    "duplicate_replay_must_be_exact": True,
    "idempotency_conflict_action": "REQUIRE_MANUAL_REVIEW",
    "worker_exception_action": "REQUIRE_MANUAL_REVIEW",
    "resource_pause_reasons": [
        "EXTERNAL_DRIVE_OFFLINE",
        "DISK_SPACE_INSUFFICIENT",
        "EXTERNAL_API_BUDGET_INSUFFICIENT",
    ],
    "same_source_start_action": "REQUIRE_MANUAL_REVIEW",
    "resume_owner_ttl_seconds": 30,
    "resume_resource_stability_seconds": 60,
    "safe_close_timeout_seconds": 35,
    "safe_close_timeout_action": "REQUIRE_MANUAL_REVIEW",
}
PROTECTED_REFS = {
    "FACT_SOURCE": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md"
    ),
    "MANIFEST": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE026_PHASE2_ARCHIVE_MANIFEST_SLICE.md"
    ),
    "EVIDENCE_LEDGER": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_runtime_contract.json"
    ),
    "REPORT_SNAPSHOT": (
        "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md"
    ),
    "AUDIT_LOG": "repo:KM_IDSystem/docs/governance/events.jsonl",
}
PROTECTED_ARTIFACT_CONTRACT = {
    "protected_refs": PROTECTED_REFS,
    "all_refs_must_be_git_tracked": True,
    "decision_only": True,
    "delete_attempt_allowed": False,
    "delete_api_call_allowed": False,
    "cleanup_runtime_allowed": False,
    "runtime_owner": "STAGE-044",
}
DOWNSTREAM_OWNERSHIP = {
    "retry_resume": "STAGE-039",
    "lock_exclusion": "STAGE-041",
    "crash_recovery": "STAGE-043",
    "cleanup_execution": "STAGE-044",
    "phase3_process_recovery_claim_allowed": False,
    "phase3_cleanup_execution_claim_allowed": False,
}
HUMAN_STATUS_CONTRACT = {
    "SCENARIOS_PASS": "自动生命周期隔离场景已通过，生产运行仍未启用",
    "RESOURCE_PAUSED": "资源条件不满足，已生成安全暂停候选",
    "START_BLOCKED": "检测到同源任务，自动启动已阻止",
    "RESUME_WAITING": "owner 或资源门禁尚未满足，保持暂停",
    "SAFE_CLOSE_BLOCKED": "活动写入未结束，等待人工复核",
    "PROTECTED_ARTIFACT": "受保护资料禁止清理",
    "REQUIRE_MANUAL_REVIEW": "场景证据无效，等待人工复核",
}
PHASE4_ENTRY_GATE = {
    "required_scenario_status": "PASS",
    "required_scenario_count": 10,
    "next_task_id": "IDS-V0_1-STAGE042-P4",
    "next_gate": "IDS-STAGE042-P4-GATE",
    "production_lifecycle_runtime_enabled": False,
    "github_upload_allowed": False,
    "app_reinstall_allowed": False,
}
TRUE_TRUTH_FLAGS = {
    "taskpack_source_read_performed",
    "stage041_scenario_replay_performed",
    "actual_isolated_worker_exception_performed",
    "actual_disk_observation_performed",
    "isolated_lifecycle_scenarios_evaluated",
    "protected_refs_git_tracked",
}
FALSE_TRUTH_FLAGS = {
    "ids_business_source_read_performed",
    "raw_metadata_content_accessed",
    "fake_ids_business_data_used",
    "real_ids_business_job_created",
    "process_termination_performed",
    "physical_drive_removal_performed",
    "disk_allocation_performed",
    "external_api_call_performed",
    "cleanup_runtime_performed",
    "protected_ref_delete_performed",
    "queue_runtime_performed",
    "worker_runtime_performed",
    "retry_scheduler_performed",
    "persistent_lifecycle_runtime_performed",
    "production_lock_runtime_performed",
    "automatic_resume_production_performed",
    "safe_close_production_performed",
    "force_kill_performed",
    "crash_recovery_runtime_performed",
    "production_runtime_activation_performed",
    "persistent_state_write_performed",
    "database_connection_performed",
    "runtime_output_written",
    "whole_stage_review_performed",
    "github_upload_allowed",
    "app_reinstall_allowed",
}
TOP_LEVEL_KEYS = {
    "schema_version",
    "stage",
    "phase",
    "task_id",
    "acceptance_id",
    "execution_mode",
    "scenario_contract_id",
    "contract_state",
    "next_gate",
    "source_binding",
    "phase2_commit_binding",
    "upstream_bindings",
    "policy_version",
    "scenario_catalog",
    "scenario_expectations",
    "physical_action_boundary",
    "lifecycle_scenario_contract",
    "protected_artifact_contract",
    "downstream_ownership",
    "human_status_contract",
    "phase4_entry_gate",
    "truth_flags",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _positive_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def _load_module(path: Path, module_name: str) -> Any:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"unable to load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _phase2_module() -> Any:
    return _load_module(P2_CHECKER_PATH, "stage042_phase2_runtime")


def _stage041_module() -> Any:
    return _load_module(STAGE041_CHECKER_PATH, "stage041_phase3_scenarios")


def _repo_ref_path(value: Any) -> Optional[Path]:
    if not isinstance(value, str):
        return None
    raw = value.removeprefix("repo:")
    path = PurePosixPath(raw)
    if (
        path.is_absolute()
        or not raw.startswith("KM_IDSystem/")
        or ".." in path.parts
        or "" in path.parts
    ):
        return None
    return REPO_ROOT / path


def _git_tracked(value: Any) -> bool:
    path = _repo_ref_path(value)
    if path is None or not path.is_file():
        return False
    relative = path.relative_to(REPO_ROOT).as_posix()
    result = subprocess.run(
        ["git", "ls-files", "--error-unmatch", "--", relative],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
    )
    return result.returncode == 0


def _commit_is_ancestor(value: Any) -> bool:
    if not isinstance(value, str) or len(value) != 40:
        return False
    result = subprocess.run(
        ["git", "merge-base", "--is-ancestor", value, "HEAD"],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
    )
    return result.returncode == 0


def _upstream_refs_tracked(value: Any) -> bool:
    if not isinstance(value, Mapping) or set(value) != set(UPSTREAM_BINDINGS):
        return False
    return all(_git_tracked(item.get("ref")) for item in value.values())


def _upstream_hashes_current(value: Any) -> bool:
    if not isinstance(value, Mapping) or set(value) != set(UPSTREAM_BINDINGS):
        return False
    for item in value.values():
        if not isinstance(item, Mapping):
            return False
        path = _repo_ref_path(item.get("ref"))
        if path is None or not path.is_file() or _sha256(path) != item.get("sha256"):
            return False
    return True


def load_scenario_contract(path: Path = CONTRACT_PATH) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    return value if isinstance(value, dict) else {}


def validate_scenario_contract(contract: Any) -> dict[str, bool]:
    if not isinstance(contract, Mapping):
        return {"contract_object": False}
    value = dict(contract)
    truth = value.get("truth_flags")
    protected = value.get("protected_artifact_contract")
    protected_refs = (
        protected.get("protected_refs") if isinstance(protected, Mapping) else None
    )
    return {
        "top_level_keys_exact": set(value) == TOP_LEVEL_KEYS,
        "identity_exact": (
            value.get("schema_version")
            == "ids.stage042.automatic_lifecycle.phase3.v1"
            and value.get("stage") == "STAGE-042"
            and value.get("phase") == "Phase 3"
            and value.get("task_id") == TASK_ID
            and value.get("acceptance_id") == ACCEPTANCE_ID
            and value.get("execution_mode") == EXECUTION_MODE
            and value.get("scenario_contract_id")
            == "ids.automatic_lifecycle_policy.v0_1.stage042.p3.scenarios"
            and value.get("contract_state")
            == "PHASE3_SCENARIOS_ENABLED_PRODUCTION_DISABLED"
            and value.get("next_gate") == "IDS-STAGE042-P4-GATE"
        ),
        "source_binding_exact": value.get("source_binding") == SOURCE_BINDING,
        "phase2_commit_binding_exact": (
            value.get("phase2_commit_binding") == PHASE2_COMMIT_BINDING
        ),
        "phase2_commit_is_ancestor": _commit_is_ancestor(
            dict(value.get("phase2_commit_binding", {})).get("commit")
            if isinstance(value.get("phase2_commit_binding"), Mapping)
            else None
        ),
        "upstream_bindings_exact": value.get("upstream_bindings") == UPSTREAM_BINDINGS,
        "upstream_refs_git_tracked": _upstream_refs_tracked(
            value.get("upstream_bindings")
        ),
        "upstream_hashes_current": _upstream_hashes_current(
            value.get("upstream_bindings")
        ),
        "policy_version_exact": value.get("policy_version") == POLICY_VERSION,
        "scenario_catalog_exact": value.get("scenario_catalog") == SCENARIO_CATALOG,
        "scenario_expectations_exact": (
            value.get("scenario_expectations") == SCENARIO_EXPECTATIONS
        ),
        "physical_action_boundary_exact": (
            value.get("physical_action_boundary") == PHYSICAL_ACTION_BOUNDARY
        ),
        "lifecycle_scenario_contract_exact": (
            value.get("lifecycle_scenario_contract")
            == LIFECYCLE_SCENARIO_CONTRACT
        ),
        "protected_artifact_contract_exact": (
            protected == PROTECTED_ARTIFACT_CONTRACT
        ),
        "protected_refs_git_tracked": (
            protected_refs == PROTECTED_REFS
            and all(_git_tracked(ref) for ref in PROTECTED_REFS.values())
        ),
        "downstream_ownership_exact": (
            value.get("downstream_ownership") == DOWNSTREAM_OWNERSHIP
        ),
        "human_status_contract_exact": (
            value.get("human_status_contract") == HUMAN_STATUS_CONTRACT
        ),
        "phase4_entry_gate_exact": (
            value.get("phase4_entry_gate") == PHASE4_ENTRY_GATE
        ),
        "truth_flags_exact": (
            isinstance(truth, Mapping)
            and set(truth) == TRUE_TRUTH_FLAGS | FALSE_TRUTH_FLAGS
            and all(truth.get(name) is True for name in TRUE_TRUTH_FLAGS)
            and all(truth.get(name) is False for name in FALSE_TRUTH_FLAGS)
        ),
    }


def _duplicate_request_scenario(phase2: Any, contract: Mapping[str, Any]) -> dict[str, Any]:
    engine = phase2.IsolatedAutomaticLifecycle(contract)
    snapshot = phase2.build_control_snapshot("CREATED", 100)
    request = phase2.build_lifecycle_request(
        snapshot, intent="AUTO_START", logical_now=110
    )
    first = engine.evaluate(snapshot, request)
    second = engine.evaluate(copy.deepcopy(snapshot), copy.deepcopy(request))
    conflict_request = copy.deepcopy(request)
    conflict_request["logical_now"] = 120
    conflict = engine.evaluate(snapshot, conflict_request)
    ledger_count = len(engine._ledger)
    passed = (
        first.get("result_code") == "START_QUEUED"
        and second == first
        and conflict.get("result_code")
        == "REJECT_IDEMPOTENCY_KEY_INPUT_CONFLICT"
        and conflict.get("decision_action") == "REQUIRE_MANUAL_REVIEW"
        and ledger_count == 1
        and first.get("persistent_state_write_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "first_result_code": first.get("result_code"),
        "second_is_exact_replay": second == first,
        "input_conflict_result_code": conflict.get("result_code"),
        "input_conflict_action": conflict.get("decision_action"),
        "ledger_record_count": ledger_count,
        "persistent_state_write_performed": False,
        "queue_runtime_performed": False,
    }


def _worker_exception_scenario(
    phase2: Any,
    contract: Mapping[str, Any],
    stage041_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage041_report.get("scenario_results", {}).get(
        "worker_exception_orphaned_lease_boundary", {}
    )
    engine = phase2.IsolatedAutomaticLifecycle(contract)
    snapshot = phase2.build_control_snapshot(
        "PAUSE_REQUESTED",
        100,
        pause_requested_at=100,
        lease_active=True,
        lock_active=True,
        fencing_token=1,
        active_writer=True,
        pause_reason_code="EXTERNAL_DRIVE_OFFLINE",
    )
    request = phase2.build_lifecycle_request(
        snapshot, intent="COMPLETE_PAUSE", logical_now=131
    )
    result = engine.evaluate(snapshot, request)
    passed = (
        source.get("status") == "PASS"
        and source.get("actual_isolated_worker_exception_performed") is True
        and source.get("worker_error_ref") == "error:RuntimeError"
        and result.get("result_code") == "PAUSE_ACKNOWLEDGEMENT_TIMEOUT"
        and result.get("decision_action") == "REQUIRE_MANUAL_REVIEW"
        and result.get("crash_recovery_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "actual_isolated_worker_exception_performed": source.get(
            "actual_isolated_worker_exception_performed"
        ),
        "worker_error_ref": source.get("worker_error_ref"),
        "lifecycle_result_code": result.get("result_code"),
        "decision_action": result.get("decision_action"),
        "process_termination_performed": False,
        "crash_recovery_runtime_performed": False,
        "crash_recovery_owner": "STAGE-043",
    }


def _resource_pause_result(
    phase2: Any,
    contract: Mapping[str, Any],
    *,
    state: str,
    reason: str,
) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    if state in {"CLAIMED", "RUNNING"}:
        overrides.update(
            {
                "lease_active": True,
                "lock_active": True,
                "fencing_token": 1,
                "active_writer": state == "RUNNING",
            }
        )
    snapshot = phase2.build_control_snapshot(state, 100, **overrides)
    request = phase2.build_lifecycle_request(
        snapshot,
        intent="RESOURCE_PAUSE",
        logical_now=110,
        pause_reason_code=reason,
    )
    return phase2.IsolatedAutomaticLifecycle(contract).evaluate(snapshot, request)


def _drive_pause_scenario(
    phase2: Any,
    contract: Mapping[str, Any],
    stage041_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage041_report.get("scenario_results", {}).get(
        "external_drive_offline_pause_before_lock", {}
    )
    result = _resource_pause_result(
        phase2, contract, state="RUNNING", reason="EXTERNAL_DRIVE_OFFLINE"
    )
    passed = (
        source.get("status") == "PASS"
        and source.get("signal_code") == "EXTERNAL_DRIVE_OFFLINE"
        and result.get("result_code") == "RESOURCE_PAUSE_REQUESTED"
        and result.get("transition") == "RUNNING->PAUSE_REQUESTED"
        and source.get("physical_drive_removal_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "signal_code": source.get("signal_code"),
        "lifecycle_result_code": result.get("result_code"),
        "transition": result.get("transition"),
        "physical_drive_removal_performed": False,
        "persistent_state_write_performed": False,
    }


def _disk_pause_scenario(
    phase2: Any,
    contract: Mapping[str, Any],
    stage041_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage041_report.get("scenario_results", {}).get(
        "actual_disk_observation_and_low_disk_pause_before_lock", {}
    )
    result = _resource_pause_result(
        phase2, contract, state="QUEUED", reason="DISK_SPACE_INSUFFICIENT"
    )
    passed = (
        source.get("status") == "PASS"
        and _positive_int(source.get("actual_disk_free_bytes"))
        and source.get("actual_disk_decision_matches_formula") is True
        and source.get("boundary_signal_code") == "DISK_SPACE_INSUFFICIENT"
        and result.get("result_code") == "RESOURCE_PAUSED_BEFORE_CLAIM"
        and result.get("transition") == "QUEUED->PAUSED"
        and source.get("disk_allocation_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "actual_disk_free_bytes": source.get("actual_disk_free_bytes"),
        "actual_disk_decision_matches_formula": source.get(
            "actual_disk_decision_matches_formula"
        ),
        "signal_code": source.get("boundary_signal_code"),
        "lifecycle_result_code": result.get("result_code"),
        "transition": result.get("transition"),
        "disk_allocation_performed": False,
        "persistent_state_write_performed": False,
    }


def _api_pause_scenario(
    phase2: Any,
    contract: Mapping[str, Any],
    stage041_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage041_report.get("scenario_results", {}).get(
        "external_api_budget_pause_before_lock", {}
    )
    result = _resource_pause_result(
        phase2,
        contract,
        state="CLAIMED",
        reason="EXTERNAL_API_BUDGET_INSUFFICIENT",
    )
    passed = (
        source.get("status") == "PASS"
        and source.get("signal_code") == "EXTERNAL_API_BUDGET_INSUFFICIENT"
        and result.get("result_code") == "RESOURCE_PAUSE_REQUESTED"
        and result.get("transition") == "CLAIMED->PAUSE_REQUESTED"
        and source.get("external_api_call_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "signal_code": source.get("signal_code"),
        "lifecycle_result_code": result.get("result_code"),
        "transition": result.get("transition"),
        "external_api_call_performed": False,
        "persistent_state_write_performed": False,
    }


def _same_source_scenario(
    phase2: Any,
    contract: Mapping[str, Any],
    stage041_report: Mapping[str, Any],
) -> dict[str, Any]:
    source = stage041_report.get("scenario_results", {}).get(
        "same_source_cross_operation_contention", {}
    )
    snapshot = phase2.build_control_snapshot(
        "CREATED", 100, lease_active=True, lock_active=True, fencing_token=1
    )
    request = phase2.build_lifecycle_request(
        snapshot, intent="AUTO_START", logical_now=110
    )
    request["guard_facts"]["no_active_claim_or_lock"] = False
    result = phase2.IsolatedAutomaticLifecycle(contract).evaluate(snapshot, request)
    passed = (
        source.get("status") == "PASS"
        and source.get("resource_conflict_count") == 4
        and source.get("partial_operation_lock_count") == 0
        and result.get("result_code") == "GUARD_OR_EDGE_NOT_SATISFIED"
        and result.get("decision_action") == "REQUIRE_MANUAL_REVIEW"
        and result.get("queue_runtime_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "resource_conflict_count": source.get("resource_conflict_count"),
        "partial_operation_lock_count": source.get("partial_operation_lock_count"),
        "lifecycle_result_code": result.get("result_code"),
        "decision_action": result.get("decision_action"),
        "queue_record_created": False,
        "persistent_state_write_performed": False,
    }


def _operation_duplicate_scenario(stage041_report: Mapping[str, Any]) -> dict[str, Any]:
    source = stage041_report.get("scenario_results", {}).get(
        "operation_family_duplicate_prevention", {}
    )
    passed = (
        source.get("status") == "PASS"
        and source.get("acquired_count") == 5
        and source.get("duplicate_conflict_count") == 5
        and source.get("idempotent_replay_count") == 5
        and source.get("partial_lock_count") == 0
        and source.get("duplicate_processing_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "operation_families": source.get("operation_families"),
        "acquired_count": source.get("acquired_count"),
        "duplicate_conflict_count": source.get("duplicate_conflict_count"),
        "idempotent_replay_count": source.get("idempotent_replay_count"),
        "partial_lock_count": source.get("partial_lock_count"),
        "duplicate_processing_performed": False,
        "production_lock_runtime_performed": False,
    }


def _resume_gate_scenario(phase2: Any, contract: Mapping[str, Any]) -> dict[str, Any]:
    stale_snapshot = phase2.build_control_snapshot(
        "PAUSED", 100, owner_evaluated_at=100, resource_gates_clear_since=0
    )
    stale_request = phase2.build_lifecycle_request(
        stale_snapshot, intent="AUTO_RESUME", logical_now=131
    )
    stale = phase2.IsolatedAutomaticLifecycle(contract).evaluate(
        stale_snapshot, stale_request
    )

    unstable_snapshot = phase2.build_control_snapshot(
        "PAUSED", 200, owner_evaluated_at=200, resource_gates_clear_since=180
    )
    unstable_request = phase2.build_lifecycle_request(
        unstable_snapshot, intent="AUTO_RESUME", logical_now=220
    )
    unstable = phase2.IsolatedAutomaticLifecycle(contract).evaluate(
        unstable_snapshot, unstable_request
    )

    ready_snapshot = phase2.build_control_snapshot(
        "PAUSED", 200, owner_evaluated_at=230, resource_gates_clear_since=150
    )
    ready_request = phase2.build_lifecycle_request(
        ready_snapshot, intent="AUTO_RESUME", logical_now=260
    )
    ready = phase2.IsolatedAutomaticLifecycle(contract).evaluate(
        ready_snapshot, ready_request
    )
    passed = (
        stale.get("result_code") == "OWNER_EVIDENCE_STALE"
        and unstable.get("result_code") == "RESOURCE_GATES_NOT_STABLE"
        and ready.get("result_code") == "RESUME_QUEUED_CANDIDATE"
        and ready.get("transition") == "PAUSED->QUEUED"
        and ready.get("persistent_state_write_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "stale_owner_result_code": stale.get("result_code"),
        "unstable_resource_result_code": unstable.get("result_code"),
        "ready_result_code": ready.get("result_code"),
        "ready_transition": ready.get("transition"),
        "automatic_resume_production_performed": False,
        "persistent_state_write_performed": False,
    }


def _safe_close_scenario(phase2: Any, contract: Mapping[str, Any]) -> dict[str, Any]:
    snapshot = phase2.build_control_snapshot(
        "RUNNING",
        100,
        safe_close_started_at=100,
        lease_active=True,
        lock_active=True,
        fencing_token=1,
        active_writer=True,
    )
    request = phase2.build_lifecycle_request(
        snapshot, intent="SAFE_CLOSE", logical_now=136
    )
    result = phase2.IsolatedAutomaticLifecycle(contract).evaluate(snapshot, request)
    passed = (
        result.get("result_code") == "SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER"
        and result.get("decision_action") == "REQUIRE_MANUAL_REVIEW"
        and result.get("force_kill_performed") is False
        and result.get("persistent_state_write_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "result_code": result.get("result_code"),
        "decision_action": result.get("decision_action"),
        "force_kill_performed": False,
        "process_termination_performed": False,
        "safe_close_production_performed": False,
        "persistent_state_write_performed": False,
    }


def _protected_cleanup_scenario(stage041_report: Mapping[str, Any]) -> dict[str, Any]:
    source = stage041_report.get("scenario_results", {}).get(
        "protected_cleanup_denied", {}
    )
    passed = (
        source.get("status") == "PASS"
        and source.get("protected_ref_count") == 5
        and source.get("git_tracked_ref_count") == 5
        and source.get("denied_delete_count") == 5
        and source.get("category_decisions")
        == {category: "PROTECTED_ARTIFACT" for category in PROTECTED_REFS}
        and source.get("delete_attempt_performed") is False
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "protected_ref_count": source.get("protected_ref_count"),
        "git_tracked_ref_count": source.get("git_tracked_ref_count"),
        "denied_delete_count": source.get("denied_delete_count"),
        "category_decisions": source.get("category_decisions"),
        "delete_function_exposed": False,
        "delete_attempt_performed": False,
        "cleanup_runtime_performed": False,
        "cleanup_runtime_owner": "STAGE-044",
    }


def _run_scenarios(
    contract: Mapping[str, Any]
) -> tuple[dict[str, dict[str, Any]], bool, bool]:
    phase2 = _phase2_module()
    p2_contract = phase2.load_contract()
    p2_report = phase2.build_stage042_phase2_report()
    stage041 = _stage041_module()
    stage041_report = stage041.build_stage041_phase3_report()
    results = {
        "duplicate_lifecycle_request_replay_and_conflict": (
            _duplicate_request_scenario(phase2, p2_contract)
        ),
        "worker_exception_requires_manual_recovery": _worker_exception_scenario(
            phase2, p2_contract, stage041_report
        ),
        "external_drive_offline_requests_pause": _drive_pause_scenario(
            phase2, p2_contract, stage041_report
        ),
        "actual_disk_observation_and_low_disk_pause": _disk_pause_scenario(
            phase2, p2_contract, stage041_report
        ),
        "external_api_budget_requests_pause": _api_pause_scenario(
            phase2, p2_contract, stage041_report
        ),
        "same_source_concurrency_blocks_start_admission": _same_source_scenario(
            phase2, p2_contract, stage041_report
        ),
        "operation_lock_duplicate_prevention": _operation_duplicate_scenario(
            stage041_report
        ),
        "resume_requires_fresh_owner_and_stable_resources": _resume_gate_scenario(
            phase2, p2_contract
        ),
        "safe_close_active_writer_times_out_without_force_kill": (
            _safe_close_scenario(phase2, p2_contract)
        ),
        "protected_cleanup_denied": _protected_cleanup_scenario(stage041_report),
    }
    return (
        results,
        p2_report.get("phase2_slice_valid") is True,
        stage041_report.get("scenario_validation_valid") is True,
    )


def _blank_report(
    contract_checks: Mapping[str, bool], *, load_error: Optional[str]
) -> dict[str, Any]:
    return {
        "schema_version": "ids.stage042.automatic_lifecycle.phase3.report.v1",
        "stage": "STAGE-042",
        "phase": "Phase 3",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "policy_version": POLICY_VERSION,
        "contract_valid": False,
        "scenario_runtime_performed": False,
        "scenario_validation_valid": False,
        "contract_checks": dict(contract_checks),
        "scenario_count": 0,
        "passed_scenario_count": 0,
        "scenario_results": {},
        "phase2_slice_valid": False,
        "stage041_scenario_replay_valid": False,
        "execution_mode": "BLOCKED_INVALID_SCENARIO_CONTRACT",
        "contract_state": "BLOCKED_INVALID_SCENARIO_CONTRACT",
        "load_error": load_error,
        "next_gate": "IDS-STAGE042-P3-GATE",
        "owner_feedback_zh": HUMAN_STATUS_CONTRACT["REQUIRE_MANUAL_REVIEW"],
        **{key: False for key in TRUE_TRUTH_FLAGS | FALSE_TRUTH_FLAGS},
    }


def build_stage042_phase3_report(
    contract: Optional[Mapping[str, Any]] = None,
) -> dict[str, Any]:
    try:
        if contract is None:
            contract_value = load_scenario_contract()
        elif isinstance(contract, Mapping):
            contract_value = copy.deepcopy(dict(contract))
        else:
            return _blank_report(
                {"contract_object": False},
                load_error="TypeError: contract must be a mapping",
            )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        return _blank_report(
            {"contract_loadable": False},
            load_error=f"{type(exc).__name__}: {exc}",
        )
    contract_checks = validate_scenario_contract(contract_value)
    contract_valid = bool(contract_checks) and all(contract_checks.values())
    if not contract_valid:
        return _blank_report(contract_checks, load_error=None)
    try:
        results, phase2_valid, stage041_valid = _run_scenarios(contract_value)
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        report = _blank_report(
            contract_checks,
            load_error=f"{type(exc).__name__}: {exc}",
        )
        report["contract_valid"] = True
        report["scenario_runtime_performed"] = True
        report["execution_mode"] = contract_value["execution_mode"]
        report["contract_state"] = "BLOCKED_SCENARIO_EXECUTION_ERROR"
        return report
    passed = sum(item.get("status") == "PASS" for item in results.values())
    scenario_valid = (
        list(results) == SCENARIO_CATALOG
        and len(results) == len(SCENARIO_CATALOG)
        and passed == len(SCENARIO_CATALOG)
        and phase2_valid
        and stage041_valid
    )
    truth = contract_value["truth_flags"]
    worker = results["worker_exception_requires_manual_recovery"]
    disk = results["actual_disk_observation_and_low_disk_pause"]
    protected = results["protected_cleanup_denied"]
    return {
        "schema_version": "ids.stage042.automatic_lifecycle.phase3.report.v1",
        "stage": "STAGE-042",
        "phase": "Phase 3",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "policy_version": POLICY_VERSION,
        "contract_valid": contract_valid,
        "scenario_runtime_performed": True,
        "scenario_validation_valid": scenario_valid,
        "contract_checks": contract_checks,
        "scenario_count": len(results),
        "passed_scenario_count": passed,
        "scenario_results": results,
        "phase2_slice_valid": phase2_valid,
        "stage041_scenario_replay_valid": stage041_valid,
        "execution_mode": contract_value["execution_mode"],
        "contract_state": contract_value["contract_state"],
        "load_error": None,
        "next_gate": (
            "IDS-STAGE042-P4-GATE"
            if scenario_valid
            else "IDS-STAGE042-P3-GATE"
        ),
        "owner_feedback_zh": (
            HUMAN_STATUS_CONTRACT["SCENARIOS_PASS"]
            if scenario_valid
            else HUMAN_STATUS_CONTRACT["REQUIRE_MANUAL_REVIEW"]
        ),
        "taskpack_source_read_performed": truth[
            "taskpack_source_read_performed"
        ],
        "stage041_scenario_replay_performed": (
            stage041_valid and truth["stage041_scenario_replay_performed"]
        ),
        "actual_isolated_worker_exception_performed": (
            worker.get("actual_isolated_worker_exception_performed") is True
            and truth["actual_isolated_worker_exception_performed"]
        ),
        "actual_disk_observation_performed": (
            _positive_int(disk.get("actual_disk_free_bytes"))
            and truth["actual_disk_observation_performed"]
        ),
        "isolated_lifecycle_scenarios_evaluated": (
            len(results) == len(SCENARIO_CATALOG)
            and truth["isolated_lifecycle_scenarios_evaluated"]
        ),
        "protected_refs_git_tracked": (
            protected.get("git_tracked_ref_count") == len(PROTECTED_REFS)
            and truth["protected_refs_git_tracked"]
        ),
        **{key: bool(truth.get(key, False)) for key in FALSE_TRUTH_FLAGS},
    }


def main() -> int:
    report = build_stage042_phase3_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["scenario_validation_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
