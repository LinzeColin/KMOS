# STAGE-041 Phase 2 Lock Registry Slice

- Stage: `STAGE-041`
- Phase: `Phase 2`
- Task: `IDS-V0_1-STAGE041-P2`
- Acceptance: `ACC-STAGE-041`
- Policy: `ids.lock_registry_policy.v0_1.stage041.p2`
- Result: `PASS_ISOLATED_IN_MEMORY_PRODUCTION_DISABLED`
- Next gate: `IDS-STAGE041-P3-GATE`

## Parameter Truth

The seven numeric values are `PROPOSED` local engineering safety boundaries,
not measured production values and not production calibrated:

| Parameter | Value | Source and constraint |
|---|---:|---|
| `lease_duration_seconds` | 30 | Local safety boundary; exactly three renewal intervals. |
| `renewal_interval_seconds` | 10 | Local safety boundary; strictly before lease expiry. |
| `expiry_grace_seconds` | 5 | Local safety boundary; positive and below one renewal interval. |
| `acquisition_timeout_seconds` | 1 | Finite synchronous decision ceiling; no sleep occurs. |
| `maximum_wait_seconds` | 0 | Preserves STAGE-038 pause-before-queue behavior. |
| `retry_jitter_seconds` | 0 | Preserves STAGE-039 retry ownership; lock contention consumes no retry. |
| `deadlock_timeout_seconds` | 1 | Registered finite guard; canonical all-or-none acquisition does not block. |

Production calibration remains assigned to `TASK-OPME-B-001`. Any invalid
parameter, request, lease, version, or fencing evidence disables the isolated
runtime and requires manual review. Rollback reverts Phase 2 files only while
preserving Phase 1 and STAGE-037..040 evidence.

## Controlled Evidence

The executed inputs were two real Git-tracked control documents: the Phase 1
scope boundary as `source_identity_ref` and the Stage 041 entry contract as
`operation_identity_ref`. They are control metadata, not IDS business data.
No raw body, Downloads metadata content, fabricated business record,
placeholder corpus, database row, or real IDS job was read or created.

The stdout-only checker executed deterministic logical-clock cases:

1. Separately derived `SOURCE_PIPELINE` and operation-specific keys were
   canonically sorted and acquired as one set; distinct operation identities
   for one source still conflicted on the shared source guard.
2. Exact duplicate acquisition replayed without advancing fence or lock version.
3. A contender received `RESOURCE_CONFLICT_ACTIVE` and paused before queue admission.
4. Matching renewal extended expiry without advancing fence or lock version.
5. Takeover failed before expiry plus grace and succeeded at the boundary, advancing the global fence and every lock version atomically.
6. The stale holder was rejected for commit, renewal, and release; the successor could commit.
7. Matching release removed the whole set and replayed idempotently.
8. Unknown nested contract fields and raw-path requests failed closed without echoing the rejected path.
9. The same idempotency key with changed identity input was rejected without a
   lock change; boolean/float fencing evidence and backward logical time also
   failed closed.

Machine evidence:

- `KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/stage041_lock_registry_runtime_contract.json`
- `KM_IDSystem/scripts/check_lock_registry_runtime.py`
- `KM_IDSystem/docs/pursuing_goal/ids_v0_1/tests/test_stage041_lock_registry_runtime.py`

## Runtime Boundary

State exists only in `IsolatedLockRegistry` process memory. The checker uses
caller-supplied logical timestamps and never sleeps. It performed no database
connection, schema or state-registry write, persistent lock write, runtime file
write, queue or worker execution, retry scheduling, automatic resume, crash
recovery, cleanup, external API call, production activation, GitHub action, or
app reinstall.

Phase 3 scenarios, Phase 4 closeout, whole-stage review, batch review, and upload
remain separate runs. This run stops at `IDS-STAGE041-P3-GATE`.
