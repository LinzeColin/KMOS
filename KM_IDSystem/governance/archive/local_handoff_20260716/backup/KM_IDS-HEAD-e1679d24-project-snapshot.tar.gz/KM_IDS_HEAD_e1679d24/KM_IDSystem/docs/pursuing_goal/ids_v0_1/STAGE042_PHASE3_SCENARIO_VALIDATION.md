# STAGE-042 Phase 3 Scenario Validation

## Scope

- Task: `IDS-V0_1-STAGE042-P3`
- Acceptance: `ACC-STAGE-042`
- Scenario contract: `ids.automatic_lifecycle_policy.v0_1.stage042.p3.scenarios`
- Lifecycle policy: `ids.automatic_lifecycle_policy.v0_1.stage042.p2`
- Execution mode: `ISOLATED_NON_PRODUCTION_AUTOMATIC_LIFECYCLE_SCENARIOS`
- Next gate: `IDS-STAGE042-P4-GATE`

This phase validates automatic start, resource pause, guarded resume, cooperative
safe close, duplicate suppression, same-source exclusion, and protected cleanup
classification. It evaluates control metadata and Git-tracked evidence only. It
does not create an IDS business job or persistent lifecycle record.

## Source And Upstream Binding

- Approved taskpack archive SHA-256:
  `55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3`
- Unique Stage042 member SHA-256:
  `78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08`
- Committed Phase 2 binding:
  `205f33d2049de8e9174f50a8cbeb7e2898af44ed`
- The scenario contract binds the exact Phase 2 contract, checker, evidence, and
  tests plus the reviewed Stage041 scenario contract and checker.
- Phase 3 replays the reviewed Stage041 worker-exception, resource-gate,
  lock-contention, fencing, and protected-cleanup evidence. It does not replace
  the Stage039 retry owner, Stage041 lock owner, Stage043 crash-recovery owner,
  or Stage044 cleanup owner.

## Scenario Evidence

| Scenario | Verified result |
| --- | --- |
| Duplicate lifecycle request | Exact replay returns the original decision; the same request ID with different input returns `REJECT_IDEMPOTENCY_KEY_INPUT_CONFLICT`; one process-local ledger record remains. |
| Isolated worker exception | The reviewed Stage041 replay executes an isolated `RuntimeError`; missing checkpoint evidence after the 30-second acknowledgement timeout returns `PAUSE_ACKNOWLEDGEMENT_TIMEOUT` and manual review. No process crash recovery is claimed. |
| External drive offline | `RUNNING -> PAUSE_REQUESTED` for `EXTERNAL_DRIVE_OFFLINE`; no physical drive action occurs. |
| Low disk | A read-only observation of the current project filesystem is positive and matches the reviewed formula; the deterministic low-space boundary produces `QUEUED -> PAUSED`. No disk allocation occurs. |
| External API budget | `CLAIMED -> PAUSE_REQUESTED` for `EXTERNAL_API_BUDGET_INSUFFICIENT`; no external API call occurs. |
| Same-source concurrency | The reviewed lock scenario reports four cross-operation conflicts and zero partial locks; lifecycle start returns `GUARD_OR_EDGE_NOT_SATISFIED` before queue admission. |
| Operation duplicate prevention | File processing, archive extraction, index build, index switch, and report generation each acquire once, replay exactly, and block a competing duplicate. |
| Resume gates | Stale owner evidence is rejected, unstable resources wait, and only fresh owner evidence plus a 60-second stable resource window yields `PAUSED -> QUEUED` as a candidate. |
| Safe close | An active writer beyond the 35-second safe-close timeout returns `SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER` and manual review; force kill is unavailable. |
| Protected cleanup | Fact source, manifest, evidence ledger, report snapshot, and audit log are Git-tracked and all return `PROTECTED_ARTIFACT`; no delete function or cleanup runtime is exposed. |

## Validation

```bash
python3 -B KM_IDSystem/scripts/check_automatic_lifecycle_scenarios.py
python3 -B -m unittest -q KM_IDSystem.docs.pursuing_goal.ids_v0_1.tests.test_stage042_automatic_lifecycle_scenarios
```

The direct checker passes all `19/19` contract checks and all `10/10`
scenarios. The checker is stdout-only and fails closed before scenario execution
when identity, source, commit, upstream hash, physical-action, protected-ref,
phase-gate, or truth-flag contracts differ.

## Safety And Truth Boundary

- Performed: approved taskpack evidence read, reviewed Stage041 scenario replay,
  isolated worker exception, read-only project filesystem free-space observation,
  process-local lifecycle evaluations, and read-only Git evidence checks.
- Not performed: real process termination, physical drive removal, disk
  allocation, external API calls, cleanup/delete, queue/worker/retry scheduler,
  production lock or lifecycle runtime, persistent state writes, database access,
  runtime output writes, raw metadata access, fake IDS data, real IDS business
  job creation, whole-stage review, GitHub upload, or app reinstall.
- `IDS-STAGE042-P4-GATE` is only a future entry gate. Phase 3 does not authorize
  Phase 4 execution in this run and does not imply production readiness.

## Rollback

Remove only the Phase 3 scenario contract, checker, focused tests, this evidence
document, and the matching Phase 3 governance/event projections. Preserve Phase
1 and Phase 2, reviewed Stage037-041 evidence, owner dirty files, raw data,
database state, runtime outputs, GitHub state, and app installation state.
