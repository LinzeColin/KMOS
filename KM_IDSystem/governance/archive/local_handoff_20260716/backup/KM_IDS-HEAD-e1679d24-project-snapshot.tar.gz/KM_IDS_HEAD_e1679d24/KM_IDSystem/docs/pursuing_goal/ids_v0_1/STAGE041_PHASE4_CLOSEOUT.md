# STAGE-041 Phase 4 - Lock Registry Closeout

## Identity

- Stage: `STAGE-041 · 锁注册与竞态控制`
- Task: `IDS-V0_1-STAGE041-P4`
- Acceptance: `ACC-STAGE-041`
- Delivery schema: `ids.stage041.lock_registry.phase4.delivery.v1`
- Report schema: `ids.stage041.lock_registry.phase4.report.v1`
- Policy: `ids.lock_registry_policy.v0_1.stage041.p2`
- Execution mode: `ISOLATED_NON_PRODUCTION_CLOSEOUT_EVIDENCE`
- Result: `PASS_ISOLATED_CLOSEOUT_PRODUCTION_DISABLED`
- Review state: `stage_review_status=pending_next_run`
- Next gate: `IDS-STAGE041-REVIEW-GATE`
- Marker: `NO_STAGE_REVIEW_THIS_RUN`

The exact Stage041 taskpack member, roadmap, and instructions remain source
verified. The machine contract binds committed Phase 3 commit
`c1e8de9c798b533cb93f68a39db00d81b11f68b8`, the Stage037 state model,
reviewed Stage039 and Stage040 delivery surfaces, and every Stage041 Phase 1-3
contract, checker, evidence file, and focused test by SHA-256.

Phase 4 reruns isolated control-metadata checks only. It writes no lock row,
queue row, database row, retry log file, cleanup manifest, audit log, or runtime
output. The current project-volume free-space observation is emitted only in
checker stdout and is not persisted in this evidence or the delivery contract.

This closeout is not whole-stage review and is not production readiness.
`push_allowed=false`; Stage041 review, batch review/upload, GitHub actions,
issue mutation, app reinstall, and STAGE-042 remain disabled.

## Job State And Lock Decision Graphs

Stage037 remains the sole authority for `ids.job_state.v1`: 8 job types, 11
states, 4 terminal states, and 21 directed transitions. Phase 4 renders that
graph without creating another state registry.

```mermaid
stateDiagram-v2
    CREATED --> QUEUED
    CREATED --> CANCELLED
    QUEUED --> CLAIMED
    QUEUED --> PAUSED
    QUEUED --> CANCELLED
    CLAIMED --> RUNNING
    CLAIMED --> PAUSE_REQUESTED
    CLAIMED --> RETRY_WAIT
    RUNNING --> SUCCEEDED
    RUNNING --> PAUSE_REQUESTED
    RUNNING --> RETRY_WAIT
    RUNNING --> FAILED
    PAUSE_REQUESTED --> PAUSED
    PAUSE_REQUESTED --> CANCELLED
    PAUSE_REQUESTED --> RETRY_WAIT
    PAUSED --> QUEUED
    PAUSED --> CANCELLED
    RETRY_WAIT --> QUEUED
    RETRY_WAIT --> PAUSED
    RETRY_WAIT --> DEAD_LETTERED
    RETRY_WAIT --> CANCELLED
```

Every Stage041 operation carries separate source and operation identity refs,
requires a shared `SOURCE_PIPELINE` guard and its operation-specific key. Keys
are sorted lexicographically and acquired by one
all-or-none compare-and-set decision. Invalid evidence fails closed, resource
pressure pauses before acquisition, and contention creates no queue record or
retry consumption.

```mermaid
flowchart TD
    R["Operation request"] --> V{"Exact resource evidence?"}
    V -->|No| M["REQUIRE_MANUAL_REVIEW"]
    V -->|Yes| G{"Resource gates pass?"}
    G -->|No| P["PAUSE_RESOURCE_GATE before lock"]
    G -->|Yes| K["Derive SOURCE_PIPELINE and operation keys"]
    K --> C["Canonical lexicographic order"]
    C --> A{"Atomic all-or-none CAS"}
    A -->|Conflict| P2["PAUSE_BEFORE_QUEUE_ADMISSION"]
    A -->|Acquired| F["Issue monotonic fencing token"]
    F --> W{"Current holder, version, token and lease?"}
    W -->|No| S["REJECT_STALE_FENCING_TOKEN"]
    W -->|Yes| O["Guard output, state, checkpoint and evidence"]
```

## Failure And Retry Log

Stage041 does not invent or persist a retry log. The checker reruns the reviewed
Stage039 Phase 4 delivery path over one real Git-tracked control document:

```text
QUEUED -> CLAIMED -> RUNNING -> RETRY_WAIT
       -> QUEUED -> CLAIMED -> RUNNING -> RETRY_WAIT
       -> QUEUED -> CLAIMED -> RUNNING -> RETRY_WAIT -> DEAD_LETTERED
```

- source: `STAGE039_REVIEWED_PHASE4_ACTUAL_ISOLATED_CONTROL_METADATA`;
- attempts: `3`;
- retry admissions: `2`;
- final `retry_count=2`, `max_retries=2`;
- final state: `DEAD_LETTERED`;
- disposition: `exhausted`;
- Chinese status: `需要人工处理`;
- output refs: empty;
- checkpoint: actual SHA-256 of the tracked control document;
- persistence: false;
- raw payload copy: false.

This is failure/retry evidence, not a persistent scheduler or automatic
recovery proof.

## Backpressure Trigger Proof

The delivery report binds the seven reviewed Stage040 trigger classes. Resource
pressure is additionally checked against Stage041 Phase 3 to prove that lock
acquisition was not attempted.

| Signal | Proven decision | Lock boundary |
|---|---|---|
| `QUEUE_SOFT_PRESSURE` | `THROTTLE_ADMISSION` | No job, lock, or persistent write. |
| `QUEUE_HARD_CAPACITY` | `DENY_NEW_ADMISSION` | No queue record, lock, or retry use. |
| `EXTERNAL_DRIVE_OFFLINE` | `PAUSE_RESOURCE_GATE` | No lock attempt; no physical removal. |
| `DISK_SPACE_INSUFFICIENT` | `PAUSE_RESOURCE_GATE` | Actual read-only observation plus controlled boundary; no lock or allocation. |
| `EXTERNAL_API_BUDGET_INSUFFICIENT` | `PAUSE_RESOURCE_GATE` | No lock attempt and no API call. |
| `JOB_TYPE_CONCURRENCY_LIMIT_REACHED` | `THROTTLE_ADMISSION` | Four decisions throttled; no jobs created. |
| `SAME_SOURCE_CONFLICT` | `THROTTLE_ADMISSION` | Reviewed one-execution/three-conflict proof; no production lock. |

Throttle, denial, resource pause, and lock contention consume no retry budget.
These checks do not prove measured production throughput or fairness.

## Lock Control Proof

The nine Phase 3 scenarios provide these exact isolated proofs:

- one duplicate click replays one canonical two-key lock set and one fence;
- all five operation families acquire once and reject one duplicate each;
- one shared source paired with five distinct operation identities permits one
  acquisition, while four cross-operation requests stop before queue admission
  with no partial lock retained;
- renewal preserves the current fence and versions;
- takeover is denied before expiry plus grace, then atomically advances fence
  and versions after eligibility;
- stale holders cannot commit, renew, release, or mutate guarded output, job
  state, checkpoint, or evidence surfaces;
- same-key/different-input idempotency conflicts, boolean/float fencing
  evidence, backward logical time, and stale release fail closed;
- no lock record is persistent and no production lock service runs.

The five operation families are `FILE_PROCESSING`, `ARCHIVE_EXTRACTION`,
`INDEX_BUILD`, `INDEX_SWITCH`, and `REPORT_GENERATION`.

## Cleanup Allowlist

Only these two classes are eligible for a future Stage044 cleanup manifest:

- `TEMP_STAGING_OUTPUT`
- `INCOMPLETE_DERIVATIVE_OUTPUT`

Every future candidate still requires approved-root identity, root-relative
path, immutable lstat identity, symlink blocking, an exclusive namespace lock,
writer quiescence, and no-follow traversal.

These five classes are protected:

- `FACT_SOURCE`
- `MANIFEST`
- `EVIDENCE_LEDGER`
- `REPORT_SNAPSHOT`
- `AUDIT_LOG`

All five exact Git-tracked Phase 3 references return `PROTECTED_ARTIFACT`.
No delete API, delete attempt, cleanup manifest write, or cleanup runtime runs.
STAGE-044 retains cleanup execution ownership.

## Automatic Recovery And Manual Handling

Stage041 proves a controlled lock-level takeover decision after expiry plus
grace. That is not task recovery and does not authorize an automatic resume:

```text
automatic_recovery_eligible_cases=[]
successful_automatic_recovery_cases_observed=[]
controlled_takeover_candidates=[
  EXPIRED_LEASE_AFTER_GRACE_REQUIRES_FRESH_EXACT_GATE_REVALIDATION
]
```

The controlled takeover candidate requires fresh exact source, policy,
resource, lease, holder, version, and fencing evidence. It creates no worker,
queue record, retry, checkpoint restore, or resumed business task.

Manual handling or an explicit downstream gate is required for:

1. unknown or stale lock evidence;
2. active lease contention;
3. drive, disk, or API resource owner revalidation;
4. worker or process loss;
5. stale-holder commit or release attempts;
6. terminal-job restart requests;
7. uncalibrated lock policy values;
8. invalid or missing contracts;
9. persistent registry reconstruction;
10. protected cleanup requests.

STAGE-042 owns automatic resume and lifecycle runtime. STAGE-043 owns process
crash recovery. This Phase executes neither.

## Safe Shutdown And Recovery

Stage041 has no persistent lock service or process to terminate. Its isolated
shutdown instructions are:

1. `STOP_NEW_LOCK_ACQUISITIONS`
2. `STOP_RENEW_AND_TAKEOVER_DECISIONS`
3. `FREEZE_LOGICAL_CLOCK_SNAPSHOT`
4. `COMPLETE_OR_RELEASE_ACCEPTED_ISOLATED_EVALUATIONS`
5. `PRESERVE_CONTRACT_EVIDENCE_AND_AUDIT_REFS`
6. `DISCARD_PROCESS_LOCAL_LOCK_REGISTRY`
7. `VERIFY_NO_PERSISTENT_OR_RUNTIME_OUTPUT`

Recovery instructions are:

1. `VERIFY_EXACT_SOURCE_POLICY_AND_UPSTREAM_HASHES`
2. `REVALIDATE_RESOURCE_AND_BACKPRESSURE_GATES`
3. `REBUILD_ONLY_FROM_DURABLE_JOB_AND_CHECKPOINT_EVIDENCE`
4. `REJECT_STALE_FENCING_TOKENS`
5. `REACQUIRE_CANONICAL_FULL_LOCK_SET`
6. `REQUIRE_MANUAL_REVIEW_FOR_UNKNOWN_OR_MISSING_EVIDENCE`
7. `DEFER_AUTOMATIC_RESUME_TO_STAGE042`
8. `DEFER_PROCESS_CRASH_RECOVERY_TO_STAGE043`

After process exit, no Stage041 registry exists. Rebuilding from durable job and
checkpoint evidence is an instruction for future persistent implementations,
not a capability supplied by this in-memory Phase. A stale holder never resumes
with its old token.

## Rollback

If any source, contract, graph, retry log, pressure proof, lock proof, cleanup
rule, shutdown, recovery, or truth check fails:

1. `STOP_ON_INVALID_DELIVERY_CONTRACT`
2. `DISABLE_ISOLATED_LOCK_RUNTIME`
3. `REJECT_NEW_LOCK_ACQUIRE_RENEW_TAKEOVER`
4. `REVERT_PHASE4_FILES_ONLY`
5. `PRESERVE_PHASE1_PHASE3_EVIDENCE`
6. `PRESERVE_RAW_DATA_AND_DURABLE_EVIDENCE`

Rollback is non-destructive. It preserves owner-authored dirty files, raw
metadata, databases, manifests, evidence ledgers, audit logs, reports, indexes,
app entries, GitHub state, and Stage041 Phase 1-3 evidence.

## Known Limits

- no persistent lock registry;
- no production lock, lease, renewal, or fencing service;
- seven lock parameters remain uncalibrated `PROPOSED` values;
- no queue, worker, or retry scheduler runtime;
- no automatic resume or lifecycle runtime;
- no process-crash recovery;
- no cleanup runtime;
- no database or raw-source access;
- static closeout does not prove production readiness.

## Truth Contract

- `delivery_contract_valid=true`
- `execution_ready=false`
- `isolated_lock_decision_runtime_replayed=true`
- `lock_scenario_replay_performed=true`
- `actual_disk_observation_replayed=true`
- `actual_isolated_worker_exception_replayed=true`
- `reviewed_failure_retry_log_replayed=true`
- `reviewed_backpressure_proof_replayed=true`
- `production_lock_runtime_performed=false`
- `persistent_lock_write_performed=false`
- `database_connection_performed=false`
- `runtime_output_written=false`
- `ids_business_source_read_performed=false`
- `raw_metadata_content_accessed=false`
- `fake_ids_business_data_used=false`
- `real_ids_business_job_created=false`
- `automatic_resume_performed=false`
- `process_crash_recovery_performed=false`
- `cleanup_runtime_performed=false`
- `whole_stage_review_performed=false`
- `batch_review_performed=false`
- `github_upload_allowed=false`
- `app_reinstall_allowed=false`

## Chinese Owner Feedback

Stage 41 四个 Phase 的本地交付证据已齐备，当前仅允许进入独立整阶段复审。
过期租约在宽限期后仅形成重新校验候选；本轮未观察到自动恢复成功，自动恢复仍由
Stage 42 实现和验证。当前不是生产运行或生产就绪证明，不提供持久锁注册、自动恢复、
崩溃恢复或清理运行时。
