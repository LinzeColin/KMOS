import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parents[4]
REPO_ROOT = ROOT.parent
BASE = ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
CONTRACT = BASE / "lock_registry" / "stage041_lock_registry_delivery_contract.json"
EVIDENCE = BASE / "STAGE041_PHASE4_CLOSEOUT.md"
CHECKER = ROOT / "scripts" / "check_lock_registry_delivery.py"
CURRENT_BATCH = BASE / "BATCH041_050_UPLOAD_LOCK.yaml"
ROADMAP = ROOT / "docs" / "governance" / "roadmap.yaml"
EVENTS = ROOT / "docs" / "governance" / "events.jsonl"

EXPECTED_STATE_HISTORY = [
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "RETRY_WAIT",
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "RETRY_WAIT",
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "RETRY_WAIT",
    "DEAD_LETTERED",
]
EXPECTED_OPERATION_FAMILIES = {
    "FILE_PROCESSING",
    "ARCHIVE_EXTRACTION",
    "INDEX_BUILD",
    "INDEX_SWITCH",
    "REPORT_GENERATION",
}
EXPECTED_PRESSURE_SIGNALS = {
    "QUEUE_SOFT_PRESSURE",
    "QUEUE_HARD_CAPACITY",
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
    "JOB_TYPE_CONCURRENCY_LIMIT_REACHED",
    "SAME_SOURCE_CONFLICT",
}
EXPECTED_CLEANUP_CLASSES = {
    "TEMP_STAGING_OUTPUT",
    "INCOMPLETE_DERIVATIVE_OUTPUT",
}
EXPECTED_PROTECTED_CLASSES = {
    "FACT_SOURCE",
    "MANIFEST",
    "EVIDENCE_LEDGER",
    "REPORT_SNAPSHOT",
    "AUDIT_LOG",
}


class Stage041LockRegistryDeliveryTests(unittest.TestCase):
    def _module(self):
        self.assertTrue(CHECKER.is_file(), f"missing Phase 4 checker: {CHECKER}")
        spec = importlib.util.spec_from_file_location(
            "stage041_lock_registry_delivery", CHECKER
        )
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def _contract(self):
        self.assertTrue(CONTRACT.is_file(), f"missing Phase 4 contract: {CONTRACT}")
        return json.loads(CONTRACT.read_text(encoding="utf-8"))

    def _report(self):
        return self._module().build_stage041_phase4_delivery_report()

    def test_phase4_contract_sources_and_fail_closed_tampering(self):
        module = self._module()
        contract = self._contract()
        self.assertTrue(EVIDENCE.is_file(), f"missing Phase 4 evidence: {EVIDENCE}")
        checks = module.validate_delivery_contract(contract)
        self.assertTrue(all(checks.values()), checks)
        self.assertEqual("IDS-V0_1-STAGE041-P4", contract["task_id"])
        self.assertEqual("ACC-STAGE-041", contract["acceptance_id"])
        for binding in contract["upstream_bindings"].values():
            path = REPO_ROOT / binding["ref"]
            self.assertTrue(path.is_file(), path)
            self.assertEqual(binding["sha256"], module.sha256_file(path))

        mutations = []
        for mutate in (
            lambda value: value.update({"unknown_root": True}),
            lambda value: value.update({"delivery_contract": []}),
            lambda value: value["delivery_contract"]["required_operation_families"].append(
                "UNREGISTERED_OPERATION"
            ),
            lambda value: value["cleanup_allowlist"][
                "cleanup_eligible_classes"
            ].append("FACT_SOURCE"),
            lambda value: value["recovery_handling"].update(
                {"successful_automatic_recovery_cases_observed": ["FAKE_SUCCESS"]}
            ),
            lambda value: value["review_gate"].update(
                {"phase4_may_mark_stage_reviewed": True}
            ),
            lambda value: value["truth_flags"].update(
                {"production_lock_runtime_performed": True}
            ),
        ):
            candidate = copy.deepcopy(contract)
            mutate(candidate)
            mutations.append(candidate)
        for candidate in mutations:
            with self.subTest(candidate=candidate):
                blocked = module.build_stage041_phase4_delivery_report(
                    contract=candidate, execute_delivery_checks=True
                )
                self.assertFalse(blocked["contract_valid"], blocked)
                self.assertFalse(blocked["delivery_checks_performed"], blocked)
                self.assertEqual("IDS-STAGE041-P4-GATE", blocked["next_gate"])
        for candidate in ([], "not-an-object"):
            with self.subTest(non_object=candidate):
                blocked = module.build_stage041_phase4_delivery_report(
                    contract=candidate, execute_delivery_checks=True
                )
                self.assertFalse(blocked["contract_valid"], blocked)
                self.assertFalse(blocked["delivery_checks_performed"], blocked)
                self.assertEqual("IDS-STAGE041-P4-GATE", blocked["next_gate"])

        source = CHECKER.read_text(encoding="utf-8")
        for forbidden_api in (
            "os.remove(",
            ".unlink(",
            "shutil.rmtree(",
            "sqlite3.connect(",
            "psycopg.connect(",
            "requests.",
            ".write_text(",
            ".write_bytes(",
        ):
            with self.subTest(forbidden_api=forbidden_api):
                self.assertNotIn(forbidden_api, source)

    def test_job_state_and_lock_decision_graphs_are_exact(self):
        graph = self._report()["state_lock_graph"]
        self.assertEqual("ids.job_state.v1", graph["state_model_version"])
        self.assertEqual(8, len(graph["job_types"]))
        self.assertEqual(11, len(graph["job_states"]))
        self.assertEqual(4, len(graph["terminal_states"]))
        self.assertEqual(21, graph["allowed_transition_count"])
        self.assertEqual(
            EXPECTED_OPERATION_FAMILIES, set(graph["operation_families"])
        )
        self.assertEqual("SOURCE_PIPELINE", graph["shared_guard_namespace"])
        self.assertEqual(2, graph["required_lock_count_per_operation"])
        self.assertEqual("ALL_OR_NONE_CAS", graph["multi_lock_atomicity"])
        self.assertIn("stateDiagram-v2", graph["mermaid_state_diagram"])
        self.assertIn("flowchart TD", graph["mermaid_lock_flow"])

    def test_failure_retry_log_replays_reviewed_actual_isolated_evidence(self):
        log = self._report()["failure_retry_log"]
        self.assertEqual(
            "STAGE039_REVIEWED_PHASE4_ACTUAL_ISOLATED_CONTROL_METADATA",
            log["source"],
        )
        self.assertEqual(EXPECTED_STATE_HISTORY, log["state_history"])
        self.assertEqual(3, log["attempt_count"])
        self.assertEqual(2, log["retry_count"])
        self.assertEqual(2, log["max_retries"])
        self.assertEqual("DEAD_LETTERED", log["final_state"])
        self.assertEqual("exhausted", log["retry_disposition"])
        self.assertEqual([], log["output_refs"])
        self.assertTrue(log["checkpoint_ref"].startswith("checkpoint:sha256:"))
        self.assertTrue(log["reviewed_stage039_delivery_valid"])
        self.assertFalse(log["persisted"])

    def test_backpressure_and_lock_trigger_proof_is_complete(self):
        report = self._report()
        pressure = report["backpressure_trigger_proof"]
        locks = report["lock_control_proof"]
        self.assertEqual(EXPECTED_PRESSURE_SIGNALS, set(pressure))
        self.assertEqual(
            "DENY_NEW_ADMISSION",
            pressure["QUEUE_HARD_CAPACITY"]["decision_action"],
        )
        for signal in (
            "EXTERNAL_DRIVE_OFFLINE",
            "DISK_SPACE_INSUFFICIENT",
            "EXTERNAL_API_BUDGET_INSUFFICIENT",
        ):
            with self.subTest(signal=signal):
                self.assertEqual("PAUSE_RESOURCE_GATE", pressure[signal]["decision_action"])
                self.assertFalse(pressure[signal]["lock_acquire_attempted"])
        self.assertEqual(EXPECTED_OPERATION_FAMILIES, set(locks["operation_families"]))
        self.assertEqual(5, locks["operation_acquired_count"])
        self.assertEqual(5, locks["operation_duplicate_conflict_count"])
        self.assertEqual(4, locks["same_source_cross_operation_conflict_count"])
        self.assertTrue(locks["takeover_advanced_fence_and_versions_atomically"])
        self.assertEqual("STALE_FENCING_TOKEN", locks["stale_commit_result_code"])
        self.assertFalse(locks["persistent_lock_write_performed"])

    def test_cleanup_allowlist_is_narrow_and_protected(self):
        cleanup = self._report()["cleanup_allowlist"]
        self.assertEqual(
            EXPECTED_CLEANUP_CLASSES, set(cleanup["cleanup_eligible_classes"])
        )
        self.assertEqual(
            EXPECTED_PROTECTED_CLASSES,
            set(cleanup["protected_artifact_classes"]),
        )
        self.assertTrue(cleanup["cleanup_manifest_required"])
        self.assertEqual(5, cleanup["protected_ref_count"])
        self.assertTrue(all(cleanup["phase3_protected_ref_checks"].values()))
        self.assertFalse(cleanup["cleanup_runtime_performed"])
        self.assertFalse(cleanup["delete_attempt_performed"])
        self.assertEqual("STAGE-044", cleanup["runtime_owner"])

    def test_recovery_classification_does_not_overclaim_automation(self):
        handling = self._report()["recovery_handling"]
        self.assertEqual([], handling["automatic_recovery_eligible_cases"])
        self.assertEqual([], handling["successful_automatic_recovery_cases_observed"])
        self.assertEqual(
            ["EXPIRED_LEASE_AFTER_GRACE_REQUIRES_FRESH_EXACT_GATE_REVALIDATION"],
            handling["controlled_takeover_candidates"],
        )
        self.assertIn("STALE_HOLDER_COMMIT_OR_RELEASE", handling["manual_action_required_cases"])
        self.assertIn("RESOURCE_GATE_OWNER_REVALIDATION", handling["manual_action_required_cases"])
        self.assertIn("WORKER_OR_PROCESS_LOSS", handling["manual_action_required_cases"])
        self.assertIn("UNCALIBRATED_LOCK_POLICY", handling["manual_action_required_cases"])
        self.assertFalse(handling["automatic_resume_allowed"])
        self.assertFalse(handling["automatic_resume_performed"])
        self.assertEqual("STAGE-042", handling["automatic_resume_runtime_owner"])
        self.assertEqual("STAGE-043", handling["process_crash_recovery_runtime_owner"])

    def test_safe_shutdown_recovery_and_rollback_are_explicit(self):
        report = self._report()
        shutdown = report["safe_shutdown_and_recovery"]
        self.assertFalse(shutdown["persistent_lock_registry_available_after_exit"])
        self.assertFalse(shutdown["process_termination_performed"])
        self.assertFalse(shutdown["automatic_process_recovery_performed"])
        self.assertIn("STOP_NEW_LOCK_ACQUISITIONS", shutdown["shutdown_steps"])
        self.assertIn("REJECT_STALE_FENCING_TOKENS", shutdown["recovery_steps"])
        self.assertIn("DEFER_AUTOMATIC_RESUME_TO_STAGE042", shutdown["recovery_steps"])
        self.assertIn("DEFER_PROCESS_CRASH_RECOVERY_TO_STAGE043", shutdown["recovery_steps"])
        self.assertGreaterEqual(len(report["rollback_steps"]), 6)
        self.assertIn("DISABLE_ISOLATED_LOCK_RUNTIME", report["rollback_steps"])

    def test_delivery_truth_and_chinese_feedback_stop_at_review(self):
        report = self._report()
        self.assertEqual("PASS_ISOLATED_CLOSEOUT_PRODUCTION_DISABLED", report["result"])
        self.assertEqual("pending_next_run", report["stage_review_status"])
        self.assertEqual("IDS-STAGE041-REVIEW-GATE", report["next_gate"])
        self.assertFalse(report["execution_ready"])
        for flag in (
            "production_runtime_activation_performed",
            "production_lock_runtime_performed",
            "persistent_lock_write_performed",
            "database_connection_performed",
            "runtime_output_written",
            "ids_business_source_read_performed",
            "raw_metadata_content_accessed",
            "fake_ids_business_data_used",
            "real_ids_business_job_created",
            "automatic_resume_performed",
            "process_crash_recovery_performed",
            "cleanup_runtime_performed",
            "whole_stage_review_performed",
            "batch_review_performed",
            "github_upload_allowed",
            "app_reinstall_allowed",
        ):
            with self.subTest(flag=flag):
                self.assertFalse(report[flag])
        self.assertIn("整阶段复审", report["owner_feedback_zh"])
        self.assertIn("未观察到自动恢复成功", report["owner_feedback_zh"])
        self.assertIn("不是生产运行或生产就绪证明", report["owner_feedback_zh"])

    def test_phase4_governance_history_routes_to_completed_whole_stage_review(self):
        self.assertTrue(EVIDENCE.is_file(), f"missing closeout: {EVIDENCE}")
        current_batch = CURRENT_BATCH.read_text(encoding="utf-8")
        roadmap = ROADMAP.read_text(encoding="utf-8")
        self.assertIn(
            'stage041_phase4_state:\n'
            '    status: "stage041_phase4_completed_review_pending"\n'
            '    current_task_id: "IDS-V0_1-STAGE041-P4"\n'
            '    next_allowed_task_id: "IDS-V0_1-STAGE041-REVIEW"',
            current_batch,
        )
        self.assertIn(
            'stage041_phase4_state:\n'
            '    current_stage_id: "IDS-STAGE041"\n'
            '    current_phase_id: "IDS-STAGE041-P4"\n'
            '    current_task_id: "IDS-V0_1-STAGE041-P4"\n'
            '    next_gate_id: "IDS-STAGE041-REVIEW-GATE"',
            roadmap,
        )
        self.assertIn('status: "stage041_completed_reviewed_local"', current_batch)
        self.assertIn('next_gate: "IDS-STAGE042-P1-GATE"', current_batch)
        self.assertIn('current_phase_id: "IDS-STAGE041-REVIEW"', roadmap)
        self.assertIn('next_gate_id: "IDS-STAGE042-P1-GATE"', roadmap)
        self.assertIn('push_allowed: false', current_batch)

        events = [
            json.loads(line)
            for line in EVENTS.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        matching = [
            item
            for item in events
            if item.get("event_id") == "EVT-IDS-V0_1-STAGE041-P4-20260715-001"
        ]
        self.assertEqual(1, len(matching), matching)
        self.assertEqual("phase_completed", matching[0]["event_type"])
        self.assertEqual("IDS-V0_1-STAGE041-P4", matching[0]["task_id"])
        self.assertIn("whole_stage_review_performed=false", matching[0]["notes"])
        self.assertIn("batch_review_performed=false", matching[0]["notes"])
        self.assertIn("push_allowed=false", matching[0]["notes"])

    def test_cli_returns_exact_machine_report(self):
        module = self._module()
        completed = subprocess.run(
            [sys.executable, "-B", str(CHECKER)],
            cwd=REPO_ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
        self.assertEqual("", completed.stderr)
        payload = json.loads(completed.stdout)
        self.assertTrue(payload["delivery_contract_valid"], payload)
        self.assertEqual("IDS-STAGE041-REVIEW-GATE", payload["next_gate"])
        self.assertEqual(module.VALID_RESULT, payload["result"])


if __name__ == "__main__":
    unittest.main()
