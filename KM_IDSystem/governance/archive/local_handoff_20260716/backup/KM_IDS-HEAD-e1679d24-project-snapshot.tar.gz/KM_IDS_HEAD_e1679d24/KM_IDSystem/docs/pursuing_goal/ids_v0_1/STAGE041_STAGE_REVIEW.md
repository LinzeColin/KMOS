# STAGE-041 Whole-Stage Review

## Review Identity

- Task: `IDS-V0_1-STAGE041-REVIEW`
- Acceptance: `ACC-STAGE-041`
- Review gate: `IDS-STAGE041-REVIEW-GATE`
- Result after repairs: `completed_reviewed_local`
- Next gate: `IDS-STAGE042-P1-GATE`
- Production: disabled

This run independently reviewed Stage 041 Phase 1 through Phase 4 against the
approved taskpack and v0.1 roadmap/instructions. It did not enter Stage 042,
perform the ten-stage batch review, upload to GitHub, or reinstall app entries.

## Source Reverification

The review checker rehashes the three approved external files and reads only
the exact Stage 041 member from the ZIP with Python `zipfile`; it does not
extract the archive.

| Source | Verified SHA-256 |
|---|---|
| `IDS_Taskpack_v0_1_only_中文修订版.zip` | `55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3` |
| `IDS_v0_1_Final_Chinese_Revised/stages/STAGE-041_锁注册与竞态控制.md` | `2258a7b57c6c2881f208f43fbe2862c7815a2794c908d6fef108a1a4b5a2ad36` |
| `IDS_Codex开发Roadmap_v0_1_only_中文修订版.txt` | `a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6` |
| `IDS_Codex使用说明_v0_1_only_中文修订版.txt` | `ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8` |

`/Users/linzezhang/Downloads/IDS_MetaData` remains path-only. No content under
it was listed, opened, hashed, copied, scanned, dumped, moved, modified, or
deleted.

## Findings And Repairs

### STAGE041-REVIEW-F1 - Critical - Repaired

The Phase 1 design required a shared source guard plus an operation-specific
guard, but the Phase 2 request exposed one `resource_identity_ref` and derived
both keys from it. A real index-version ref and index-namespace ref therefore
produced different `SOURCE_PIPELINE` keys, allowing index build and index switch
for one source to acquire concurrently. Existing scenarios reused one ref and
masked the missing two-level identity model.

Repair: requests and records now carry `source_identity_ref` and
`operation_identity_ref`. The shared key derives only from the source identity;
the specific key derives only from the operation identity. Phase 3 proves one
shared source paired with five distinct operation identities still permits only
one complete lock set and four conflicts.

### STAGE041-REVIEW-F2 - Critical - Repaired

Python equality allowed JSON `true` and numeric `1.0` to compare equal to
fencing token/version integer `1`. Malformed evidence could therefore receive
`CURRENT_FENCE_VALID` and authorize a guarded commit.

Repair: fencing tokens and every lock version must be strict positive JSON
integers: `bool` and `float` are rejected. Evidence must also name the exact
canonical lock set. Invalid evidence returns `INVALID_FENCING_EVIDENCE` and
cannot commit.

### STAGE041-REVIEW-F3 - Important - Repaired

Phase 1 required `same_idempotency_key_different_input_action=REJECT_CONFLICT`,
but Phase 2 only keyed its replay ledger by the complete request. Reusing one
idempotency key with a different source/operation request could acquire another
lock set.

Repair: the idempotency key is now the SHA-256 of job identity, attempt identity
and the canonical full lock set. A same-key/different-input request returns
`IDEMPOTENCY_KEY_INPUT_CONFLICT` / `REJECT_CONFLICT`, exposes no rejected refs,
creates no lock, and invokes no operation.

### STAGE041-REVIEW-F4 - Important - Repaired

The logical-clock slice accepted renewal at a timestamp earlier than the
original acquisition. This shortened the lease to a time before acquisition
and could make takeover eligible prematurely.

Repair: request timestamps must be non-negative JSON integers and may not move
backward from acquire or latest renewal time. Backward renew, commit, or release
returns `NON_MONOTONIC_LOGICAL_TIME` without mutating the lock set.

### STAGE041-REVIEW-F5 - Minor - Repaired

Phase 1 specified `REJECT_STALE_RELEASE`, while the runtime returned the generic
`REQUIRE_MANUAL_REVIEW` action for a stale release. The lock was not removed,
but the machine decision did not match the declared contract.

Repair: stale, malformed, or backward-time release attempts now use the
explicit `REJECT_STALE_RELEASE` action and a dedicated restrained Chinese status.

Final finding count: `2 Critical / 2 Important / 1 Minor`; all five findings
are repaired and machine checked.

## Acceptance Decision

`ACC-STAGE-041` is closed only as `completed_reviewed_local`. The Phase 1-4
contracts remain isolated and production-disabled. There is no persistent lock
registry, production lease/fencing runtime, queue, worker, retry scheduler,
automatic resume, crash recovery, cleanup execution, database connection, raw
metadata access, fake IDS business data, GitHub upload, or app reinstall.

The next and only authorized task is `IDS-V0_1-STAGE042-P1` in a separate run.
The `BATCH041_050` upload lock remains `push_allowed=false`; no single-Stage
GitHub upload gate is created.

## Validation

Final validation passed the review checker with `5/5` source-integrity,
`4/4` phase, `5/5` repaired-finding, `5/5` governance and `2/2` Git-index
binding checks. Focused review tests passed `11/11`; Stage005 passed `159/159`;
the Stage039 historical review passed `6/6`; Stage040-041 aggregate regression
passed `118/118`; and full IDS v0.1 discovery passed `800/800`.

The first full discovery exposed three stale Stage038 future-state assertions;
all three were restricted to the exact `IDS-STAGE042-P1-GATE` route and passed
`3/3` before the final `800/800` rerun. Events parsed `200` records with zero
duplicate IDs. Owner render drift/reference and changed-only governance
errors/warnings were `0/0`; full semantic governance also returned `0/0`.
Direct Stage005 validation failed closed only on the four preserved owner dirty
paths and reported no forbidden runtime path, missing source, event, phase-state,
or data-boundary issue.

## Stop Markers

- `NO_STAGE042_THIS_RUN`
- `NO_BATCH_REVIEW_THIS_RUN`
- `NO_GITHUB_UPLOAD`
- `NO_APP_REINSTALL`
- `NO_RAW_METADATA_ACCESS`
- `NO_FAKE_IDS_BUSINESS_DATA`

## Rollback

Revert only the Stage 041 review repairs, rebuilt Phase 1-4 hash chain, review
artifacts, and this review's governance transition. Preserve earlier stages,
approved external sources, raw data, durable evidence, owner-authored dirty
files, GitHub state, and app entries. On any inconsistency, restore
`IDS-STAGE041-REVIEW-GATE`; do not proceed to Stage 042.
