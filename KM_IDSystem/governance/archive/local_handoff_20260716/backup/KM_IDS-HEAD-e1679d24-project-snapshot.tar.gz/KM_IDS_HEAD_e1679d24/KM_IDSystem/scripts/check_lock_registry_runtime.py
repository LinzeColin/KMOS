#!/usr/bin/env python3
"""Run and validate the STAGE-041 Phase 2 isolated lock registry slice."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
from typing import Any, Mapping, Optional


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent
CONTRACT_PATH = (
    PROJECT_ROOT
    / "docs/pursuing_goal/ids_v0_1/lock_registry/"
    "stage041_lock_registry_runtime_contract.json"
)
POLICY_VERSION = "ids.lock_registry_policy.v0_1.stage041.p2"
TASK_ID = "IDS-V0_1-STAGE041-P2"
ACCEPTANCE_ID = "ACC-STAGE-041"
PRODUCTION_CALIBRATION_TASK_ID = "TASK-" + "OP" + "ME-B-001"
CONTROL_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md"
)
OPERATION_CONTROL_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE041_ENTRY_CONTRACT.md"
)
AUDIT_REF = (
    "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md#Controlled-Evidence"
)
EXPECTED_PARAMETERS = {
    "lease_duration_seconds": 30,
    "renewal_interval_seconds": 10,
    "expiry_grace_seconds": 5,
    "acquisition_timeout_seconds": 1,
    "maximum_wait_seconds": 0,
    "retry_jitter_seconds": 0,
    "deadlock_timeout_seconds": 1,
}
EXPECTED_UPSTREAM = {
    "phase1_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_contract.json",
        "3b8c753dd277dab7d55a611f548e9dd14fd299a6123a8c5a25547ac169b33c0e",
    ),
    "phase1_checker": (
        "KM_IDSystem/scripts/check_lock_registry.py",
        "e957e9639cf5fc14b38eaa96d08b9884b8bbb59264beda223b68d36ead9ce450",
    ),
    "phase1_boundary": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md",
        "d8f2852f01a096c67460da34fab8e372f994cb13e10f93e8faf406d570a94483",
    ),
    "stage038_conflict_scenarios": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/worker_queue_baseline/"
        "stage038_worker_queue_scenarios.json",
        "0ec9f1a0de6ec24d64d4108214ea426f9171b15eebdd6c3c60693fade62f2961",
    ),
    "stage039_retry_runtime": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/retry_dead_letter/"
        "stage039_retry_dead_letter_runtime_contract.json",
        "5fc9b49b0ede0fdbc87311f3280ffc69e8ec8e59f219b17a04a2ccae1e9124c0",
    ),
    "stage040_backpressure_runtime": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
        "stage040_backpressure_runtime_contract.json",
        "3db2409b082b9f788e061dfbb3a8e33ad8459c8e56a863e21fe0faeca8581b5c",
    ),
}
EXPECTED_SOURCE = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-041_锁注册与竞态控制.md"
    ),
    "source_member_match_count": 1,
    "source_member_sha256": (
        "2258a7b57c6c2881f208f43fbe2862c7815a2794c908d6fef108a1a4b5a2ad36"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}
REQUEST_FIELDS = {
    "source_identity_ref",
    "operation_identity_ref",
    "operation_family",
    "holder_job_id",
    "holder_attempt_id",
    "lease_owner_ref",
    "requested_at_epoch_seconds",
    "input_refs",
    "idempotency_key",
    "policy_version",
}
RECORD_FIELDS = {
    "lock_key",
    "lock_namespace",
    "source_identity_ref",
    "operation_identity_ref",
    "operation_scope",
    "holder_job_id",
    "holder_attempt_id",
    "lease_owner_ref",
    "lease_expires_at",
    "fencing_token",
    "lock_version",
    "acquired_at",
    "renewed_at",
    "released_at",
    "release_reason",
    "audit_ref",
    "checkpoint_ref",
    "policy_version",
}
FALSE_TRUTH_FLAGS = {
    "queue_runtime_performed",
    "worker_runtime_performed",
    "retry_scheduler_performed",
    "automatic_resume_performed",
    "crash_recovery_runtime_performed",
    "cleanup_runtime_performed",
    "database_connection_performed",
    "persistent_lock_write_performed",
    "state_registry_write_performed",
    "runtime_output_written",
    "external_api_call_performed",
    "ids_business_source_read_performed",
    "raw_metadata_content_accessed",
    "fake_ids_business_data_used",
    "real_ids_business_job_created",
    "production_runtime_activation_performed",
    "github_upload_allowed",
    "app_reinstall_allowed",
}
TRUE_TRUTH_FLAGS = {
    "parameter_values_assigned",
    "isolated_lock_decision_runtime_performed",
    "actual_control_ref_verified",
    "acquire_evaluation_performed",
    "renew_evaluation_performed",
    "release_evaluation_performed",
    "takeover_evaluation_performed",
    "fencing_evaluation_performed",
}


def _canonical_digest(value: Any) -> str:
    try:
        encoded = json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError):
        encoded = b"INVALID_NON_JSON_CONTROL_METADATA"
    return hashlib.sha256(encoded).hexdigest()


def _canonical_lock_key(namespace: str, identity_ref: str) -> str:
    digest = _canonical_digest(
        {"lock_namespace": namespace, "resource_identity_ref": identity_ref}
    )
    return f"{namespace}:{digest}"


def _canonical_input_refs(source_ref: str, operation_ref: str) -> list[str]:
    return [source_ref] if source_ref == operation_ref else [source_ref, operation_ref]


def _is_json_integer(value: Any, *, minimum: int = 0) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= minimum


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _keys_exact(value: Any, expected: set[str]) -> bool:
    return isinstance(value, dict) and set(value) == expected


def _git_tracked(relative: str) -> bool:
    result = subprocess.run(
        ["git", "ls-files", "--error-unmatch", "--", relative],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _repo_relative_ref(value: Any) -> Optional[str]:
    if not isinstance(value, str) or not value.startswith("repo:"):
        return None
    if "\\" in value or len(value) > 512:
        return None
    relative = value.removeprefix("repo:")
    pure = PurePosixPath(relative)
    normalized = pure.as_posix()
    if (
        pure.is_absolute()
        or ".." in pure.parts
        or not normalized.startswith("KM_IDSystem/")
        or "ids_metadata" in normalized.lower()
    ):
        return None
    path = REPO_ROOT / normalized
    if not path.is_file() or not _git_tracked(normalized):
        return None
    return normalized


def _upstream_valid(contract: Mapping[str, Any]) -> bool:
    bindings = contract.get("upstream_bindings")
    if not isinstance(bindings, dict) or set(bindings) != set(EXPECTED_UPSTREAM):
        return False
    for name, (relative, expected_hash) in EXPECTED_UPSTREAM.items():
        if bindings.get(name) != {"ref": relative, "sha256": expected_hash}:
            return False
        path = REPO_ROOT / relative
        if not path.is_file() or _sha256(path) != expected_hash:
            return False
    return True


def load_contract(path: Path = CONTRACT_PATH) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Stage041 Phase2 contract must be an object")
    return value


def evaluate_contract(contract: Any) -> dict[str, bool]:
    """Validate the complete contract shape; unknown nested fields fail closed."""
    if not isinstance(contract, dict):
        return {"contract_is_object": False}
    policy = contract.get("policy")
    scope = contract.get("operation_scope_contract")
    request = contract.get("request_contract")
    decision = contract.get("decision_contract")
    record = contract.get("registry_record_contract")
    control = contract.get("control_metadata_contract")
    projection = contract.get("human_status_projection")
    binding = contract.get("registry_binding")
    runtime = contract.get("runtime_boundary")
    rollback = contract.get("rollback")
    truth = contract.get("truth_flags")
    root_keys = {
        "schema_version",
        "stage",
        "phase",
        "task_id",
        "acceptance_id",
        "execution_mode",
        "policy_contract_id",
        "contract_state",
        "next_gate",
        "source_binding",
        "upstream_bindings",
        "policy",
        "operation_scope_contract",
        "request_contract",
        "decision_contract",
        "registry_record_contract",
        "control_metadata_contract",
        "human_status_projection",
        "registry_binding",
        "runtime_boundary",
        "rollback",
        "truth_flags",
    }
    expected_policy_keys = {
        "policy_version",
        "parameters",
        "parameter_provenance",
        "parameter_relationships",
        "logical_clock_only",
        "wall_clock_sleep_allowed",
        "parameter_source",
        "fact_level",
        "production_calibrated",
        "production_calibration_required",
        "production_calibration_task_id",
        "rollback_policy",
    }
    provenance_keys = {
        "unit",
        "source",
        "rationale",
        "policy_version",
        "validation_evidence",
        "rollback",
    }
    scope_keys = {
        "FILE_PROCESSING",
        "ARCHIVE_EXTRACTION",
        "INDEX_BUILD",
        "INDEX_SWITCH",
        "REPORT_GENERATION",
    }
    scope_valid = isinstance(scope, dict) and set(scope) == scope_keys
    if scope_valid:
        scope_valid = all(
            _keys_exact(value, {"job_types", "required_lock_namespaces"})
            and isinstance(value["job_types"], list)
            and len(value["job_types"]) == 1
            and value["required_lock_namespaces"] == [
                "SOURCE_PIPELINE",
                name,
            ]
            for name, value in scope.items()
        )
    parameters = policy.get("parameters") if isinstance(policy, dict) else None
    provenance = (
        policy.get("parameter_provenance") if isinstance(policy, dict) else None
    )
    parameters_valid = parameters == EXPECTED_PARAMETERS
    provenance_valid = (
        isinstance(provenance, dict)
        and set(provenance) == set(EXPECTED_PARAMETERS)
        and all(_keys_exact(item, provenance_keys) for item in provenance.values())
        and all(item["unit"] == "seconds" for item in provenance.values())
        and all(item["policy_version"] == POLICY_VERSION for item in provenance.values())
        and all(item["rationale"] for item in provenance.values())
    )
    projections = {
        "ACQUIRED",
        "RENEWED",
        "RELEASED",
        "PAUSE_BEFORE_QUEUE_ADMISSION",
        "REJECT_COMMIT",
        "COMMIT_ALLOWED",
        "REJECT_CONFLICT",
        "REJECT_STALE_RELEASE",
        "REQUIRE_MANUAL_REVIEW",
    }
    projection_valid = isinstance(projection, dict) and set(projection) == projections
    if projection_valid:
        projection_valid = all(
            _keys_exact(
                item,
                {"label_zh", "owner_action_zh", "owner_attention_required"},
            )
            and isinstance(item["label_zh"], str)
            and isinstance(item["owner_action_zh"], str)
            and isinstance(item["owner_attention_required"], bool)
            for item in projection.values()
        )
    checks = {
        "root_schema_exact": _keys_exact(contract, root_keys),
        "identity_exact": (
            contract.get("schema_version") == "ids.stage041.lock_registry.phase2.v1"
            and contract.get("stage") == "STAGE-041"
            and contract.get("phase") == "Phase 2"
            and contract.get("task_id") == TASK_ID
            and contract.get("acceptance_id") == ACCEPTANCE_ID
            and contract.get("execution_mode")
            == "ISOLATED_NON_PRODUCTION_LOCK_DECISION_SLICE"
            and contract.get("policy_contract_id") == POLICY_VERSION
            and contract.get("contract_state")
            == "PHASE2_ISOLATED_LOCK_DECISION_SLICE_ENABLED_PRODUCTION_DISABLED"
            and contract.get("next_gate") == "IDS-STAGE041-P3-GATE"
        ),
        "source_binding_exact": contract.get("source_binding") == EXPECTED_SOURCE,
        "upstream_bindings_current": _upstream_valid(contract),
        "policy_schema_exact": _keys_exact(policy, expected_policy_keys),
        "parameters_exact": parameters_valid,
        "parameter_provenance_complete": provenance_valid,
        "parameter_bounds_valid": (
            parameters_valid
            and parameters["lease_duration_seconds"]
            == 3 * parameters["renewal_interval_seconds"]
            and 0
            < parameters["expiry_grace_seconds"]
            < parameters["renewal_interval_seconds"]
            < parameters["lease_duration_seconds"]
            and parameters["acquisition_timeout_seconds"]
            == parameters["deadlock_timeout_seconds"]
            and parameters["maximum_wait_seconds"] == 0
            and parameters["retry_jitter_seconds"] == 0
        ),
        "parameter_truth_bounded": (
            isinstance(policy, dict)
            and policy.get("policy_version") == POLICY_VERSION
            and policy.get("logical_clock_only") is True
            and policy.get("wall_clock_sleep_allowed") is False
            and policy.get("fact_level") == "PROPOSED"
            and policy.get("production_calibrated") is False
            and policy.get("production_calibration_required") is True
            and policy.get("production_calibration_task_id")
            == PRODUCTION_CALIBRATION_TASK_ID
        ),
        "operation_scope_exact": scope_valid,
        "request_contract_exact": request
        == {
            "required_fields": [
                "source_identity_ref",
                "operation_identity_ref",
                "operation_family",
                "holder_job_id",
                "holder_attempt_id",
                "lease_owner_ref",
                "requested_at_epoch_seconds",
                "input_refs",
                "idempotency_key",
                "policy_version",
            ],
            "reference_only": True,
            "raw_path_allowed": False,
            "raw_payload_allowed": False,
            "unknown_field_action": "REQUIRE_MANUAL_REVIEW",
            "identity_roles": {
                "source_identity_ref": "SOURCE_PIPELINE",
                "operation_identity_ref": "OPERATION_SPECIFIC_NAMESPACE",
            },
            "idempotency_derivation": "SHA256_JOB_ATTEMPT_CANONICAL_FULL_LOCK_SET",
            "same_idempotency_key_different_input_action": "REJECT_CONFLICT",
        },
        "decision_contract_exact": decision
        == {
            "acquire": "CANONICAL_ALL_OR_NONE_CAS",
            "renew": "MATCHING_LIVE_HOLDER_NO_FENCE_ADVANCE",
            "takeover": "EXPIRY_PLUS_GRACE_ATOMIC_FENCE_AND_VERSION_ADVANCE",
            "commit": "CURRENT_HOLDER_FENCE_VERSION_AND_LIVE_LEASE_REQUIRED",
            "release": "MATCHING_HOLDER_FENCE_VERSION_IDEMPOTENT",
            "contention": "PAUSE_BEFORE_QUEUE_ADMISSION_NO_RETRY_NO_PARTIAL_LOCK",
            "idempotency_conflict": "REJECT_CONFLICT_NO_LOCK_OR_OPERATION",
            "non_monotonic_time": "REQUIRE_MANUAL_REVIEW_NO_MUTATION",
            "unknown_or_invalid": "REQUIRE_MANUAL_REVIEW",
        },
        "registry_record_contract_exact": record
        == {
            "required_fields": [
                "lock_key",
                "lock_namespace",
                "source_identity_ref",
                "operation_identity_ref",
                "operation_scope",
                "holder_job_id",
                "holder_attempt_id",
                "lease_owner_ref",
                "lease_expires_at",
                "fencing_token",
                "lock_version",
                "acquired_at",
                "renewed_at",
                "released_at",
                "release_reason",
                "audit_ref",
                "checkpoint_ref",
                "policy_version",
            ],
            "registry_mode": "IN_MEMORY_CONTROL_METADATA_ONLY",
            "canonical_key_order_required": True,
            "partial_record_retention_allowed": False,
            "persistent_write_allowed": False,
        },
        "control_metadata_exact": control
        == {
            "input_refs": [CONTROL_REF, OPERATION_CONTROL_REF],
            "input_refs_must_be_git_tracked": True,
            "raw_body_allowed": False,
            "output_refs": [],
            "checkpoint_ref_format": (
                "checkpoint:sha256:<canonical-decision-digest>"
            ),
            "error_ref_format": "error:<safe-control-reason-code>",
            "audit_ref": AUDIT_REF,
        },
        "control_refs_real_and_tracked": all(
            _repo_relative_ref(ref) is not None
            for ref in (CONTROL_REF, OPERATION_CONTROL_REF)
        ),
        "human_status_projection_exact": projection_valid,
        "registry_binding_exact": binding
        == {
            "model_id": "MOD-010",
            "formula_id": "FORM-010",
            "parameter_ids": [f"PARAM-{value:03d}" for value in range(65, 72)],
            "production_calibration_task_id": PRODUCTION_CALIBRATION_TASK_ID,
        },
        "runtime_boundary_exact": _keys_exact(
            runtime,
            {
                "isolated_lock_decision_runtime_allowed",
                "logical_clock_evaluation_allowed",
                "wall_clock_sleep_allowed",
                "queue_runtime_allowed",
                "worker_runtime_allowed",
                "retry_scheduler_allowed",
                "automatic_resume_allowed",
                "crash_recovery_allowed",
                "cleanup_runtime_allowed",
                "database_allowed",
                "persistent_lock_write_allowed",
                "state_registry_write_allowed",
                "runtime_output_write_allowed",
                "external_api_allowed",
                "raw_metadata_access_allowed",
                "ids_business_job_allowed",
                "fake_ids_business_data_allowed",
                "production_activation_allowed",
            },
        )
        and runtime.get("isolated_lock_decision_runtime_allowed") is True
        and runtime.get("logical_clock_evaluation_allowed") is True
        and all(
            runtime.get(name) is False
            for name in set(runtime)
            - {
                "isolated_lock_decision_runtime_allowed",
                "logical_clock_evaluation_allowed",
            }
        ),
        "rollback_exact": rollback
        == {
            "trigger": "INVALID_CONTRACT_PARAMETER_REQUEST_LEASE_OR_FENCE_EVIDENCE",
            "action": (
                "DISABLE_ISOLATED_LOCK_RUNTIME_REQUIRE_MANUAL_REVIEW_"
                "AND_REVERT_PHASE2_FILES_ONLY"
            ),
            "preserve_phase1": True,
            "preserve_stage037_stage040": True,
            "preserve_source_and_evidence": True,
            "github_action_allowed": False,
        },
        "truth_flags_exact": (
            _keys_exact(truth, TRUE_TRUTH_FLAGS | FALSE_TRUTH_FLAGS)
            and all(truth.get(name) is True for name in TRUE_TRUTH_FLAGS)
            and all(truth.get(name) is False for name in FALSE_TRUTH_FLAGS)
        ),
    }
    return checks


def build_control_request(
    source_identity_ref: str,
    *,
    operation_identity_ref: Optional[str] = None,
    operation_family: str,
    holder_role: str,
    requested_at_epoch_seconds: int,
) -> dict[str, Any]:
    """Create deterministic control metadata from a real repository reference."""
    operation_identity_ref = operation_identity_ref or source_identity_ref
    identity = _canonical_digest(
        {
            "source_identity_ref": source_identity_ref,
            "operation_identity_ref": operation_identity_ref,
            "operation_family": operation_family,
            "holder_role": holder_role,
        }
    )
    holder_job_id = f"control-job:{identity[:24]}"
    holder_attempt_id = f"control-attempt:{identity[24:48]}"
    lock_keys = sorted(
        [
            _canonical_lock_key("SOURCE_PIPELINE", source_identity_ref),
            _canonical_lock_key(operation_family, operation_identity_ref),
        ]
    )
    idempotency = _canonical_digest(
        {
            "holder_job_id": holder_job_id,
            "holder_attempt_id": holder_attempt_id,
            "lock_keys": lock_keys,
        }
    )
    return {
        "source_identity_ref": source_identity_ref,
        "operation_identity_ref": operation_identity_ref,
        "operation_family": operation_family,
        "holder_job_id": holder_job_id,
        "holder_attempt_id": holder_attempt_id,
        "lease_owner_ref": f"control-owner:{holder_role}",
        "requested_at_epoch_seconds": requested_at_epoch_seconds,
        "input_refs": _canonical_input_refs(
            source_identity_ref, operation_identity_ref
        ),
        "idempotency_key": f"idempotency:sha256:{idempotency}",
        "policy_version": POLICY_VERSION,
    }


class IsolatedLockRegistry:
    """A deterministic process-local registry with no persistence or waiting."""

    def __init__(self, contract: Mapping[str, Any]):
        self.contract = copy.deepcopy(dict(contract))
        self.contract_valid = all(evaluate_contract(self.contract).values())
        self.parameters = self.contract.get("policy", {}).get("parameters", {})
        self.scopes = self.contract.get("operation_scope_contract", {})
        self.projections = self.contract.get("human_status_projection", {})
        self._locks: dict[str, dict[str, Any]] = {}
        self._lock_versions: dict[str, int] = {}
        self._fencing_counter = 0
        self._operation_ledger: dict[str, dict[str, Any]] = {}

    def snapshot(self) -> dict[str, Any]:
        return copy.deepcopy(
            {
                "locks": self._locks,
                "lock_versions": self._lock_versions,
                "fencing_counter": self._fencing_counter,
                "operation_ledger_size": len(self._operation_ledger),
            }
        )

    def _request_shape_valid(self, request: Any) -> bool:
        if not self.contract_valid or not _keys_exact(request, REQUEST_FIELDS):
            return False
        if request.get("policy_version") != POLICY_VERSION:
            return False
        if request.get("operation_family") not in self.scopes:
            return False
        source_ref = request.get("source_identity_ref")
        operation_ref = request.get("operation_identity_ref")
        if _repo_relative_ref(source_ref) is None:
            return False
        if _repo_relative_ref(operation_ref) is None:
            return False
        if request.get("input_refs") != _canonical_input_refs(source_ref, operation_ref):
            return False
        if not _is_json_integer(request.get("requested_at_epoch_seconds")):
            return False
        for name in (
            "holder_job_id",
            "holder_attempt_id",
            "lease_owner_ref",
            "idempotency_key",
        ):
            value = request.get(name)
            if not isinstance(value, str) or not value or len(value) > 256:
                return False
        value = request["idempotency_key"]
        return (
            value.startswith("idempotency:sha256:")
            and len(value) == len("idempotency:sha256:") + 64
        )

    def _expected_idempotency_key(self, request: Mapping[str, Any]) -> str:
        digest = _canonical_digest(
            {
                "holder_job_id": request["holder_job_id"],
                "holder_attempt_id": request["holder_attempt_id"],
                "lock_keys": self._lock_keys(request),
            }
        )
        return f"idempotency:sha256:{digest}"

    def _request_valid(self, request: Any) -> bool:
        return self._request_shape_valid(request) and request.get(
            "idempotency_key"
        ) == self._expected_idempotency_key(request)

    def _lock_keys(self, request: Mapping[str, Any]) -> list[str]:
        namespaces = self.scopes[request["operation_family"]][
            "required_lock_namespaces"
        ]
        return sorted(
            _canonical_lock_key(
                name,
                (
                    request["source_identity_ref"]
                    if name == "SOURCE_PIPELINE"
                    else request["operation_identity_ref"]
                ),
            )
            for name in namespaces
        )

    def _ledger_key(
        self,
        operation: str,
        request: Mapping[str, Any],
        evidence: Optional[Mapping[str, Any]] = None,
    ) -> str:
        return _canonical_digest(
            {"operation": operation, "request": request, "evidence": evidence}
        )

    def _human_status(self, decision_action: str) -> dict[str, Any]:
        return copy.deepcopy(
            self.projections.get(
                decision_action,
                {
                    "label_zh": "等待人工复核",
                    "owner_action_zh": "检查请求、租约与 fencing 证据",
                    "owner_attention_required": True,
                },
            )
        )

    def _result(
        self,
        operation: str,
        request: Optional[Mapping[str, Any]],
        *,
        result_code: str,
        decision_action: str,
        lock_keys: Optional[list[str]] = None,
        fencing_token: Optional[int] = None,
        lock_versions: Optional[dict[str, int]] = None,
        lease_expires_at: Optional[int] = None,
        error_code: Optional[str] = None,
    ) -> dict[str, Any]:
        safe_request = request if self._request_valid(request) else None
        result = {
            "operation": operation,
            "decision_valid": safe_request is not None,
            "result_code": result_code,
            "decision_action": decision_action,
            "holder_job_id": (
                safe_request.get("holder_job_id") if safe_request else None
            ),
            "holder_attempt_id": (
                safe_request.get("holder_attempt_id") if safe_request else None
            ),
            "lease_owner_ref": (
                safe_request.get("lease_owner_ref") if safe_request else None
            ),
            "lock_keys": list(lock_keys or []),
            "fencing_token": fencing_token,
            "lock_versions": copy.deepcopy(lock_versions or {}),
            "lease_expires_at": lease_expires_at,
            "input_refs": list(safe_request.get("input_refs", [])) if safe_request else [],
            "output_refs": [],
            "error_ref": f"error:{error_code}" if error_code else None,
            "audit_ref": AUDIT_REF,
            "human_status": self._human_status(decision_action),
            "queue_record_created": False,
            "retry_budget_consumed": False,
            "partial_lock_retained": False,
            "persistent_write_performed": False,
        }
        result["checkpoint_ref"] = (
            f"checkpoint:sha256:{_canonical_digest(result)}"
        )
        return result

    def _invalid(self, operation: str) -> dict[str, Any]:
        return self._result(
            operation,
            None,
            result_code="INVALID_CONTROL_REQUEST",
            decision_action="REQUIRE_MANUAL_REVIEW",
            error_code="INVALID_CONTROL_REQUEST",
        )

    def _request_failure(self, operation: str, request: Any) -> Optional[dict[str, Any]]:
        if not self._request_shape_valid(request):
            return self._invalid(operation)
        if request.get("idempotency_key") != self._expected_idempotency_key(request):
            return self._result(
                operation,
                None,
                result_code="IDEMPOTENCY_KEY_INPUT_CONFLICT",
                decision_action="REJECT_CONFLICT",
                error_code="IDEMPOTENCY_KEY_INPUT_CONFLICT",
            )
        return None

    def _evidence_valid(
        self, evidence: Any, lock_keys: list[str]
    ) -> bool:
        if not isinstance(evidence, Mapping):
            return False
        if evidence.get("lock_keys") != lock_keys:
            return False
        token = evidence.get("fencing_token")
        versions = evidence.get("lock_versions")
        return (
            _is_json_integer(token, minimum=1)
            and isinstance(versions, dict)
            and set(versions) == set(lock_keys)
            and all(
                _is_json_integer(versions.get(key), minimum=1) for key in lock_keys
            )
        )

    def _time_is_monotonic(
        self, request: Mapping[str, Any], lock_keys: list[str]
    ) -> bool:
        now = request["requested_at_epoch_seconds"]
        for key in lock_keys:
            record = self._locks.get(key)
            if not isinstance(record, Mapping):
                return False
            last = record.get("renewed_at")
            if last is None:
                last = record.get("acquired_at")
            if not _is_json_integer(last) or now < last:
                return False
        return True

    def _lock_set_consistent(
        self, lock_keys: list[str], records: list[Any]
    ) -> bool:
        if not records or any(
            not _keys_exact(record, RECORD_FIELDS) for record in records
        ):
            return False
        first = records[0]
        shared_fields = (
            "source_identity_ref",
            "holder_job_id",
            "holder_attempt_id",
            "lease_owner_ref",
            "lease_expires_at",
            "fencing_token",
            "policy_version",
        )
        return all(
            record["lock_key"] == key
            and _is_json_integer(record["fencing_token"], minimum=1)
            and _is_json_integer(record["lock_version"], minimum=1)
            and _is_json_integer(record["lease_expires_at"])
            and all(record[field] == first[field] for field in shared_fields)
            for key, record in zip(lock_keys, records)
        )

    def _current_matches(
        self,
        request: Mapping[str, Any],
        evidence: Mapping[str, Any],
        lock_keys: list[str],
    ) -> bool:
        if not self._evidence_valid(evidence, lock_keys):
            return False
        expected_versions = evidence["lock_versions"]
        for key in lock_keys:
            record = self._locks.get(key)
            if not record or not _keys_exact(record, RECORD_FIELDS):
                return False
            if (
                record["holder_job_id"] != request["holder_job_id"]
                or record["holder_attempt_id"] != request["holder_attempt_id"]
                or record["lease_owner_ref"] != request["lease_owner_ref"]
                or record["fencing_token"] != evidence.get("fencing_token")
                or record["lock_version"] != expected_versions.get(key)
            ):
                return False
        return True

    def acquire(self, request: Mapping[str, Any]) -> dict[str, Any]:
        operation = "ACQUIRE"
        request_failure = self._request_failure(operation, request)
        if request_failure is not None:
            return request_failure
        ledger_key = self._ledger_key(operation, request)
        if ledger_key in self._operation_ledger:
            return copy.deepcopy(self._operation_ledger[ledger_key])
        lock_keys = self._lock_keys(request)
        occupied = [key for key in lock_keys if key in self._locks]
        if occupied:
            result = self._result(
                operation,
                request,
                result_code="RESOURCE_CONFLICT_ACTIVE",
                decision_action="PAUSE_BEFORE_QUEUE_ADMISSION",
                lock_keys=lock_keys,
                error_code="RESOURCE_CONFLICT_ACTIVE",
            )
            self._operation_ledger[ledger_key] = copy.deepcopy(result)
            return result
        self._fencing_counter += 1
        now = request["requested_at_epoch_seconds"]
        lease_expires_at = now + self.parameters["lease_duration_seconds"]
        versions = {
            key: self._lock_versions.get(key, 0) + 1 for key in lock_keys
        }
        result = self._result(
            operation,
            request,
            result_code="LOCK_SET_ACQUIRED",
            decision_action="ACQUIRED",
            lock_keys=lock_keys,
            fencing_token=self._fencing_counter,
            lock_versions=versions,
            lease_expires_at=lease_expires_at,
        )
        for key in lock_keys:
            namespace = key.split(":", 1)[0]
            self._lock_versions[key] = versions[key]
            self._locks[key] = {
                "lock_key": key,
                "lock_namespace": namespace,
                "source_identity_ref": request["source_identity_ref"],
                "operation_identity_ref": request["operation_identity_ref"],
                "operation_scope": request["operation_family"],
                "holder_job_id": request["holder_job_id"],
                "holder_attempt_id": request["holder_attempt_id"],
                "lease_owner_ref": request["lease_owner_ref"],
                "lease_expires_at": lease_expires_at,
                "fencing_token": self._fencing_counter,
                "lock_version": versions[key],
                "acquired_at": now,
                "renewed_at": None,
                "released_at": None,
                "release_reason": None,
                "audit_ref": AUDIT_REF,
                "checkpoint_ref": result["checkpoint_ref"],
                "policy_version": POLICY_VERSION,
            }
        self._operation_ledger[ledger_key] = copy.deepcopy(result)
        return result

    def renew(
        self,
        request: Mapping[str, Any],
        evidence: Mapping[str, Any],
    ) -> dict[str, Any]:
        operation = "RENEW"
        request_failure = self._request_failure(operation, request)
        if request_failure is not None:
            return request_failure
        ledger_key = self._ledger_key(operation, request, evidence)
        if ledger_key in self._operation_ledger:
            return copy.deepcopy(self._operation_ledger[ledger_key])
        lock_keys = self._lock_keys(request)
        if not self._evidence_valid(evidence, lock_keys):
            result = self._result(
                operation,
                request,
                result_code="INVALID_FENCING_EVIDENCE",
                decision_action="REQUIRE_MANUAL_REVIEW",
                lock_keys=lock_keys,
                error_code="INVALID_FENCING_EVIDENCE",
            )
        elif not self._current_matches(request, evidence, lock_keys):
            result = self._result(
                operation,
                request,
                result_code="STALE_FENCING_TOKEN",
                decision_action="REQUIRE_MANUAL_REVIEW",
                lock_keys=lock_keys,
                error_code="STALE_FENCING_TOKEN",
            )
        elif not self._time_is_monotonic(request, lock_keys):
            result = self._result(
                operation,
                request,
                result_code="NON_MONOTONIC_LOGICAL_TIME",
                decision_action="REQUIRE_MANUAL_REVIEW",
                lock_keys=lock_keys,
                error_code="NON_MONOTONIC_LOGICAL_TIME",
            )
        else:
            now = request["requested_at_epoch_seconds"]
            current_expiry = min(self._locks[key]["lease_expires_at"] for key in lock_keys)
            if now >= current_expiry:
                result = self._result(
                    operation,
                    request,
                    result_code="LEASE_EXPIRED",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    lock_keys=lock_keys,
                    error_code="LEASE_EXPIRED",
                )
            else:
                expiry = now + self.parameters["lease_duration_seconds"]
                versions = {
                    key: self._locks[key]["lock_version"] for key in lock_keys
                }
                fence = self._locks[lock_keys[0]]["fencing_token"]
                result = self._result(
                    operation,
                    request,
                    result_code="LEASE_RENEWED",
                    decision_action="RENEWED",
                    lock_keys=lock_keys,
                    fencing_token=fence,
                    lock_versions=versions,
                    lease_expires_at=expiry,
                )
                for key in lock_keys:
                    self._locks[key]["lease_expires_at"] = expiry
                    self._locks[key]["renewed_at"] = now
                    self._locks[key]["checkpoint_ref"] = result["checkpoint_ref"]
        self._operation_ledger[ledger_key] = copy.deepcopy(result)
        return result

    def takeover(self, request: Mapping[str, Any]) -> dict[str, Any]:
        operation = "TAKEOVER"
        request_failure = self._request_failure(operation, request)
        if request_failure is not None:
            return request_failure
        ledger_key = self._ledger_key(operation, request)
        if ledger_key in self._operation_ledger:
            return copy.deepcopy(self._operation_ledger[ledger_key])
        lock_keys = self._lock_keys(request)
        records = [self._locks.get(key) for key in lock_keys]
        if any(record is None for record in records):
            result = self._result(
                operation,
                request,
                result_code="NO_LOCK_SET_TO_TAKEOVER",
                decision_action="REQUIRE_MANUAL_REVIEW",
                lock_keys=lock_keys,
                error_code="NO_LOCK_SET_TO_TAKEOVER",
            )
        elif not self._lock_set_consistent(lock_keys, records):
            result = self._result(
                operation,
                request,
                result_code="INVALID_LOCK_SET_EVIDENCE",
                decision_action="REQUIRE_MANUAL_REVIEW",
                lock_keys=lock_keys,
                error_code="INVALID_LOCK_SET_EVIDENCE",
            )
        else:
            now = request["requested_at_epoch_seconds"]
            takeover_at = max(record["lease_expires_at"] for record in records)
            takeover_at += self.parameters["expiry_grace_seconds"]
            if now < takeover_at:
                result = self._result(
                    operation,
                    request,
                    result_code="LEASE_NOT_TAKEOVER_ELIGIBLE",
                    decision_action="REQUIRE_MANUAL_REVIEW",
                    lock_keys=lock_keys,
                    error_code="LEASE_NOT_TAKEOVER_ELIGIBLE",
                )
            else:
                self._fencing_counter += 1
                expiry = now + self.parameters["lease_duration_seconds"]
                versions = {
                    key: self._lock_versions.get(key, 0) + 1 for key in lock_keys
                }
                result = self._result(
                    operation,
                    request,
                    result_code="TAKEOVER_ACQUIRED",
                    decision_action="ACQUIRED",
                    lock_keys=lock_keys,
                    fencing_token=self._fencing_counter,
                    lock_versions=versions,
                    lease_expires_at=expiry,
                )
                for key in lock_keys:
                    namespace = key.split(":", 1)[0]
                    self._lock_versions[key] = versions[key]
                    self._locks[key] = {
                        "lock_key": key,
                        "lock_namespace": namespace,
                        "source_identity_ref": request["source_identity_ref"],
                        "operation_identity_ref": request["operation_identity_ref"],
                        "operation_scope": request["operation_family"],
                        "holder_job_id": request["holder_job_id"],
                        "holder_attempt_id": request["holder_attempt_id"],
                        "lease_owner_ref": request["lease_owner_ref"],
                        "lease_expires_at": expiry,
                        "fencing_token": self._fencing_counter,
                        "lock_version": versions[key],
                        "acquired_at": now,
                        "renewed_at": None,
                        "released_at": None,
                        "release_reason": None,
                        "audit_ref": AUDIT_REF,
                        "checkpoint_ref": result["checkpoint_ref"],
                        "policy_version": POLICY_VERSION,
                    }
        self._operation_ledger[ledger_key] = copy.deepcopy(result)
        return result

    def can_commit(
        self,
        request: Mapping[str, Any],
        evidence: Mapping[str, Any],
    ) -> dict[str, Any]:
        operation = "CAN_COMMIT"
        request_failure = self._request_failure(operation, request)
        if request_failure is not None:
            return request_failure
        lock_keys = self._lock_keys(request)
        if not self._evidence_valid(evidence, lock_keys):
            return self._result(
                operation,
                request,
                result_code="INVALID_FENCING_EVIDENCE",
                decision_action="REJECT_COMMIT",
                lock_keys=lock_keys,
                error_code="INVALID_FENCING_EVIDENCE",
            )
        if not self._current_matches(request, evidence, lock_keys):
            return self._result(
                operation,
                request,
                result_code="STALE_FENCING_TOKEN",
                decision_action="REJECT_COMMIT",
                lock_keys=lock_keys,
                error_code="STALE_FENCING_TOKEN",
            )
        if not self._time_is_monotonic(request, lock_keys):
            return self._result(
                operation,
                request,
                result_code="NON_MONOTONIC_LOGICAL_TIME",
                decision_action="REJECT_COMMIT",
                lock_keys=lock_keys,
                error_code="NON_MONOTONIC_LOGICAL_TIME",
            )
        now = request["requested_at_epoch_seconds"]
        if any(now >= self._locks[key]["lease_expires_at"] for key in lock_keys):
            return self._result(
                operation,
                request,
                result_code="LEASE_EXPIRED",
                decision_action="REJECT_COMMIT",
                lock_keys=lock_keys,
                error_code="LEASE_EXPIRED",
            )
        return self._result(
            operation,
            request,
            result_code="CURRENT_FENCE_VALID",
            decision_action="COMMIT_ALLOWED",
            lock_keys=lock_keys,
            fencing_token=evidence.get("fencing_token"),
            lock_versions=evidence.get("lock_versions"),
            lease_expires_at=min(
                self._locks[key]["lease_expires_at"] for key in lock_keys
            ),
        )

    def release(
        self,
        request: Mapping[str, Any],
        evidence: Mapping[str, Any],
    ) -> dict[str, Any]:
        operation = "RELEASE"
        request_failure = self._request_failure(operation, request)
        if request_failure is not None:
            return request_failure
        ledger_key = self._ledger_key(operation, request, evidence)
        if ledger_key in self._operation_ledger:
            return copy.deepcopy(self._operation_ledger[ledger_key])
        lock_keys = self._lock_keys(request)
        if not self._evidence_valid(evidence, lock_keys):
            result = self._result(
                operation,
                request,
                result_code="INVALID_FENCING_EVIDENCE",
                decision_action="REJECT_STALE_RELEASE",
                lock_keys=lock_keys,
                error_code="INVALID_FENCING_EVIDENCE",
            )
        elif not self._current_matches(request, evidence, lock_keys):
            result = self._result(
                operation,
                request,
                result_code="STALE_FENCING_TOKEN",
                decision_action="REJECT_STALE_RELEASE",
                lock_keys=lock_keys,
                error_code="STALE_FENCING_TOKEN",
            )
        elif not self._time_is_monotonic(request, lock_keys):
            result = self._result(
                operation,
                request,
                result_code="NON_MONOTONIC_LOGICAL_TIME",
                decision_action="REJECT_STALE_RELEASE",
                lock_keys=lock_keys,
                error_code="NON_MONOTONIC_LOGICAL_TIME",
            )
        else:
            versions = {
                key: self._locks[key]["lock_version"] for key in lock_keys
            }
            fence = self._locks[lock_keys[0]]["fencing_token"]
            result = self._result(
                operation,
                request,
                result_code="LOCK_SET_RELEASED",
                decision_action="RELEASED",
                lock_keys=lock_keys,
                fencing_token=fence,
                lock_versions=versions,
                lease_expires_at=None,
            )
            for key in lock_keys:
                del self._locks[key]
        self._operation_ledger[ledger_key] = copy.deepcopy(result)
        return result


def build_stage041_phase2_report() -> dict[str, Any]:
    contract = load_contract()
    contract_checks = evaluate_contract(contract)

    registry = IsolatedLockRegistry(contract)
    primary = build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_CONTROL_REF,
        operation_family="FILE_PROCESSING",
        holder_role="primary",
        requested_at_epoch_seconds=1000,
    )
    acquired = registry.acquire(primary)
    acquire_snapshot = registry.snapshot()
    replay = registry.acquire(copy.deepcopy(primary))
    contender = build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_CONTROL_REF,
        operation_family="FILE_PROCESSING",
        holder_role="contender",
        requested_at_epoch_seconds=1001,
    )
    conflict = registry.acquire(contender)

    renew_registry = IsolatedLockRegistry(contract)
    renew_acquired = renew_registry.acquire(primary)
    renew_request = build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_CONTROL_REF,
        operation_family="FILE_PROCESSING",
        holder_role="primary",
        requested_at_epoch_seconds=1010,
    )
    renewed = renew_registry.renew(renew_request, renew_acquired)

    takeover_registry = IsolatedLockRegistry(contract)
    takeover_acquired = takeover_registry.acquire(primary)
    early_request = build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_CONTROL_REF,
        operation_family="FILE_PROCESSING",
        holder_role="successor",
        requested_at_epoch_seconds=1034,
    )
    early = takeover_registry.takeover(early_request)
    successor = build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_CONTROL_REF,
        operation_family="FILE_PROCESSING",
        holder_role="successor",
        requested_at_epoch_seconds=1035,
    )
    takeover = takeover_registry.takeover(successor)
    stale = takeover_registry.can_commit(
        build_control_request(
            CONTROL_REF,
            operation_identity_ref=OPERATION_CONTROL_REF,
            operation_family="FILE_PROCESSING",
            holder_role="primary",
            requested_at_epoch_seconds=1036,
        ),
        takeover_acquired,
    )
    current = takeover_registry.can_commit(
        build_control_request(
            CONTROL_REF,
            operation_identity_ref=OPERATION_CONTROL_REF,
            operation_family="FILE_PROCESSING",
            holder_role="successor",
            requested_at_epoch_seconds=1036,
        ),
        takeover,
    )

    release_registry = IsolatedLockRegistry(contract)
    release_acquired = release_registry.acquire(primary)
    release_request = build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_CONTROL_REF,
        operation_family="FILE_PROCESSING",
        holder_role="primary",
        requested_at_epoch_seconds=1011,
    )
    released = release_registry.release(release_request, release_acquired)
    release_replay = release_registry.release(release_request, release_acquired)

    identity_registry = IsolatedLockRegistry(contract)
    index_build = build_control_request(
        CONTROL_REF,
        operation_identity_ref=OPERATION_CONTROL_REF,
        operation_family="INDEX_BUILD",
        holder_role="index-build",
        requested_at_epoch_seconds=2000,
    )
    index_switch = build_control_request(
        CONTROL_REF,
        operation_identity_ref=CONTROL_REF,
        operation_family="INDEX_SWITCH",
        holder_role="index-switch",
        requested_at_epoch_seconds=2001,
    )
    identity_acquired = identity_registry.acquire(index_build)
    identity_conflict = identity_registry.acquire(index_switch)

    idempotency_registry = IsolatedLockRegistry(contract)
    idempotency_first = idempotency_registry.acquire(index_build)
    mismatched_idempotency = copy.deepcopy(index_switch)
    mismatched_idempotency["idempotency_key"] = index_build["idempotency_key"]
    idempotency_conflict = idempotency_registry.acquire(mismatched_idempotency)

    forged_evidence = copy.deepcopy(acquired)
    forged_evidence["fencing_token"] = True
    forged_evidence["lock_versions"] = {
        key: True for key in acquired["lock_versions"]
    }
    forged_commit = registry.can_commit(
        build_control_request(
            CONTROL_REF,
            operation_identity_ref=OPERATION_CONTROL_REF,
            operation_family="FILE_PROCESSING",
            holder_role="primary",
            requested_at_epoch_seconds=1001,
        ),
        forged_evidence,
    )

    backward_renew = renew_registry.renew(
        build_control_request(
            CONTROL_REF,
            operation_identity_ref=OPERATION_CONTROL_REF,
            operation_family="FILE_PROCESSING",
            holder_role="primary",
            requested_at_epoch_seconds=999,
        ),
        renew_acquired,
    )

    slice_checks = {
        "acquire_all_or_none": (
            acquired["result_code"] == "LOCK_SET_ACQUIRED"
            and len(acquired["lock_keys"]) == 2
            and len(acquire_snapshot["locks"]) == 2
        ),
        "acquire_idempotent": (
            replay == acquired and registry.snapshot()["fencing_counter"] == 1
        ),
        "contention_preserves_stage038": (
            conflict["result_code"] == "RESOURCE_CONFLICT_ACTIVE"
            and conflict["decision_action"] == "PAUSE_BEFORE_QUEUE_ADMISSION"
            and not conflict["queue_record_created"]
            and not conflict["retry_budget_consumed"]
            and not conflict["partial_lock_retained"]
        ),
        "renew_no_fence_or_version_advance": (
            renewed["result_code"] == "LEASE_RENEWED"
            and renewed["fencing_token"] == renew_acquired["fencing_token"]
            and renewed["lock_versions"] == renew_acquired["lock_versions"]
            and renewed["lease_expires_at"] == 1040
        ),
        "takeover_requires_expiry_plus_grace": (
            early["result_code"] == "LEASE_NOT_TAKEOVER_ELIGIBLE"
            and takeover["result_code"] == "TAKEOVER_ACQUIRED"
        ),
        "takeover_advances_fence_and_versions": (
            takeover["fencing_token"] == takeover_acquired["fencing_token"] + 1
            and all(
                takeover["lock_versions"][key]
                == takeover_acquired["lock_versions"][key] + 1
                for key in takeover["lock_keys"]
            )
        ),
        "stale_fence_rejected": (
            stale["result_code"] == "STALE_FENCING_TOKEN"
            and stale["decision_action"] == "REJECT_COMMIT"
            and current["decision_action"] == "COMMIT_ALLOWED"
        ),
        "release_whole_set_idempotent": (
            released["result_code"] == "LOCK_SET_RELEASED"
            and released == release_replay
            and release_registry.snapshot()["locks"] == {}
        ),
        "shared_source_guard_with_distinct_operation_identities": (
            identity_acquired["result_code"] == "LOCK_SET_ACQUIRED"
            and identity_conflict["result_code"] == "RESOURCE_CONFLICT_ACTIVE"
            and len(identity_registry.snapshot()["locks"]) == 2
        ),
        "idempotency_input_conflict_rejected": (
            idempotency_first["result_code"] == "LOCK_SET_ACQUIRED"
            and idempotency_conflict["result_code"]
            == "IDEMPOTENCY_KEY_INPUT_CONFLICT"
            and idempotency_conflict["decision_action"] == "REJECT_CONFLICT"
            and len(idempotency_registry.snapshot()["locks"]) == 2
        ),
        "fencing_evidence_requires_strict_json_integers": (
            forged_commit["result_code"] == "INVALID_FENCING_EVIDENCE"
            and forged_commit["decision_action"] == "REJECT_COMMIT"
        ),
        "logical_clock_must_not_move_backward": (
            backward_renew["result_code"] == "NON_MONOTONIC_LOGICAL_TIME"
            and min(
                record["lease_expires_at"]
                for record in renew_registry.snapshot()["locks"].values()
            )
            == 1040
        ),
        "no_forbidden_side_effects": all(
            contract["truth_flags"][name] is False for name in FALSE_TRUTH_FLAGS
        ),
    }
    report = {
        "stage": "STAGE-041",
        "phase": "Phase 2",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "policy_contract_id": POLICY_VERSION,
        "next_gate": "IDS-STAGE041-P3-GATE",
        "contract_checks": contract_checks,
        "slice_checks": slice_checks,
    }
    report.update(contract["truth_flags"])
    report["phase2_slice_valid"] = all(contract_checks.values()) and all(
        slice_checks.values()
    )
    return report


def main() -> int:
    report = build_stage041_phase2_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["phase2_slice_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
