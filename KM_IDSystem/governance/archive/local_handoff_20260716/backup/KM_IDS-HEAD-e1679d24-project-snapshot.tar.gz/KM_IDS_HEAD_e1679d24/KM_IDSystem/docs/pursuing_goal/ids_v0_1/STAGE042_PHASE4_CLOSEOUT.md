# IDS v0.1 STAGE-042 Phase 4 Closeout

## 1. 本轮结论

- Task：`IDS-V0_1-STAGE042-P4`
- Acceptance：`ACC-STAGE-042`
- 执行模式：`ISOLATED_NON_PRODUCTION_CLOSEOUT_EVIDENCE`
- 结果：`PASS_ISOLATED_CLOSEOUT_PRODUCTION_DISABLED`
- 当前状态：`PHASE4_CLOSEOUT_EVIDENCE_REVIEW_PENDING`
- 下一门禁：`IDS-STAGE042-REVIEW-GATE`
- 整阶段复审：未执行，必须在下一次独立 run 完成
- GitHub、批次复审、应用重装：均未执行，`push_allowed=false`

本 Phase 只聚合并重放已经存在的受控证据，不启动生产自动生命周期，不读取 IDS
业务资料，不创建真实或虚构 IDS job，不连接数据库，不写 runtime output，不终止进程，
不执行 cleanup/delete。

## 2. 批准来源与哈希链

- Source archive：`/Users/linzezhang/Downloads/IDS_Taskpack_v0_1_only_中文修订版.zip`
- Archive SHA-256：`55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3`
- Unique member：`IDS_v0_1_Final_Chinese_Revised/stages/STAGE-042_自动运行、暂停、恢复与关闭.md`
- Member SHA-256：`78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08`
- Phase 3 commit：`bba58cc9e4fb676929960be5ef23f70e89563986`
- Phase 3 subject：`feat(ids): validate stage042 lifecycle scenarios`

`stage042_automatic_lifecycle_delivery_contract.json` 绑定以下精确证据：

- STAGE-037 状态模型索引；
- STAGE-039 retry/dead-letter delivery 与 review；
- STAGE-040 backpressure delivery 与 review；
- STAGE-041 lock-registry delivery 与 review；
- STAGE-042 Phase 1-3 contract、checker、evidence 和 tests。

checker 会重新计算批准文件和所有绑定文件的 SHA-256，确认 Phase 3 commit 是当前
`HEAD` 的祖先，并要求所有 repo ref 已被 Git 跟踪。任一来源漂移均返回
`IDS-STAGE042-P4-GATE`，不会运行交付聚合。

## 3. Job 状态图

继承 `ids.job_state.v1`，没有新增状态：

- job type：`8`
- job state：`11`
- terminal state：`4`
- legal transition：`21`
- terminal history 自动重开：禁止

```mermaid
stateDiagram-v2
  CREATED --> QUEUED
  CREATED --> CANCELLED
  QUEUED --> CLAIMED
  QUEUED --> PAUSED
  QUEUED --> CANCELLED
  CLAIMED --> RUNNING
  CLAIMED --> PAUSE_REQUESTED
  CLAIMED --> RETRY_WAIT
  RUNNING --> SUCCEEDED
  RUNNING --> PAUSE_REQUESTED
  RUNNING --> RETRY_WAIT
  RUNNING --> FAILED
  PAUSE_REQUESTED --> PAUSED
  PAUSE_REQUESTED --> CANCELLED
  PAUSE_REQUESTED --> RETRY_WAIT
  PAUSED --> QUEUED
  PAUSED --> CANCELLED
  RETRY_WAIT --> QUEUED
  RETRY_WAIT --> PAUSED
  RETRY_WAIT --> DEAD_LETTERED
  RETRY_WAIT --> CANCELLED
```

自动启动、资源暂停、暂停完成、受控恢复和安全关闭只能复用上述合法边，并且每条边仍需
通过 STAGE-037 的 guard、CAS、reference 和 append-only audit 合同。

## 4. 失败与重试日志

重放 STAGE-039 经 STAGE-040 复核聚合的真实隔离控制元数据：

| 项目 | 结果 |
|---|---|
| attempt count | `3` |
| retry count | `2` |
| max retries | `2` |
| final state | `DEAD_LETTERED` |
| safe error | `TRANSIENT_OPERATION_TIMEOUT` |
| output refs | `[]` |
| persisted | `false` |

该日志证明受控 retry admission 和耗尽后进入 dead letter；不证明生产 retry scheduler、
生产恢复或持久重试状态。

## 5. 反压与锁证明

### 5.1 七类反压信号

| 信号 | 受控动作 | 关键边界 |
|---|---|---|
| `QUEUE_SOFT_PRESSURE` | `THROTTLE_ADMISSION` | 不写持久队列 |
| `QUEUE_HARD_CAPACITY` | `DENY_NEW_ADMISSION` | 不创建 job |
| `EXTERNAL_DRIVE_OFFLINE` | `PAUSE_RESOURCE_GATE` | 未物理拔盘 |
| `DISK_SPACE_INSUFFICIENT` | `PAUSE_RESOURCE_GATE` | 重放只读项目卷空间观测，未分配磁盘 |
| `EXTERNAL_API_BUDGET_INSUFFICIENT` | `PAUSE_RESOURCE_GATE` | 未调用外部 API |
| `JOB_TYPE_CONCURRENCY_LIMIT_REACHED` | `THROTTLE_ADMISSION` | 不消耗 retry budget |
| `SAME_SOURCE_CONFLICT` | `THROTTLE_ADMISSION` | 不执行生产锁 |

### 5.2 五类操作阻断

以下 operation family 各自只允许一个完整 canonical lock set：

- `FILE_PROCESSING`
- `ARCHIVE_EXTRACTION`
- `INDEX_BUILD`
- `INDEX_SWITCH`
- `REPORT_GENERATION`

重放结果为 `5` 次完整 acquire、`5` 次 duplicate conflict、`4` 次同源跨操作冲突，
partial lock 为 `0`。陈旧提交返回 `STALE_FENCING_TOKEN`；本轮未写持久锁。

## 6. Phase 3 场景聚合

十个场景全部通过：

1. 生命周期请求精确重放与输入冲突拒绝；
2. 实际隔离 worker exception 进入人工恢复；
3. 外接盘离线产生合法 pause candidate；
4. 实际项目卷只读空间观测和受控低磁盘边界；
5. API 预算不足产生合法 pause candidate；
6. 同源并发在 start admission 前被阻止；
7. 五类 operation duplicate barrier；
8. fresh owner 和稳定资源满足后产生 `PAUSED->QUEUED` 候选；
9. active writer 超时返回人工复核且不 force kill；
10. 五类 Git-tracked protected ref 全部拒绝清理。

实际隔离 `RuntimeError` 不是进程崩溃恢复；该能力仍归 STAGE-043。实际磁盘观测只读取
项目所在文件系统的 free-space 数值，不分配空间，不访问原始资料。

## 7. 清理白名单

唯一 cleanup candidate class：

- `TEMPORARY_PARTIAL_OUTPUT`
- `REBUILDABLE_CACHE`

受保护 class：

- `ORIGINAL_RAW_DATA`
- `FACT_SOURCE`
- `MANIFEST`
- `EVIDENCE_LEDGER`
- `REPORT_SNAPSHOT`
- `AUDIT_LOG`
- `ACTIVE_INDEX`
- `REQUIRED_CHECKPOINT`

任何未来候选还必须具备 approved root、root-relative path、immutable lstat identity、
symlink block、exclusive namespace lock、writer quiescence 和 no-follow traversal。
本轮只做 decision evidence，未暴露 delete 路径；执行所有权仍归 STAGE-044。

## 8. 自动候选与人工处理分类

### 8.1 仅形成隔离候选

| 候选 | 必须重新通过的门禁 | 当前结论 |
|---|---|---|
| 资源暂停任务继续 | fresh owner、稳定资源、无 active claim/lock、CAS、幂等 | 已观察 `RESUME_QUEUED_CANDIDATE`，未执行生产恢复 |
| 安全错误重试继续 | exact policy、安全错误 allowlist、budget、资源、CAS、幂等 | 已观察隔离 controlled retry admission，未执行生产恢复 |

生产自动恢复 eligible set 为 `[]`；观察到的生产自动恢复成功 set 为 `[]`。压力解除本身
不是恢复授权，任何缓存、过期或部分门禁都不能继续任务。

### 8.2 必须人工处理

- idempotency key 输入冲突；
- worker 或 process 丢失；
- owner evidence 过期；
- resource gate 不稳定；
- 同源竞争；
- active writer safe-close timeout；
- retry exhausted / dead-lettered；
- terminal job restart；
- invalid or missing contract；
- 未校准 lifecycle policy；
- persistent state reconstruction；
- protected cleanup request。

## 9. 安全关闭与恢复

受控成功场景重放 `QUEUED->PAUSED`，返回 `SAFE_CLOSE_COMPLETED`，controller candidate 为
`CLOSED`。活动写入超时场景返回 `SAFE_CLOSE_TIMEOUT_ACTIVE_WRITER`，保持人工复核；
`force_kill=false`、`process_termination=false`。

关闭顺序：

1. 停止新 admission；
2. 停止新 claim/lock；
3. 停止新 retry admission；
4. 对 active job 发出 pause intent；
5. 等待 checkpoint 或 quarantine；
6. 仅通过合法边转入 paused；
7. 使用 fencing 释放当前 lease/lock；
8. 保留 audit 和 state evidence；
9. 确认无 active writer；
10. 标记 controller closed。

新会话恢复前必须重新验证 source/policy hashes、owner/resource、retry policy/budget/error、
claim/lock/fencing、CAS 和幂等。未知证据保持人工复核；process crash recovery 转交
STAGE-043，cleanup execution 转交 STAGE-044。退出后没有持久 lifecycle state 可供自动重建。

## 10. 回滚

1. 任一 delivery contract 或 upstream binding 无效即停止；
2. 禁用 isolated lifecycle；
3. 拒绝新 automatic start/resume/close decision；
4. 只回滚 Phase 4 contract/checker/test/closeout/governance 变更；
5. 保留 Phase 1-3 和 STAGE-037..041 已复核证据；
6. 保留 raw data、manifest、evidence ledger、report snapshot 和 audit history。

禁止 destructive rollback。

## 11. 中文 Owner 反馈

Stage 42 四个 Phase 的本地交付证据已齐备，当前仅允许进入独立整阶段复审。资源暂停任务
与安全重试任务仅形成隔离候选；每次继续前仍须重新通过 owner、资源、策略、锁、fencing、
CAS 和幂等门禁，未观察到生产自动恢复成功。幂等输入冲突、worker 或进程丢失、owner
过期、资源不稳定、同源竞争、活动写入关闭超时、重试耗尽、终态重启、合同无效、策略未
校准、状态重建和受保护清理均需要人工处理。当前不是生产运行或生产就绪证明，不提供持久
自动生命周期、进程崩溃恢复或清理执行。

## 12. 当前验证证据

- TDD RED：`10/10` 预期失败，原因是 P4 checker 和 closeout 尚不存在。
- Contract checker：`14/14`
- Delivery checks：`8/8`
- Focused P4：`10/10`
- Stage042 aggregate：`55/55`
- Stage005 governance：`162/162`
- Stage040/041 review gates：`19/19`
- Stage040-042 aggregate：`173/173`
- 首次 full discovery：`854/858`；4 个失败均为 Stage038/039 历史有限路由白名单未接受
  精确 `IDS-STAGE042-P4 -> IDS-STAGE042-REVIEW-GATE` 状态。只扩展该精确兼容路径后，
  定向回归 `31/31` 通过。
- 首次精确暂存态 full discovery 因 roadmap 验证记录与 Stage005 精确预期块未同步而产生
  `25` 个级联失败；同步该结果块后，最终精确暂存态 full discovery `858/858` 通过。
- Events：`204` records、`0` duplicate IDs、唯一 P4 event `1` 条。
- 8 个暂存 Python 文件内存解析错误：`0`。
- Owner render drift/reference：`0/0`；changed-only governance：`0 errors / 0 warnings`。

## 13. 停止点

`ACC-STAGE-042` 仍为 `in_progress`。Phase 4 不得自行标记 whole-stage reviewed；下一次
独立 run 只能执行 `IDS-V0_1-STAGE042-REVIEW`，修复全部复审发现后，才可将 Stage042
标记为 `completed_reviewed_local`。
