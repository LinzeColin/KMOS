# STAGE-042 Phase 1 Entry Contract

## Identity

- Stage: `STAGE-042 · 自动运行、暂停、恢复与关闭`
- Task: `IDS-V0_1-STAGE042-P1`
- Acceptance: `ACC-STAGE-042`
- Local code: `D07-S006`
- Domain: `D07 · 任务编排与机器控制`
- Entrance: `IDS 系统运营入口`
- Contract: `ids.automatic_lifecycle.v0_1.stage042.p1`
- State: `PHASE1_ENGINEERING_CONTRACT_RUNTIME_DISABLED`
- Next gate: `IDS-STAGE042-P2-GATE`

## Goal

Define an executable and testable engineering contract for automatic start,
resource-triggered pause, guarded resume, retry resume, cooperative safe close,
and partial-output cleanup classification. Phase 1 composes the reviewed
STAGE-037 through STAGE-041 contracts; it does not run a queue, worker, lock,
retry scheduler, lifecycle controller, crash recovery, or cleanup process.

## Source Binding

The unique task-pack member
`IDS_v0_1_Final_Chinese_Revised/stages/STAGE-042_自动运行、暂停、恢复与关闭.md`
was read from the approved v0.1-only archive. Its member SHA256 is
`78a4bed1f5348837699bd7dd227898e6d47cc4099ca268ee1600bae84605ec08`.
The archive, Roadmap, instruction, and reviewed STAGE-037 through STAGE-041
delivery hashes are recorded in the machine contract. No IDS business source
or raw metadata content was read.

## Entry Preconditions

- STAGE-037 `ids.job_state.v1` remains authoritative; no job state or legal
  edge is added here.
- STAGE-038 remains the queue and worker transport owner.
- STAGE-039 remains the retry/dead-letter policy owner.
- STAGE-040 remains the pressure-signal and decision-policy owner.
- STAGE-041 remains the lock, lease, fencing, and race-control owner.
- The metadata root remains a path-only configuration value and is untouched.
- Owner-authored dirty files and root `.DS_Store` remain outside this task.

## Phase 1 Deliverables

1. This entry contract.
2. `STAGE042_PHASE1_AUTOMATIC_LIFECYCLE_SCOPE_BOUNDARY.md`.
3. `automatic_lifecycle/stage042_automatic_lifecycle_contract.json`.
4. `scripts/check_automatic_lifecycle.py`.
5. `tests/test_stage042_automatic_lifecycle.py`.
6. `BATCH041_050_UPLOAD_LOCK.yaml` and minimal governance routing.

## Stop Boundary

`Phase 2 must run separately`. It may implement only an isolated,
non-production lifecycle decision slice after sourcing every numeric parameter.
This run stops at:

- `NO_PHASE2`
- `NO_AUTOMATIC_START_RUNTIME`
- `NO_AUTOMATIC_PAUSE_RUNTIME`
- `NO_AUTOMATIC_RESUME_RUNTIME`
- `NO_SAFE_CLOSE_RUNTIME`
- `NO_QUEUE_RUNTIME`
- `NO_WORKER_RUNTIME`
- `NO_RETRY_SCHEDULER`
- `NO_LOCK_RUNTIME`
- `NO_CRASH_RECOVERY_RUNTIME`
- `NO_CLEANUP_RUNTIME`
- `NO_POSTGRES_CONNECTION`
- `NO_SCHEMA_CHANGE`
- `NO_RUNTIME_OUTPUT`
- `NO_RAW_METADATA_ACCESS`
- `NO_FAKE_IDS_BUSINESS_DATA`
- `NO_GITHUB_UPLOAD`
- `NO_APP_REINSTALL`

`push_allowed=false`. The next task is only `IDS-V0_1-STAGE042-P2` in a
separate run.

## Rollback

Revert only STAGE-042 Phase 1 artifacts and its governance transition. Do not
touch earlier Stages, the raw metadata root, databases, runtime outputs,
reports, owner-authored dirty files, GitHub state, or app entries.
