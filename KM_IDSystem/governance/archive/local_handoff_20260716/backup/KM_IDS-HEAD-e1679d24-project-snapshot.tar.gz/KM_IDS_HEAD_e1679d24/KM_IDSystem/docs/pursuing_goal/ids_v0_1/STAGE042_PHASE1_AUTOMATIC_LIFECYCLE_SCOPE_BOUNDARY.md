# STAGE-042 Phase 1 Automatic Lifecycle Scope Boundary

## Composed State Machine

STAGE-042 uses all eight job types, eleven states, four terminal states, and
twenty-one legal transitions from STAGE-037 `ids.job_state.v1`. It defines no
new job state. Lifecycle-controller states `OPEN`, `CLOSING`, and `CLOSED` are
controller metadata only and cannot be stored as job states. Every transition
uses compare-and-set over job, expected state, and expected state version and
appends audit evidence. Terminal job history is immutable and is never reopened
by automatic resume or safe close.

## Automatic Start

Automatic start follows only `CREATED -> QUEUED -> CLAIMED -> RUNNING`.
Admission requires identity/idempotency, admission gates, and no active claim
or lock. Claim then requires a lease and the complete STAGE-041 lock set.
Worker invocation is forbidden before the claim transition commits. Entering
`RUNNING` requires a live lease and current fencing token. A failure at any
edge stops the sequence without skipping or synthesizing a transition.

## Resource-triggered Pause

The three required pause signals are:

- `EXTERNAL_DRIVE_OFFLINE`
- `DISK_SPACE_INSUFFICIENT`
- `EXTERNAL_API_BUDGET_INSUFFICIENT`

Queued work uses `QUEUED -> PAUSED`. Claimed or running work first records a
pause intent and uses `CLAIMED/RUNNING -> PAUSE_REQUESTED`; it reaches `PAUSED`
only after checkpoint or quarantine evidence exists. Deactivation revokes the
lease and lock and advances the fencing token so the stale worker cannot
commit. A pause is cooperative and cannot force-kill the worker process.

## Guarded Automatic Resume

Pressure clearing creates only a fresh evaluation candidate. A paused job may
use `PAUSED -> QUEUED` only when current, reference-only owner authorization is
`ACTIVE`, all resource gates pass, no claim or lock is active, idempotency
matches, and compare-and-set succeeds. Cached, partial, missing, malformed, or
unknown evidence cannot resume work and returns `REQUIRE_MANUAL_REVIEW`.

`owner_revalidated` means deterministic validation of a versioned owner-policy
evidence reference; it does not permit bypassing authorization or inventing a
human confirmation. Terminal jobs cannot resume. An authorized rerun of a
terminal job must create a separately linked new job while preserving the
terminal source history.

## Retry And Dead Letter

STAGE-039 remains authoritative for retry budget, safe error allowlist, and
dead-letter disposition. `RETRY_WAIT -> QUEUED` requires next-eligible evidence,
all current resource gates, no active claim or lock, exact policy version,
allowlisted error, remaining budget, compare-and-set, and idempotency. STAGE-042
does not broaden retry eligibility or reopen dead-letter history.

## Lock And Worker Boundary

STAGE-038 owns queue and worker transport. STAGE-041 owns lock granularity,
lease, fencing, takeover, and release. STAGE-042 requires their reviewed
decisions and the mandatory `SOURCE_PIPELINE` guard but does not redefine or
persist either subsystem. Worker-process crash reconstruction belongs to
STAGE-043.

## Safe Close

Safe close is cooperative and fail-closed. It stops new admission, claim/lock,
and retry-admission decisions; requests a legal pause for active work; waits
for checkpoint or quarantine evidence; releases only current leases and locks
with fencing; preserves state and audit evidence; verifies writer quiescence;
and then marks the controller closed. It does not force a terminal transition,
kill a process, reopen history, or claim persistent crash recovery.

## Partial-output Cleanup

Phase 1 can classify only `TEMPORARY_PARTIAL_OUTPUT` and `REBUILDABLE_CACHE` as
cleanup candidates in a reference-only manifest after checkpoint and writer
quiescence evidence. It cannot delete anything. `ORIGINAL_RAW_DATA`,
`FACT_SOURCE`, `MANIFEST`, `EVIDENCE_LEDGER`, `REPORT_SNAPSHOT`, `AUDIT_LOG`,
`ACTIVE_INDEX`, and `REQUIRED_CHECKPOINT` are protected. Cleanup execution is
owned by STAGE-044.

## Idempotency And Deferred Parameters

The lifecycle request key is SHA-256 over job ID, expected state/version,
action, policy version, and canonical intent reference. An exact replay returns
the existing decision. Reusing the key with different intent is rejected before
state, worker, lock, retry, or output changes.

Phase 1 assigns no numeric lifecycle values. Evaluation interval, pause
acknowledgement timeout, safe-close timeout, owner-revalidation TTL, and
resource-gate stability window require source, rationale, unit, policy version,
validation evidence, and rollback in Phase 2. There is no implicit default.

## Phase 2 Gate

`Phase 2 must run separately`. The next run may implement one isolated
non-production lifecycle decision slice, restrained Chinese status projection,
and reference-only input/output/error/checkpoint recording. Persistence,
production activation, process-crash recovery, and cleanup execution remain
disabled.

Stop markers:

- `NO_PHASE2`
- `NO_AUTOMATIC_START_RUNTIME`
- `NO_AUTOMATIC_PAUSE_RUNTIME`
- `NO_AUTOMATIC_RESUME_RUNTIME`
- `NO_SAFE_CLOSE_RUNTIME`
- `NO_CRASH_RECOVERY_RUNTIME`
- `NO_CLEANUP_RUNTIME`
- `NO_RAW_METADATA_ACCESS`
- `NO_FAKE_IDS_BUSINESS_DATA`
- `NO_GITHUB_UPLOAD`
- `NO_APP_REINSTALL`

The next gate is `IDS-STAGE042-P2-GATE`; `push_allowed=false`.
