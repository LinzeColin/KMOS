#!/usr/bin/env python3
"""Build the fail-closed STAGE-041 whole-stage review report."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from typing import Any, Mapping, Optional
import zipfile


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent
PURSUE_ROOT = PROJECT_ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
LOCK_ROOT = PURSUE_ROOT / "lock_registry"

ARCHIVE_PATH = Path(
    "/Users/linzezhang/Downloads/IDS_Taskpack_v0_1_only_中文修订版.zip"
)
ROADMAP_SOURCE_PATH = Path(
    "/Users/linzezhang/Downloads/IDS_Codex开发Roadmap_v0_1_only_中文修订版.txt"
)
INSTRUCTIONS_SOURCE_PATH = Path(
    "/Users/linzezhang/Downloads/IDS_Codex使用说明_v0_1_only_中文修订版.txt"
)
SOURCE_MEMBER = (
    "IDS_v0_1_Final_Chinese_Revised/stages/STAGE-041_锁注册与竞态控制.md"
)
EXPECTED_SOURCE_HASHES = {
    "archive_sha256_exact": (
        ARCHIVE_PATH,
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3",
    ),
    "roadmap_sha256_exact": (
        ROADMAP_SOURCE_PATH,
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6",
    ),
    "instructions_sha256_exact": (
        INSTRUCTIONS_SOURCE_PATH,
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8",
    ),
}
EXPECTED_MEMBER_SHA256 = (
    "2258a7b57c6c2881f208f43fbe2862c7815a2794c908d6fef108a1a4b5a2ad36"
)

PHASE_CHECKERS = {
    "phase1": PROJECT_ROOT / "scripts" / "check_lock_registry.py",
    "phase2": PROJECT_ROOT / "scripts" / "check_lock_registry_runtime.py",
    "phase3": PROJECT_ROOT / "scripts" / "check_lock_registry_scenarios.py",
    "phase4": PROJECT_ROOT / "scripts" / "check_lock_registry_delivery.py",
}
REVIEW_ARTIFACT_PATH = PURSUE_ROOT / "STAGE041_STAGE_REVIEW.md"
BATCH_PATH = PURSUE_ROOT / "BATCH041_050_UPLOAD_LOCK.yaml"
ROADMAP_PATH = PROJECT_ROOT / "docs" / "governance" / "roadmap.yaml"
EVENTS_PATH = PROJECT_ROOT / "docs" / "governance" / "events.jsonl"

TASK_ID = "IDS-V0_1-STAGE041-REVIEW"
ACCEPTANCE_ID = "ACC-STAGE-041"
REVIEW_GATE = "IDS-STAGE041-REVIEW-GATE"
NEXT_GATE = "IDS-STAGE042-P1-GATE"
PASS_RESULT = "PASS_REVIEWED_LOCAL_PRODUCTION_DISABLED"
REVIEW_EVENT_ID = "EVT-IDS-V0_1-STAGE041-REVIEW-20260715-001"

SOURCE_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md"
)
INDEX_VERSION_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
    "stage041_lock_registry_runtime_contract.json"
)
INDEX_NAMESPACE_REF = (
    "repo:KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
    "STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md"
)

REVIEW_SOURCE_PATHS = (
    PURSUE_ROOT / "STAGE041_ENTRY_CONTRACT.md",
    PURSUE_ROOT / "STAGE041_PHASE1_LOCK_REGISTRY_SCOPE_BOUNDARY.md",
    LOCK_ROOT / "stage041_lock_registry_contract.json",
    PHASE_CHECKERS["phase1"],
    PURSUE_ROOT / "tests" / "test_stage041_lock_registry.py",
    PURSUE_ROOT / "STAGE041_PHASE2_LOCK_REGISTRY_SLICE.md",
    LOCK_ROOT / "stage041_lock_registry_runtime_contract.json",
    PHASE_CHECKERS["phase2"],
    PURSUE_ROOT / "tests" / "test_stage041_lock_registry_runtime.py",
    PURSUE_ROOT / "STAGE041_PHASE3_SCENARIO_VALIDATION.md",
    LOCK_ROOT / "stage041_lock_registry_scenarios.json",
    PHASE_CHECKERS["phase3"],
    PURSUE_ROOT / "tests" / "test_stage041_lock_registry_scenarios.py",
    PURSUE_ROOT / "STAGE041_PHASE4_CLOSEOUT.md",
    LOCK_ROOT / "stage041_lock_registry_delivery_contract.json",
    PHASE_CHECKERS["phase4"],
    PURSUE_ROOT / "tests" / "test_stage041_lock_registry_delivery.py",
    REVIEW_ARTIFACT_PATH,
    Path(__file__).resolve(),
    PURSUE_ROOT / "tests" / "test_stage041_lock_registry_review.py",
    PURSUE_ROOT / "tests" / "test_stage039_retry_dead_letter_review.py",
    PURSUE_ROOT / "tests" / "test_stage040_backpressure_review.py",
    PURSUE_ROOT / "validate_stage005_governance_regression.py",
    PURSUE_ROOT / "tests" / "test_stage005_governance_regression.py",
    BATCH_PATH,
    ROADMAP_PATH,
    EVENTS_PATH,
    PROJECT_ROOT / "docs" / "HANDOFF.md",
    PROJECT_ROOT / "CHANGELOG.md",
    PROJECT_ROOT / "功能清单.md",
    PROJECT_ROOT / "开发记录.md",
    PROJECT_ROOT / "模型参数文件.md",
)


def _load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"unable to load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _source_integrity_checks() -> dict[str, bool]:
    checks: dict[str, bool] = {}
    for name, (path, expected) in EXPECTED_SOURCE_HASHES.items():
        try:
            checks[name] = path.is_file() and _sha256_file(path) == expected
        except OSError:
            checks[name] = False
    try:
        with zipfile.ZipFile(ARCHIVE_PATH) as archive:
            matches = [name for name in archive.namelist() if name == SOURCE_MEMBER]
            member = archive.read(SOURCE_MEMBER) if len(matches) == 1 else b""
    except (OSError, KeyError, zipfile.BadZipFile, RuntimeError):
        matches = []
        member = b""
    checks["source_member_unique"] = len(matches) == 1
    checks["source_member_sha256_exact"] = (
        bool(member) and hashlib.sha256(member).hexdigest() == EXPECTED_MEMBER_SHA256
    )
    return checks


def _phase_results() -> dict[str, bool]:
    try:
        phase1 = _load_module(PHASE_CHECKERS["phase1"], "stage041_review_phase1")
        phase2 = _load_module(PHASE_CHECKERS["phase2"], "stage041_review_phase2")
        phase3 = _load_module(PHASE_CHECKERS["phase3"], "stage041_review_phase3")
        phase4 = _load_module(PHASE_CHECKERS["phase4"], "stage041_review_phase4")
        p1_report = phase1.build_stage041_phase1_report()
        p2_report = phase2.build_stage041_phase2_report()
        p3_report = phase3.build_stage041_phase3_report()
        p4_report = phase4.build_stage041_phase4_delivery_report()
    except Exception:
        return {
            "phase1_contract_valid": False,
            "phase2_slice_valid": False,
            "phase3_scenarios_valid": False,
            "phase4_delivery_valid": False,
        }
    return {
        "phase1_contract_valid": p1_report.get("phase1_contract_valid") is True,
        "phase2_slice_valid": p2_report.get("phase2_slice_valid") is True,
        "phase3_scenarios_valid": p3_report.get("scenario_validation_valid") is True,
        "phase4_delivery_valid": p4_report.get("delivery_contract_valid") is True,
    }


def _request(
    runtime: Any,
    *,
    operation: str,
    operation_ref: str,
    role: str,
    now: int,
) -> dict[str, Any]:
    return runtime.build_control_request(
        SOURCE_REF,
        operation_identity_ref=operation_ref,
        operation_family=operation,
        holder_role=role,
        requested_at_epoch_seconds=now,
    )


def _canonical_finding_checks() -> dict[str, bool]:
    try:
        runtime = _load_module(
            PHASE_CHECKERS["phase2"], "stage041_review_runtime_findings"
        )
        contract = runtime.load_contract()

        identity_registry = runtime.IsolatedLockRegistry(contract)
        index_build = _request(
            runtime,
            operation="INDEX_BUILD",
            operation_ref=INDEX_VERSION_REF,
            role="index-build",
            now=1000,
        )
        index_switch = _request(
            runtime,
            operation="INDEX_SWITCH",
            operation_ref=INDEX_NAMESPACE_REF,
            role="index-switch",
            now=1001,
        )
        identity_first = identity_registry.acquire(index_build)
        identity_second = identity_registry.acquire(index_switch)

        idempotency_registry = runtime.IsolatedLockRegistry(contract)
        idempotency_first = idempotency_registry.acquire(index_build)
        changed = copy.deepcopy(index_switch)
        changed["idempotency_key"] = index_build["idempotency_key"]
        idempotency_conflict = idempotency_registry.acquire(changed)

        fencing_results = []
        for invalid_value in (True, 1.0):
            registry = runtime.IsolatedLockRegistry(contract)
            request = _request(
                runtime,
                operation="FILE_PROCESSING",
                operation_ref=INDEX_VERSION_REF,
                role="fence-holder",
                now=1000,
            )
            acquired = registry.acquire(request)
            forged = copy.deepcopy(acquired)
            forged["fencing_token"] = invalid_value
            forged["lock_versions"] = {
                key: invalid_value for key in acquired["lock_versions"]
            }
            fencing_results.append(
                registry.can_commit(
                    _request(
                        runtime,
                        operation="FILE_PROCESSING",
                        operation_ref=INDEX_VERSION_REF,
                        role="fence-holder",
                        now=1001,
                    ),
                    forged,
                )
            )

        clock_registry = runtime.IsolatedLockRegistry(contract)
        clock_request = _request(
            runtime,
            operation="FILE_PROCESSING",
            operation_ref=INDEX_VERSION_REF,
            role="clock-holder",
            now=1000,
        )
        clock_acquired = clock_registry.acquire(clock_request)
        backward = _request(
            runtime,
            operation="FILE_PROCESSING",
            operation_ref=INDEX_VERSION_REF,
            role="clock-holder",
            now=999,
        )
        backward_renew = clock_registry.renew(backward, clock_acquired)
        backward_commit = clock_registry.can_commit(backward, clock_acquired)

        release_registry = runtime.IsolatedLockRegistry(contract)
        primary = _request(
            runtime,
            operation="INDEX_BUILD",
            operation_ref=INDEX_VERSION_REF,
            role="release-primary",
            now=1000,
        )
        primary_evidence = release_registry.acquire(primary)
        successor = _request(
            runtime,
            operation="INDEX_BUILD",
            operation_ref=INDEX_VERSION_REF,
            role="release-successor",
            now=1035,
        )
        release_registry.takeover(successor)
        stale_release = release_registry.release(
            _request(
                runtime,
                operation="INDEX_BUILD",
                operation_ref=INDEX_VERSION_REF,
                role="release-primary",
                now=1036,
            ),
            primary_evidence,
        )
    except Exception:
        return {
            "dual_identity_shared_guard_repaired": False,
            "strict_fencing_evidence_repaired": False,
            "idempotency_input_conflict_repaired": False,
            "logical_clock_monotonicity_repaired": False,
            "stale_release_action_repaired": False,
        }

    return {
        "dual_identity_shared_guard_repaired": (
            identity_first.get("result_code") == "LOCK_SET_ACQUIRED"
            and identity_second.get("result_code") == "RESOURCE_CONFLICT_ACTIVE"
            and len(identity_registry.snapshot().get("locks", {})) == 2
            and index_build["source_identity_ref"] == index_switch["source_identity_ref"]
            and index_build["operation_identity_ref"]
            != index_switch["operation_identity_ref"]
        ),
        "strict_fencing_evidence_repaired": all(
            result.get("result_code") == "INVALID_FENCING_EVIDENCE"
            and result.get("decision_action") == "REJECT_COMMIT"
            for result in fencing_results
        ),
        "idempotency_input_conflict_repaired": (
            idempotency_first.get("result_code") == "LOCK_SET_ACQUIRED"
            and idempotency_conflict.get("result_code")
            == "IDEMPOTENCY_KEY_INPUT_CONFLICT"
            and idempotency_conflict.get("decision_action") == "REJECT_CONFLICT"
            and idempotency_conflict.get("input_refs") == []
            and len(idempotency_registry.snapshot().get("locks", {})) == 2
        ),
        "logical_clock_monotonicity_repaired": (
            backward_renew.get("result_code") == "NON_MONOTONIC_LOGICAL_TIME"
            and backward_commit.get("result_code") == "NON_MONOTONIC_LOGICAL_TIME"
            and min(
                item["lease_expires_at"]
                for item in clock_registry.snapshot()["locks"].values()
            )
            == 1030
        ),
        "stale_release_action_repaired": (
            stale_release.get("result_code") == "STALE_FENCING_TOKEN"
            and stale_release.get("decision_action") == "REJECT_STALE_RELEASE"
        ),
    }


def _governance_checks() -> dict[str, bool]:
    try:
        batch = BATCH_PATH.read_text(encoding="utf-8")
        roadmap = ROADMAP_PATH.read_text(encoding="utf-8")
        review = REVIEW_ARTIFACT_PATH.read_text(encoding="utf-8")
        events = [
            json.loads(line)
            for line in EVENTS_PATH.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
    except (OSError, json.JSONDecodeError):
        return {"governance_files_parse": False}
    matching = [event for event in events if event.get("event_id") == REVIEW_EVENT_ID]
    return {
        "governance_files_parse": True,
        "batch_reviewed_local_exact": all(
            term in batch
            for term in (
                'status: "stage041_completed_reviewed_local"',
                'review_status: "passed"',
                'current_task_id: "IDS-V0_1-STAGE041-REVIEW"',
                'next_allowed_task_id: "IDS-V0_1-STAGE042-P1"',
                'next_gate: "IDS-STAGE042-P1-GATE"',
                "push_allowed: false",
                "batch_review_performed: false",
            )
        ),
        "roadmap_reviewed_local_exact": all(
            term in roadmap
            for term in (
                'current_phase_id: "IDS-STAGE041-REVIEW"',
                'current_task_id: "IDS-V0_1-STAGE041-REVIEW"',
                'next_gate_id: "IDS-STAGE042-P1-GATE"',
                'status: "completed_reviewed_local"',
            )
        ),
        "review_event_exact": len(matching) == 1
        and matching[0].get("event_type") == "stage_review"
        and matching[0].get("task_id") == TASK_ID
        and matching[0].get("acceptance_ids") == [ACCEPTANCE_ID],
        "review_markers_exact": all(
            term in review
            for term in (
                "STAGE041-REVIEW-F1",
                "STAGE041-REVIEW-F2",
                "STAGE041-REVIEW-F3",
                "STAGE041-REVIEW-F4",
                "STAGE041-REVIEW-F5",
                "NO_STAGE042_THIS_RUN",
                "NO_BATCH_REVIEW_THIS_RUN",
                "NO_GITHUB_UPLOAD",
                "NO_APP_REINSTALL",
            )
        ),
    }


def _git_source_binding_checks() -> dict[str, bool]:
    tracked: list[bool] = []
    index_matches: list[bool] = []
    for path in REVIEW_SOURCE_PATHS:
        try:
            relative = path.resolve().relative_to(REPO_ROOT).as_posix()
        except ValueError:
            tracked.append(False)
            index_matches.append(False)
            continue
        tracked_result = subprocess.run(
            ["git", "ls-files", "--error-unmatch", "--", relative],
            cwd=REPO_ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        tracked.append(path.is_file() and tracked_result.returncode == 0)
        index_result = subprocess.run(
            ["git", "diff", "--quiet", "--", relative],
            cwd=REPO_ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        index_matches.append(tracked[-1] and index_result.returncode == 0)
    return {
        "all_review_sources_git_tracked": bool(tracked) and all(tracked),
        "all_review_sources_match_git_index": bool(index_matches)
        and all(index_matches),
    }


def build_stage041_review_report(
    *, finding_checks: Optional[Mapping[str, Any]] = None
) -> dict[str, Any]:
    source_checks = _source_integrity_checks()
    phase_results = _phase_results()
    canonical_findings = _canonical_finding_checks()
    effective_findings = (
        dict(finding_checks)
        if isinstance(finding_checks, Mapping)
        else canonical_findings
    )
    governance_checks = _governance_checks()
    source_binding_checks = _git_source_binding_checks()
    review_valid = all(
        bool(checks) and all(value is True for value in checks.values())
        for checks in (
            source_checks,
            phase_results,
            effective_findings,
            governance_checks,
            source_binding_checks,
        )
    )
    return {
        "schema_version": "ids.stage041.lock_registry.stage_review.v1",
        "stage": "STAGE-041",
        "task_id": TASK_ID,
        "acceptance_id": ACCEPTANCE_ID,
        "review_valid": review_valid,
        "result": PASS_RESULT if review_valid else "FAIL_CLOSED",
        "stage_review_status": (
            "completed_reviewed_local" if review_valid else "review_blocked"
        ),
        "next_gate": NEXT_GATE if review_valid else REVIEW_GATE,
        "source_integrity_valid": bool(source_checks)
        and all(source_checks.values()),
        "source_integrity_checks": source_checks,
        "phase_results": phase_results,
        "finding_count": 5,
        "finding_counts": {"Critical": 2, "Important": 2, "Minor": 1},
        "finding_checks": effective_findings,
        "governance_checks": governance_checks,
        "source_binding_checks": source_binding_checks,
        "production_runtime_activation_performed": False,
        "raw_metadata_content_accessed": False,
        "fake_ids_business_data_used": False,
        "stage042_started": False,
        "batch_review_performed": False,
        "github_upload_allowed": False,
        "app_reinstall_allowed": False,
    }


def main() -> int:
    report = build_stage041_review_report()
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["review_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
