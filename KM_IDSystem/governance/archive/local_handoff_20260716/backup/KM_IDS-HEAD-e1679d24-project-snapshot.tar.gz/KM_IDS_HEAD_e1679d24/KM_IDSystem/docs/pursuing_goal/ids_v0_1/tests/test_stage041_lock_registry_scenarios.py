from __future__ import annotations

import copy
import importlib.util
import json
import subprocess
import unittest
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[5]
PROJECT_ROOT = REPO_ROOT / "KM_IDSystem"
CHECKER_PATH = PROJECT_ROOT / "scripts" / "check_lock_registry_scenarios.py"
CONTRACT_PATH = (
    PROJECT_ROOT
    / "docs"
    / "pursuing_goal"
    / "ids_v0_1"
    / "lock_registry"
    / "stage041_lock_registry_scenarios.json"
)
EVIDENCE_PATH = (
    PROJECT_ROOT
    / "docs"
    / "pursuing_goal"
    / "ids_v0_1"
    / "STAGE041_PHASE3_SCENARIO_VALIDATION.md"
)
ROADMAP_PATH = PROJECT_ROOT / "docs" / "governance" / "roadmap.yaml"
BATCH_PATH = (
    PROJECT_ROOT
    / "docs"
    / "pursuing_goal"
    / "ids_v0_1"
    / "BATCH041_050_UPLOAD_LOCK.yaml"
)
EVENTS_PATH = PROJECT_ROOT / "docs" / "governance" / "events.jsonl"

P2_COMMIT = "7295065f344fcf286be419153788a774b271d42f"
EVENT_ID = "EVT-IDS-V0_1-STAGE041-P3-20260715-001"
SCENARIOS = [
    "duplicate_click_lock_replay",
    "worker_exception_orphaned_lease_boundary",
    "external_drive_offline_pause_before_lock",
    "actual_disk_observation_and_low_disk_pause_before_lock",
    "external_api_budget_pause_before_lock",
    "same_source_cross_operation_contention",
    "operation_family_duplicate_prevention",
    "renewal_takeover_and_stale_fencing",
    "protected_cleanup_denied",
]
OPERATION_FAMILIES = [
    "FILE_PROCESSING",
    "ARCHIVE_EXTRACTION",
    "INDEX_BUILD",
    "INDEX_SWITCH",
    "REPORT_GENERATION",
]


def _load_checker() -> Any:
    spec = importlib.util.spec_from_file_location(
        "stage041_lock_registry_scenarios", CHECKER_PATH
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("unable to load Stage041 Phase 3 checker")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Stage041LockRegistryScenarioTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.checker = _load_checker()
        cls.contract = cls.checker.load_scenario_contract()
        cls.report = cls.checker.build_stage041_phase3_report()

    def test_phase3_artifacts_and_identity_exist(self):
        self.assertTrue(CHECKER_PATH.is_file())
        self.assertTrue(CONTRACT_PATH.is_file())
        self.assertTrue(EVIDENCE_PATH.is_file())
        self.assertEqual("ids.stage041.lock_registry.phase3.v1", self.contract["schema_version"])
        self.assertEqual("STAGE-041", self.contract["stage"])
        self.assertEqual("Phase 3", self.contract["phase"])
        self.assertEqual("IDS-V0_1-STAGE041-P3", self.contract["task_id"])
        self.assertEqual("ACC-STAGE-041", self.contract["acceptance_id"])
        self.assertEqual(
            "ISOLATED_NON_PRODUCTION_LOCK_REGISTRY_SCENARIOS",
            self.contract["execution_mode"],
        )
        self.assertEqual(
            "PHASE3_SCENARIOS_ENABLED_PRODUCTION_DISABLED",
            self.contract["contract_state"],
        )
        self.assertEqual("IDS-STAGE041-P4-GATE", self.contract["next_gate"])

    def test_source_and_phase2_commit_bindings_are_exact(self):
        source = self.contract["source_binding"]
        self.assertEqual(1, source["source_member_match_count"])
        self.assertEqual(
            "2258a7b57c6c2881f208f43fbe2862c7815a2794c908d6fef108a1a4b5a2ad36",
            source["source_member_sha256"],
        )
        self.assertEqual("SOURCE_VERIFIED", source["source_verification_status"])
        binding = self.contract["phase2_commit_binding"]
        self.assertEqual(P2_COMMIT, binding["commit"])
        self.assertEqual("COMMITTED_LOCAL_PHASE2", binding["binding_mode"])
        ancestor = subprocess.run(
            ["git", "merge-base", "--is-ancestor", P2_COMMIT, "HEAD"],
            cwd=REPO_ROOT,
            check=False,
        )
        self.assertEqual(0, ancestor.returncode)

    def test_upstream_hashes_are_exact_and_git_tracked(self):
        checks = self.checker.validate_scenario_contract(self.contract)
        self.assertTrue(checks["phase2_commit_is_ancestor"])
        self.assertTrue(checks["upstream_bindings_exact"])
        self.assertTrue(checks["upstream_refs_git_tracked"])
        self.assertTrue(checks["upstream_hashes_current"])
        self.assertEqual(
            {
                "phase2_contract",
                "phase2_checker",
                "phase2_evidence",
                "phase2_tests",
                "stage040_scenario_contract",
                "stage040_scenario_checker",
            },
            set(self.contract["upstream_bindings"]),
        )

    def test_scenario_and_physical_action_contracts_are_exact(self):
        self.assertEqual(SCENARIOS, self.contract["scenario_catalog"])
        self.assertEqual(set(SCENARIOS), set(self.contract["scenario_expectations"]))
        boundary = self.contract["physical_action_boundary"]
        allowed_true = {
            "stage040_scenario_replay_allowed",
            "stage041_isolated_lock_scenarios_allowed",
            "actual_project_disk_observation_allowed",
        }
        self.assertEqual(allowed_true, {key for key, value in boundary.items() if value})
        self.assertTrue(all(value is False for key, value in boundary.items() if key not in allowed_true))

    def test_protected_refs_are_exact_git_tracked_and_delete_is_unavailable(self):
        protected = self.contract["protected_artifact_contract"]
        self.assertEqual(
            {"FACT_SOURCE", "MANIFEST", "EVIDENCE_LEDGER", "REPORT_SNAPSHOT", "AUDIT_LOG"},
            set(protected["protected_refs"]),
        )
        self.assertTrue(protected["all_refs_must_be_git_tracked"])
        self.assertFalse(protected["delete_attempt_allowed"])
        self.assertFalse(protected["delete_api_call_allowed"])
        self.assertFalse(protected["cleanup_runtime_allowed"])
        self.assertEqual("STAGE-044", protected["runtime_owner"])
        for ref in protected["protected_refs"].values():
            path = ref.removeprefix("repo:")
            result = subprocess.run(
                ["git", "ls-files", "--error-unmatch", "--", path],
                cwd=REPO_ROOT,
                check=False,
                capture_output=True,
            )
            self.assertEqual(0, result.returncode, path)

    def test_report_passes_all_contract_checks_and_nine_scenarios(self):
        self.assertTrue(self.report["contract_valid"])
        self.assertTrue(all(self.report["contract_checks"].values()))
        self.assertTrue(self.report["scenario_runtime_performed"])
        self.assertTrue(self.report["scenario_validation_valid"])
        self.assertEqual(9, self.report["scenario_count"])
        self.assertEqual(9, self.report["passed_scenario_count"])
        self.assertEqual(SCENARIOS, list(self.report["scenario_results"]))
        self.assertTrue(
            all(item["status"] == "PASS" for item in self.report["scenario_results"].values())
        )

    def test_duplicate_click_replays_one_lock_set_without_side_effects(self):
        result = self.report["scenario_results"]["duplicate_click_lock_replay"]
        self.assertEqual("LOCK_SET_ACQUIRED", result["first_result_code"])
        self.assertTrue(result["second_is_exact_replay"])
        self.assertEqual(1, result["fencing_counter"])
        self.assertEqual(2, result["lock_record_count"])
        self.assertEqual(1, result["operation_ledger_size"])
        self.assertFalse(result["queue_record_created"])
        self.assertFalse(result["retry_budget_consumed"])
        self.assertFalse(result["persistent_write_performed"])

    def test_worker_exception_leaves_bounded_lease_and_stale_holder_is_fenced(self):
        result = self.report["scenario_results"][
            "worker_exception_orphaned_lease_boundary"
        ]
        self.assertTrue(result["actual_isolated_worker_exception_performed"])
        self.assertEqual("error:RuntimeError", result["worker_error_ref"])
        self.assertEqual("RESOURCE_CONFLICT_ACTIVE", result["pre_expiry_result_code"])
        self.assertEqual("TAKEOVER_ACQUIRED", result["takeover_result_code"])
        self.assertEqual("STALE_FENCING_TOKEN", result["stale_commit_result_code"])
        self.assertGreater(result["successor_fencing_token"], result["orphaned_fencing_token"])
        self.assertFalse(result["process_termination_performed"])
        self.assertFalse(result["crash_recovery_runtime_performed"])
        self.assertEqual("STAGE-043", result["crash_recovery_owner"])

    def test_drive_disk_and_api_pauses_create_no_lock(self):
        results = self.report["scenario_results"]
        drive = results["external_drive_offline_pause_before_lock"]
        self.assertEqual("EXTERNAL_DRIVE_OFFLINE", drive["signal_code"])
        self.assertEqual("PAUSE_RESOURCE_GATE", drive["decision_action"])
        self.assertFalse(drive["lock_acquire_attempted"])
        self.assertEqual(0, drive["lock_record_count"])
        disk = results["actual_disk_observation_and_low_disk_pause_before_lock"]
        self.assertGreater(disk["actual_disk_free_bytes"], 0)
        self.assertTrue(disk["actual_disk_decision_matches_formula"])
        self.assertEqual("DISK_SPACE_INSUFFICIENT", disk["boundary_signal_code"])
        self.assertFalse(disk["lock_acquire_attempted"])
        self.assertEqual(0, disk["lock_record_count"])
        api = results["external_api_budget_pause_before_lock"]
        self.assertEqual("EXTERNAL_API_BUDGET_INSUFFICIENT", api["signal_code"])
        self.assertEqual("PAUSE_RESOURCE_GATE", api["decision_action"])
        self.assertFalse(api["lock_acquire_attempted"])
        self.assertEqual(0, api["lock_record_count"])

    def test_same_source_cross_operation_contention_keeps_one_complete_lock_set(self):
        result = self.report["scenario_results"]["same_source_cross_operation_contention"]
        self.assertEqual(OPERATION_FAMILIES, result["operation_families"])
        self.assertEqual("FILE_PROCESSING", result["acquired_operation_family"])
        self.assertEqual(4, result["resource_conflict_count"])
        self.assertEqual(0, result["partial_operation_lock_count"])
        self.assertEqual(2, result["retained_lock_record_count"])
        self.assertEqual(1, result["fencing_counter"])

    def test_every_operation_family_blocks_duplicate_work(self):
        result = self.report["scenario_results"]["operation_family_duplicate_prevention"]
        self.assertEqual(OPERATION_FAMILIES, result["operation_families"])
        self.assertEqual(5, result["acquired_count"])
        self.assertEqual(5, result["duplicate_conflict_count"])
        self.assertEqual(5, result["idempotent_replay_count"])
        self.assertEqual(0, result["partial_lock_count"])
        self.assertFalse(result["duplicate_processing_performed"])

    def test_renew_takeover_and_stale_fencing_are_atomic(self):
        result = self.report["scenario_results"]["renewal_takeover_and_stale_fencing"]
        self.assertEqual("LEASE_RENEWED", result["renew_result_code"])
        self.assertTrue(result["renew_preserved_fence_and_versions"])
        self.assertEqual("LEASE_NOT_TAKEOVER_ELIGIBLE", result["early_takeover_result_code"])
        self.assertEqual("TAKEOVER_ACQUIRED", result["eligible_takeover_result_code"])
        self.assertTrue(result["takeover_advanced_fence_and_versions_atomically"])
        self.assertEqual("STALE_FENCING_TOKEN", result["stale_commit_result_code"])
        self.assertEqual("CURRENT_FENCE_VALID", result["current_commit_result_code"])

    def test_protected_cleanup_is_decision_only_and_denies_all_categories(self):
        result = self.report["scenario_results"]["protected_cleanup_denied"]
        self.assertEqual(5, result["protected_ref_count"])
        self.assertEqual(5, result["git_tracked_ref_count"])
        self.assertEqual(5, result["denied_delete_count"])
        self.assertEqual(
            {"FACT_SOURCE", "MANIFEST", "EVIDENCE_LEDGER", "REPORT_SNAPSHOT", "AUDIT_LOG"},
            set(result["category_decisions"]),
        )
        self.assertTrue(
            all(value == "PROTECTED_ARTIFACT" for value in result["category_decisions"].values())
        )
        self.assertFalse(result["delete_function_exposed"])
        self.assertFalse(result["delete_attempt_performed"])

    def test_truth_flags_and_next_gate_stop_at_phase4(self):
        self.assertTrue(self.report["taskpack_source_read_performed"])
        self.assertTrue(self.report["stage040_scenario_replay_valid"])
        self.assertTrue(self.report["actual_isolated_worker_exception_performed"])
        self.assertTrue(self.report["actual_disk_observation_performed"])
        self.assertEqual("IDS-STAGE041-P4-GATE", self.report["next_gate"])
        for key in self.checker.FALSE_TRUTH_FLAGS:
            self.assertFalse(self.report[key], key)

    def test_checker_exposes_only_read_only_git_subprocesses_and_no_side_effect_api(self):
        source = CHECKER_PATH.read_text(encoding="utf-8")
        forbidden_tokens = [
            "unlink(",
            "write_text(",
            "write_bytes(",
            "rmtree(",
            "os.remove(",
            "time.sleep(",
            "socket.",
            "requests.",
            "urllib.",
            ".kill(",
            ".terminate(",
            "subprocess.Popen(",
            "subprocess.check_call(",
        ]
        for token in forbidden_tokens:
            with self.subTest(token=token):
                self.assertNotIn(token, source)
        self.assertEqual(2, source.count("subprocess.run("))
        self.assertIn('["git", "ls-files", "--error-unmatch"', source)
        self.assertIn('["git", "merge-base", "--is-ancestor"', source)

    def test_invalid_contract_variants_fail_closed_without_running_scenarios(self):
        non_object = self.checker.build_stage041_phase3_report([])
        self.assertFalse(non_object["contract_valid"])
        self.assertFalse(non_object["scenario_runtime_performed"])
        self.assertFalse(non_object["scenario_validation_valid"])
        self.assertEqual("BLOCKED_INVALID_SCENARIO_CONTRACT", non_object["contract_state"])
        mutators = [
            lambda value: value.update({"task_id": "IDS-V0_1-STAGE041-P4"}),
            lambda value: value["phase2_commit_binding"].update({"commit": "0" * 40}),
            lambda value: value["upstream_bindings"]["phase2_checker"].update(
                {"sha256": "0" * 64}
            ),
            lambda value: value["scenario_catalog"].append("UNAUTHORIZED"),
            lambda value: value["physical_action_boundary"].update(
                {"process_termination_allowed": True}
            ),
            lambda value: value["resource_gate_contract"].update(
                {"lock_acquire_on_pause_allowed": True}
            ),
            lambda value: value["protected_artifact_contract"].update(
                {"delete_attempt_allowed": True}
            ),
            lambda value: value["protected_artifact_contract"]["protected_refs"].update(
                {"FACT_SOURCE": "repo:KM_IDSystem/not-tracked.txt"}
            ),
            lambda value: value.update({"truth_flags": []}),
        ]
        for mutate in mutators:
            with self.subTest(mutate=mutate):
                invalid = copy.deepcopy(self.contract)
                mutate(invalid)
                report = self.checker.build_stage041_phase3_report(invalid)
                self.assertFalse(report["scenario_validation_valid"])
                self.assertFalse(report["scenario_runtime_performed"])
                self.assertEqual("BLOCKED_INVALID_SCENARIO_CONTRACT", report["contract_state"])
                self.assertEqual("IDS-STAGE041-P3-GATE", report["next_gate"])

    def test_governance_records_phase3_once_and_preserves_no_upload(self):
        roadmap = ROADMAP_PATH.read_text(encoding="utf-8")
        batch = BATCH_PATH.read_text(encoding="utf-8")
        events = [
            json.loads(line)
            for line in EVENTS_PATH.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        matches = [event for event in events if event.get("event_id") == EVENT_ID]
        self.assertEqual(1, len(matches))
        event = matches[0]
        self.assertEqual("IDS-V0_1-STAGE041-P3", event["task_id"])
        self.assertEqual(["ACC-STAGE-041"], event["acceptance_ids"])
        self.assertIn("push_allowed=false", event["notes"])
        self.assertIn('current_phase_id: "IDS-STAGE041-P3"', roadmap)
        self.assertIn('current_task_id: "IDS-V0_1-STAGE041-P3"', roadmap)
        self.assertIn('next_gate_id: "IDS-STAGE041-P4-GATE"', roadmap)
        self.assertIn('status: "stage041_phase3_completed"', batch)
        self.assertIn('next_allowed_task_id: "IDS-V0_1-STAGE041-P4"', batch)
        self.assertIn("github_upload_allowed: false", batch)


if __name__ == "__main__":
    unittest.main()
