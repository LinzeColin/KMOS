import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parents[4]
REPO_ROOT = ROOT.parent
BASE = ROOT / "docs" / "pursuing_goal" / "ids_v0_1"
CONTRACT = (
    BASE
    / "worker_crash_recovery"
    / "stage043_worker_crash_recovery_contract.json"
)
ENTRY = BASE / "STAGE043_ENTRY_CONTRACT.md"
BOUNDARY = BASE / "STAGE043_PHASE1_WORKER_CRASH_RECOVERY_SCOPE_BOUNDARY.md"
BATCH = BASE / "BATCH041_050_UPLOAD_LOCK.yaml"
ROADMAP = ROOT / "docs" / "governance" / "roadmap.yaml"
PROJECT = ROOT / "docs" / "governance" / "project.yaml"
EVENTS = ROOT / "docs" / "governance" / "events.jsonl"
CHECKER = ROOT / "scripts" / "check_worker_crash_recovery.py"

SOURCE_BINDING = {
    "source_archive_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Taskpack_v0_1_only_中文修订版.zip"
    ),
    "source_archive_sha256": (
        "55b782e338610aab6361b7945bb5e290ba60038a06cc765c7c2da801734db6d3"
    ),
    "source_member": (
        "IDS_v0_1_Final_Chinese_Revised/stages/"
        "STAGE-043_Worker崩溃恢复.md"
    ),
    "source_member_match_count": 1,
    "source_member_sha256": (
        "e1d5169cbc30515930a7224743b860d9b577ccfbf9e0f913ec254d2ea060317b"
    ),
    "roadmap_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Codex开发Roadmap_v0_1_only_中文修订版.txt"
    ),
    "roadmap_sha256": (
        "a193fd2c44c51d634bf7887a1a6baf7e5199d9a8535e4211e35e97588e2e21a6"
    ),
    "instructions_path": (
        "/Users/linzezhang/Downloads/"
        "IDS_Codex使用说明_v0_1_only_中文修订版.txt"
    ),
    "instructions_sha256": (
        "ce456e06136d5ecc56cd7c9dc926abb5894817dda87bf7667588bf85211794f8"
    ),
    "source_verification_status": "SOURCE_VERIFIED",
}

UPSTREAM_BINDINGS = {
    "stage037_state_index": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/"
        "job_state_model/stage037_job_state_model_index.json",
        "b70bf72ebe4212f45d380c13fbfe429791e1f4a5c73dccbba81211b7adc1c2d3",
    ),
    "stage038_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/worker_queue_baseline/"
        "stage038_worker_queue_delivery_contract.json",
        "a4067c25b46340c33bee5017c286d6867d2b72e8fa208430c005d6b1a342c7e4",
    ),
    "stage038_delivery_checker": (
        "KM_IDSystem/scripts/check_worker_queue_delivery.py",
        "305536595643979e34be5b3fdbc8e1c850f9869d4cd656331f4af0c7e2c12fd6",
    ),
    "stage038_review": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE038_STAGE_REVIEW.md",
        "5bb4cb3382f97ded9228d278c4cfb34fc5f0a65b8858263ed0c9bbd6c035eb04",
    ),
    "stage039_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/retry_dead_letter/"
        "stage039_retry_dead_letter_delivery_contract.json",
        "c4aad64a9283de683067aff07026d723c708285c57eef8a0eac4ee1b13f5cb96",
    ),
    "stage039_delivery_checker": (
        "KM_IDSystem/scripts/check_retry_dead_letter_delivery.py",
        "babff5f0be9e6be06508cbe4efbe355c354a65324d0895e7c9c5f3322621e4da",
    ),
    "stage039_review": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE039_STAGE_REVIEW.md",
        "32e621db9d7d4ad87ff4f6788e1de22d7ada9c0f57ce756a76a9608a864c4b9b",
    ),
    "stage040_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/backpressure_policy/"
        "stage040_backpressure_delivery_contract.json",
        "84f3d69f4bda15e0042631d9b049c8988c1375be632d96e366e57cf0b1ab0ac2",
    ),
    "stage040_delivery_checker": (
        "KM_IDSystem/scripts/check_backpressure_delivery.py",
        "8a16e7b079de9a05ed43029b6c6a858af8d293f49df9a2c4ceaff196cd35b4c9",
    ),
    "stage040_review": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE040_STAGE_REVIEW.md",
        "ea1a6dacacc862d66de60883dd10ee2dbf23d3adc72efbf9586ba2ccf6c223f0",
    ),
    "stage041_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/lock_registry/"
        "stage041_lock_registry_delivery_contract.json",
        "a4ae34a249bc7fc6a54434f611f83214f8dc5d8c526aea60e468963f91a9fd75",
    ),
    "stage041_delivery_checker": (
        "KM_IDSystem/scripts/check_lock_registry_delivery.py",
        "4d4f5186e0f704b62d0d30bffcd320bddd05ed8e0bf520d9c30944cf945e1168",
    ),
    "stage041_review": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE041_STAGE_REVIEW.md",
        "a829c4fb097d566a13f503bf39bf5a0276ee4bc859775c7cf1ef4e28aea72bee",
    ),
    "stage042_delivery_contract": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/automatic_lifecycle/"
        "stage042_automatic_lifecycle_delivery_contract.json",
        "3e6a4664cfa28fea368efa86669b61d7eb06cf893c4366a9edcc3132d19ec23a",
    ),
    "stage042_delivery_checker": (
        "KM_IDSystem/scripts/check_automatic_lifecycle_delivery.py",
        "1b9c40e39a0b3fdfd36eb8acdbec1616d50c500d247c8226379dda8da3841879",
    ),
    "stage042_review": (
        "KM_IDSystem/docs/pursuing_goal/ids_v0_1/STAGE042_STAGE_REVIEW.md",
        "0b52b1fd4d00ebe1f62a87d1b8c8c401e4d9ad3934e892ee6969b2dbc91efe85",
    ),
}

JOB_TYPES = ["IMPORT", "ARCHIVE", "PARSE", "OCR", "CHUNK", "EMBED", "INDEX", "REPORT"]
JOB_STATES = [
    "CREATED",
    "QUEUED",
    "CLAIMED",
    "RUNNING",
    "PAUSE_REQUESTED",
    "PAUSED",
    "RETRY_WAIT",
    "SUCCEEDED",
    "FAILED",
    "DEAD_LETTERED",
    "CANCELLED",
]
TERMINAL_STATES = ["SUCCEEDED", "FAILED", "DEAD_LETTERED", "CANCELLED"]
RESOURCE_SIGNALS = [
    "EXTERNAL_DRIVE_OFFLINE",
    "DISK_SPACE_INSUFFICIENT",
    "EXTERNAL_API_BUDGET_INSUFFICIENT",
]
PROTECTED_ARTIFACTS = [
    "ORIGINAL_RAW_DATA",
    "FACT_SOURCE",
    "MANIFEST",
    "EVIDENCE_LEDGER",
    "REPORT_SNAPSHOT",
    "AUDIT_LOG",
    "ACTIVE_INDEX",
    "REQUIRED_CHECKPOINT",
]


class Stage043WorkerCrashRecoveryPhase1Tests(unittest.TestCase):
    def _contract(self):
        self.assertTrue(CONTRACT.is_file(), f"missing contract: {CONTRACT}")
        return json.loads(CONTRACT.read_text(encoding="utf-8"))

    def _checker(self):
        self.assertTrue(CHECKER.is_file(), f"missing checker: {CHECKER}")
        spec = importlib.util.spec_from_file_location(
            "stage043_worker_crash_recovery_checker", CHECKER
        )
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module

    def test_phase1_artifacts_exist(self):
        for path in (CONTRACT, ENTRY, BOUNDARY, BATCH, CHECKER):
            with self.subTest(path=path):
                self.assertTrue(path.is_file(), f"missing Phase 1 artifact: {path}")

    def test_source_review_commit_and_upstream_bindings_are_exact(self):
        contract = self._contract()
        self.assertEqual(SOURCE_BINDING, contract["source_binding"])
        commit = contract["stage042_review_commit_binding"]
        self.assertEqual("38ca6b40383b55c8cd3116baae9dea089a9516ce", commit["commit"])
        self.assertEqual(
            "fix(ids): complete stage042 lifecycle review", commit["subject"]
        )
        self.assertTrue(commit["required_ancestor_of_head"])
        self.assertEqual(set(UPSTREAM_BINDINGS), set(contract["upstream_bindings"]))
        for key, (relative, expected_sha) in UPSTREAM_BINDINGS.items():
            with self.subTest(binding=key):
                binding = contract["upstream_bindings"][key]
                self.assertEqual({"ref": relative, "sha256": expected_sha}, binding)
                observed = hashlib.sha256((REPO_ROOT / relative).read_bytes()).hexdigest()
                self.assertEqual(expected_sha, observed)

    def test_state_model_is_inherited_without_reopening_terminal_history(self):
        state = self._contract()["state_model_inheritance"]
        self.assertEqual("ids.job_state.v1", state["state_model_version"])
        self.assertEqual(JOB_TYPES, state["job_types"])
        self.assertEqual(JOB_STATES, state["job_states"])
        self.assertEqual(TERMINAL_STATES, state["terminal_states"])
        self.assertEqual(21, state["inherited_transition_count"])
        self.assertFalse(state["new_job_state_defined"])
        self.assertFalse(state["terminal_history_reopen_allowed"])
        self.assertEqual(
            ["job_id", "expected_state", "expected_state_version"],
            state["compare_and_set_fields"],
        )

    def test_task_exception_is_not_misclassified_as_process_crash(self):
        boundary = self._contract()["crash_detection_boundary"]
        self.assertEqual(
            "TASK_EXCEPTION_NOT_PROCESS_CRASH",
            boundary["reviewed_runtime_error_classification"],
        )
        self.assertFalse(boundary["task_exception_alone_is_process_crash"])
        self.assertFalse(boundary["heartbeat_expiry_alone_authorizes_recovery"])
        self.assertEqual(
            [
                "WORKER_PROCESS_EXITED_UNCLEANLY",
                "WORKER_HEARTBEAT_EXPIRED",
                "CLAIM_LEASE_EXPIRED_WITHOUT_RELEASE",
            ],
            boundary["candidate_signals"],
        )
        self.assertEqual(
            "REQUIRE_CORROBORATED_PROCESS_LOSS_EVIDENCE",
            boundary["classification_rule"],
        )

    def test_durable_state_must_commit_before_worker_side_effects(self):
        durable = self._contract()["durable_recovery_preconditions"]
        self.assertEqual(
            [
                "JOB_STATE_AND_VERSION",
                "INPUT_REFS_AND_IDEMPOTENCY_KEY",
                "WORKER_AND_PROCESS_INSTANCE_REFS",
                "CLAIM_LEASE_LOCK_AND_FENCING",
                "ATTEMPT_RETRY_POLICY_AND_BUDGET",
                "CHECKPOINT_AND_PARTIAL_OUTPUT_MANIFEST",
                "APPEND_ONLY_AUDIT_REF",
            ],
            durable["required_durable_fields"],
        )
        self.assertEqual(
            [
                "COMMIT_JOB_AND_INPUT_IDENTITY",
                "COMMIT_CLAIM_LEASE_LOCK_AND_FENCING",
                "COMMIT_ATTEMPT_AND_RECOVERY_POLICY",
                "ACKNOWLEDGE_WORKER_INVOCATION",
                "COMMIT_CHECKPOINT_BEFORE_RESTARTABLE_SIDE_EFFECT",
            ],
            durable["required_commit_order"],
        )
        self.assertTrue(durable["process_independent_state_store_required"])
        self.assertTrue(durable["transaction_or_fsync_boundary_required"])
        self.assertFalse(durable["current_persistent_recovery_state_available"])
        self.assertFalse(durable["state_survival_verified"])

    def test_recovery_classification_uses_only_legal_edges_and_fails_closed(self):
        recovery = self._contract()["recovery_classification_contract"]
        self.assertEqual(
            {
                "CLAIMED": ["CLAIMED->RETRY_WAIT"],
                "RUNNING": ["RUNNING->RETRY_WAIT", "RUNNING->FAILED"],
                "PAUSE_REQUESTED": [
                    "PAUSE_REQUESTED->RETRY_WAIT",
                    "PAUSE_REQUESTED->PAUSED",
                ],
            },
            recovery["legal_crash_disposition_edges"],
        )
        self.assertEqual(
            [
                "SAFE_RETRY_WAIT_CANDIDATE",
                "SAFE_FAILED_CANDIDATE",
                "CHECKPOINT_REVIEW_CANDIDATE",
                "REQUIRE_MANUAL_REVIEW",
            ],
            recovery["decision_classes"],
        )
        self.assertEqual("REQUIRE_MANUAL_REVIEW", recovery["unknown_evidence_action"])
        self.assertFalse(recovery["direct_running_to_queued_allowed"])
        self.assertFalse(recovery["automatic_process_restart_allowed"])
        self.assertFalse(recovery["automatic_job_resume_performed"])

    def test_retry_backpressure_lock_and_resource_ownership_are_preserved(self):
        contract = self._contract()
        retry = contract["retry_dead_letter_boundary"]
        pressure = contract["backpressure_boundary"]
        lock = contract["claim_lock_fencing_boundary"]
        self.assertEqual("STAGE-039", retry["policy_owner"])
        self.assertFalse(retry["retry_budget_or_safe_error_redefined"])
        self.assertTrue(retry["remaining_budget_and_allowlisted_error_required"])
        self.assertEqual("STAGE-040", pressure["policy_owner"])
        self.assertEqual(RESOURCE_SIGNALS, pressure["resource_pause_signals"])
        self.assertEqual("PAUSE_OR_MANUAL_REVIEW", pressure["blocked_resource_action"])
        self.assertFalse(pressure["pressure_clear_alone_authorizes_recovery"])
        self.assertEqual("STAGE-041", lock["policy_owner"])
        self.assertTrue(lock["expired_claim_revalidation_required"])
        self.assertTrue(lock["fencing_must_advance_before_new_holder"])
        self.assertFalse(lock["stale_worker_commit_allowed"])
        self.assertFalse(lock["persistent_lock_runtime_performed"])

    def test_checkpoint_idempotency_and_partial_outputs_are_reference_only(self):
        contract = self._contract()
        checkpoint = contract["checkpoint_and_idempotency_contract"]
        partial = contract["partial_output_boundary"]
        self.assertEqual(
            [
                "job_id",
                "expected_state",
                "expected_state_version",
                "attempt_no",
                "worker_process_instance_ref",
                "checkpoint_ref",
                "recovery_policy_version",
            ],
            checkpoint["recovery_idempotency_components"],
        )
        self.assertEqual("SHA-256", checkpoint["hash_algorithm"])
        self.assertTrue(checkpoint["exact_replay_returns_existing_decision"])
        self.assertEqual(
            "REJECT_RECOVERY_IDEMPOTENCY_INPUT_CONFLICT",
            checkpoint["same_key_different_input_action"],
        )
        self.assertTrue(checkpoint["checkpoint_reference_only"])
        self.assertFalse(checkpoint["raw_payload_allowed"])
        self.assertEqual(
            ["TEMPORARY_PARTIAL_OUTPUT", "REBUILDABLE_CACHE"],
            partial["quarantine_candidate_classes"],
        )
        self.assertEqual(PROTECTED_ARTIFACTS, partial["protected_artifact_classes"])
        self.assertEqual("STAGE-044", partial["cleanup_execution_owner"])
        self.assertFalse(partial["delete_execution_allowed"])

    def test_parameters_status_and_phase2_gate_remain_explicit(self):
        contract = self._contract()
        parameters = contract["parameter_contract"]
        status = contract["human_status_projection"]
        gate = contract["phase2_entry_gate"]
        self.assertFalse(parameters["numeric_values_assigned"])
        self.assertFalse(parameters["implicit_default_allowed"])
        self.assertEqual(
            [
                "worker_heartbeat_interval",
                "worker_liveness_timeout",
                "crash_confirmation_window",
                "claim_recovery_grace_period",
                "checkpoint_freshness_ttl",
            ],
            parameters["deferred_parameters"],
        )
        self.assertEqual("检测到 Worker 异常", status["CRASH_EVIDENCE_DETECTED"])
        self.assertEqual("正在核对恢复条件", status["RECOVERY_EVALUATING"])
        self.assertEqual("等待人工处理", status["MANUAL_REVIEW_REQUIRED"])
        self.assertEqual("崩溃恢复运行时未启用", status["RUNTIME_DISABLED"])
        self.assertTrue(gate["entry_authorized"])
        self.assertTrue(gate["separate_run_required"])
        self.assertEqual("IDS-V0_1-STAGE043-P2", gate["required_task_id"])
        self.assertEqual("IDS-STAGE043-P2-GATE", gate["required_gate"])

    def test_checker_is_contract_only_and_tampering_fails_closed(self):
        checker = self._checker()
        report = checker.build_stage043_phase1_report()
        self.assertTrue(report["phase1_contract_valid"], report)
        self.assertTrue(all(report["contract_checks"].values()), report)
        self.assertEqual("IDS-STAGE043-P2-GATE", report["next_gate"])
        self.assertEqual(
            "PHASE1_ENGINEERING_CONTRACT_RUNTIME_DISABLED",
            report["contract_state"],
        )
        for key in (
            "actual_process_crash_induced",
            "process_termination_performed",
            "worker_restart_performed",
            "automatic_job_resume_performed",
            "persistent_recovery_state_written",
            "database_connection_performed",
            "schema_change_performed",
            "queue_runtime_performed",
            "worker_runtime_performed",
            "retry_scheduler_performed",
            "lock_runtime_performed",
            "cleanup_runtime_performed",
            "runtime_output_written",
            "ids_business_source_read_performed",
            "raw_metadata_content_accessed",
            "fake_ids_business_data_used",
            "github_upload_allowed",
            "app_reinstall_allowed",
        ):
            with self.subTest(flag=key):
                self.assertFalse(report[key])

        original = self._contract()
        mutations = []
        for mutate in (
            lambda item: item.update({"unknown_root_field": True}),
            lambda item: item["crash_detection_boundary"].update(
                {"task_exception_alone_is_process_crash": True}
            ),
            lambda item: item["durable_recovery_preconditions"].update(
                {"current_persistent_recovery_state_available": True}
            ),
            lambda item: item["recovery_classification_contract"].update(
                {"direct_running_to_queued_allowed": True}
            ),
            lambda item: item["partial_output_boundary"].update(
                {"delete_execution_allowed": True}
            ),
            lambda item: item["truth_flags"].update(
                {"actual_process_crash_induced": True}
            ),
        ):
            changed = copy.deepcopy(original)
            mutate(changed)
            mutations.append(changed)
        for changed in mutations:
            with self.subTest(mutation=changed):
                checks = checker.evaluate_contract(changed, verify_files=False)
                self.assertFalse(all(checks.values()), checks)

    def test_phase1_governance_routes_only_to_phase2(self):
        batch = BATCH.read_text(encoding="utf-8")
        roadmap = ROADMAP.read_text(encoding="utf-8")
        project = PROJECT.read_text(encoding="utf-8")
        self.assertIn('status: "stage043_phase1_completed"', batch)
        self.assertIn(
            'stage043_phase1_state:\n'
            '    status: "stage043_phase1_completed"\n'
            '    current_task_id: "IDS-V0_1-STAGE043-P1"\n'
            '    next_allowed_task_id: "IDS-V0_1-STAGE043-P2"',
            batch,
        )
        self.assertIn('next_gate: "IDS-STAGE043-P2-GATE"', batch)
        self.assertIn('push_allowed: false', batch)
        self.assertIn('current_stage_id: "IDS-STAGE043"', roadmap)
        self.assertIn('current_phase_id: "IDS-STAGE043-P1"', roadmap)
        self.assertIn('current_task_id: "IDS-V0_1-STAGE043-P1"', roadmap)
        self.assertIn('next_gate_id: "IDS-STAGE043-P2-GATE"', roadmap)
        self.assertIn('status: "in_progress"', roadmap)
        self.assertIn('EVID-IDS-STAGE043-P1', project)

        events = [
            json.loads(line)
            for line in EVENTS.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        matching = [
            item
            for item in events
            if item.get("event_id") == "EVT-IDS-V0_1-STAGE043-P1-20260715-001"
        ]
        self.assertEqual(1, len(matching), matching)
        event = matching[0]
        self.assertEqual("phase_completed", event["event_type"])
        self.assertEqual("IDS-V0_1-STAGE043-P1", event["task_id"])
        self.assertEqual(["ACC-STAGE-043"], event["acceptance_ids"])
        for term in (
            "source_member_sha256=e1d5169cbc30515930a7224743b860d9b577ccfbf9e0f913ec254d2ea060317b",
            "actual_process_crash_induced=false",
            "state_survival_verified=false",
            "persistent_recovery_state_written=false",
            "raw_metadata_content_accessed=false",
            "fake_ids_business_data_used=false",
            "push_allowed=false",
            "next_gate=IDS-STAGE043-P2-GATE",
        ):
            self.assertIn(term, event["notes"])

    def test_cli_emits_valid_json_without_side_effects(self):
        completed = subprocess.run(
            [sys.executable, "-B", str(CHECKER), "--json"],
            cwd=REPO_ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
        self.assertEqual("", completed.stderr)
        payload = json.loads(completed.stdout)
        self.assertTrue(payload["phase1_contract_valid"], payload)
        self.assertEqual("IDS-STAGE043-P2-GATE", payload["next_gate"])
        self.assertFalse(payload["execution_ready"])


if __name__ == "__main__":
    unittest.main()
