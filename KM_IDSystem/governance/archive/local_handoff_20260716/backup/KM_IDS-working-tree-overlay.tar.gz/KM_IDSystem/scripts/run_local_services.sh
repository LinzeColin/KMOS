#!/bin/bash
set -euo pipefail

CODEX_RUNTIME_DEPS="${CODEX_RUNTIME_DEPS:-$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies}"
export PATH="/Library/Frameworks/Python.framework/Versions/3.13/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"
if [ -d "$CODEX_RUNTIME_DEPS" ]; then
  export PATH="$CODEX_RUNTIME_DEPS/bin:$CODEX_RUNTIME_DEPS/node/bin:$CODEX_RUNTIME_DEPS/python/bin:${PATH:-}"
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_DIR="$ROOT_DIR/data"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/launcher.log"

log() {
  printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >>"$LOG_FILE"
}

find_cmd() {
  local name="$1"
  command -v "$name" 2>/dev/null || true
}

notify_failure() {
  local message="$1"
  log "ERROR: $message"
  /usr/bin/osascript -e "display notification \"$message\" with title \"IDS / Industrial Data System\"" >/dev/null 2>&1 || true
}

fail() {
  notify_failure "$1"
  exit 1
}

PYTHON_BIN="$(find_cmd python3)"
NODE_BIN="$(find_cmd node)"
NPM_BIN="$(find_cmd npm)"
PNPM_BIN="$(find_cmd pnpm)"
PKG_MANAGER_BIN="$NPM_BIN"
PKG_MANAGER_NAME="npm"
if [ -z "$PKG_MANAGER_BIN" ] && [ -n "$PNPM_BIN" ]; then
  PKG_MANAGER_BIN="$PNPM_BIN"
  PKG_MANAGER_NAME="pnpm"
fi
LSOF_BIN="$(find_cmd lsof)"
OPEN_BIN="$(find_cmd open)"
CURL_BIN="$(find_cmd curl)"

[ -n "$PYTHON_BIN" ] || fail "找不到 python3，请安装 Python 3"
[ -n "$NODE_BIN" ] || fail "找不到 node，请安装 Node.js"
[ -n "$PKG_MANAGER_BIN" ] || fail "找不到 npm/pnpm，请安装 Node.js/npm"
[ -n "$LSOF_BIN" ] || fail "找不到 lsof，无法检查端口"
[ -n "$CURL_BIN" ] || fail "找不到 curl，无法检查服务健康状态"

port_open() {
  local port="$1"
  "$LSOF_BIN" -nP -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1
}

http_get() {
  "$CURL_BIN" -fsS --max-time 2 "$1" 2>/dev/null || true
}

backend_healthy() {
  local port="$1"
  http_get "http://127.0.0.1:$port/api/health" | grep -q "ids-industrial-data-system"
}

frontend_healthy() {
  local port="$1"
  http_get "http://127.0.0.1:$port/" | grep -q "IDS / Industrial Data System"
}

frontend_dependencies_ready() {
  [ -d "$ROOT_DIR/frontend/node_modules" ] || return 1
  [ -x "$ROOT_DIR/frontend/node_modules/esbuild/bin/esbuild" ] || return 1
  "$ROOT_DIR/frontend/node_modules/esbuild/bin/esbuild" --version >/dev/null 2>&1
}

first_free_port() {
  local start="$1"
  local end="$2"
  local port
  for port in $(seq "$start" "$end"); do
    if ! port_open "$port"; then
      echo "$port"
      return 0
    fi
  done
  return 1
}

select_backend_port() {
  local saved_port=""
  if [ -f "$LOG_DIR/backend_port" ]; then
    saved_port="$(cat "$LOG_DIR/backend_port" 2>/dev/null || true)"
  fi
  if [ -n "$saved_port" ] && backend_healthy "$saved_port"; then
    echo "$saved_port"
    return 0
  fi
  local port
  for port in $(seq 8000 8020); do
    if backend_healthy "$port"; then
      echo "$port"
      return 0
    fi
  done
  first_free_port 8000 8020
}

select_frontend_port() {
  local backend_port="$1"
  local saved_port=""
  local saved_proxy=""
  if [ -f "$LOG_DIR/frontend_port" ]; then
    saved_port="$(cat "$LOG_DIR/frontend_port" 2>/dev/null || true)"
  fi
  if [ -f "$LOG_DIR/frontend_proxy_port" ]; then
    saved_proxy="$(cat "$LOG_DIR/frontend_proxy_port" 2>/dev/null || true)"
  fi
  if [ -n "$saved_port" ] && [ "$saved_proxy" = "$backend_port" ] && frontend_healthy "$saved_port"; then
    echo "$saved_port"
    return 0
  fi
  first_free_port 5173 5190
}

wait_for_backend() {
  local port="$1"
  local attempt
  for attempt in $(seq 1 30); do
    if backend_healthy "$port"; then
      return 0
    fi
    sleep 1
  done
  return 1
}

wait_for_frontend() {
  local port="$1"
  local attempt
  for attempt in $(seq 1 30); do
    if frontend_healthy "$port"; then
      return 0
    fi
    sleep 1
  done
  return 1
}

ensure_backend() {
  cd "$ROOT_DIR"
  log "Using python: $PYTHON_BIN"
  if [ ! -x ".venv/bin/python" ]; then
    log "Creating backend virtualenv at $ROOT_DIR/.venv"
    "$PYTHON_BIN" -m venv "$ROOT_DIR/.venv" >>"$LOG_FILE" 2>&1 || fail "后端虚拟环境创建失败，请查看 data/launcher.log"
  fi
  if [ ! -x ".venv/bin/uvicorn" ]; then
    [ -f "$ROOT_DIR/backend/requirements.txt" ] || fail "找不到 backend/requirements.txt，无法安装后端依赖"
    log "Installing backend dependencies from backend/requirements.txt"
    "$ROOT_DIR/.venv/bin/python" -m pip install --upgrade pip >>"$LOG_FILE" 2>&1 || fail "后端 pip 升级失败，请查看 data/launcher.log"
    "$ROOT_DIR/.venv/bin/python" -m pip install -r "$ROOT_DIR/backend/requirements.txt" >>"$LOG_FILE" 2>&1 || fail "后端依赖安装失败，请查看 data/launcher.log"
  fi

  BACKEND_PORT="$(select_backend_port || true)"
  [ -n "$BACKEND_PORT" ] || fail "8000-8020 均不可用，无法启动后端"
  if backend_healthy "$BACKEND_PORT"; then
    log "Backend already healthy on 127.0.0.1:$BACKEND_PORT"
  else
    log "Starting backend on 127.0.0.1:$BACKEND_PORT"
    (
      cd "$ROOT_DIR"
      nohup env PYTHONPATH="$ROOT_DIR/backend" "$ROOT_DIR/.venv/bin/uvicorn" app.main:app --host 127.0.0.1 --port "$BACKEND_PORT" >>"$LOG_FILE" 2>&1 </dev/null &
      echo $! >"$LOG_DIR/backend.pid"
    )
    wait_for_backend "$BACKEND_PORT" || fail "后端启动失败，请查看 data/launcher.log"
  fi
  echo "$BACKEND_PORT" >"$LOG_DIR/backend_port"
}

ensure_frontend() {
  cd "$ROOT_DIR/frontend"
  log "Using node: $NODE_BIN"
  log "Using package manager: $PKG_MANAGER_BIN"
  if ! frontend_dependencies_ready; then
    log "Installing frontend dependencies"
    if [ "$PKG_MANAGER_NAME" = "npm" ] && [ -f "package-lock.json" ]; then
      "$PKG_MANAGER_BIN" ci >>"$LOG_FILE" 2>&1 || fail "前端依赖安装失败，请查看 data/launcher.log"
    elif [ "$PKG_MANAGER_NAME" = "npm" ]; then
      "$PKG_MANAGER_BIN" install >>"$LOG_FILE" 2>&1 || fail "前端依赖安装失败，请查看 data/launcher.log"
    else
      "$PKG_MANAGER_BIN" install --no-lockfile >>"$LOG_FILE" 2>&1 || fail "前端依赖安装失败，请查看 data/launcher.log"
    fi
  fi
  FRONTEND_PORT="$(select_frontend_port "$BACKEND_PORT" || true)"
  [ -n "$FRONTEND_PORT" ] || fail "5173-5190 均不可用，无法启动前端"
  if frontend_healthy "$FRONTEND_PORT"; then
    log "Frontend already healthy on 127.0.0.1:$FRONTEND_PORT"
  else
    log "Starting frontend on 127.0.0.1:$FRONTEND_PORT with API proxy $BACKEND_PORT"
    (
      cd "$ROOT_DIR/frontend"
      nohup env VITE_API_PROXY="http://127.0.0.1:$BACKEND_PORT" "$PKG_MANAGER_BIN" run dev -- --host 127.0.0.1 --port "$FRONTEND_PORT" --strictPort >>"$LOG_FILE" 2>&1 </dev/null &
      echo $! >"$LOG_DIR/frontend.pid"
    )
    wait_for_frontend "$FRONTEND_PORT" || fail "前端启动失败，请查看 data/launcher.log"
  fi
  echo "$FRONTEND_PORT" >"$LOG_DIR/frontend_port"
  echo "$BACKEND_PORT" >"$LOG_DIR/frontend_proxy_port"
}

ensure_backend
ensure_frontend
sleep 3
if [ "${OPEN_BROWSER:-1}" != "0" ]; then
  [ -n "$OPEN_BIN" ] || fail "找不到 open 命令，无法打开浏览器"
  "$OPEN_BIN" "http://127.0.0.1:$FRONTEND_PORT/"
fi
log "Launch complete: frontend=http://127.0.0.1:$FRONTEND_PORT backend=http://127.0.0.1:$BACKEND_PORT"

if [ "${KEEP_TERMINAL_OPEN:-0}" = "1" ]; then
  echo "IDS / Industrial Data System is running."
  echo "Frontend: http://127.0.0.1:$FRONTEND_PORT/"
  echo "Backend:  http://127.0.0.1:$BACKEND_PORT/api/health"
  echo "Keep this Terminal window open while using the system. Press Ctrl-C to stop watching."
  while true; do
    sleep 30
    if ! backend_healthy "$BACKEND_PORT"; then
      echo "Backend health check failed. See $LOG_FILE"
    fi
    if ! frontend_healthy "$FRONTEND_PORT"; then
      echo "Frontend health check failed. See $LOG_FILE"
    fi
  done
fi
